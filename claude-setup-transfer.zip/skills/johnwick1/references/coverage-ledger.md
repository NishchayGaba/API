# The Coverage Ledger — how "skip nothing" is enforced

The ledger is the mechanism that makes total coverage real instead of aspirational. No asset, no feature,
and no step is ever "done" on a claim — only when a ledger query proves it. There are **two tiers**:
`coverage.jsonl` (one row per in-scope asset) and `features.jsonl` (one row per discovered feature/
endpoint/operation on that asset). Asset-level `covered` is *computed* from feature-level completeness,
never hand-set — an asset can look hunted after one feature and one probe; it isn't. Mirror both into the
task list so progress is gated and visible.

## Run folder
```
./johnwick-runs/<target>-<YYYY-MM-DD>/
  scope.txt        # in-scope + out-of-scope, verbatim from the user
  coverage.jsonl   # one row per asset — rolls up from features.jsonl
  features.jsonl   # one row per feature/endpoint/operation — the source of truth for "done"
  assets/  js/  api/  auth/  findings/  notes.md
```

## coverage.jsonl row schema (asset tier)
```json
{"asset":"api.target.com","type":"subdomain","in_scope":true,
 "recon":"untested","js_read":"untested","authed_mapped":"untested",
 "hunted":[],"status":"untested","evidence":""}
```
`recon`/`js_read`/`authed_mapped` progress `untested → done` as Phases 2/4 finish for that asset.
`hunted`/`status` are **rollups** written by the compute step below — never set by hand.

## features.jsonl row schema (feature tier — this is where "every bug" lives)
```json
{"asset":"api.target.com","feature":"GET /api/invoices/{id}/pdf","kind":"id-read",
 "dev_hypothesis":"invoice export shipped after the core CRUD, likely reused the wrong auth check",
 "applicable_classes":["idor","bypass-403"],
 "hunted":[
   {"class":"idor","status":"tested_positive",
    "evidence":"acct A baseline 200 on 1042; acct B session on 1042 returns 200 with acct A's PII (body diff: email/name/amount all A's) — see findings/api.target.com/idor-invoice.md",
    "escalation_attempted":true,
    "escalation_note":"Q1 sequential int id → enumerated 1000-1200, 187 foreign invoices readable, PII confirmed at scale. Q3 no matching write found (PUT/DELETE both 403 cross-tenant). Capped at mass PII read, no write escalation."}
 ],
 "status":"untested"}
```

**Field rules (this is what Rule 10 checks against):**
- `applicable_classes` is set at enrollment (Phase 2 for pre-auth features, Phase 4 for authed ones), from
  the surface the feature exposes (id param → `idor`; URL-accepting field → `ssrf`; upload → `rce`+`xxe`;
  template-rendered field → `ssti`; query/filter/sort → `sqli`; any 401/403 seen while mapping → `bypass-403`;
  auth/OAuth/reset flow → `auth`; GraphQL op → `graphql`; create/update body → `mass-assign`; money/limit
  flow → `race`+`logic`). **Default to inclusive when unsure — narrowing this list silently is a Rule 1/10
  violation.**
- `dev_hypothesis` is one line, written when the feature is enrolled, applying mindset.md domain 2 to
  *this specific feature* (not the target in the abstract). It drives which class you try first, not
  whether you try the rest.
- Each entry in `hunted[]` needs a non-empty `class`, `status` ∈ `tested_negative`/`tested_positive`/
  `not_applicable`, and `evidence` describing what was actually done — a bare class name is not a valid
  entry and does not count toward `status:"covered"`.
  - `not_applicable` still needs evidence: what did you check to confirm the surface isn't there (e.g.
    "checked all params on this route against the SSRF param list + fuzzed 10 more; none accept a
    URL/host — not applicable")? An assumed absence is not a checked absence.
  - `tested_positive` additionally needs `escalation_attempted:true` and a non-empty `escalation_note`
    answering the six forward questions in [chaining.md](chaining.md) — "no further chain found" is a
    valid note; a missing one is not.
- `status` on the feature row = `covered` once every class in `applicable_classes` has a terminal,
  evidenced `hunted[]` entry (and every positive among them has `escalation_attempted:true`).

## Init + enroll (Phase 0 — assets; Phase 2/4 — features)
```bash
RUN="johnwick-runs/${TARGET}-$(date +%F)"; mkdir -p "$RUN"/{assets,js,api,auth,findings}
: > "$RUN/coverage.jsonl"; : > "$RUN/features.jsonl"
# enroll every in-scope subdomain (assets/subs.txt) as an untested asset row
while read a; do
  jq -cn --arg a "$a" '{asset:$a,type:"subdomain",in_scope:true,recon:"untested",
    js_read:"untested",authed_mapped:"untested",hunted:[],status:"untested",evidence:""}' \
    >> "$RUN/coverage.jsonl"
done < "$RUN/assets/subs.txt"

# enroll a feature discovered in Phase 2/4 (repeat per feature)
jq -cn --arg asset "api.target.com" --arg feat "GET /api/invoices/{id}/pdf" \
  --arg hyp "invoice export shipped after core CRUD, likely reused wrong auth check" \
  --argjson classes '["idor","bypass-403"]' \
  '{asset:$asset,feature:$feat,kind:"id-read",dev_hypothesis:$hyp,
    applicable_classes:$classes,hunted:[],status:"untested"}' >> "$RUN/features.jsonl"
```

## Before adding a row — check one doesn't already exist for this asset+feature
If you're following up on something already enrolled (a new class, a differential re-test, a deeper
probe), **append to the existing row's `hunted[]`** — don't create a second row for the same
asset+feature. A duplicate row fragments the record: the original still shows the class as missing even
though you tested it, an audit script counting "rows fully covered" over/under-counts, and a future pass
can't tell at a glance whether a feature is actually done. Grep for the asset+feature pair first; if
found, merge into it.
```bash
jq -c 'select(.asset=="api.target.com" and .feature=="GET /api/invoices/{id}/pdf")' features.jsonl
# if that returns a row, append to ITS hunted[] (see below) — do not write a new line
```

## Mark progress (per feature, per class)
```bash
# append an evidenced class verdict to one feature's hunted[]
jq -c '(select(.asset=="api.target.com" and .feature=="GET /api/invoices/{id}/pdf")
  | .hunted += [{"class":"idor","status":"tested_positive",
                 "evidence":"...","escalation_attempted":true,"escalation_note":"..."}])
  // .' features.jsonl > t && mv t features.jsonl

# recompute this feature's status once all its applicable_classes have terminal entries
jq -c 'if (.asset=="api.target.com" and .feature=="GET /api/invoices/{id}/pdf")
  then (if ([.applicable_classes[] as $c | (.hunted[]|select(.class==$c and (.status=="tested_negative" or .status=="tested_positive" or .status=="not_applicable")))] | length) == (.applicable_classes|length)
        then .status="covered" else . end)
  else . end' features.jsonl > t && mv t features.jsonl

# roll features up into their asset's coverage.jsonl row
FEATS_TOTAL=$(jq -s '[.[]|select(.asset=="api.target.com")]|length' features.jsonl)
FEATS_COVERED=$(jq -s '[.[]|select(.asset=="api.target.com" and .status=="covered")]|length' features.jsonl)
if [ "$FEATS_TOTAL" -gt 0 ] && [ "$FEATS_TOTAL" -eq "$FEATS_COVERED" ]; then
  jq -c 'if .asset=="api.target.com" then .status="covered" else . end' coverage.jsonl > t && mv t coverage.jsonl
fi
```

## Completion checks (the invariant — run at every phase gate)
```bash
# recon phase incomplete rows:
jq -c 'select(.in_scope and (.recon!="done" or .js_read!="done"))' coverage.jsonl
# authed-map incomplete:
jq -c 'select(.in_scope and .authed_mapped!="done")' coverage.jsonl
# feature-tier incomplete — any feature not covered:
jq -c 'select(.status!="covered")' features.jsonl
# feature-tier entries missing evidence (a hunted[] entry with no evidence is not a real verdict):
jq -c 'select(any(.hunted[]?; (.evidence//"")==""))' features.jsonl
# positives missing an escalation record:
jq -c 'select(any(.hunted[]?; .status=="tested_positive" and .escalation_attempted!=true))' features.jsonl
# hunt incomplete at the asset roll-up:
jq -c 'select(.in_scope and .status!="covered")' coverage.jsonl
# whole-run invariant — MUST print 0:
jq -s '[.[]|select(.in_scope and .status!="covered")]|length' coverage.jsonl
```

**The run is complete only when the whole-run invariant prints `0`, no field is `untested`, and every one
of the queries above returns nothing.** If any query returns rows, name them, finish them, and re-run —
this is exactly the Rule-1/Rule-10 no-skip guarantee, verified per
`superpowers:verification-before-completion` (see [phase-gates.md](phase-gates.md)).

## Depth stats are not breadth stats — never report one as if it were the other
"N of M feature rows fully covered" measures how thoroughly the *enrolled* rows were tested. It says
**nothing** about whether M is anywhere close to the target's real feature count. A UI panel, a node
palette, an app/integration list, or a nav menu that shows 8 sibling items when only 1 got a feature row
is the concrete failure mode: the 1 row can go to 100% class-coverage while 7 real features sit
completely untouched, and "17/18 rows covered (94%)" reads like near-completion when it's actually a
small, cherry-picked sample. **Whenever you enroll a feature because you're looking at it (a workflow
node, an admin panel entry, an API operation from a list), enroll every sibling visible in that same
view right then** — even if you won't hunt them immediately, an `untested` row for each keeps the gap
visible instead of silently dropping it. And whenever you report a coverage number to the user, pair it
with an honest breadth statement: how many features are known to exist that never got a row, not just
the ratio among the ones that did.
