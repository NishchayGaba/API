# Phase 3 — Access Acquisition (auto-signup + temp-mail, the only human gate)

Attempt in strict order; escalate only when the prior option fails. Store working session material in
`auth/` and set up self-refresh (Rule 5) so you never re-prompt mid-hunt.

```
1. USE provided creds/cookies        → if the user already gave them (auth/)
2. AUTO-SIGNUP yourself via temp-mail → rotate providers until one works, confirm email, log in
3. ASK the human                     → ONLY if 1 and 2 both fail. Sole mandatory pause.
```

## Temp-mail fallback chain

Try providers in order; if create-inbox / poll fails, or the target's signup form throws a real CAPTCHA
challenge for this provider's address, move to the next provider. Never give up after one provider
(Rule 8). Never attempt to automate past or stealth-solve a CAPTCHA itself — rotating providers is the
tool-switch here, not defeating the challenge (see Registration mechanics below).

| Provider | Type | Notes |
|---|---|---|
| mail.tm / mail.gw | JSON API | best default — real inbox, no key |
| 1secmail | JSON API | simplest polling, but sometimes blocklisted |
| dropmail.me | GraphQL | good when 1secmail is blocked |
| guerrillamail | JSON API | long-lived, api_email flow |
| maildrop.cc | GraphQL | UI + API |
| emailnator | web (Playwright) | Google-friendly addresses, beats naive blocklists |
| temp-mail.io | web/API | fallback |

### mail.tm (recommended API)
```bash
# 1. get a domain
DOMAIN=$(curl -s https://api.mail.tm/domains | jq -r '.["hydra:member"][0].domain')
ADDR="jw$(date +%s)@$DOMAIN"; PASS="Jw!$(openssl rand -hex 6)"
# 2. create account + token
curl -s -X POST https://api.mail.tm/accounts -H 'Content-Type: application/json' \
  -d "{\"address\":\"$ADDR\",\"password\":\"$PASS\"}" >/dev/null
TOKEN=$(curl -s -X POST https://api.mail.tm/token -H 'Content-Type: application/json' \
  -d "{\"address\":\"$ADDR\",\"password\":\"$PASS\"}" | jq -r .token)
# 3. (register on target with $ADDR) then poll inbox for the confirmation link
for i in $(seq 1 30); do
  ID=$(curl -s https://api.mail.tm/messages -H "Authorization: Bearer $TOKEN" | jq -r '.["hydra:member"][0].id')
  [ "$ID" != "null" ] && break; sleep 5
done
curl -s "https://api.mail.tm/messages/$ID" -H "Authorization: Bearer $TOKEN" \
  | jq -r '.text, .html[]?' | grep -oP 'https?://[^\s"'\''<>]+(verify|confirm|activate|token)[^\s"'\''<>]*'
```

### 1secmail (no account needed)
```bash
LOGIN="jw$(date +%s)"; DOMAIN=$(curl -s "https://www.1secmail.com/api/v1/?action=getDomainList" | jq -r '.[0]')
ADDR="$LOGIN@$DOMAIN"     # register on target with $ADDR
# poll
for i in $(seq 1 30); do
  MID=$(curl -s "https://www.1secmail.com/api/v1/?action=getMessages&login=$LOGIN&domain=$DOMAIN" | jq -r '.[0].id')
  [ "$MID" != "null" ] && break; sleep 5
done
curl -s "https://www.1secmail.com/api/v1/?action=readMessage&login=$LOGIN&domain=$DOMAIN&id=$MID" \
  | jq -r .body | grep -oP 'https?://[^\s"'\''<>]+'
```

## Registration mechanics
- Simple form → `curl`/httpx the signup POST directly.
- JS-guarded form / SPA flow, **no CAPTCHA present** → drive it with **Playwright real-Chrome**
  (`channel="chrome"`) — same engine used to render JS elsewhere. This is rendering the page, not evading
  a human-verification check.
- **Real CAPTCHA/anti-bot challenge (hCaptcha, reCAPTCHA, Turnstile) on the form** → this provider is a
  dead end for automation. Do not stealth-solve it, do not automate through it. Rotate to the next
  provider in the fallback chain. If every provider hits a CAPTCHA, that exhausts step 2 — go to step 3
  (ask the human). This is the one case where "blocked" *is* a stop, not a tool-switch — it overrides
  Rule 4 by design. **Presence, not difficulty, is the trigger:** this applies the instant the widget
  renders, checkbox-only or image-challenge alike. Don't click it "to see if it passes trivially" —
  testing that is itself an attempt to get past an anti-bot mechanism.
- **Phone/SMS OTP verification during signup is the same category, not a different one.** It's an
  anti-fraud/anti-bot gate exactly like CAPTCHA, not a neutral step like email. Do not reach for a
  temp-SMS/virtual-number service to receive the OTP — those exist specifically to defeat this control,
  which is the thing Rule 4's CAPTCHA exception already forbids in spirit. If a signup flow requires phone
  verification, treat it as a dead end for that path exactly like a CAPTCHA: no other provider offers a
  way around it (there is no fallback chain for phone-gated signups the way there is for email), so this
  goes straight to step 3 — ask the human.
- After the confirmation link, log in and capture the session (cookie jar / bearer token) to `auth/`.

## Self-refresh (Rule 5)
Prefer, in order: refresh-token endpoint → re-login with stored `auth/creds.json` → cookie renewal.
Wire this before Phase 5 so long hunts don't stall on an expired session.

## Exit gate
`auth/` holds working session material **and** a live authenticated request succeeds right now (prove
it — `superpowers:verification-before-completion`). Only then start Phase 4.
