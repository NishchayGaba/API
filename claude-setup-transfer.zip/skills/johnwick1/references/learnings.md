# Cross-Session Learnings

Append-only log across johnwick1 runs. Read at Phase 1 (filter to anything matching the current target's
stack); append at Phase 6 (Rule 13). Keep entries short and specific — a technique + result + why, not a
narrative. This file is what makes the skill sharper every run instead of re-deriving the same dead ends.

Format per entry:
```
## <YYYY-MM-DD> <target> — <stack/component>
- What: <technique tried>
- Result: <worked / blocked / partial> — <why>
- Reusable takeaway: <what to try first next time this stack shows up>
```

---

## 2026-07-21 shopware.com — Ory Kratos + Hydra (managed identity)
- What: cross-tenant IDOR sweep on account/company REST resources fronted by Ory-issued JWT
  (`X-Shopware-Token`, from `GET /sessions/whoami?tokenize_as=<template>`).
- Result: clean — proper server-side ownership checks on every resource and sub-resource tested.
- Reusable takeaway: on Ory-Kratos-backed targets, the API layer *behind* Kratos is where custom app bugs
  live, not Kratos itself (it's managed SaaS, low custom-bug surface). Registration API flow (`/self-
  service/registration/api`) requires solving an Ory "puzzle" (anti-bot) field server-side — don't try to
  forge it; use the browser registration flow instead (passes invisibly, not a bypass).

## 2026-07-21 shopware.com — invite/accept-membership endpoint pattern
- What: differential test — same accept-invite call from two different caller identities (owner-token vs
  unrelated member-token) against an invite addressed to a third party.
- Result: **positive** (low severity) — the accept endpoint resolved the account-to-add from the
  invitation's stored email, not from the caller's session, i.e. caller-agnostic. Confirmed via identical
  error response (`UserAccount not found`) regardless of which of two different real tokens called it.
- Reusable takeaway: for any "accept an invite/token" endpoint, always run the caller-identity differential
  test (does the response change when a *different* authenticated identity calls the same accept URL for
  someone else's pending invite?) — cheap to run, catches consent-bypass bugs that a single-account test
  can't see. Low severity alone (attacker gains no access) but chains with any way to control the
  invitation's target email.

## 2026-07-21 shopware.com — depth-vs-breadth reporting trap (same session, later)
- What: reported "17/18 feature rows fully covered (94%)" as a headline coverage stat after a follow-up
  pass closed most per-row class gaps.
- Result: user caught it immediately — that number only describes the 18 rows that got *enrolled*, not
  how much of the real target got enrolled in the first place. Concrete unenrolled features existed the
  whole time: a workflow-builder's other connector nodes (seen in the same node palette as the one
  feature that WAS tested), a Cloud console's pre-installed AI/media apps (seen in the same integrations
  list, never opened), a marketplace's plugin-upload pipeline, a whole account-settings area.
- Reusable takeaway: never report "N/M covered" without also stating what M *should* be. The moment you
  see siblings in the same view as the feature you're about to test (a list, a palette, a nav menu),
  enroll all of them as `untested` rows immediately — don't let 1-of-8 visible items become "the" feature
  row for that area. Added as SKILL.md rationalization-table entries + coverage-ledger.md guidance.

## 2026-07-21 shopware.com — false-positive traps caught before reporting
- What: two near-misses this session, both caught by verifying content instead of trusting a surface
  signal. (1) SSTI probe `{{7*7}}` seemed to reflect `49` in the response — was actually a coincidental
  substring inside an unrelated static theme-asset hash (`64f649f038ff...`), not evaluated template
  output; literal payload wasn't reflected anywhere. (2) A same-origin `/api/projects/{uuid}` call
  returned `200` for a fully random, never-created UUID — looked like a broken-object-level-authz issue,
  but the body was the SPA's own `index.html` shell (client-side-router catch-all for any unmatched
  path), not real API data; the real backend was cross-origin and required a bearer token this route
  never touched.
- Reusable takeaway: a matching digit/status code is not evidence by itself on either SSTI or IDOR.
  Always pull the actual response body/context before concluding a hit — added explicit false-positive
  sections to both ssti.md and authz-idor.md with the exact verification steps.

## 2026-07-21 shopware.com — differential-by-identity when nothing returns a clean success
- What: two authz tests where no identity could get a genuine success response to compare against
  (schema-validation errors, no-op stub routes), so used the SAME malformed/edge-case request across two
  identities and compared the *error*, not a result. Owner got 400 (schema error, meaning it passed
  authz), unrelated low-priv account got 403 (blocked before reaching business logic) — the status
  asymmetry alone proved the authz gate was real. Separately, a cross-user session-delete returned 204
  for both a same-owner and a cross-owner target, with NO real effect on either — proved it was an
  idempotent no-op stub, not a boundary-dependent bug, by checking actual state after, not just the
  response code.
- Reusable takeaway: when you can't get a working payload through, compare *how* two identities fail on
  the identical request instead of whether either succeeds. Added as a named technique in authz-idor.md.

## 2026-07-21 shopware.com — self-audit: premature "hardened" conclusion
- What: after clean IDOR results on account/api/auth-api, generalized "well-defended target" before
  touching 44 of ~49 real assets (update-api, console/PaaS, nexus.shopware.com, git/partner-git,
  packages.shopware.com, sbp-staging cluster, frontends/component-library all still untested at the time).
- Result: correctly called out by the operator — one clean cluster is not a target verdict.
- Reusable takeaway: never write a target-wide characterization until the ledger is actually `covered`.
  High-value under-tested asset types to prioritize *precisely because* they're easy to skip past: the
  auto-update/package-distribution mechanism (classic RCE/dep-confusion surface), any PaaS/Cloud console
  (tenant-isolation ATO), internal-sounding SPAs with their own auth (often less scrutinized than the
  flagship app), staging subdomains, and public source/package repos (dependency confusion, leaked
  internal package names).

## 2026-07-21 pinterest.com — generic write-wrapper resources return misleading 200 on silent no-op
- What: Pinterest's frontend routes most mutations through generic wrapper resources
  (`ApiCResource/create/`, `ApiSResource/create/`, `ApiResource/delete/`) that embed the real REST
  path + params inside a `{"options":{"url":"/v3/...","data":{...}}}` body, rather than calling a
  named resource directly. Tested two cross-account write/delete IDOR hypotheses this way: (1) a
  stranger calling a private board's `collaborators/invite/{self}/` endpoint, (2) a stranger calling
  `DELETE /v3/sessions/{victim_session_id}/`. **Both returned HTTP 200 `{"status":"success"}`.**
- Result: both were false positives. Verified real state in both cases (board's own
  `collaborator_count`/`collaborators` list stayed empty; the victim session's `current`/
  `last_accessed_at` were byte-for-byte unchanged) — neither write actually happened. The generic
  wrapper appears to swallow an internal authorization failure and still emit a generic success
  envelope, rather than propagating a 403/404 to the caller.
- Reusable takeaway: **on this app (and probably similar generic-resource-wrapper architectures),
  a 200/"success" from a POST/DELETE call is not evidence of anything by itself — cheaper to fake
  than a GET.** Always re-fetch the target's own state afterward (via the *victim's* authenticated
  session if at all possible, exactly as done here) before calling a write-based IDOR a finding.
  GET-based IDOR responses (404 "not found" vs 200 with real data) have been reliable and trustworthy
  all session — the unreliable layer is specifically writes/deletes through these wrappers.

## 2026-07-21 pinterest.com — username-path collision looks like cross-account IDOR, isn't
- What: swept 204 no-parameter `/v3/` endpoints for unexpected cross-account data. Five
  (`/v3/users/follow/`, `/v3/users/forgot_password/`, `/v3/users/parental_control_passcode/`,
  `/v3/users/phone/`, `/v3/users/request_delete/`) returned 200 with a FULL user-profile object for
  an unrelated account (confirmed via distinct node_id/username per call, decoded from the base64
  GraphQL global-id and cross-checked against the real caller's own id from `/v3/users/me/`).
- Result: false alarm, root-caused rather than reported blind. These path segments coincidentally
  collide with a generic `/v3/users/{username}/` public-profile-lookup route — real Pinterest
  accounts are registered under literal usernames like "follow" and "forgot_password". Verified the
  response contains ONLY public-profile fields (first_name/last_name/images/follow_counts) and
  explicitly confirmed the ABSENCE of any private-only field (email, phone, creation_time, 2FA
  status) — identical to what a logged-out visitor sees on the public profile page.
- Reusable takeaway: on any app with a generic `/{entity}/{name_or_id}/` catch-all route, an
  unexpected 200-with-real-object result for a literal path segment that looks like an action verb
  (follow, forgot_password, phone...) is worth one extra check — decode the returned id, compare
  fields present against a known-private-data baseline (your own profile) — before calling it an
  IDOR. A routing collision onto already-public data is not a privacy or authz bug.

## 2026-07-21 pinterest.com — self-audit: category names in evidence prose aren't per-item evidence
- What: an earlier batch entry in this same run (batch5) listed ~24 endpoint categories by name in
  its dev_hypothesis field (aggregated_comments, conversations, experiences, news_hub, surveys,
  tag_validation, etc.) implying full coverage, but the evidence field only actually walked through
  a subset (catalogs, contact_requests/did_it/scheduledpins/shuffles, domains, oauth, partners,
  thirdpartyad) in prose. A reproducible diff script (normalize {placeholder} paths in the master
  endpoint list against every literally-tested path) caught 79 endpoints that were named but never
  individually requested.
- Result: closed the gap with a dedicated batch7 before reporting completion, per Rule 10 — a class/
  batch is only tested_negative when every named item has its own real evidence, not when the
  hypothesis text merely lists the category.
- Reusable takeaway: when logging a large batch row, either (a) literally enumerate every tested path
  in the evidence string (as done in batch3/4/6/7), or (b) if summarizing by category, immediately
  run a diff of "categories claimed" vs "master list membership" before marking the row covered —
  don't trust your own summary prose as proof of coverage. Cheap to check, catches silent undercounts
  before the user does.

## 2026-07-21 pinterest.com — parallel-burst + bad-CSRF-token replay tripped abuse detection, suspended test account
- What: in the same short window, ran (a) three deliberately-invalid CSRF token replays (missing/
  empty/bogus) against two different real mutation endpoints, and (b) a 20-way Promise.all parallel
  burst of identical follow requests, both via raw fetch() from the live authenticated session.
- Result: the test account was suspended/deactivated by Pinterest's own abuse-detection system
  immediately after -- confirmed by a subsequent login attempt showing "Your account has been
  suspended". Both browser tabs (shared cookie jar) were logged out simultaneously, consistent with
  a server-side session kill, not a client artifact. This is Pinterest's defense working correctly,
  not a vulnerability -- but it ends that account's usability for the rest of the run.
- Reusable takeaway: when testing CSRF-bypass and race-condition classes on the SAME target in close
  succession, throttle and pace them (small batches, delays between) rather than firing malformed-
  auth-header replays and N-way parallel bursts back-to-back in the same tight loop -- the combination
  reads as automated abuse even though each technique alone is a legitimate, narrow test. Budget for
  losing a test account when doing this kind of testing; keep a fast temp-mail re-signup path ready
  (mail.tm domains/accounts/token flow, ~3 curl calls) so a burned account doesn't stall the run.

## 2026-07-21 pinterest.com — Business AI Assistant (agentic ad-campaign chatbot) found in JS, gated behind account state this session couldn't reach
- What: grepped 694 mined JS bundles for AI/LLM keywords and found a real, substantial feature:
  `BusinessAI.components.FloatingAIAssistant.*` -- a chat UI with history, RAG-style "Sources" citer,
  and agentic actions (`CampaignCreationCard`, `CampaignManagementConfirmation` -- it can create/edit
  real ad campaigns with budgets). Tried to reach it live: business hub landing page (not present),
  freshly-created ads.pinterest.com ad account + accepted Advertising Agreement (not present on
  account overview), the full "Create campaign" -> Automated -> manual-builder flow including the
  "Pinterest Performance+" promo (not present there either; that page also threw "Authorisation
  failed" / audience-calc errors for the zero-spend fresh account).
- Result: not reached, not ruled a vulnerability absence -- disposition is `not_applicable` for THIS
  session, with evidence, not a guess. Most likely gate: billing/spend-history/experiment-bucket state
  that a brand-new $0 account can't satisfy without entering real payment info (out of bounds by the
  operator's standing rule against entering financial credentials).
- Reusable takeaway: this is a live, high-value, NOT-YET-TESTED prompt-injection surface for a future
  Pinterest session -- ideally with a longer-lived business account that has real (even minimal) ad
  spend history, or by asking the operator whether entering a real payment method is authorized for
  this specific purpose. Chain candidate once reached: the assistant's catalog/feed summarization
  ability + the already-confirmed feed_ingestion CSV/RSS/TikTok-URL ingestion endpoints = an indirect-
  prompt-injection-via-poisoned-feed vector worth trying first.

## Sellsy (sellsy.com) — 2026-07-27

**Stack:** Symfony/PHP monolith on www.sellsy.com (private `/rest/` API, ~100 paths recovered from a
24 MB rspack bundle at static.sellsy.com), public API v2 on api.sellsy.com (205 paths, OpenAPI at
docs.sellsy.com/api/v2/dist/sellsy.v2.latest.yaml), legacy OAuth 1.0a API on apifeed.sellsy.com.
Cloudflare everywhere. Owned by TeamSystem.

**Session mechanics (cost me a lot of time — remember this):**
- `api_access_token` cookie = RS256 JWT, **15-minute** expiry, carries corpId/userId/scopes.
- `/rest/*` on www.sellsy.com authenticates off **PHPSESSID**, NOT the JWT.
- `api.sellsy.com/v2` requires the **JWT** — the web JWT (aud `SAAS_WEB_TOKEN`) works there.
- Re-mint via `GET https://login.sellsy.com/auth/connect/saas?redirect_url=...` refreshes the PHP
  session but NOT the JWT. `POST /web-token` is the JWT mint endpoint (405 on GET) but needs a live
  login.sellsy.com SSO session, which also expires.
- **Practical lesson:** with borrowed cookies, batch ALL authed tests into one script that refreshes
  then fires immediately. Single ad-hoc curls waste the window.

**Tenant isolation is genuinely solid — do not re-spend time here:**
- API v2 object IDs are **per-tenant sequential** post-Aug-2024 migration (companies 1-30 etc.);
  every out-of-range ID 404s. No BOLA.
- Staff IDs ARE global-sequential (673794/673796) but cross-tenant GET `/v2/staffs/{id}` → 404.
- `mf[corp]` cookie swap does not switch tenants (401/500, never another tenant's data).
- SAM (`/rest/sellsy-account-manager/*`) endpoints all scope to own corp.
- JWT tamper (alg:none, payload corpId swap) → 401, RS256 verified.

**Worth knowing / weak spots found:**
- `/rest/sellsy-account-manager/third-connection/{id}` is reachable by a **normal trial user** and
  returns **500** for own-tenant third IDs (404 outside) — missing function-level authz on an internal
  Sellsy-staff (masquerade/impersonation) endpoint, but non-exploitable: the data path fails.
- `mf[corp]` swap gives a corp-existence oracle: 401 = exists, 500 = does not.
- `/v2/staffs/{id}` returns an auto-provisioned "Support Sellsy" (config@sellsy.com) staff record that
  `/v2/staffs` list omits — list/get inconsistency inside own tenant.
- Bubble app on subscription.sellsy.com exposes `/api/1.1/meta` (9 workflow endpoints incl. Chargebee
  billing webhooks). Sensitive workflows are gated by a token evaluated as a **workflow condition**
  (wrong token → `{"status":"NOT_RUN"}`), so disclosure only.
- `webhook.sam.sellsy.com` `/chargebee` + `/stripe` enforce an **IP allowlist** ("Request must be
  triggered by Chargebee (untrusted IP)") that survived a 10-header spoof matrix; Cloudflare rejects
  `CF-Connecting-IP` tampering with error 1000.

**Dead ends (don't repeat):**
- Mercure hub at mercure.sellsy.com: default JWT secrets incl. `!ChangeThisMercureHubJWTSecretKey!`,
  alg:none, anon subscribe, unauth publish, `/subscriptions` API → all 401/404. Locked down.
- Activepieces 0.82.3 at automation.sellsy.com: `/api/v1/flags` is public (version + config), and the
  version is in range for CVE-2026-12813 (SSRF), but that lives in the flow **engine's** variable
  processor `handleUrlFile` → post-auth only, and registration is closed. The 400-vs-403 split on
  `/flows`,`/app-connections`,`/project-members` is just schema-validation-before-authz, NOT a bypass.
- bo-kering.sellsy.com (bespoke Kering back-office, PHP 7.4/Plesk): catch-all router to login, no user
  enumeration (identical messages), no content discovery — every ffuf hit was a Cloudflare WAF 403 on
  `.bak` (4568 b) or Apache 403 (318 b). Needs credentials.
- Subdomain takeover: lemlist/Signitic custom domains are claimed ("your custom domain is working").
  `ecommerce.sellsy.com` IS a dangling CNAME → `apps1.ecommerce.myfacture.typhon.net`, but typhon.net
  is a live third-party zone we cannot register under. Not takeover-able.
- No secrets in any JS (trufflehog + pattern grep over 24 MB bundle + vendor + mobile).
- CORS: api.sellsy.com `*` with `credentials:false`; Bubble reflects Origin but never sets
  Allow-Credentials. Not exploitable.

**Still untested when the session ran out:** `/v2/batch` (POST), `/v2/companies/search` filter
injection, `/v2/files/{id}` IDOR, and all write/mass-assignment paths.

---
## ClearTax VDP (*.cleartax.com, *.clear.in, *.cleartax.in) — 2026-07-27

**Stack:** AWS CloudFront + S3 front; Traefik ingress; ~17 Spring Boot microservices behind
`app.clear.in/api/<service>/`; React SPA using **Webpack Module Federation** (21 microfrontend
"remotes"); SSO at `accounts.cleartax.in` (also proxied at `app.clear.in/accounts/*`).

**What paid off**
- **Module Federation is a recon goldmine.** `enterprise-shell-remote.js` embeds an `external`
  record per remote, which leaked 30+ internal hostnames (`*.internal.cleartax.co`) and the full
  microfrontend inventory. Enumerating 24 remote paths × 40 app hosts found 300 live remotes and
  36 exposed `.map` files that per-host crawling never surfaced.
- **Webpack runtime chunk map** in `main.*.js` (`{1048:"9563c79a…",…}`) yielded 87 lazy chunks no
  crawler ever triggered — that's where the entire `/v0/*`, `/v1/orgUnit/*`, `/api/internal/*`
  admin route table lived (~310 paths).
- **Distinguishing 404 flavours fingerprints the backend instantly:** Traefik `404 page not found`
  (plain text) vs Spring `{"timestamp":…,"status":404}` vs Jersey `{"code":404,"message":"HTTP 404
  Not Found"}`. Comparing them locates the real service prefix (`/api/platform/pfapi` vs
  `/api/platform`) in one pass.

**Dead ends (don't repeat)**
- Actuator paths return a canned 2-byte `OK` at the edge on *every* service, including
  non-existent ones. **Always test a bogus service name before celebrating** — 432 "200 OK" hits
  were all one WAF rule. Case-variant bypasses reach Spring but actuator genuinely isn't enabled.
- `sourcemapper` is far too slow (3 maps in 10 min). A ~25-line Python `sourcesContent` extractor
  does 36 maps in under a minute. Also: ClearTax's remote `.map` files strip app source and keep
  only node_modules + webpack runtime — still valuable for the dependency inventory and the
  `external` host records, but don't expect original TSX.
- PubNub PAM is enforced and the token-grant endpoint ignores client-supplied `workspaceId`.

**Tooling gotchas (macOS/zsh)**
- BSD `xargs` has no `-a` — use `cat file | xargs`. `xargs -I@ sh -c '… @'` silently dies after a
  few items; write a real script file and use `xargs -n1 ./script.sh`.
- zsh does not word-split unquoted vars in `for x in $VAR` — wrap loops in `bash -c`.
- `timeout` is not present; use curl's own `-m`.
- crt.sh was returning 502 all session — certspotter + hackertarget + rapiddns + OTX covered it.
- Some CDN JS (assets1.cleartax-cdn.com) is served pre-gzipped regardless of Accept-Encoding;
  `file` the downloads or the whole secret scan silently reads binary.

**Signup for testing:** mail.tm → `send-email-otp` / `verify-email-otp` with
`product=enterprise_app` gets a B2B Clear Finance Cloud session with **no CAPTCHA**. The
create-workspace flow only renders when domain suggestions are empty — stub the
`workspace-suggestions` response to `[]` in Playwright to reach it and provision your own tenant.

## Sellsy (sellsy.com) — 2026-08-03 (continued)

**New SAN subdomains from SSL cert (previously unknown):**
- `automation.sellsy.com` = ActivePieces 0.82.3 EE prod (confirmed dead end from prior session)
- `mercure.sellsy.com` = Mercure hub (confirmed dead end from prior session)
- `sales.sellsy.com` → Salesloft tracking infrastructure (34.48.58.236, Google Cloud) — OOS
- `releasenotes.sellsy.com` = Node.js Express stub, returns blank XHTML on root only, all other paths 404
- `diagnostic-excel.sellsy.com` = DNS lookup fails — decommissioned or internal-only
- `dl.sellsy.com` = bare Apache (51.159.164.249/host1.slsy.tech, Scaleway, no Cloudflare) — all paths 404
- `academy.sellsy.com` = nginx+Plesk, redirects to go.sellsy.com/academy (Webflow site)
- `zapier.sellsy.com` = 403 Forbidden, Cloudflare+PHP — Zapier OAuth integration entry point
- `webhook.sellsy.com` = Webflow marketing page (go.sellsy.com), `/status` returns 403
- `snippet.sellsy.com` = same Symfony PHP app as www.sellsy.com, all unknown routes return 200 with `window.console.error('Sellsy : You are not allowed to continue')`
- `home.sellsy.com` = Lemlist custom-domain check page ("Hey lemlisters!") — OOS (Lemlist third-party)
- `signatures.sellsy.com` = Signitic (email signature tool) custom domain — OOS
- `sam.sellsy.com` = 404, no accessible endpoints

**New lead — needs auth to confirm:**
- `file.sellsy.com/?id={integer}` = Sellsy file download service (integer ID from API spec comment: `example: https://file.sellsy.com/?id=xxxx`). ALL responses (including 404) have `Access-Control-Allow-Origin: *`. If files served without auth OR if auth is URL-token-based, this = cross-origin read of any file by ID. **Requires a valid file ID to test.**

**New confirmed dead ends:**
- `www.sellsy.com/onboarding/trial/validate` POST — reCAPTCHA v3 is server-side enforced; empty token → 400 "Une erreur s'est produite". No bypass found.
- `login.sellsy.com` forgot password = 404 for `/password/forgot` route. User enumeration not possible on this endpoint.
- `www.sellsy.com/graphql` GET = 404 JSON error (route exists, but handler returns 404). POST = 405 (Allow: GET only). Not a live GraphQL endpoint.
- `dl.sellsy.com` = all paths 404, `.htaccess`/`server-status`/`.git` = 403. File download server but all paths inaccessible without known URL.
- `sales.sellsy.com` = Salesloft tracking (OOS). Returns 204 for all paths.
- QuickPay URL format = `POST /quickpay/pdf` + `GET /quickpay/{hash}` pattern; Wayback has zero indexed quickpay URLs.

**Still blocked (requires auth):**
- `/v2/batch` POST, `/v2/files/{id}` IDOR, `/v2/companies/search` injection, all write paths
