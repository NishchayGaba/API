# IDOR / BOLA / BFLA — Authorization Bypass Hunting

Hunt only resource-level authorization bugs that chain to PII-at-scale, ATO, or financial impact.

## Kill list (instant reject)
- Self-IDOR (reading your own data) is not IDOR.
- "Possible IDOR — needs confirmation" is not a finding. Confirm or kill.
- Reading a public-by-design resource is not IDOR.
- ID disclosure in a URL with no read/write follow-on is not P-class.
- Org-admin reading their own org's data is not IDOR.

## Valid classes (what we hunt)
- **Cross-tenant read/write** — Tenant A reads/modifies Tenant B's records (orders, invoices, KYC, tickets).
- **Horizontal IDOR** — User A reads User B's data, same tenant, no shared scope.
- **Vertical IDOR / BFLA** — low-priv role calls admin-only function/mutation.
- **Sub-route auth skip** — `/orders/{id}` 403s but `/orders/{id}/edit|refund|notes|export` is unscoped.
- **Per-verb authz gap (CRUD split)** — GET/PUT scoped, but `DELETE`/`archive`/`clone`/`export` isn't.
  **Test every verb/action on the same object independently.** Delete is the classic unguarded sibling.
- **Status-sibling gap** — swap the lifecycle word (`challenged`↔`unchallenged`, `pending`↔`accepted`,
  `active`↔`archived`, `draft`↔`published`) with a foreign `org_id`; authz is wired per-variant, one
  sibling returns 200 while the other 4xx. A status-code diff between siblings is the tell.
- **JWT claim IDOR** — `sub`/`uid` is mutable and used as the model key, or trusted across service hops.
- **GraphQL nested/field IDOR** — top resolver checks auth, nested resolver or deprecated field doesn't.
- **Predictable-ID enumeration** — sequential/short-token IDs make every class enumerable platform-wide.

## The subtler failure: authz check evaluates the wrong identity
Not every IDOR is a *missing* check — some are a check that runs but is handed the wrong actor. A real
disclosed CVE-track case: `$student_id = $request->get_param('user_id') ?: get_current_user_id()`, then
the authz gate calls `is_enrolled($student_id)` — so an attacker who supplies a foreign `user_id` makes the
gate ask "is the **victim** allowed to see this" (trivially true) instead of "is the **caller** allowed."
When reviewing or black-box-probing any authz gate, ask not just *does a check run* but *whose identity
does the check actually evaluate* — grep source for authz helper calls and check every argument, or
black-box it by watching whether supplying a foreign id anywhere in the request (not just the resource id
itself) changes which identity gets checked.

The sibling failure, same root shape: **the check validates against the resource named in the URL, but the
mutation is applied to a *different* resource named in the body.** Real disclosed CVE (GitHub Enterprise,
2026): an endpoint checked the caller's admin rights against the repo ID in the URL path, then applied the
actual write using an `owner_id` field from the request body pointing at a repo the caller had no rights
to. Whenever a route takes an id in the URL *and* a second id-like field in the body/query (`owner_id`,
`target_id`, `account_id`), test them independently — same-object-both-places is the honest case, and
mismatching them is the probe.

## No-hallucination rule — every IDOR needs all 3
1. Request A from Account 1 returns **Account 1's** record.
2. Same request shape with Account 2's id, still authed as Account 1, returns **Account 2's** record
   (not 403, not an empty form).
3. Body-level proof of the foreign record (different email/name/amount/order_id in the response).
If you can't show all three, it isn't IDOR.

## The loop
1. **Intel** — tenant model (subdomain / JWT claim / header / path)? ID scheme per resource? auth stack?
2. **Surface map** — every endpoint taking a resource id (path/query/body/JWT). Sources: authed HTML/JS
   (`wire:snapshot`, `data-id`, `fetch(`), proxy history, OpenAPI/GraphQL introspection, JS bundles
   (`jsluice urls`), wayback. Decode Filament/Livewire `wire:snapshot` → model class + key.
3. **ID scheme** — sequential numeric = enumerable (whole platform sweeps even if route authz is right);
   UUIDv4 = needs cross-tenant access; UUIDv1/ULID/Snowflake = time-ordered, partly predictable;
   base62 ≤8 = brute-forceable; HMAC-signed = only if secret leaks (check JS/sourcemaps).
4. **Actor model** — get 2 accounts in different tenants (cross), same tenant diff role (vertical),
   same tenant same role (horizontal), plus an anon session (auth-skip). Record each account's ids.
5. **Hypotheses** — one row per id-endpoint: `endpoint | sub-id | observation that proves the bug`.
   Rank by (scope-cross-severity × ID-enumerability). Cross-tenant + sequential first.
6. **Test** — Baseline (own) → Cross probe (foreign id, own session) → Reverse (B reads A) → Negative
   control (a sibling that *should* 403) → **Body diff** (foreign identifiers present). Pace ~1 probe/
   min; WAFs escalate to a CAPTCHA challenge after ~10 fast requests — treat that as a rate signal, not a
   puzzle: back off pacing, switch to Playwright `channel="chrome"` for legitimate JS rendering if the
   block was a WAF page, or ask the user to re-export a fresh WAF/session token. Never automate past the
   CAPTCHA itself.
7. **Escalate (mandatory)** — one cross-tenant read ≠ P1. Chain: one read → enumerate id range →
   quantify PII at scale → probe the matching write endpoint → ceiling.
   ```
   read IDOR   → enumerate → full PII dump           (P1 if PII)
   write IDOR  → modify foreign resource             (P1 if money/auth)
   admin BFLA  → low-priv calls admin fn             (P1 if user-data scope)
   JWT sub     → forge token → ATO                   (P1 always)
   ```

## Extra hypotheses (highest-yield disclosed patterns)
- Replay every nameable GraphQL/REST op from a **no-permission / lowest-role** session (undocumented
  mutations with no authz = #1 payer). "Not found" ≠ safe — retry with a valid foreign id.
- Any resource that 403s in UI/GET → retry API, `DELETE`, `PUT`, `/edit`, older `/v1` siblings.
- Add a privilege field (`admin:true`, `role`, `is_admin`) to update requests (mass assignment).
- Capture an owner-only request, replay verbatim as low-priv (forced request).
- Flip approval/status params to skip moderation; inject `email` to accept invites you don't own → ATO.
- Feed wayback/gau UUIDs back into current endpoints.

## Extended technique surface (less-obvious vectors — hunt these too)
- **Nested/child-resource gap** — the parent 403s correctly (`GET /orders/{id}`) but a child route under
  it isn't re-checked (`/orders/{id}/items/{item_id}`, `/refund`, `/notes`, `/export`). Walk every child
  route under a foreign object, not just the parent.
- **Batch/bulk-endpoint IDOR** — bulk export/delete/update accepting an id array (`{"ids":[1,2,3]}`) often
  checks ownership on the first element only, or not at all. Mix your own ids with foreign ones in one call.
- **GraphQL global-ID IDOR** — base64-decode an opaque `id` (`VXNlcjox` → `User:1`), increment the numeric
  part, re-encode, query `node(id:"...")` or the type-specific query directly ([graphql.md](graphql.md)).
- **Search/typeahead/autocomplete leak** — the search index is sometimes built without the same per-tenant
  scoping as the direct-read endpoint. Search for another tenant's known value (email fragment, order
  number, name) and see if it surfaces even though reading it directly 403s.
- **Storage-path IDOR** — predictable object-storage keys or local paths keyed by sequential/guessable ids
  (`/uploads/{user_id}/{filename}`, `/exports/{export_id}.csv`) — a pure path-guessing problem, independent
  of any API authz check.
- **Real-time channel IDOR** — WebSocket/SSE subscribe to another user's `room_id`/`order_id`/`ticket_id`
  with no per-connection ownership check (distinct from GraphQL subscriptions — see graphql.md for those).
- **Second-order / stored IDOR** — a foreign id is *accepted and stored* now (set as "linked_account",
  "referred_by", "parent_ticket") and only becomes exploitable later when a downstream feature trusts that
  stored link without re-checking ownership.
- **Draft/pending-object gap** — objects in a draft/pending/unpublished state often skip the authz check
  that applies once finalized (draft invoices, pending orders, unsent messages). Test the same object
  across its full lifecycle, not just its "published" state.
- **Compare/diff/merge endpoints** — "compare A vs B" or "merge account A into B" features that validate
  ownership of one side and not the other.
- **Notification-link IDOR** — one-click email/SMS links (`unsubscribe?uid=`, `accept-invite?token=`,
  `confirm?id=`) using a guessable/sequential id instead of a signed, single-use token.
- **Impersonation-feature abuse** — support/admin "view as" / "login as user" trusting a client-supplied
  target-user id without re-verifying the *caller's* privilege server-side on every subsequent request,
  not just the initial switch.
- **List-endpoint filter bypass** — a correctly-scoped detail endpoint sits next to a list endpoint that
  accepts an `owner_id`/`account_id`/`tenant_id` *filter* param and doesn't intersect it with your actual
  scope. Pass a foreign id as the filter, not the resource id.
- **Shared counter/quota IDOR** — usage/rate-limit counters keyed by a client-supplied id
  (`POST /usage?account_id=`) let you drain or inflate another tenant's quota.
- **Async job/report IDOR** — `POST /reports {order_id}` → `GET /reports/{report_id}` where the
  *report_id* isn't bound to the requesting user, only the underlying data is bound to the order.
  Enumerate `report_id` directly and skip the order-level check entirely.
- **Cache-key IDOR** — a response cached by resource id alone (not id + requesting user), served to
  whoever asks for that id next through a shared cache/CDN ([cache-attacks.md](cache-attacks.md)).
- **Slug/alias IDOR** — endpoints keyed by username/slug instead of an internal numeric id
  (`/u/{username}/private-notes`) — under-tested because slugs don't "feel" enumerable like integers.
- **Post-transfer ownership drift** — right after an object changes hands (reassigned, transferred,
  unshared), test whether the *previous* owner's session/cached link still works — a TOCTOU-adjacent
  authz bug at the handoff moment.
- **Full cross-role matrix, not just cross-user** — don't stop at user-vs-user; test user vs support-agent
  vs org-admin vs super-admin vs service-account/API-key as separate BFLA hypotheses — each pair is its
  own trust boundary (mindset.md domain 1).

## Differential-by-identity — when you can't get a clean success to compare against
Some endpoints never return a clean 200 for anyone in black-box testing (schema validation, missing
required fields, etc.), so the usual "baseline vs cross-probe" comparison has nothing to anchor on. The
fix: send the **exact same** (possibly malformed) request as two different identities and compare the
*error*, not the result:
- If the legitimate owner gets a **business-logic error** (400 schema/validation, 422, deserialization
  failure) while an unrelated identity gets a **clean 403/401**, that status *difference* proves the
  authz check runs before the request reaches business logic — even though neither call succeeded.
  (Real example: `PUT /companies/{id}/members/{memberId}` with a malformed body — the company owner got
  `400 Deserialization failed`, an unrelated zero-role member got `403 Forbidden`. The asymmetry alone
  confirms proper gating; you never needed a working payload.)
- Conversely, if both identities get the **identical** response to the same request against someone
  else's resource (e.g. both get `204 No Content` on a `DELETE`), don't count that as a bypass until
  you've verified the delete actually *did* anything for the legitimate case too — an idempotent/no-op
  stub route returns the same "success" whether or not the target belonged to the caller. Confirm real
  effect (re-fetch the target resource) before calling identical-response-across-identities either a pass
  or a fail.

## False-positive traps specific to this class
- **SPA client-side-router 200s are not API responses.** Same-origin `fetch('/api/whatever/<any-uuid>')`
  on a single-page app frequently returns `200 text/html` — the app's own `index.html` shell, served by
  the router's catch-all for any unmatched path, not a real backend response. A `200` for a **random,
  never-created** UUID is the tell: check `Content-Type` and the actual body before treating any 200 as
  IDOR evidence. If the real API lives on a separate (often cross-origin) host, hitting a same-origin
  `/api/...` path on the frontend's own domain may not reach it at all.

## Anti-slop checklist (run silently)
- [ ] Own baseline captured before cross probe. [ ] Every verb tested separately (read+update+delete/export).
- [ ] Both directions (A→B and B→A). [ ] Body diff shows foreign identifiers. [ ] Negative control 403s.
- [ ] Ruled out "Account 1 is secretly superadmin." [ ] Enumeration quantified. [ ] Phase-7 chain done.
- [ ] No "potential/possible" language. [ ] Switched to real-Chrome if WAF blocked.
