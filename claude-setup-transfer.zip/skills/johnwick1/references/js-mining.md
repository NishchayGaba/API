# JS Mining — Read ALL JavaScript (Rule 3, MANDATORY)

Every JS file from the **union of live-crawl ∪ waybackurls ∪ gau ∪ katana, run independently
against every live subdomain** (not just the apex/main app) gets downloaded and mined.
Sampling, "vendor bundle" skipping, "this subdomain probably shares the main app's bundle so
skip it", or "min.js is noise" reasoning are Rule 3 violations. The count of files mined must
equal `wc -l js/js-urls.txt` summed across every subdomain.

**"Mined" in this file means regex/jsluice extraction — that is a fast first pass, not the
whole job.** Regex finds secrets and known-shape endpoint strings; it cannot find a logic bug
(a client-side role check that's never re-verified server-side, a URL-upload field that
silently proxies through an SSRF-able server endpoint) because those don't match any keyword
pattern. After steps 1-5 below, every downloaded file must ALSO be beautified
(`js-beautify`/`jsbeautifier`, not just left as one giant minified line) and **read completely,
end to end**, before the file counts as done. This has no file-count exception — hundreds of
files across dozens of subdomains all still get the full read.

## 1. Collect the JS URL union

```bash
# from the URL corpus (recon-pipeline.md step 3)
grep -Ei '\.js(\?|$)' assets/all-urls.txt | sed 's/\\//g' | cut -d'?' -f1 | sort -u > js/js-urls.txt
# plus JS referenced directly by live pages (SPA bundles wayback never saw)
cat assets/live-200.txt | awk '{print $1}' | while read url; do
  curl -sL --max-time 15 "$url" | grep -oP '(?:src|href)=["'\''][^"'\'' ]*\.js[^"'\'' ]*' \
    | sed 's/.*=["'\'']//' >> js/js-urls-discovered.txt
done
# plus a katana JS-only crawl to catch dynamically loaded chunks
cat assets/live-200.txt | awk '{print $1}' | katana -d 3 -jc -silent | grep -Ei '\.js(\?|$)' >> js/js-urls-discovered.txt
sort -u js/js-urls-discovered.txt >> js/js-urls.txt && sort -u js/js-urls.txt -o js/js-urls.txt
wc -l js/js-urls.txt      # THIS is the number of files that must be mined
```

## 2. Download everything (20 concurrent)

```bash
mkdir -p js/files
cat js/js-urls.txt | xargs -P 20 -I{} sh -c \
  'h=$(echo "{}" | md5sum | cut -d" " -f1); curl -sL --max-time 15 "{}" -o "js/files/${h}.js" 2>/dev/null'
```

## 3. Extract endpoints + secrets

```bash
jsluice urls    js/files/*.js > js/endpoints.txt 2>/dev/null
jsluice secrets js/files/*.js > js/secrets.txt   2>/dev/null
# backend-critical greps
grep -rniE '(secret|token|api[_-]?key|bearer|authorization|password|credential)' js/files/ | sort -u > js/credentials.txt
grep -rnE  'isAdmin|isOwner|role|permission|canAccess|hasRole|requireAdmin'      js/files/ | sort -u > js/authz-checks.txt
grep -rniE 'graphql|gql|apollo|hasura|urql'                                       js/files/ | sort -u > js/graphql.txt
grep -rniE 'admin|internal|dashboard|manage|super|/debug'                         js/files/ | sort -u > js/admin-refs.txt
grep -rnE  'sourceMappingURL|\.map'                                               js/files/ > js/sourcemap-refs.txt
```

## 4. High-value secret regex (tiered — check most valuable first)

**TIER 1 — cloud/infra (≈$5K–$25K):**
```
AKIA[0-9A-Z]{16}                         # AWS access key id
"type": "service_account"|private_key    # GCP service account
AccountKey=|SharedAccessSignature        # Azure storage
firebaseConfig|apiKey.*AIza              # Firebase
SUPABASE_URL|supabaseKey                 # Supabase
```
**TIER 2 — API keys / auth tokens (≈$1K–$10K):**
```
eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}   # JWT
client_secret|clientSecret|refresh_token
x-api-key|bearer_token|access_token
-----BEGIN (RSA|EC|OPENSSH|PRIVATE) KEY-----
```

## 5. Sourcemap recovery (reconstruct original source)

```bash
mkdir -p js/sourcemaps
cat js/js-urls.txt | while read url; do
  curl -sL --max-time 15 "${url}.map" -o "js/sourcemaps/$(echo "${url}.map"|md5sum|cut -d' ' -f1).map" 2>/dev/null
done
for f in js/sourcemaps/*.map; do [ -s "$f" ] && jq -r '.sourcesContent[]?' "$f" 2>/dev/null >> js/sourcemap-src.txt; done
grep -Ei 'api|endpoint|fetch\(|axios|admin|internal|secret|token|password' js/sourcemap-src.txt | sort -u > js/sourcemap-hits.txt
```

## 6. What to do with hits (impact-first)
| Hit | Action — prove impact now |
|---|---|
| Live cloud key (AWS/GCP/Firebase/Algolia/Mapbox/SendGrid) | Verify against issuer API. Live=P1; dead=trash. |
| Internal/staging base URL web recon missed | `httpx` it → new host → enroll in ledger, recon it. |
| Admin/internal endpoint the app never calls | Hit from an authed session (Phase 5) → IDOR/BFLA candidate. |
| Hardcoded backend password / basic-auth | Verify it authenticates against the live host. |

**Only mark `js_read:"done"` when files mined == `wc -l js/js-urls.txt`.** Verify with a count, per
`superpowers:verification-before-completion`.

## 7. If the target has ever open-sourced any component, mine that repo's full history too
This is separate from bundled-JS mining and just as high-value when it applies. A live legacy/internal
endpoint's exact params, auth scheme, or response-signing logic often isn't in current docs but *is*
sitting in an old commit of a component the target open-sourced (a core product, a plugin SDK, an old
version of a still-running microservice).
```bash
gh search code "class UpdateCheck" --repo <org>/<repo>          # find the file by a class/function name
                                                                  # you saw referenced from the live app
gh api "repos/<org>/<repo>/commits?path=<file>&per_page=100"     # full commit history for that one file
curl -s "https://raw.githubusercontent.com/<org>/<repo>/<old-sha>/<path>"   # pull the version that
                                                                  # matches what's actually live today
                                                                  # (current HEAD may have since migrated
                                                                  #  to a different endpoint/library —
                                                                  #  check the OLD version against what
                                                                  #  the live host actually still serves)
```
Also search the repo for internal engineering docs that get committed alongside code and never get
scrubbed before a public push: `AGENTS.md`, `ADR`/`adr/` decision records, `docs/gaps-*.md` or
`docs/*-backlog.md` style tracking files, `CHANGELOG` entries with "Security" or "Fixed" (feeds
mindset.md's changelog-driven sibling audit). These routinely reveal auth models, known limitations,
and unshipped-feature roadmaps straight from the source, more reliably than reverse-engineering minified
JS. `gh search code "<distinctive-term>" --repo <org>/<repo>` beats guessing file paths.

## 8. When a modern SPA's auth token isn't reachable via page-context JS at all
Some frontends deliberately hold the bearer token only in an in-memory JS closure/module variable —
absent from `localStorage`, `sessionStorage`, and `IndexedDB`, and not sent as a readable cookie either.
This is good hardening on the target's part, and it's a real, recurring blocker for curl-based testing of
that specific feature. Recognize it fast instead of burning time on it:
```javascript
// quick check — do this BEFORE trying to test the feature via curl at all
Object.keys(localStorage).concat(Object.keys(sessionStorage))   // empty/irrelevant?
await indexedDB.databases()                                      // empty?
// if both are empty, patching window.fetch / XMLHttpRequest.prototype.setRequestHeader to log the
// Authorization header on the app's own next authenticated call is worth ONE try, but often won't catch
// anything either — client-side caching (TanStack Query/SWR-style) can mean no NEW authenticated request
// fires on a given in-app navigation, so a null capture doesn't prove the token isn't attached this way.
```
If that one attempt doesn't yield the token, **stop guessing and switch tools** — this is a Rule-4-style
tool-switch, not a dead end: capture a HAR file via the browser's own DevTools Network tab (right-click →
"Save all as HAR"), or route the browser through mitmproxy/Burp, to see the real request headers as they
actually go out. Either gives you the exact header name/value to replicate in curl. Don't spend more than
one round of in-page JS interception before making this switch — record what you tried and move to the
proxy method rather than repeating variations of the same patch.
