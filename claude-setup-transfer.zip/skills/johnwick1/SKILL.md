---
name: johnwick1
description: Use when the user says "run johnwick1" / "/johnwick1", hands you a bug-bounty target or scope and wants the full manual+recon+automated hunt run end-to-end, or asks to hunt a target with total coverage (every in-scope domain/subdomain, all JS, signup+login, then exploit and validate). Self-contained long-running orchestrator — recon, JS mining, auto-signup, and hunting for IDOR, SSRF, RCE, SSTI, XXE, SQLi, request smuggling, cache poisoning, race conditions, OAuth/JWT/SAML ATO, GraphQL, 403-bypass, and mobile are all built in via internal reference files (each grounded in disclosed paid HackerOne reports), with a zero-skip coverage ledger and a superpowers verification gate between every phase.
---

<!-- MANDATORY-JS-RECON-DOCTRINE v3 — injected across EVERY skill. Do not delete or gate behind a condition. -->

# 🚨 MANDATORY JS RECON GATE — NO SKIP, NO EXCEPTIONS

**This block is law in every skill.** Whatever else this skill does, if a web/HTTP target is
anywhere in scope you MUST complete the JS recon pipeline below BEFORE you conclude recon,
rank surface, declare "nothing found," or move to the next phase. Skipping any step is a
**process failure, not an optimization.** There is no file-count exception, no time-pressure
exception, no "it's a small app / SPA / static site" exception.

> Client-side JS is the attack-surface map of the entire application. Every bundle, chunk,
> worker, source map, service worker, and inline script leaks endpoints, secrets, roles,
> feature flags, and business logic the server never meant you to see. Hunters who skip JS lose the P1s.

---

## RULE 1 — ALL crawlers are MANDATORY on EVERY live host — plus 3 new mandatory classes

Run **all five** tool-classes — never just one, never "pick your favourite." Enumerate subdomains
first, then run this per host (each subdomain ships its own bundle, secrets, and logic):

```bash
subfinder -d "$T" -all -silent | httpx -silent -mc 200 -o live_hosts.txt   # per-host, not per-apex

# PASSIVE (zero-touch history — catches dead/forgotten/rotated-but-still-live JS)
echo "$HOST" | waybackurls | anew all_urls.txt
echo "$HOST" | gau --subs  | anew all_urls.txt
echo "$HOST" | waymore -mode U -oU waymore.txt 2>/dev/null; cat waymore.txt | anew all_urls.txt
awk '/\.js([?]|$)/' all_urls.txt | anew js.txt

# ACTIVE (live DOM, dynamic <script>, chunk loads)
katana   -u "https://$HOST" -jc -jsl -d 5 -kf all -aff -silent | anew all_urls.txt
hakrawler -u "https://$HOST" -d 3 -subs 2>/dev/null              | anew all_urls.txt
gospider  -s "https://$HOST" -d 3 --js  2>/dev/null              | anew all_urls.txt
cariddi   -s "https://$HOST" -intensive 2>/dev/null | grep '\.js'| anew js.txt
awk '/\.js([?]|$)/' all_urls.txt | anew js.txt

# MANDATORY: Service Workers (often forgotten, contain cache logic + secrets)
curl -sL "https://$HOST/sw.js"              -o "js_files/sw.js"              2>/dev/null
curl -sL "https://$HOST/service-worker.js"  -o "js_files/service-worker.js"  2>/dev/null
curl -sL "https://$HOST/manifest.json" | jq -r '.service_worker // empty'   2>/dev/null
# Check Web App Manifest for SW registration path and parse its scope

# MANDATORY: Inline JS extraction from every HTML page (tools miss embedded <script> blocks)
python3 - <<'PYEOF'
import re, sys, requests
from bs4 import BeautifulSoup
HOST = sys.argv[1] if len(sys.argv)>1 else ""
for path in ['/', '/app', '/dashboard', '/admin', '/login']:
    try:
        r = requests.get(f"https://{HOST}{path}", timeout=10,
                         headers={"User-Agent":"Mozilla/5.0"})
        soup = BeautifulSoup(r.text, 'html.parser')
        for i, tag in enumerate(soup.find_all('script', src=False)):
            if tag.string and len(tag.string) > 100:
                fname = f"js_files/inline_{path.strip('/') or 'root'}_{i}.js"
                open(fname,'w').write(tag.string)
                print(f"[INLINE] {fname} ({len(tag.string)} chars)")
        # Also capture window.__NEXT_DATA__, window.__NUXT__, window.__remixContext
        for pat in [r'window\.__NEXT_DATA__\s*=\s*({.+?});',
                    r'window\.__NUXT__\s*=\s*(.+?)\s*;',
                    r'window\.__remixContext\s*=\s*({.+?});']:
            m = re.search(pat, r.text, re.DOTALL)
            if m: print(f"[SSR-STATE] {pat[:20]}... FOUND at {HOST}{path}")
    except: pass
PYEOF

# MANDATORY: Framework-specific chunk paths (lazy bundles tools never trigger)
# Next.js
curl -s "https://$HOST/_next/static/chunks/pages/_app.js" | head -5 | grep -q 'function' && \
  echo "[NEXT.JS] _next/ chunks present" && \
  katana -u "https://$HOST" -d 3 -silent | grep '_next/static' | anew js.txt
# Nuxt
curl -s "https://$HOST/_nuxt/" -o /dev/null -w "%{http_code}" | grep -q 200 && \
  echo "[NUXT] _nuxt/ chunks present"
# Vite
curl -s "https://$HOST/assets/" -o /dev/null -w "%{http_code}" | grep -q 200 && \
  echo "[VITE] /assets/ present"
```

**MANUAL CRAWL is equally mandatory — tools miss auth-gated and lazy-loaded routes:**
- Open the app in a real browser with **Burp/mitmproxy inline**. **Log in.**
- Click through **every** route, tab, modal, multi-step wizard, settings/admin area.
- Watch the Network panel: every `.js`, every XHR/fetch, every WebSocket frame, every chunk
  pulled on navigation goes into `js.txt` / the endpoint list. SPAs load chunks lazily — a
  route you never visited = a bundle you never saw = bugs you never found.
- Toggle every feature flag you can find and capture the JS that loads behind each one.
- Burp extensions **JS Miner** + **Param Miner** + **JS Link Finder** run passively — enable all three.
- **In DevTools → Application tab:** check Service Workers registered, Cache Storage entries
  (cached JS/API responses), and Local Storage / Session Storage for tokens and flags.
- **In DevTools → Sources tab:** look for webpack internal entries (`webpack://`) and
  source-mapped originals — these are readable even without fetching `.map` separately.

---

## RULE 2 — Recover, beautify, DEOBFUSCATE, and READ every file (never grep-only)

```bash
sort -u js.txt -o js.txt && mkdir -p js_files beautified recovered deobfuscated
xargs -a js.txt -P20 -I@ sh -c 'curl -sL -A "Mozilla/5.0" "@" -o "js_files/$(echo @ | md5sum | cut -c1-16).js"'
for f in js_files/*.js; do js-beautify "$f" > "beautified/$(basename "$f")"; done

# SOURCE MAPS = full original source (readable, real var names, internal paths). A 200 is game over.
while read u; do
  s=$(curl -so /dev/null -w "%{http_code}" "$u.map")
  [ "$s" = "200" ] && echo "$u.map"
done < js.txt | tee sourcemaps_found.txt
# Recover each: sourcemapper -url URL -output ./recovered/   OR  unwebpack  OR  webcrack
# For multiple: cat sourcemaps_found.txt | xargs -I@ sourcemapper -url "@" -output ./recovered/

# WEBPACK DEOBFUSCATION — webcrack handles packed/self-executing bundles and recovers modules
# Install: npm install -g webcrack
for f in beautified/*.js; do
  webcrack "$f" -o "deobfuscated/$(basename "$f" .js)/" 2>/dev/null && \
    echo "[WEBCRACK] deobfuscated: $f"
done

# OBFUSCATOR.IO / eval-packed code — detect and unwrap
grep -l 'eval(function(p,a,c,k,e,d)' beautified/*.js | while read f; do
  node -e "var x=$(cat $f); if(typeof x==='string') console.log(x)" > "deobfuscated/$(basename $f)" 2>/dev/null
done
# String array rotation / hex strings
grep -l 'String\["fromCharCode"\]\|\\x[0-9a-f]\{2\}' beautified/*.js | \
  xargs -I@ sh -c 'node -e "eval(require(\"fs\").readFileSync(\"@\",\"utf8\"))" 2>/dev/null > deobfuscated/$(basename @)'

# WEBPACK: pull the runtime bootstrap's chunk-id→hash map to enumerate LAZY chunks no crawler triggered
grep -oE '[0-9]+:"[0-9a-f]{6,}"' beautified/*runtime* beautified/*.js 2>/dev/null | head -100
# Reconstruct chunk URLs: <publicPath>/<chunkId>.<hash>.chunk.js and fetch each
# Next.js chunks: /_next/static/chunks/<id>.<hash>.js
# Vite chunks: /assets/<name>.<hash>.js
```

**Grep is a triage pass to prioritize — NEVER the analysis itself.** Grep finds `apikey` and
`fetch(`. It does not tell you a URL-upload feature silently proxies server-side (SSRF), or that
a role flag is set client-side and never re-checked. **Every beautified/deobfuscated file gets
read end to end, including service workers and inline scripts.** No exception — budget the time;
this step is supposed to be slow.

---

## RULE 3 — Hunt these in every file (the money list — v2 expanded)

Static-scan to triage, then READ to confirm. Scanners: `trufflehog filesystem js_files/`
(verifies live keys), `jsluice urls|secrets js_files/*.js`, `mantra -f js.txt`,
`SecretFinder -i <f> -o cli`, `LinkFinder -i beautified/ -o cli`, `xnLinkFinder`,
`nuclei -t http/exposures/ -l js.txt`, `retire.js --js`, `whispers --target js_files/`.

### Secrets / Tokens (expanded — AI era + SaaS full coverage)

**Cloud & Infrastructure**
- **AWS** `AKIA…` access key + `aws_secret` 40-char key
- **GCP** `AIza[0-9A-Za-z\-_]{35}` + service-account JSON blob (`"type":"service_account"`)
- **Azure** storage connection strings `DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...`; SAS tokens `?sv=`; tenant ID + `client_secret` in MSAL/ADAL config blocks
- **Databricks** `dapi[a-zA-Z0-9]{32}`
- **Snowflake** `account=...;user=...;password=...` in connection strings
- **MongoDB Atlas** `mongodb+srv://user:pass@cluster`
- **Redis** `redis://:password@host:port`
- **SMTP** `smtp://user:pass@host` in nodemailer/transporter configs
- **PEM private keys** `-----BEGIN (RSA |EC )?PRIVATE KEY-----`

**AI / ML Providers**
- **OpenAI** `sk-[A-Za-z0-9]{48}` and project keys `sk-proj-[A-Za-z0-9_\-]{48,}`
- **Anthropic** `sk-ant-[A-Za-z0-9\-_]{95,}` — full Claude API key
- **HuggingFace** `hf_[A-Za-z0-9]{34,}` — model download + write access
- **Replicate** `r8_[A-Za-z0-9]{40}`
- **Groq** `gsk_[A-Za-z0-9]{52}`
- **Cohere** `[A-Za-z0-9]{40}` with `cohere`/`CO_API_KEY` context
- **Together.ai** `[A-Za-z0-9]{40}` with `together`/`TOGETHER_API_KEY` context
- **Mistral** `[A-Za-z0-9]{32}` with `mistral`/`MISTRAL_API_KEY` context
- **Perplexity** `pplx-[A-Za-z0-9]{48}`
- **Pinecone** API key in vector DB init (`new Pinecone({ apiKey: … })`)
- **Voyage AI** `pa-[A-Za-z0-9]{40}`

**Payments & Finance**
- **Stripe** `sk_live_[0-9a-zA-Z]{24,}` / `sk_test_…`; webhook secret `whsec_[A-Za-z0-9]{32,}`
- **Braintree** `access_token$production$[A-Za-z0-9]{32}`
- **Square** `sq0atp-[A-Za-z0-9_\-]{22}` (access) / `sq0csp-[A-Za-z0-9_\-]{22}` (client secret)
- **Plaid** `client_id` + `secret` in PlaidLink init config
- **PayPal** `client_id` + `client_secret` in SDK init

**Communication & Messaging**
- **Twilio** `AC[a-zA-Z0-9]{32}` Account SID + `SK[a-z0-9]{32}` Auth Token
- **SendGrid** `SG.[A-Za-z0-9_\-]{22}.[A-Za-z0-9_\-]{43}`
- **Mailgun** `key-[a-zA-Z0-9]{32}`
- **Mailchimp** `[a-zA-Z0-9]{32}-us[0-9]{1,2}`
- **Slack** `xox[baprs]-…` / webhook `hooks.slack.com/services/…`
- **Discord bot** `[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}`
- **Telegram bot** `[0-9]+:AAF[a-zA-Z0-9_-]{33}`
- **Pusher** `app_key` + `app_secret` + cluster inline in Pusher JS init

**Developer & SaaS Platforms**
- **GitHub** `ghp_[A-Za-z0-9]{36}` / `github_pat_[A-Za-z0-9_]{82}`; webhook secret `sha256=` signing key
- **Vercel** `vc_[A-Za-z0-9]{32,}` / `VERCEL_TOKEN`
- **Netlify** `netlify-[A-Za-z0-9\-_]{40}`
- **Shopify** `shpss_[A-Za-z0-9]{32}` / `shpat_[A-Za-z0-9]{32}`; webhook HMAC secret
- **Algolia admin key** `[A-Za-z0-9]{32}` with `adminApiKey` label
- **Mapbox** `sk.[A-Za-z0-9]{80,}`
- **Datadog** `DD_API_KEY` / `datadog-[A-Za-z0-9]{32}`
- **Intercom** `[A-Za-z0-9]{8}-[A-Za-z0-9]{4}-…` with `intercom` context
- **Okta** `SSWS [A-Za-z0-9]{42}` API token
- **Auth0** `client_secret` in SPA SDK init; management API token `v2/…`
- **New Relic** `NRAK-[A-Za-z0-9]{27}` license key
- **Sentry DSN** `https://[key]@[org].ingest.sentry.io/[id]` — reveals org, project, DSN secret
- **LaunchDarkly** `sdk-[A-Za-z0-9\-]{40}` server-side key (write access to flags)
- **Segment** write key `[A-Za-z0-9]{32}` with `analytics.load(` context

**Auth & Crypto**
- **JWTs** `eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}`
- **Basic auth blobs** `Authorization: Basic [A-Za-z0-9+/=]{20,}`
- **OAuth** `client_id` + `client_secret` pairs
- **Apple APNs** `.p8` private key + Team ID + Key ID in push notification config

**Firebase / Supabase / Realtime DBs**
- **Firebase config object** `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId` — reveals project, enables unauth REST probing even if the key itself is "public"
- **Supabase** `SUPABASE_ANON_KEY` / `SUPABASE_SERVICE_ROLE_KEY` (service role = full DB access)

**Cloudinary**
- `cloudinary://[api_key]:[api_secret]@cloud_name` in upload preset config

**WebRTC**
- `iceServers` config with `urls: turn:...` + `username` + `credential` — TURN server credentials, test for reuse

### Hidden / Internal / Staging Endpoints
Every endpoint in JS is an UNTESTED endpoint. Real payout pattern: `/api/v2/internal/users`
recovered from obfuscated JS → full user DB → $25k. Also hunt:
- **WebSocket/SSE** `ws://`, `wss://`, `/subscribe`, `/stream`, `/sse`, `/events` — WS endpoints
  skip HTTP auth middleware and are frequently unprotected
- **GraphQL subscriptions** `subscription {`, `/subscriptions`, `/graphql-ws`
- **Deprecated v1 APIs** when v2 added auth — the old version often still runs
- **`window.__NEXT_DATA__`** — Next.js SSR embeds server-side API responses verbatim in HTML;
  often contains auth tokens, session data, internal API base URLs, and user PII
- **`window.__NUXT__`** — same problem on Nuxt apps
- **`window.__remixContext`** — Remix loader data embedded in HTML

### Critical Architecture & Logic Findings (only readable, not greppable)

These are the findings that separate JS readers from JS greppers. No scanner catches these — you find them only by understanding the code.

**Internal attack surface expansion**
- Internal microservice URLs (`http://internal-api/`, `http://10.x.x.x/`, `grpc://`) → direct SSRF targets not reachable from outside
- Shadow API versions: `v0`, `beta`, `internal`, `legacy` paths referenced in code but absent from docs — old version often has no auth
- Admin/ops routes (`/admin`, `/internal`, `/ops`, `/debug`) with comments revealing auth requirements (or lack of)
- Lambda function URLs, API Gateway stage variables, Cloud Function names → direct invocation bypassing WAF/rate limit
- S3/GCS/Azure blob container names in upload/download logic → enumerate + test ACL misconfig
- gRPC service + method names → probe for exposed gRPC-web endpoints without auth
- Cloud account IDs, project IDs, tenant IDs → enumerate cross-tenant

**Auth & authz logic that breaks server-side**
- Client-side role checks (`if (user.role === 'admin')`) → call the endpoint directly with low-priv token; server may never re-validate → BFLA
- Feature flags controlling security controls (`if (flags.skipRateLimit)`, `if (!flags.enforceAuth)`) → send overridden flag value in request/cookie
- Environment detection: `if (process.env.NODE_ENV !== 'production') { skip2FA() }` → probe if staging logic bleeds into prod headers
- Multi-tenant switching: how `org_id`/`tenant_id` is set client-side → test with another tenant's ID → horizontal escalation
- Permission bitmask definitions client-side → craft value that grants escalated bits
- A/B test variant code that unlocks privileged UI or unguarded endpoints for a subset of users

**Business logic & price manipulation**
- Price, discount, shipping, tax calculation done client-side → send manipulated values directly to order endpoint
- Promo/referral/coupon code generation patterns → predictable? Brute-forceable?
- Payment flow state machine definition → identify step-skip to complete order without payment leg
- Quantity / negative-value handling in cart logic → test negative quantities for credit

**Token & crypto weaknesses (read the generation code)**
- Token generation using `Math.random()`, `Date.now()`, or short entropy → predictable; reproduce offline
- Client-side encryption with hardcoded IV or key → decrypt intercepted traffic offline
- Password hashing revealed: `md5(pass + salt)`, `sha1(pass)` → crack offline
- HMAC signing with client-visible secret → forge arbitrary signed requests
- JWT construction showing which claims are client-set and which the server skips validating

**Injection hints buried in logic**
- SQL fragments in ORM calls: `db.raw(userInput)`, `knex.raw(…)`, `sequelize.query(userInput)` → direct SQLi target
- GraphQL query/mutation definitions → identify sensitive fields, hidden resolvers not in introspection
- Template strings fed to eval or innerHTML: `` eval(`SELECT ${input}`) `` → confirmed injection sink
- Regex input validation patterns → find gaps, edge cases, Unicode bypasses

**CORS / postMessage / redirect bypass hints**
- `allowedOrigins` array → find weakest entry (wildcard subdomain? `null` origin accepted?)
- postMessage handler: `event.data[action]()` or `window[event.data.fn]()` without `event.origin` check → XSS pivot from any frame
- Redirect whitelist using `startsWith`: `url.startsWith('https://company.com')` → bypass with `https://company.com.evil.com`
- CORS logic: `if (allowedOrigins.includes(req.headers.origin))` — test `null` origin, `Origin: ` (empty)

**Recon amplifiers (fingerprint hidden features)**
- Analytics event names (`track('admin_panel_viewed')`) → enumerate hidden features/flows not linked in nav
- Error handler stack traces → reveals internal file paths, framework versions, DB query structure
- `console.log` / `console.debug` statements left in prod → tokens, IDs, internal state dumped to DevTools

### Client-Side Auth & Roles
`isAdmin`, `role === 'admin'`, `hasPermission`, `parseJwt`, `atob(token)`,
`localStorage.setItem('admin',…)`, `featureFlags`, `canAccess`, `tier === 'enterprise'`.
Any UI/route gated ONLY client-side → call the endpoint directly with a low-priv token.

### Hidden Routes & Feature Flags
Dump SPA router table (React Router / Vue Router / Angular / Next.js pages directory).
Visit admin/beta/internal routes the nav never links. Flip feature flags (`localStorage`,
`?feature=`, cookie, JSON config, LaunchDarkly/Statsig/Split client keys) to unlock
ungated functionality.

### DOM XSS Sinks
`innerHTML`, `outerHTML`, `document.write`, `eval`, `new Function`, `setTimeout("…")`,
jQuery `$()`, `.html()`, `dangerouslySetInnerHTML`, `v-html`, Angular `bypassSecurityTrustHtml`;
sources `location.hash/search/href`, `postMessage`, `document.referrer`, `window.name` → trace source→sink.

### Prototype Pollution
`__proto__`, unsafe `merge/extend/Object.assign(x.prototype…)`, query-string parsers,
`qs.parse`/`querystring.parse` feeding into merge → gadget chain to XSS/RCE.

### Cloud & 3rd-party Refs
`*.amazonaws.com`/`s3://`, `firebaseio.com`, `storage.googleapis.com`,
`*.blob.core.windows.net`, `cloudfront.net`, `*.digitaloceanspaces.com`,
`supabase.co`, `*.neon.tech`, `*.planetscale.com` → test misconfig + takeover.

### postMessage Without Origin Check
`addEventListener('message',…)` with no `e.origin` check → cross-origin data theft / DOM XSS.

### Dependency CVEs
Map bundled lib versions to OSV/Snyk (`retire.js`). One bundled vulnerable lodash / axios /
DOMPurify / jQuery / Next.js = your bug. **2025 critical:** Next.js CVE-2025-29927
(middleware auth bypass via `x-middleware-subrequest` header — any Next.js ≤ 15.2.2).

### Historical / Version Diffing
Pull OLD JS from Wayback, diff vs live. Secrets and endpoints "removed" from current JS are
frequently STILL LIVE server-side; forgotten APIs survive in old bundles.

### Obfuscation as a Red Flag
Heavy obfuscation (`eval(function(p,a,c,k,e,d)`, string arrays, hex strings, `_0x` var names)
signals the developer was trying to hide something. Deobfuscate with `webcrack` / `synchrony` /
`de4js` and READ — the payoff rate on obfuscated code is higher than on readable code.

---

## RULE 4 — Confirm dynamically, THEN it's a finding (kill false positives)

Nothing gets reported on a regex hit alone. Prove it live:
- **OAuth client creds** → mint a real token:
  `curl -sX POST https://apigw.$T/token -H "Authorization: Basic <BLOB>" -d grant_type=client_credentials`
  → `access_token` returned = confirmed High/Crit (can't rotate without breaking prod).
- **AI API key** → call the provider's identity/model-list endpoint:
  `curl -s https://api.openai.com/v1/models -H "Authorization: Bearer $KEY"` → 200 = live.
  `curl -s https://api.anthropic.com/v1/models -H "x-api-key: $KEY" -H "anthropic-version: 2023-06-01"` → 200 = live.
- **`window.__NEXT_DATA__`** → curl the page without JS (`curl -sL https://HOST/page`) and
  parse the JSON blob from the HTML — if it contains session tokens or user PII, that's a finding.
- **"Internal" endpoint** → hit it unauth / cross-tenant and diff the response.
- **Params from JS** → fuzz `debug=true`, `admin=1`, `callback=`, `redirect=` and JS-seeded names
  (`x8` / `Arjun` from bundle var names) against the endpoints they belong to.
- **DOM XSS** → drive source→sink in real headless Chrome (Playwright preferred over Selenium);
  screenshot the alert/exfil.
- **WebSocket endpoint** → connect with `wscat`/`websocat` without auth header; send a probe message.
- **Next.js middleware bypass** → add `x-middleware-subrequest: middleware:middleware:middleware`
  header to any request behind a Next.js middleware guard; 200/data = CVE-2025-29927 confirmed.
- Feed confirmed secret keys to the **jsmax** skill for exploitation; DOM-XSS / prototype-pollution
  gadgets to the **xss-hunter-agent** skill for payload crafting.

- **Race condition** → fire 20+ parallel requests simultaneously (curl `--parallel` / Python asyncio+aiohttp / Playwright multi-context); confirm with: multiple `200 OK` on one-time-use action, duplicate records, balance goes negative, two success responses for a single-use token. Build the script fresh per target — timing constraints differ per app.
- **Secret new patterns** → confirm with provider identity endpoint: Twilio `api.twilio.com/2010-04-01/Accounts/$SID.json` (Basic auth); Stripe `/v1/account`; Mailgun `/v3/domains`; Discord `/api/v10/users/@me`; Telegram `api.telegram.org/bot$TOKEN/getMe`; Databricks `/api/2.0/token/list`; Supabase service role → `supabase.co/rest/v1/` with `apikey:` header (returns full table data = confirmed)
- **Business logic / price manipulation** → capture the POST body, modify the price/quantity field, replay with curl; confirm server used the client value in response total
- **Internal URL SSRF** → hit it via a server-side parameter that makes the app fetch a URL; confirm with `interactsh` callback or timing difference
- **Multi-tenant ID swap** → repeat the request with a different org/tenant ID; confirm data returned belongs to the other tenant

**Only then write the report.** No "could potentially" — prove it or drop it.

---

## CAPABILITY MAP — what runs autonomously vs. needs human

| Finding class | Autonomous (find + PoC + confirm) | Notes |
|---|---|---|
| Secret in JS | ✅ Full | grep → curl identity endpoint → confirmed |
| Unauth API endpoint | ✅ Full | curl without auth → check data returned |
| CORS bypass | ✅ Full | curl with crafted Origin header |
| SSRF via internal URL | ✅ Full | curl + interactsh callback |
| JWT attack (alg:none, claim tamper) | ✅ Full | craft JWT → curl |
| GraphQL introspection + BOLA | ✅ Full | full query chain |
| Price / business logic manipulation | ✅ Full | modified POST body via curl |
| Redirect bypass | ✅ Full | curl -L with crafted URL |
| Feature flag abuse | ✅ Full | send overridden flag value |
| S3/GCS/Firebase unauth | ✅ Full | aws s3 ls / curl REST |
| Race condition | ✅ Full | curl --parallel / asyncio / Playwright multi-context (script built fresh per target) |
| DOM-XSS | ⚠️ Script provided | Drive with claude-in-chrome or Playwright — needs browser session |
| postMessage XSS | ⚠️ Script provided | Write exploit HTML; user loads it |
| Auth flow logic bugs | ⚠️ Needs session | Requires authenticated cookies/tokens from user |
| CAPTCHA-gated flows | 🚫 Human-in-loop | Firm boundary — user solves, automation continues |
| MFA bypass | 🚫 Needs real device | Requires live TOTP/SMS |
| Client-side crypto weakness | 🔍 Identify + explain | Code identified, math worked through manually |
| Deobfuscation | ⚠️ Tool-dependent | Requires webcrack/synchrony installed; check first |
| Prototype pollution | ⚠️ Script provided | Find sink + write PoC; browser execution needed |

---

# johnwick1 — Full-Spectrum Hunt Orchestrator (standalone)

One command that takes an authorized target from raw scope → understood → fully mapped (unauth + authed)
→ hunted → validated. **Everything is built in** — this skill depends on no other skill. All techniques
(recon commands, JS mining, temp-mail signup, IDOR/backend/GraphQL/403/mobile hunting, validation gates)
live in this skill's own `references/` files. It runs autonomously and **takes its time**, pausing for a
human only at the auth gate. Its defining trait: **it does not skip anything** — a written coverage
ledger makes skipping structurally impossible, and a superpowers verification gate blocks every phase
boundary until the current phase is provably complete.

Authorized testing only. The user supplies in-scope targets — assume authorization is granted.

---

## Rule 0 — The Prime Directive

**Violating the letter of the no-skip rules is violating the spirit of johnwick1.**

The entire value of this skill is *total coverage*. An agent that samples, prioritizes, or "reasonably"
trims is running a different, worse skill. If you catch yourself about to narrow the surface, STOP —
that instinct is the exact failure this skill exists to prevent.

Total coverage has two axes, and both are load-bearing: every **feature** gets touched (breadth), and
every touch is **earned** — a real hypothesis, a real attempt against that class's own playbook, a real
escalation attempt on anything positive (depth). Breadth without depth is a scanner with extra steps.
The bar is the one the best public bug-bounty researchers hold themselves to: nothing is "probably fine,"
nothing is "probably not exploitable" — it's proven, one way or the other, in evidence, per feature.

**A target is never "well-defended" until the ledger says so.** Real targets that have paid out ATO and
RCE before still look clean on whichever cluster you happen to test first — that's survivorship, not
evidence. Don't let two or three clean assets talk you into a target-wide verdict. Every remaining
`untested` row is still a live chance at the critical you haven't found yet.

## Rule 1 — The Hard Rules (never negotiable)

1. **Zero-skip scope.** Every **in-scope** domain and subdomain enters the ledger and must reach `covered`. None is ever dropped. (Bounded by Rule 9 — never touch out-of-scope.)
2. **No prioritization.** All assets are equally important. The run is not done while any asset is `untested`.
3. **Read ALL JavaScript.** Collect JS from live crawl **and `waybackurls`/`gau`** **and `katana`** — dedup the union — then read every file. Vendor/minified/hashed: all of them. MANDATORY. ([js-mining.md](references/js-mining.md))
4. **Never curl-only.** When `curl`/`httpx` is blocked (WAF/403/JS-rendered), fall back to **Playwright real-Chrome**. A block is a tool-switch, not a stop. Triage every 403 through [bypass-403.md](references/bypass-403.md)'s verdict logic before accepting it as either "blocked" or "correctly enforced" — the two look identical in raw status code, and treating a clean, correctly-enforced authz decision as an unsolved block is its own failure (see Rule 10). **Exception: a real CAPTCHA/anti-bot challenge (hCaptcha, reCAPTCHA, Turnstile) is never automated past or stealth-solved** — that's the Phase-3 human gate, not a tool-switch target.
5. **Self-refresh tokens.** When auth expires, refresh it yourself (refresh-token flow, re-login, cookie renewal) before asking the human.
6. **Reverse APIs yourself.** If API docs, OpenAPI/Swagger, GraphQL introspection, or discovery documents exist, reconstruct the full API surface from them.
7. **APK/IPA present → run the mobile workflow** ([mobile.md](references/mobile.md)); its recovered endpoints/secrets feed back into the ledger.
8. **No step skipped, at all cost. Take your time.** Thoroughness beats speed. No deadline justifies cutting a phase.
9. **Scope-bounded — never touch out-of-scope.** "Hit everything" means everything *in scope*. Gate every outbound request through the scope guard; default-deny; exclude third-party services; verify ownership before hitting inferred/acquisition assets. This **overrides** zero-skip when they seem to conflict — the answer is always "verify scope," never "hit it anyway." ([scope-guard.md](references/scope-guard.md))
10. **Exhaust before you concede.** A class is `tested_negative` or `not_applicable` on a **feature** only after the minimum bar from that class's own playbook ran (anti-slop checklist, proof-of-impact bar, kill-list check) — never after one payload. A positive finding is not final until the escalation questions in [chaining.md](references/chaining.md) have been asked and answered — "no further chain found" is a valid, recorded answer; silence is not. This is what "covered" actually means (see the Coverage Ledger).
11. **One clean cluster proves nothing about the rest.** Never generalize "this target is hardened/well-defended" from however many assets you've deep-tested so far — that verdict is only earned when the *whole* ledger is `covered`. A handful of clean 403s on one auth cluster is one data point, not a target-wide conclusion; the next untested subdomain can still be the one with the RCE. Catch yourself the moment you start writing sentences like "this looks like a solid target" mid-run — that sentence belongs only in the final Phase-6 summary, never before.
12. **Research when blocked — never let one failed technique be the final word.** If your first attempt at a bug class is sanitized/blocked/clean, that is the *start* of the exhaustion bar (Rule 10), not the end. Before recording `tested_negative`: (a) run every bypass variant the class's own playbook lists (encoding, context-switching, alternate params, method/verb swap, race, TOCTOU); (b) identify the exact tech/stack/version in play (framework, IdP, PaaS vendor, CMS, library) and actively search — `WebSearch`/`WebFetch` — for known CVEs, disclosed writeups, and misconfiguration classes specific to that stack; (c) try what you find. Only after (a)–(c) does a negative verdict count as exhausted. Be creative: the goal is skilled, structured persistence, not a single clean probe.
13. **Learn across sessions.** At the end of a run (or when you discover something non-obvious mid-run — a bypass that worked, a stack-specific gotcha, a dead-end technique and why), append it to [learnings.md](references/learnings.md). At the start of a run (Phase 1), read learnings.md for anything relevant to the target's identified stack before you start guessing blind. The skill should get sharper every time it's used, not repeat the same dead ends.

## Rule 2 — Rationalizations that mean STOP

If you think any of these, you are about to break Rule 1. Do not.

| Rationalization | Reality |
|---|---|
| "This subdomain is clearly parked/dead, skip it." | Enroll it, probe it, record the *evidence*. "Looks dead" ≠ "verified dead." |
| "These JS files are just vendor/minified bundles." | Vendor bundles leak endpoints, keys, internal hostnames. Read them. |
| "Wayback has 4,000 JS URLs, I'll sample the interesting ones." | Dedup the union and read all. Sampling = Rule 3 violation. |
| "Let me focus on the high-value host first." | No prioritization (Rule 2). Equal coverage or it isn't johnwick1. |
| "curl got 403, this asset is protected, move on." | Triage it through bypass-403.md first (Rule 4/10) — "protected" and "blocked" are conclusions, not observations. |
| "One clean baseline + cross-probe + 403 looks like a complete IDOR test." | It's one feature, one verb. `covered` needs every feature × every applicable class, each with evidence (Rule 10). |
| "WAF/captcha is hard-locking me, I'll switch to stealth Playwright to push through." | A WAF page → tool-switch (Rule 4). A real CAPTCHA → never automated past, rotate/ask instead (Rule 4 exception). |
| "44 of 47 assets are done, momentum says wrap this one fast." | Sunk cost on other assets doesn't shrink this one's surface. Every feature still needs its own verdict. |
| "I'll just ask the user to log in / give a token." | Try auto-signup with temp-mail first, then self-refresh, THEN ask (Phase 3). |
| "This is taking forever, I'll wrap up early." | Take your time (Rule 8). Partial coverage is a failed run. |
| "I'll note it as untested and come back." | The run does not complete while any row is `untested`. Come back now. |
| "Found nothing on the first probe, this class is clean, next feature." | Clean means the class's playbook ran to its own proof-of-impact bar, not one payload (Rule 10). |
| "The account/auth cluster was solid, this whole target is probably hardened." | One cluster ≠ the target. 40+ other assets are still `untested` (Rule 11). Keep going exactly as hard. |
| "I tried the standard payload, it got encoded/blocked, class is clean here." | That's the start of the bar, not the end (Rule 12). Run the full bypass matrix, then search for stack-specific bypasses/CVEs before recording negative. |
| "This is taking a while and I should give the user a status update / ask what's next." | Status updates are fine, but they are not a stopping point. Keep hunting after you send one unless the user explicitly says stop. |
| "The authed area needs a purchase / real customer to reach, so it's blocked." | Before conceding: can a free-tier/trial/demo account reach it? Did you actually try registering as a merchant/vendor, not just checking if SSO auto-creates one? Only mark `not_applicable` after a real registration attempt, not an inference. |
| "17/18 feature rows covered — we're basically done." | That's a depth stat on whatever got *enrolled*. It says nothing about whether 18 is anywhere near the target's real feature count. Report the enrolled-vs-known-to-exist gap too, not just the ratio among rows that exist (coverage-ledger.md). |
| "I saw 8 sibling items in this list/panel/palette but I'm only testing the one I clicked." | Enroll every sibling visible in the same view right now, even as `untested` rows — that's the difference between a real gap staying visible and silently vanishing. |

## Rule 3 — Red flags (self-check)

- You reduced a list "to save time." · You wrote "skip", "sample", "subset", or "most important" about
  in-scope assets or JS. · A phase ended with `untested` rows still in the ledger. · You asked the human
  for creds before attempting auto-signup. · You stopped at a WAF/403 without running it through
  bypass-403.md's verdict logic. · You automated past, or tried to stealth-solve, a real CAPTCHA instead
  of rotating to the next signup provider or the human gate. · You wrote a class into a feature's
  `hunted[]` after one probe, with no `evidence` field. · You marked a positive finding final without
  running the escalation questions in chaining.md. · You tracked an asset with many features as a single
  pass/fail instead of one verdict per feature.

**Any red flag → return to the ledger and finish the coverage.**

---

## The Coverage Ledger (how no-skip is enforced)

At the start of every run, create a per-target run folder and **two** ledgers: `coverage.jsonl` (one row
per in-scope asset) and `features.jsonl` (one row per discovered feature/endpoint/operation within an
asset, populated as Phase 2/4 discover them). Asset-level `covered` is *derived* from feature-level
completeness, never asserted directly — this is what makes "every feature" real instead of "every asset,
once." Schema, init/enroll, mark-done, and the completion-invariant queries are in
**[coverage-ledger.md](references/coverage-ledger.md)**. Mirror both ledgers into the task list so
progress is gated and visible — steady tracked execution, never flailing.

**Completion invariant:** the run is complete only when
`jq -s '[.[]|select(.in_scope and .status!="covered")]|length' coverage.jsonl` prints `0`, no field is
`untested`, and — per coverage-ledger.md — every row in `features.jsonl` has reached a terminal, evidenced
state with escalation questions answered for every positive.

---

## Internal reference map (this skill only — no external skills)

| Phase / topic | Built-in reference |
|---|---|
| Phase gates (superpowers verification between phases) | [phase-gates.md](references/phase-gates.md) |
| Coverage ledger schema + checks | [coverage-ledger.md](references/coverage-ledger.md) |
| **Scope safety guard** (bounds zero-skip) | [scope-guard.md](references/scope-guard.md) |
| Mindset + threat model | [mindset.md](references/mindset.md) |
| Recon pipeline (subs/live/urls) | [recon-pipeline.md](references/recon-pipeline.md) |
| JS mining — read ALL JS | [js-mining.md](references/js-mining.md) |
| Unauth P1/P2 surface | [unauth-p1.md](references/unauth-p1.md) |
| Hidden params + takeover | [params-takeover.md](references/params-takeover.md) |
| Access acquisition + temp-mail signup | [access-tempmail.md](references/access-tempmail.md) |
| Backend classes — **taxonomy hub** | [backend-classes.md](references/backend-classes.md) |
| IDOR / BOLA / BFLA | [authz-idor.md](references/authz-idor.md) |
| SSRF (deep) | [ssrf.md](references/ssrf.md) |
| RCE — deser/dep-confusion/injection/media/upload (deep) | [rce.md](references/rce.md) |
| SSTI (deep) | [ssti.md](references/ssti.md) |
| XXE (deep) | [xxe.md](references/xxe.md) |
| HTTP request smuggling / desync (deep) | [request-smuggling.md](references/request-smuggling.md) |
| Web cache poisoning / deception (deep) | [cache-attacks.md](references/cache-attacks.md) |
| Race conditions / TOCTOU (deep) | [race-conditions.md](references/race-conditions.md) |
| ATO — OAuth/OIDC/SAML/JWT/reset (deep) | [auth-attacks.md](references/auth-attacks.md) |
| SQL / NoSQL injection (deep) | [sqli.md](references/sqli.md) |
| CORS / open-redirect / CSRF / XSS→ATO | [web-misc.md](references/web-misc.md) |
| GraphQL audit | [graphql.md](references/graphql.md) |
| 403/401 bypass matrix | [bypass-403.md](references/bypass-403.md) |
| Mobile (APK/IPA) | [mobile.md](references/mobile.md) |
| WebSocket / CRLF / Host-header attacks | [websocket-crlf-hostheader.md](references/websocket-crlf-hostheader.md) |
| AI / Prompt injection | [ai-prompt-injection.md](references/ai-prompt-injection.md) |
| Payment webhooks / financial state-machine | [payment-webhooks.md](references/payment-webhooks.md) |
| Parser & normalization differentials | [parser-differentials.md](references/parser-differentials.md) |
| Payload arsenal (raw strings) | [payloads.md](references/payloads.md) |
| Exploit chaining — low→critical | [chaining.md](references/chaining.md) |
| Validate & triage gates | [validation.md](references/validation.md) |
| Report writing | [reporting.md](references/reporting.md) |
| Cross-session learnings (read Phase 1, append Phase 6) | [learnings.md](references/learnings.md) |

---

## Start Protocol (first moves when invoked)

1. **Authorization, once, up front.** Before any recon: find and read the target's security/vulnerability-
   disclosure/bug-bounty policy (fetch it if the user gave a URL or it's discoverable; ask the user for the
   program/policy URL if not). Extract whatever real scope, reward tier, and rules-of-engagement it states.
   If no clear policy exists, or scope is ambiguous, **ask the user once** — they hunt with full
   authorization as a matter of course, so this is a one-time confirmation, not a recurring gate. Once
   you have it (from the policy or from the user), that authorization is durable for the entire run: don't
   re-litigate "is this actually authorized" per-asset or per-phase afterward. (Ordinary scope-guard
   ownership checks on individual ambiguous *assets* — e.g. "is this acquisition domain really theirs" —
   still apply per [scope-guard.md](references/scope-guard.md); that's a different, narrower question than
   "do I have authorization to hunt this target at all.")
2. Read the **scope** (in + out) and any creds/cookies the user already has.
3. Create the run folder + `coverage.jsonl`; build the **scope guard** allow/deny model ([scope-guard.md](references/scope-guard.md)).
4. Enroll every in-scope asset as an `untested` row. Mirror to the task list (one task per asset).
5. Announce the plan in one line, then run Phase 1→6 autonomously, pausing **only** at the Phase-3 auth gate
   (or a genuine per-asset scope ambiguity per scope-guard.md — not a re-ask of overall authorization).
   Take your time; skip nothing in scope.
6. Between each phase, run the verification gate ([phase-gates.md](references/phase-gates.md)) before advancing.

## The Pipeline (phases 0–8, in order, skip none)

> **Between every phase:** run the `superpowers:verification-before-completion` gate against that phase's
> exit criteria before starting the next — a phase is "done" only on fresh ledger evidence, never a claim.
> Full per-phase exit criteria are in [phase-gates.md](references/phase-gates.md). Execute all phases
> sequentially, one asset and one class at a time — no subagents, no parallel spawning.

### Phase 0 — Intake & Scope Lock
Resolve authorization once (Start Protocol step 1), then write the in-scope + out-of-scope lists —
including whatever the target's own policy states (reward tiers, disallowed activities, PoC-only rules)
— verbatim to `scope.txt`. Build the **scope guard's allow/deny model** ([scope-guard.md](references/scope-guard.md))
— every later request is gated through it (default-deny; third-parties excluded; ownership verified).
Enroll **every** in-scope asset as an `untested` row in `coverage.jsonl` ([coverage-ledger.md](references/coverage-ledger.md)).
Save any creds/cookies the user already provided to `auth/`. Do not advance until every asset is enrolled.

### Phase 1 — Understand the target
Build the threat model, read developer psychology, choose an impact goal per major asset →
[mindset.md](references/mindset.md). Read [learnings.md](references/learnings.md) for anything relevant
to the stack you're about to see (prior sessions' stack-specific bypasses, dead ends, and gotchas) — cheap
to check, saves re-deriving what's already known. Record the threat model in `notes.md`. It shapes every
later phase.

### Phase 2 — Unauth full-surface recon & app map
Run against **all** enrolled assets: subdomains/live hosts/URL corpus ([recon-pipeline.md](references/recon-pipeline.md));
**JS union read in full** ([js-mining.md](references/js-mining.md), Rule 3); hidden params + subdomain
takeover ([params-takeover.md](references/params-takeover.md)); unauth P1/P2 surface
([unauth-p1.md](references/unauth-p1.md)). Blocked anywhere → Playwright (Rule 4). Set each row's
`recon` and `js_read` to `done`. Enroll every pre-auth feature you can already see (signup, login,
password reset, public API/GraphQL endpoints, pre-auth webhooks/integrations) into `features.jsonl` now —
don't wait for Phase 4 to start the feature ledger.

### Phase 3 — Access acquisition (the ONLY human gate)
In strict order: use provided creds → **auto-signup via temp-mail** (rotate a provider fallback chain,
confirm the email, log in) → only if both fail, ask the human. Set up self-refresh.
→ [access-tempmail.md](references/access-tempmail.md). This is the sole mandatory pause.

### Phase 4 — Authenticated app mapping (MAP FIRST, then attack)

**MANDATORY: Deep manual app walk before any exploitation begins.**
After logging into the attacker account, USE the application as a real user would — in full depth:
- Click every button, link, menu item, and tab
- Trigger every workflow end-to-end: onboarding, profile setup, resource creation, sharing, settings, billing, notifications, exports, imports, invites, integrations
- Visit every route visible in the SPA router — including routes that only appear conditionally
- Complete every wizard and multi-step flow
- Toggle every feature flag, plan tier, or permission visible in the UI
- Watch Burp/mitmproxy the entire time — every XHR, every WebSocket frame, every chunk load is captured
- Repeat key flows as the victim account to understand the full role/permission matrix

**Do not begin Phase 5 until this walk is complete.** Phase 5 is blind without it — every feature you
miss here is attack surface you never test.

Log in and walk the **entire** application before exploitation: every feature, route, role, workflow,
state, API call. Reverse the API from docs/OpenAPI/introspection into `api/` (Rule 6). Enroll newly
discovered authed endpoints/subdomains as fresh `coverage.jsonl` rows, **and enroll every individual
feature/endpoint/operation you just mapped as a `features.jsonl` row** — each with a one-line
developer-psychology hypothesis (mindset.md domain 2: why would *this* feature be the one the devs got
wrong?) and its applicable-class list (default to inclusive when unsure — never silently narrow). Set
`authed_mapped:"done"` per asset only once every feature on it has a row.

### Phase 5 — Hunt (manual + automated)

**Fix-bypass sweep — mandatory at Phase 5 open (before class-by-class hunting starts):**
Before touching any new feature, run a fix-bypass pass on every previously disclosed/fixed bug the
program has published. For each disclosed fix: (1) re-test the exact reported endpoint — does the
original PoC still work? (2) test the identical pattern on every sibling endpoint, sibling tenant,
and adjacent role (horizontal/vertical). Programs almost never fix the class — they patch the one
instance. Load [mobile.md §fix-bypass](references/mobile.md) and [authz-idor.md §escalation](references/authz-idor.md)
patterns. Record results in `fix-bypass.md` (found/not-found per CVE/report).

**Zero-skip execution rules (non-negotiable):**
- Every feature row in `features.jsonl` gets tested. No feature skipped for another.
- Every class in a feature's applicable-class list gets tested. No class skipped for another.
- `not_applicable` requires a CONCRETE reason tied to what the feature actually does — written
  in the evidence field. "Seems unlikely" / "probably not relevant" / "low priority" are NOT
  valid reasons. If you cannot name a specific technical reason the class cannot apply, test it.
- `tested_negative` requires the full class playbook ran — not one payload, not one probe.
  Include what bypass variants were attempted in the evidence field.
- The applicable-class list defaults to INCLUSIVE. When unsure if a class applies, include it.
  Narrowing the list requires justification. Widening it never does.
- Prioritization sets the ORDER of testing, not the scope. Lower-ranked features still get tested.
  Come back and sweep them — the run is not complete until every row is covered.

For **each feature row in `features.jsonl`**, drive it through **every class in its applicable-class
list**, starting from the taxonomy hub [backend-classes.md](references/backend-classes.md), and record
each attempt as an evidenced entry in the row's `hunted[]` (Rule 10 — exhaust before you concede). An
asset's `hunted[]`/`status` in `coverage.jsonl` is a rollup of its features, never hand-set. Assets and
their features may be worked in any order sequentially — Rule 2 forbids favoring one over another, it does not
mandate finishing one asset before touching the next. What's non-negotiable is that none stalls
incomplete: don't leave a feature half-tested to start a fresh one for variety. The per-class checklist
(apply the ones the surface exposes — do not pre-decide a class is absent without checking):

| Class | Internal ref |
|---|---|
| `idor` / access-control | [authz-idor.md](references/authz-idor.md) |
| `auth` | [auth-attacks.md](references/auth-attacks.md) |
| `ssrf` | [ssrf.md](references/ssrf.md) |
| `sqli` | [sqli.md](references/sqli.md) |
| `xss` / web-misc | [web-misc.md](references/web-misc.md) |
| `xxe` | [xxe.md](references/xxe.md) |
| `rce` / injection | [rce.md](references/rce.md) |
| `rce` / deserialization | [rce.md](references/rce.md) |
| `race` | [race-conditions.md](references/race-conditions.md) |
| `ssti` | [ssti.md](references/ssti.md) |
| file upload | [rce.md](references/rce.md) |
| path traversal | [rce.md](references/rce.md) |
| `csrf` | [web-misc.md](references/web-misc.md) |
| open redirect | [web-misc.md](references/web-misc.md) |
| crypto / tokens | [auth-attacks.md](references/auth-attacks.md) |
| secrets in responses | [backend-classes.md](references/backend-classes.md) |
| `smuggling` | [request-smuggling.md](references/request-smuggling.md) |
| `cache` | [cache-attacks.md](references/cache-attacks.md) |
| `graphql` | [graphql.md](references/graphql.md) |
| `mobile` | [mobile.md](references/mobile.md) |
| `websocket` / CSWSH / WS-authz | [websocket-crlf-hostheader.md](references/websocket-crlf-hostheader.md) |
| `crlf` / email-header-injection | [websocket-crlf-hostheader.md](references/websocket-crlf-hostheader.md) |
| `host-header` (token theft, vhost, SSRF) | [websocket-crlf-hostheader.md](references/websocket-crlf-hostheader.md) |
| `ai-injection` (indirect, agent-abuse, stored-XSS, secret-extract, RAG) | [ai-prompt-injection.md](references/ai-prompt-injection.md) |
| `payment-webhook` / financial state-machine | [payment-webhooks.md](references/payment-webhooks.md) |
| `parser-differential` (URL/path/body/identity/header) | [parser-differentials.md](references/parser-differentials.md) |

- `idor` — every id-bearing endpoint → [authz-idor.md](references/authz-idor.md)
- `ssrf` — every URL-fetch/webhook/import/preview/media feature → [ssrf.md](references/ssrf.md)
- `rce` — deserialization blobs, dep-confusion, injection, media/archive/upload → [rce.md](references/rce.md)
- `ssti` — every template-rendered field (email, name, profile, report) → [ssti.md](references/ssti.md)
- `xxe` — every XML/SVG/DOCX/SAML intake → [xxe.md](references/xxe.md)
- `sqli` — every query/filter/sort/id param, logged headers (2nd-order) → [sqli.md](references/sqli.md)
- `smuggling` — front-end/back-end pairs, H/2 → [request-smuggling.md](references/request-smuggling.md)
- `cache` — CDN-fronted paths + unkeyed inputs → [cache-attacks.md](references/cache-attacks.md)
- `race` — every "once-only"/limit/financial flow → [race-conditions.md](references/race-conditions.md)
- `auth` — every OAuth/OIDC/SAML/JWT/reset flow → [auth-attacks.md](references/auth-attacks.md)
- `graphql` — every GQL endpoint → [graphql.md](references/graphql.md)
- `bypass-403` — every 401/403, plus function-level BAC/BFLA on every action regardless of status code → [bypass-403.md](references/bypass-403.md)
- `web-misc` — CORS, open-redirect, CSRF, XSS→ATO, postMessage, clickjacking-with-impact (chain fodder) → [web-misc.md](references/web-misc.md)
- `mass-assign` / `logic` — create/update bodies, money flows → [backend-classes.md](references/backend-classes.md)
- `mobile` — any APK/IPA → [mobile.md](references/mobile.md)
- `websocket` — any `ws://`/`wss://` endpoint, Socket.IO, graphql-ws, Pusher/Ably channels → [websocket-crlf-hostheader.md](references/websocket-crlf-hostheader.md)
- `crlf` — every param that lands in a response header (redirect, lang, callback, X-Request-ID echo) → [websocket-crlf-hostheader.md](references/websocket-crlf-hostheader.md)
- `host-header` — password reset, magic link, invite flow, any URL-generation feature → [websocket-crlf-hostheader.md](references/websocket-crlf-hostheader.md)
- `ai-injection` — any LLM/assistant that ingests user-controlled content, has tool-calling, or renders output to other users → [ai-prompt-injection.md](references/ai-prompt-injection.md)
- `payment-webhook` — every app with payment flows, subscription billing, or financial state transitions → [payment-webhooks.md](references/payment-webhooks.md)
- `parser-differential` — any security gate + execution split (WAF↔app, gateway↔service, email validator↔identity lookup), auth endpoints with multi-step identity resolution → [parser-differentials.md](references/parser-differentials.md)

A **feature** reaches `status:"covered"` only when every class in its applicable-class list is
`tested_negative`, `tested_positive`, or `not_applicable` **with evidence** — not a bare class name. An
**asset** reaches `status:"covered"` only when every one of its features is covered. No feature skipped
for another, no asset skipped for another (Rule 2). Ground hypotheses in the paid-report patterns cited in
each deep file. **After every positive finding, push it to its ceiling** via
[chaining.md](references/chaining.md) — run the six forward questions and record the answers, even
"no further chain found," before the finding counts as final (Rule 10). A chained finding (IDOR→ATO,
SSRF→cloud→RCE, open-redirect→OAuth) is worth an order of magnitude more than the primitive alone.

**Phase 5 close — run sh-chainer (unconditional):**
When all features in `features.jsonl` are closed, invoke `security-harness:sh-chainer` against
`findings.jsonl`. This produces `chains-phase5.md` with cross-finding attack chains. **This step is
not conditional on Phase 7 or Phase 8 running** — it happens at the end of every Phase 5 regardless
of whether source code is available. A low-sev SSRF + a low-sev open redirect in Phase 5 can already
chain to ATO without needing white-box confirmation. Record chains in `chains-phase5.md` and elevate
any chained finding to its chain severity in `findings.jsonl` before entering Phase 6.

### Phase 6 — Validate & report
Run every candidate through the 7-Question Gate + 4 pre-submission gates ([validation.md](references/validation.md)).
Kill theoretical/N-A findings; only proven, reproduced findings survive. Then **write each survivor up**
([reporting.md](references/reporting.md)) — impact-first title, copy-paste repro, evidence of real impact,
CVSS, one bug per report — saved with its evidence in `findings/<asset>/`. Finally, append session
learnings to [learnings.md](references/learnings.md) (Rule 13) — what bypassed what, what stack-specific
research paid off, what was a dead end and why — so the next run starts sharper.

### Phase 7 — Authenticated security-harness pass

**Trigger:** Always runs after Phase 6. No skip condition — you have auth creds from Phase 3 and
a full app surface map from Phase 4. security-harness KB applies to any live target regardless of
whether source code is available.

**What this phase does:** Phase 5 was your manual black-box hunt. Phase 7 is security-harness
running its own systematic authenticated pass — fresh structured sweep per bug class using its KB,
with your live auth session. It catches what Phase 5 misses because sh-kb-* carries class-specific
techniques that go deeper than the general internal reference files. Source code is a bonus, not a
requirement.

**Step 1 — Feed sh-recon your existing surface:**
Pass Phase 4 output to sh-recon: app surface map, full endpoint list, API schema
(Swagger/OpenAPI/GraphQL), JS-derived route table, identified tech stack, any JS secrets or
internal URLs from Phase 2. If source code is additionally available (public GitHub repo,
recovered `.git`, deobfuscated source maps) — pass it too. sh-recon maps whatever exists.

**Step 2 — Invoke security-harness with auth:**
```
/security-review
```
Full 5-stage pipeline using auth session from Phase 3:
- `sh-recon` → maps attack surface from all available inputs
- `sh-hunter` → per bug class, loads `sh-kb-<class>`, hunts live using attacker session
- `sh-chainer` → chains findings into higher-severity combinations
- `sh-verifier` → confirms exploitability with live authenticated requests, builds PoC, assigns CVSS
- `sh-reporter` → produces `findings.json` + report

**Step 3 — Merge with Phase 5/6 findings:**
- Every `verified` finding from security-harness → run through Phase 6 validation gate ([validation.md](references/validation.md))
- Cross-reference against Phase 5/6 results — security-harness may confirm, escalate, or surface new findings
- A finding confirmed by both Phase 5 manual testing and Phase 7 security-harness = strongest PoC, prioritize report

> **Phase 7 gate:** run `superpowers:verification-before-completion` after Phase 7 completes.

---

### Phase 8 — Security-harness augmentation pass

**Trigger:** Runs after Phase 7. All prior phases complete — zero exceptions, zero skips.

**Context available at this point:**
- `findings.jsonl` from Phase 5 (every class tested, what was found, what came back negative)
- Auth creds (attacker + victim accounts) from Phase 3
- Full app surface map from Phase 4
- Phase 7 authenticated security-harness results

**Action:** Invoke the full security-harness pipeline (`security-harness:sh-recon` → `security-harness:sh-hunter` → `security-harness:sh-chainer` → `security-harness:sh-verifier` → `security-harness:sh-reporter`) against the live target. Feed it the Phase 4 surface map and auth creds — 2 accounts, full recon context, cross-tenant checks. Security-harness tests the application from the authenticated angle with full knowledge of what Phase 5 and Phase 7 already covered.

**After:** Any new candidates merge into `findings.jsonl` and run through the Phase 6 validation gate. Run `security-harness:sh-chainer` to catch new chains from Phase 8 findings.

## Completion criteria (do not declare done until ALL are true)
- `jq -s '[.[]|select(.in_scope and .status!="covered")]|length' coverage.jsonl` prints `0`; no field is `untested`.
- `jq -s '[.[]|select(.status!="covered")]|length' features.jsonl` prints `0` — every feature's applicable
  classes are all `tested_negative`/`tested_positive`/`not_applicable`, each with a non-empty `evidence` field.
- `jq -s '[.[]|select(any(.hunted[]?; .status=="tested_positive" and .escalation_attempted!=true))]|length' features.jsonl`
  prints `0` — every positive has an answered escalation record ([chaining.md](references/chaining.md)).
- All JS (live ∪ wayback ∪ gau ∪ katana) was read (files mined == `wc -l js/js-urls.txt`).
- Every applicable class ran on every **feature**: id-endpoints→IDOR; URL-fetch features→SSRF; XML/upload intake→XXE;
  template-rendered fields→SSTI; query/filter params→SQLi; deser/dep-confusion/media/upload→RCE; every 401/403→triaged
  through bypass-403.md; every GraphQL→audit; front/back-end pairs→smuggling; CDN paths→cache; once-only/money
  flows→race; auth flows→ATO.
- Any APK/IPA went through the mobile workflow.
- Every surviving finding passed the full validation gate.
- No `tested_negative` entry was recorded off a single probe alone — each cites what bypass variants were
  tried and, where the first attempt was blocked/clean, what stack-specific research was done (Rule 12).
- `learnings.md` was updated with this session's reusable takeaways (Rule 13).
- Phase 7 ran: security-harness completed its authenticated pass, `findings.json` produced, all `verified` findings merged and run through Phase 6 validation gate.

If any is false, the run is not complete — return to the ledger and finish it.
