# White-box conversion + auth modeling (Phases 2–3)

Goal: turn an opaque API into a full schema you can read — every method, every parameter (including hidden ones), and the exact identity layers that gate each one. This is the work that makes everything downstream possible.

---

## Phase 2 — Enumerate every endpoint and every parameter

### A. Discovery documents (the Swagger/OpenAPI of internal Google)
Google services publish **discovery documents** listing methods + parameters. Public ones are obvious (YouTube Data API); the trick is that **internal services often expose them too**.

- Pull from `https://<service>.googleapis.com/$discovery/rest?version=<v>` and from `.clients6.google.com` variants.
- `people-pa.googleapis.com` had a publicly reachable discovery doc despite being internal.
- **Staging docs leak more than prod**: `*.sandbox.googleapis.com` discovery documents historically included field comments and methods stripped from production. Try `autopush-`, `staging-`, `test-` prefixes.
- If a direct `GET` is blocked by ESPv2 rules, try `X-Http-Method-Override: GET` on a `POST`.

### B. Visibility labels (parameter-gated hidden surface)
Some Google projects expose extra endpoints/fields only when you pass a **visibility label**. Access control here is *obfuscation, not crypto* — if you name the label, you get the surface.

- Add `&labels=<LABEL>` to discovery/doc requests. Confirmed: `PANTHEON`, `GOOGLE_INTERNAL`. These map to internal visibility *annotations* on methods/fields, so the real list is service-specific.
- Signal = **response-size jump** (e.g. 214KB → 329KB, or 253KB → 329KB with `GOOGLE_INTERNAL`). Diff the responses to see what appeared.
- Labels are typically accepted one-at-a-time — iterate the wordlist.
- **Don't invent labels** — harvest them. Grep leaked sourcemaps/proto definitions (e.g. `android-review.googlesource.com`, staging discovery docs) for visibility-annotation tokens (often SCREAMING_SNAKE_CASE near `visibility`/`label`), then test each. Seeing one new label usually points at a naming family for the rest.

### C. req2proto / ProtoJson type-confusion (when no discovery doc exists)
Google transcodes JSON → gRPC via protobuf. **Send the wrong types and the validation error leaks the schema.**

- Set `Content-Type: application/json+protobuf` and POST a positional integer array: `[1,2,3,4,5,...,30]`. The error names fields, types, and indices. The InnerTube `/youtubei/v1/browse` endpoint coughed up 27 params this way, nested messages included.
- Vary types per position (int → bool → string → nested array) to recursively map sub-messages.
- `req2proto` (brutecat's Go tool) automates this into syntactically valid `.proto` files. Build/keep your own equivalent.
- Hidden parameters surface here that the app never sends: `includeSuspended`, `critical_read`, `taskConfigsInternal`. **These are the authz-bypass candidates.**

Minimal runnable starter (hand-rolled req2proto — no external tool needed to begin):
```bash
# Position-by-position type probe. The 400/INVALID_ARGUMENT body names the field at each index.
URL='https://foo-pa.clients6.google.com/$rpc/<package.Service>/<Method>'
for i in $(seq 1 40); do
  body=$(python3 -c "print('['+','.join('1' for _ in range($i))+']')")
  echo "== fields up to $i =="
  curl -s "$URL" -H 'Content-Type: application/json+protobuf' \
       -H "Authorization: SAPISIDHASH <ts>_<hash>" -H 'Origin: https://<calling-app>.google.com' \
       --data "$body" | head -c 400; echo
done
# Then re-probe a field that errored as "expected string" / "expected message" by swapping that
# position to "x" or [..] to recurse into nested messages. Collect names → reconstruct the .proto.
```
brutecat publishes the automated equivalents (`req2proto`, `gapi-service`, `aas-rs`, `gpb`, `bg_gen`) alongside the articles on brutecat.com — grab the current repos rather than relying on the snippet above for scale.

### D. Read responses as proto when JSON is filtered
- `?alt=proto` returns protobuf; pair with `X-Goog-Encode-Response-If-Executable: base64` to bypass browser/domain content restrictions and read raw fields the JSON view omits.

### E. Fallback when there's no discovery doc AND errors are swallowed
Some ESF/GFE configs return no discovery doc and terse errors. Recover method/param names from elsewhere:
- **Mobile app:** decompile the APK (`apktool`/jadx), grep smali/strings for the host and `/$rpc/`, `package.Service/Method` names, and field constants.
- **JS bundles:** the calling web app's chunks contain method names, param keys, and sometimes the full request builders. Run `js-recon-agent` / `jsmax` over them.
- **Proto-definition endpoints:** services that expose a `getProtoDefinition`-style method (`req2proto as a service`) hand you the schema directly — query it for any `fullName` you've seen.
- **Error escalation:** the test/execution path of a feature often reaches deeper backend code and leaks **stack traces** (Java exceptions, internal service+method names) where the normal path returns a clean error. Look for an `executions/.../download` or `:executeTest` style endpoint.

---

## Phase 3 — Auth modeling: the identity layers stack

A big-tech RPC call carries **several independent identity contexts**. A bug is often "this layer is checked, that one isn't." Map which layer gates the data, then attack the weak one.

### The Google layer cake
| Layer | Header / token | Binds | Notes |
|---|---|---|---|
| Project | `X-Goog-Api-Key: AIza...` | which Cloud project | Scrape from JS / DevTools / mobile. Different keys unlock different visibility. |
| User (web) | `Cookie` + `Authorization: SAPISIDHASH <ts>_<sha1>` | logged-in Gaia user | `SHA1(timestamp + " " + SAPISID + " " + origin)`. Compute per request. |
| User (mobile/OAuth) | `Authorization: Bearer ya29...` | OAuth scopes | Mint from an Android refresh token (below). |
| App | `X-Goog-Spatula` (b64 protobuf) | which app (package + sig) | **DroidGuard attestation field is NOT validated** → impersonate any Android app by editing package name + signature hash. Unlocks Android-only APIs (`gameswhitelisted.googleapis.com`). |
| App (key restriction) | `X-Android-Package`+`X-Android-Cert` / `X-Ios-Bundle-Identifier` / `Referer` | satisfies API-key restriction | Supply the matching value (collected from apps) to bypass browser/Android/iOS key restrictions. **Server/IP restrictions can't be bypassed.** |
| First-party | FPA v2 token | privileged first-party origin | Format `<ts>_<sha1>_<ids>`; ids: `e`=email, `u`=obfuscated Gaia, `a`=Workspace domain. `*.corp.google.com` origins had **no restriction** in FPA validation. |
| Assertion (JWT/idToken) | `Authorization: Bearer <firebase/idToken>` | claims inside the token | Backend may verify the **signature but not the claims**. Self-register via `identitytoolkit.googleapis.com/v1/accounts:signUp?key=<apikey>` (works even for `@google.com` emails), decode the returned idToken — `email_verified:false` — and send it to the management API. If access is granted, authZ trusts an unverified assertion (mjyKuWrfd, Cloud VRP $1,337). **Always decode the token and test whether `email_verified` / `aud` / `iss` / role claims are actually enforced.** |

### Host family matters: `clients6` vs `googleapis`
Same service, two fronts — they auth differently. Identify which you're hitting before computing anything.

- **`*.clients6.google.com`** = first-party front. Auth = **cookie + `SAPISIDHASH` + `X-Goog-Api-Key`**, called from a Google web app. Discovery doc is usually still at `/$discovery/rest?version=`.
  - **Any logged-in account often suffices** — these fronts authenticate that you're *a* Gaia user, not that you own the data. `realtimesupport.clients6.google.com/v2/changes:list` returned **global** support agent + customer PII to any account (VBbY59QXh, $14,337).
  - **`list` / `changes` / time-range RPCs leak globally:** methods that take two timestamps or a "since" cursor frequently return *all* tenants' records in that window with no per-tenant filter. Treat any `*Changes`/`List*` method as a cross-tenant dump candidate.
- **`*.googleapis.com`** = key/OAuth front. Auth = `X-Goog-Api-Key` and/or `Authorization: Bearer ya29...`. No cookie context.
- The same backend often answers on both; if cookie auth is blocked on one, try the other front for the same method.

### SAPISIDHASH — get `origin` right or you get a silent 401
`Authorization: SAPISIDHASH <unix_ts>_<sha1hex>` where `sha1hex = SHA1("<unix_ts> <SAPISID> <origin>")` (space-separated).

- **`origin` is the calling web app's origin, NOT the API host.** For a `-pa.clients6` call made by Docs, `origin = https://docs.google.com` (the `Origin` header you send), not `https://foo-pa.clients6.google.com`. Wrong origin → 401 with no hint, so confirm by matching a real request from the product's own traffic.
- Variants exist: `SAPISID1PHASH` / `SAPISID3PHASH` use the `__Secure-1PSAPISID` / `__Secure-3PSAPISID` cookies with the same formula. Send all three (`SAPISIDHASH ... SAPISID1PHASH ... SAPISID3PHASH ...`) space-joined if one alone fails.
- **Browser-relay to dodge CORS:** the simplest way to fire a first-party call with the right cookies + origin is from the API host's own tab. Open `https://<api-host>/` directly (it may **404 — that's fine**), then run your `fetch()` in the DevTools console: it executes **same-origin**, so no CORS preflight blocks it and `document.cookie` gives you `SAPISID` to compute the hash. The Real-time Support leak ran entirely this way. Compute the hash in-page:
```js
const ts = Math.floor(Date.now()/1000);
const sapisid = document.cookie.split('; ').find(r=>r.startsWith('SAPISID=')).split('=')[1];
const buf = await crypto.subtle.digest('SHA-1', new TextEncoder().encode(`${ts} ${sapisid} ${location.origin}`));
const hash = [...new Uint8Array(buf)].map(x=>x.toString(16).padStart(2,'0')).join('');
const auth = `SAPISIDHASH ${ts}_${hash}`; // -> Authorization header
```

### Get a Bearer token from an Android refresh token
1. Auth via `accounts.google.com/EmbeddedSetup`, grab the `oauth_token` cookie.
2. `POST android.googleapis.com/auth` with a random 16-hex `androidId`, the token, package `com.google.android.gms`, client signature → returns `Token=aas_et/...` (a master refresh token, visible in account security).
3. Exchange the `aas_et/` token for per-scope `ya29.` bearers.

### Don't guess scopes — make the error tell you
Send a request with insufficient auth; the `WWW-Authenticate` response header lists the **exact OAuth scopes** required. Brutecat's `gapi-service` automates token mint + scope extraction. Same idea generalizes: 401/403 bodies on big-tech APIs frequently name the missing permission/role.

---

## Doing this at scale (the $500k pattern)

When you have many keys × many labels × many params, automate with an agent + tools (MCP):
- `probe_api(endpoint, body)` → fires the **same request across every collected API key**, returns responses **grouped by hash**. The key whose hash differs is the one with extra visibility.
- Normalize cryptic errors into stable classes (`MISSING_REQUIRED_VISIBILITY_LABEL`, `INVALID_ARGUMENT`) so the agent doesn't misread an ACL rejection as a dead end.
- Tie every probe to an **operation id**; require it in any "finding" so you can't hallucinate a bug without the request/response to back it.
- False-positive discipline (Google's own reporting bar): **enumeration is not a bug**; 500/401/403/404 are not bugs; a finding = **2xx returning data you shouldn't be able to read/write**.

---

## Cross-vendor translation (Microsoft / Adobe / others)
The *primitives* are identical; only the plumbing changes. When the target isn't Google, find the local equivalent of each:

| Google primitive | Look for on other big-tech |
|---|---|
| Discovery document | OpenAPI/Swagger JSON, `$metadata` (OData on Microsoft Graph), GraphQL introspection, `.well-known/` |
| Visibility labels | feature flags, `api-version` query param (Azure), preview/beta endpoints, `x-ms-*` toggle headers |
| req2proto type-confusion | OData/GraphQL/JSON schema errors that echo field names; verbose validation messages |
| Identity layer cake | AAD bearer + `x-ms-*` app headers (MS); IMS token + `x-api-key` + client id (Adobe) |
| Staging hosts | `*-ppe.*`, `*-int.*`, `*.test.*`, `canary`, `edog` (MS); `*-stage.adobe.io`, `cc-api-*-stage` (Adobe) |
| Scope-from-error | 401/403 bodies and `WWW-Authenticate` naming the required role/scope |
