# Bug-pattern playbook (Phases 4–5)

Each pattern: **signal** (when to suspect it), **test** (own-account PoC), **escalate** (low→critical). Run these only after Phase 2 gave you the *full* parameter set — you cannot test what you cannot see.

---

## 1. Cross-tenant IDOR (the #1 big-tech bug)
**Root cause:** auth verifies *your* project/account/org, but not that the named resource belongs to it.

- **Signal:** request contains a resource path you don't fully control — `projects/<id>/.../versions/<uuid>`, `accountId`, `orgId`, `gaiaId`, `contentOwnerId`, an opaque UUID.
- **Test:** from tenant A, request tenant B's resource id (use two tenants you own). 2xx with B's data = bug. The Google Cloud RCE chain did exactly this: `GET /v1/projects/<attacker>/.../versions/<victim-uuid>` returned the victim's full integration because auth only checked the attacker's project.
- **Escalate:** if the id is a UUID you can't guess, pair with an **oracle** (pattern 5) to extract it, or find a sibling endpoint that *lists/reflects* ids.
- **Multi-RPC id-chaining:** when the gating id is unguessable, find the RPC that *mints* it from a guessable one. Google Ads Bulk Actions: brute the 8-digit `script_id` in `ScriptService/Preview` → it returns a 20-digit `execution_id` → `ExecutionProgressService/GetIncrementalProgress` returns the script output (ZP6MgzwGr, $5,000). Don't abandon a chain because step 2 needs a long id — step 1 often hands it to you.

## 2. Hidden-parameter authorization bypass
**Root cause:** an undocumented field flips an access check or expands the response.

- **Signal:** req2proto/ProtoJson surfaced a param the app never sends — `includeSuspended`, `critical_read`, `*Internal`, `includeDeleted`, `view=FULL`, `adminMode`.
- **Test:** set it `true`/elevated on an endpoint that 403s on sensitive fields. YouTube creator-email chain: `includeSuspended: true` on `get_creator_channels` exposed the `contentOwnerAssociation` the ACL otherwise hid.
- **Escalate:** the newly-exposed object usually contains an **id for another service** → go to pattern 3.

## 3. Cross-service ID → PII resolution chain
**Root cause:** service A leaks an opaque user id; a *different*, less-monitored service B resolves it to email/phone with no ACL.

- **Signal:** you hold an obfuscated user id (Gaia id, content-owner id, device id) but not a name/email.
- **Test:** enumerate *other* products that accept that id type — sharing, licensing, collaboration, recovery, notification flows are the usual culprits. Two real resolvers:
  - YouTube `get_item_context_menu` → Gaia id; **Pixel Recorder** `WriteShareList` → `["uuid",null,[["<gaiaId>",2,null]]]` returned `email` with no permission check.
  - Nest `look_up_by_nest_id` → unobfuscated Gaia id; Play Books license-owner-add → Gaia→email.
- **Stealth:** if the resolver sends the victim a notification, suppress it (pattern 9).
- **Escalate:** this *is* the critical — "leak the email/phone of any user." Stop and write it up.

## 4. Staging / sandbox → production data bleed
**Root cause:** non-prod hosts mirror prod data but disable ACLs, signature checks, or auth.

- **Signal:** any `*.sandbox.googleapis.com`, `staging-*`, `test-*`, `autopush-*` (MS: `*-ppe/-int/edog/canary`; Adobe: `*-stage.adobe.io`).
- **Test:** replay a prod request against the staging host. Watch for: weaker/no ACL, disabled query-signature validation (Cloud Console GraphQL staging let unauthenticated introspection through), richer discovery docs, the same DB.
- **Escalate:** staging often re-opens an endpoint Google already "fixed" in prod — re-test a patched bug on `autopush-`/`staging-` first.

## 5. Oracle / binary-search extraction
**Root cause:** the API lets you *compare* a secret without reading it.

- **Signal:** filter params accept operators (`field > "x"`, `<=`), or response **size/timing/status differs** based on a hidden value.
- **Test:** binary-search the secret. Cloud RCE chain extracted a 32-char hex UUID in ~128 requests via `workflow_id > "<low>" AND workflow_id <= "<high>"`. Visibility-label hunting used **response-size deltas** (253KB vs 329KB) as the oracle.
- **Escalate:** feed the extracted id straight into pattern 1 (IDOR) or pattern 3 (PII resolve).
- **Prefix / search oracle:** a search or filter endpoint that returns a presence marker (a CSS class, a non-empty result, 200-vs-empty) for *valid* prefixes lets you reconstruct redacted/secret values character-by-character. Google Groups member search `?q=email:abc*` returned HTML containing `class="LnLepd"` only when the prefix matched a real member → rebuild masked emails (`ab****@x.com`) one char at a time (MMNdrjKyr, $2,337). Any `startsWith`-style filter on sensitive data is an extraction oracle.

## 6. Internal feature exposed in a public API
**Root cause:** the public API version inherits internal-only task/field types with incomplete checks.

- **Signal:** schema shows task/action types the UI never offers — `PythonTask`, `GenericStubbyTypedTaskV2`, `CreateBuganizerIssueTask`, `taskConfigsInternal`.
- **Test:** submit a config using the internal type. Even if execution is blocked, **error/stack-trace depth** tells you how far it reached. The test-case path (`testCases:executeTest`) reached deeper backend code than normal execution and surfaced real Java exceptions + the internal Stubby caller.
- **Escalate:** if the internal task makes outbound RPCs/HTTP with a **production service identity**, that's RCE/SSRF-as-the-service. The first Cloud RCE ran arbitrary Stubby calls via `GenericStubbyTypedTaskV2` as the integration platform's prod identity → $60k.

## 7. Rate-limit / abuse-token bypass (mass-extraction enabler)
**Root cause:** rate limiting keys on IP; abuse tokens are accepted out of their minting context.

- **Signal:** an endpoint that leaks one bit per request (account-exists, phone-mask digit) but is IP-rate-limited or captcha-gated.
- **Test:** (a) **IPv6 /64 rotation** — a Vultr-style /64 = 1.8×10¹⁹ source addresses; bind a random source per request. (b) **Abuse-token reuse** — mint a BotGuard/captcha token on the JS-enabled flow and replay it on the No-JS/API flow that doesn't rate-limit it. The Google phone-leak combined both to hit ~40k checks/sec.
- **Authorization line:** prove the *bypass* against your own account/number. Do **not** actually mass-harvest real users — demonstrate throughput on data you own.

## 8. Fix-propagation timing
**Root cause:** patches roll out unevenly across load-balanced backends.

- **Signal:** an endpoint that *started* returning `PERMISSION_DENIED` after you reported/triggered a fix.
- **Test:** retry repeatedly right after the change; some requests route to unpatched backends and still succeed. Used to get past `createDraftWorkflow` ACL during fix rollout.

## 9. Notification suppression (stealth)
**Root cause:** the alerting path has weaker input validation than the action path.

- **Signal:** the action that leaks data also emails/notifies the victim.
- **Test:** oversize an attacker-controlled field so the notification builder fails silently while the core action commits. A ~2.5M-char recording title broke the email-notify path but the share still resolved the email.

## 10. Cross-tenant resource squatting (pre-provision claim)
**Root cause:** a service auto-creates a per-tenant resource with a *predictable name* in a *global namespace* and never verifies the resource doesn't already exist / isn't attacker-owned.

- **Signal:** a setup/provisioning flow creates a GCS bucket, Pub/Sub topic, dataset, Artifact-Registry repo, or package named from your `project_id`/`project_number`/email/domain in a guessable format — e.g. `${project_id}-us-central1-adc`.
- **Test:** in a project **you own**, pre-create the resource using the *other* tenant's predictable name (you only need their `project_id`) and grant yourself broad access (`--member=allUsers --role=roles/storage.admin`). When the victim enables the service, their artifacts read/write through *your* resource.
- **Escalate:** read → secrets / IP / Terraform state; **write → plant malicious Terraform / config / package → RCE in the victim's pipeline**. Same family as dependency-confusion. (HRDqQWSLs — Application Design Center bucket squatting, $13,337.)
- **Authorization line:** squat a name only **between two projects you control**. Never pre-claim a live tenant's namespace — that's the attack, not a PoC.

## 11. Alternate-client / SDK ACL divergence
**Root cause:** the same resource is reachable through several clients (web UI, REST, GraphQL, mobile, **Apps Script**, **API Explorer**, CLI) that **don't share the same authorization code**. The UI hides a field; another client returns it.

- **Signal:** the web UI *deliberately* hides data from non-owners (editor emails, a linked form, admin-only stats) but you hold the resource id — often lifted from a public "view-only" share link.
- **Test:** request the **same id through a different client**:
  - Apps Script server-side runs with weaker ACLs than the product UI: `DocumentApp.openById(id).getEditors()` leaked all editor emails of a public doc (7EhAw2hur, **$15,000**); `SpreadsheetApp.openById(id).getFormUrl()` leaked the linked Form so an attacker can forge responses (yBeFmSrJi, **$7,500**) — both with only viewer/no access.
  - API Explorer "Try it!" executes with elevated service creds even when the UI gates the feature (see case 2 / P2).
  - The REST/GraphQL/mobile endpoint for the same object.
- **Escalate:** id-from-public-link → editor PII, linked-form write, admin-only fields.
- **Lesson:** "the UI hides it" ≠ "the backend protects it." For any object you can name, enumerate **every** client that can open it.

## 12. SSRF via URL-validation / import-by-URL feature
**Root cause:** a feature fetches a **user-supplied URL** server-side (validate, import, preview, webhook test, discovery/descriptor URL, OpenAPI-spec URL, avatar-from-URL).

- **Signal:** any field the server will retrieve: "OpenAPI Spec URL", "Validate", `descriptorUrl`, webhook target, RSS/import, image-by-URL.
- **Test:** point it at a Collaborator (confirm SSRF), then `http://169.254.169.254/computeMetadata/v1/...` / `http://metadata.google.internal/...` (GCP needs `Metadata-Flavor: Google`; if the fetcher won't add it, look for header-injection or an open-redirect gadget that does), link-local, and internal hostnames.
- **Escalate:** cloud-metadata SA token (default `cloud-platform` scope = huge blast radius) → call other Google APIs; reach internal-only services; read internal responses. (PnwRwydmr — AppSheet Apigee "OpenAPI Spec URL" → partial GCP metadata, $1,500. Cloud DM `descriptorUrl` + internal transport → full internal RPC mesh, $31,837 — see case B.)
- **URL-allowlist bypass** (fetcher allowlists a domain via substring / `in` / `startsWith` / `endswith` without parsing): a leaked OAuth token went to the attacker because the yum plugin matched `'pkg.dev' in url` (H7Cxz8j7j). Bypass set when the check isn't a real host-parse:
  - `https://attacker.com/pkg.dev/` · `https://pkg.dev.attacker.com` · `https://rpmpkg.dev/` · `https://attacker.com/mirror?x=test-yum.pkg.dev/`
  - generic: `https://target.com.attacker.com` · `https://target.com@attacker.com` · `https://attacker.com#target.com` · `https://attacker.com/target.com/`
  - Fix is always `urlparse(u).scheme=='https' and netloc.endswith('.target.tld')` — so the bug is anywhere that *isn't* doing that.

## 13. Client-side-only permission gating
**Root cause:** a privileged action is blocked **only in the UI** (disabled button, hidden menu, "you must be the owner" toast) with no server-side authz re-check.

- **Signal:** the UI says you lack permission, but you can see the request the privileged action *would* send.
- **Test:** (a) flip `disabled=""`→`enabled=""` (or delete the attribute) in DevTools and click; (b) or just replay the raw request with your session. If the server performs it → bug. (5XZmpiNfg — a *Full*-permission Search Console user exported a property's full unsampled performance data to **their own BigQuery** and could stop others' exports, $3,133.70.)
- **Escalate:** access that **persists after you're removed** (BigQuery export keeps streaming), or exfil to an attacker-controlled sink. Pays on big-tech despite being "just a disabled button."

## 14. Read/write authz-gate asymmetry ← check this FIRST on any role-gated feature
**Root cause:** the app gates the privileged **action** (write / moderate / approve / solve / delete) behind a role, rank, or trust tier — and forgets to apply the same gate to the **read** that sits behind it. Reads and writes are authorized by *different code paths*; only one got the check.

- **Signal:** the UI tells you you're not allowed to *do* something — a disabled "Solve"/"Approve"/"Manage" button, a "Reach Level 2", "owner only", "upgrade to admin" toast — **yet the data those actions operate on is already rendered on your screen.** Any editor / moderation / review / admin / approval queue is a prime candidate.
- **Test:** with a **fresh, zero-privilege account** (this is the account that proves it), confirm your role is bottom-tier (`GET /api/user/get`-style → `isEditor:false, rank:0`). Then call the **read** RPCs directly — the list method (`search*`, `list*`) and, crucially, the **per-item detail** method (`get*`) — and check they return 2xx with full data despite your account being barred from the write. (Waze: writes gated "Reach Level 2"; `searchMapUpdateRequests` returned 500 records + usernames + GPS, and `getMapUpdateRequest` returned each reporter's full driven route + payment-service enrollment — to an `isEditor:false, rank:0` account, no gate at all. $11,337.)
- **Escalate:** always open the **detail** read, not just the list — the list understates impact (single GPS pin) while the detail returns the severity-setting fields (full route, PII, payment/government-service status). Then apply impact amplification (whose data + scale) — see SKILL.md.
- **Why it pays big:** the data belongs to **non-consenting end users**, not editors, and one viewport tiles globally. This is authenticated mass-PII, not "an editor saw editor data."
- **Sibling of:** P13 (client-side-only gating — write path) and P1 (cross-tenant — resource axis). This pattern is the *read-vs-write* axis: same account, same tenant, the gate simply isn't on the read.

---

## Triage gate before reporting (Google's own bar — applies broadly)
A finding must be a **2xx returning data you should not be able to read or write**. Kill it if:
- It's only **enumeration** ("I can iterate ids") with no data disclosure.
- It's a 500 / 401 / 403 / 404 / existence oracle with no payoff.
- You can't reproduce it with a clean PoC using **your own** accounts.

**Then set severity by the data subject, not the endpoint** (this is the difference between P4 and P1):
- **Whose data is it?** Records tied to *non-consenting end users* with persistent identity (username/email) = high. "An editor saw editor data" = low. Trace every record back to a person.
- **How sensitive once expanded?** Open one record's *detail* and enumerate every field — route/location history, payment/government-service enrollment, contact info set severity; the list view hides them.
- **What's the scale?** Records-per-query × tileable/enumerable = blast radius. Prove the *mechanism* with a count + one redacted sample; **never** harvest the dump.

Then hand to `triage-validation` → `report-writing`.
