# Capture & decode — the engine (Phases 1–2)

Turn the black box into a white box for **any** backend, in **any** wire format. This is the reproducible core behind both brutecat's Google chains and the Waze gRPC-web PII leak: recon finds *hosts*; **only driving the real client and decoding what it sends finds the surface where the bugs are.** gRPC-web is one format below — the method is identical for protobuf-JSON, GraphQL, batch-JSON, WebSocket, and msgpack.

> **The invisible-surface rule:** every request you can't read is an endpoint you can't test. A hunter who bounces off `application/grpc-web-text` never sees the method that leaks the data. Decode everything.

---

## Part 1 — Drive the real client (capture EVERY protocol)

Tools crawl static/linked assets. They do **not** trigger auth-gated routes, lazy chunks, or binary RPCs fired only on interaction. You must be the client.

### A. Session bootstrap
- **Sign in.** Signup automation is fine (temp-mail via mail.tm / mail.gw for verification). **Never bypass captcha / anti-bot** — human-in-the-loop split: the human solves the captcha, automation continues. A fresh, zero-privilege account is exactly what you want — it's the account that *proves* the read/write asymmetry (Waze PoC account: `isEditor:false, rank:0`).
- **Reuse an existing authenticated session directly** when you have one: pull the cookie jar (`_web_session`, `_csrf_token`, `SAPISID`, etc.) from the live browser and replay requests with `curl -b`/`-H`. The session cookie *is* the token — the human types a prompt, the browser holds the credential.

### B. Capture surface (proxy inline, then click everything)
Put Burp or mitmproxy inline (or use the browser DevTools Network panel / `mcp__claude-in-chrome__read_network_requests`). Then **click every**: route, tab, modal, multi-step wizard, settings pane, admin/moderation/**review** panel, bulk action, export, and every feature toggle. Each interaction fires requests no crawler ever will. Enable Burp **JS Miner** + **Param Miner** to run passively while you browse.

Record **all** of these — not just the JSON ones you can already read:

| You see | It is | Decode with |
|---|---|---|
| `application/grpc-web-text` | base64-wrapped gRPC-web protobuf | Part 3-A (flagship) |
| `application/grpc-web+proto` | binary gRPC-web protobuf | Part 3-A |
| `application/json+protobuf` / `application/x-protobuf` | protobuf-JSON (positional arrays) / raw proto | Part 3-B |
| `application/json` with `[[["rpcid",...`  | Google `batchexecute` batch-RPC | Part 3-D |
| `application/graphql` / `{"query":"..."}` | GraphQL | Part 3-C |
| `application/x-msgpack` / octet-stream that isn't proto | MessagePack | Part 3-E |
| `ws://` / `wss://` frames | WebSocket (often JSON or proto inside) | Part 3-F |
| opaque base64 in a JSON field | nested proto / encrypted blob | Part 3-A, then triage |

### C. Mobile (a second, richer surface)
The mobile app frequently talks to endpoints and base URLs the web app never exposes. Proxy it; if TLS-pinned, bypass with objection/Frida (`mobile-pentest` skill). Decompile the APK/IPA (`apktool`/jadx) and grep for hosts, `/$rpc/`, `package.Service/Method` names, field constants, and hardcoded keys — these hand you method/param names even when traffic is swallowed.

---

## Part 2 — Identify the format (30-second triage)
1. **Content-Type header** — the table above resolves most cases immediately.
2. **First bytes after base64-decode** — gRPC-web starts with a 5-byte frame header: 1 flag byte (`0x00` data / `0x80` trailer) + 4-byte big-endian length. If byte 0 is `0x00`/`0x80` and the length matches, it's gRPC-web.
3. **Printable protobuf tells** — field tags render as low bytes (`0x0a`=field1 len-delimited, `0x12`=field2, `0x1a`=field3…); mixed with readable strings = protobuf.
4. **`[[[` or `[null,` positional arrays** = protobuf-JSON or Google batch.
5. When unsure, throw the raw bytes at `blackboxprotobuf` / `protoscope` — if it parses as a clean field tree, it's protobuf.

---

## Part 3 — Decode each wire format

### A. gRPC-web / grpc-web-text  ← the Waze flagship
`grpc-web-text` body = **base64** of one-or-more **length-prefixed protobuf frames**. Steps:

1. **base64-decode** the whole body.
2. **Strip framing:** byte 0 = flag, bytes 1–4 = big-endian length, then that many bytes of protobuf. Repeat for trailer frame (`0x80`).
3. **Parse the protobuf** without a `.proto` (blackbox):
```python
import base64, struct, blackboxprotobuf
raw = base64.b64decode(open("body.b64").read())
off = 0
while off < len(raw):
    flag = raw[off]; ln = struct.unpack(">I", raw[off+1:off+5])[0]
    msg = raw[off+5:off+5+ln]; off += 5 + ln
    if flag & 0x80:  # trailer frame (grpc-status/message), not data
        continue
    decoded, typedef = blackboxprotobuf.decode_message(msg)
    print(decoded)          # field-number → value tree
```
4. **Decode the fields protobuf hides as numbers.** Lat/lon are **fixed64 doubles**, not the ints blackbox shows. For any `fixed64`/8-byte field that looks like garbage, reinterpret:
```python
lat = struct.unpack('<d', struct.pack('<Q', field_value))[0]   # little-endian IEEE-754
# Waze: f2 = {lon: -0.053779, lat: 51.490745} → two fixed64 doubles in a sub-message
```
5. **Map field numbers to meaning** by correlating with the UI (the record you opened in the browser shows `username`, `timestamp`, `route` — match them to `f8`, `f16`, `f2`). Build a running `field→name` legend for that method.

**Tooling:** `grpcurl` (if reflection is on), `protoscope` (hex↔proto), `blackboxprotobuf` (Python/Burp ext — decode *and* re-encode for tampering), Burp **gRPC-web** support (Repeater decodes grpc-web natively — use it to tamper fields and re-fire).

### B. protobuf-JSON (`application/json+protobuf`)
Google transcodes JSON→gRPC. Body is a **positional array** (`[val1, val2, …]`), field *names* omitted. To recover the schema, **send wrong types and read the validation error** (req2proto / ProtoJson type-confusion) — full recipe in `whitebox-recon.md` §C. Hidden params surface here that the client never sends (`includeSuspended`, `critical_read`, `*Internal`) — those are your authz-bypass candidates.

### C. GraphQL
Run introspection (`{__schema{types{name fields{name}}}}`); if disabled, recover the schema from JS bundles (`js-recon-agent`) or field-suggestion errors (`clairvoyance`). Then hunt field-level authz: request sensitive fields/edges your role shouldn't see, and `node(id:)`/`userByEmail(email:)`-style resolvers for BOLA (TiNeBTPio: `userByEmail` → any user PII, no authz). Batch/aliased queries bypass some per-request checks.

### D. batch-JSON (Google `batchexecute`)
`https://<host>/_/<App>/data/batchexecute` bodies look like `f.req=[[["<rpcid>","[\"arg\"]",null,"generic"]]]`. The `rpcid` is the method; the inner string is JSON-in-JSON args. Enumerate `rpcid`s from the app's JS (`WIZ_global_data`, `AF_dataServiceRequests`), replay with your session, tamper the args. Same authz questions as any RPC.

### E. msgpack / other binary
`msgpack` decodes with `msgpack.unpackb(raw, raw=False)`. CBOR → `cbor2`. Amf/Thrift/Avro have their own libs. The point is identical: get to a readable field tree, catalog it, tamper it.

### F. WebSocket
Log frames (Burp/mitmproxy WS view). Inner payload is usually JSON or protobuf — decode per A/C. Test authz on subscribe/publish messages and on message-level resource ids (channel/room/doc ids you don't own).

---

## Part 4 — Catalog every method + field, then tamper

Once decoded, **write down**, per method: full path/`rpcid`, every field number/name/type (including ones the client never sends), which identity layer it requires, and what it returns. This catalog *is* the white box — you can now:

- **Tamper resource ids** → cross-tenant IDOR (name tenant B's id from tenant A). Re-encode the protobuf with `blackboxprotobuf.encode_message(decoded, typedef)` after editing a field, re-frame (Part 3-A step 2 in reverse), re-base64, re-fire.
- **Flip hidden bools/enums** → hidden-parameter authz bypass (`includeSuspended:true`, `view:FULL`).
- **Swap the sibling method** → the read behind a gated write (Part: read/write asymmetry, `bug-patterns.md` P14). If `searchX`/`getX` exists next to a gated `updateX`/`solveX`, call the reads with your unprivileged account.
- **List/changes/time-range methods** → cross-tenant dump candidates (any `List*`/`*Changes`/`since`-cursor RPC — see `whitebox-recon.md`).

Those are the *authorization* routes (highest yield). But the decoded catalog feeds the **entire** bug taxonomy — the same tamperable fields reach SQLi, SSTI/XSS, SSRF, mass assignment, business logic, race conditions, deserialization, XXE, upload, token attacks, GraphQL abuse, and prompt injection. For each field, consult **SKILL.md → "The decoded surface feeds every bug class"** and route to the matching specialist skill. Decoding is protocol-specific; *what you do with the decoded field* is not.

---

## Part 5 — Replay authenticated requests (mechanics)

- **Direct curl:** copy the cookie jar + CSRF header; `curl -X POST <url> -H 'Content-Type: application/grpc-web-text' -H 'X-Grpc-Web: 1' -H 'X-CSRF-Token: <_csrf_token>' -b '<cookie jar>' --data-binary '<b64 body>'`. (This is exactly the Waze PoC shape.)
- **Browser-relay to dodge CORS:** open the API host's own tab (it may 404 — fine) and run `fetch()` in the DevTools console; it executes **same-origin**, so no preflight, and `document.cookie` gives you what you need to sign first-party requests (SAPISIDHASH recipe in `whitebox-recon.md`). `mcp__claude-in-chrome__javascript_tool` runs this for you.
- **Two-account diff:** fire the same tampered request as account A (privileged) and account B (fresh/zero-priv). A 2xx to B returning A's data = confirmed. Keep both requests + responses tied to an operation id so the finding is evidence-backed, never hallucinated.

**Guardrail:** own accounts only, one record + a count as proof, no mass harvest, read-path PoCs unless the program permits more. Enumeration ≠ disclosure — a finding is a **2xx returning data you shouldn't see**.
