# Disclosed-report corpus (Google Bug Hunters public reports)

A standing index of high-value disclosed Google VRP reports, mined to extend the patterns in `bug-patterns.md` and the worked examples in `case-studies.md` (Part B). Use it two ways: (1) skim the table to calibrate before a big-tech target; (2) re-harvest periodically for fresh patterns.

Source: `https://bughunters.google.com/report/reports` → section **"All public reports"** (fully public, no login). **202 reports** as of 2026-06-13; ~140 are topg-relevant (API authz / IDOR / cross-tenant / SSRF→cloud / auth bypass / ID→PII). Each report opens at `https://bughunters.google.com/reports/vrp/<id>`.

---

## Deep-read subset (distilled into the skill)

| Report id | $ | Class | One-line lesson | Pattern |
|---|---|---|---|---|
| jaNNXm8sg | 31,837 | Cloud DM RCE | `descriptorUrl`→sandbox + `gslbTarget:blade:` + `GAIAMINT`/`GSLB` = SSRF into internal RPC mesh as minted identity; `staging_dogfood` path | P6/P12, case B4 |
| PLviDoABs | 20,000 | ID→PII | `includeSuspended:true` overrides ACL → `contentOwnerId` → Content ID API resolves email | P2/P3, case 2 |
| 7EhAw2hur | 15,000 | ACL divergence | Apps Script `DocumentApp.openById(id).getEditors()` leaks editor emails the UI hides | P11, case B3 |
| VBbY59QXh | 14,337 | Cross-tenant PII | `realtimesupport.clients6` `ListChanges` time-range → global agent+customer PII, any account | auth notes, B1 |
| HRDqQWSLs | 13,337 | Squatting | Pre-claim `${project_id}-us-central1-adc` bucket → victim artifacts → RCE | P10, case B2 |
| yBeFmSrJi | 7,500 | ACL divergence | Apps Script `SpreadsheetApp.openById(id).getFormUrl()` leaks linked Form → forge responses | P11, case B3 |
| BrQZ18W5k | 5,000 | Cloud privesc | Relabel node → disable WIF / enable legacy concealment → steal node SA token | case B5 |
| ZP6MgzwGr | 5,000 | Multi-RPC IDOR | Brute 8-digit `script_id` → mints 20-digit `execution_id` → script output | P1, case B6 |
| 5XZmpiNfg | 3,133.70 | Client-side gate | Flip `disabled`→`enabled` → bulk-export Search Console data to own BigQuery, persists | P13, case B10 |
| MMNdrjKyr | 2,337 | Prefix oracle | `?q=email:abc*` → `class="LnLepd"` marks valid prefix → rebuild redacted emails | P5, case B9 |
| PnwRwydmr | 1,500 | SSRF | "OpenAPI Spec URL" field fetches arbitrary URL → GCP metadata | P12 |
| mjyKuWrfd | 1,337 | Auth bypass | Self-signup idToken with `email_verified:false` accepted by management API | auth notes, B7 |
| TiNeBTPio | 500 | BOLA | `userByEmail(email)` GraphQL on `*.run.app` → any user PII, no authz | P1, B11 |
| mMS2XBwod | 500 | IDOR+enum | API-enumerable `ContentDocument` ids → IDOR download all private uploads | P1, B11 |
| bt112fj1k | 500 | ATO | Victim email + blank name → logged in as victim | B12 |
| ftv2rpN3r | 500 | Authz | Ignore "switch account" → click logo → admin org dashboard | B12 |
| F8GFYGv4g | 500 | OAuth theft | Open redirect *inside* the allowed `redirect_uri` origin → code via Referer | B12 |
| ZFYGoLaHt | 100 | Cross-tenant IDOR | Swap `orgId` in body → mint master-api-key in victim org (`terra-devel-*`) | P1, B11 |
| H7Cxz8j7j | — | Supply chain | `'pkg.dev' in url` substring check → `attacker.com/pkg.dev/` exfils SA token | P12, B8 |

## Next to mine (high topg-relevance, not yet distilled)
Pull these next with `bodies.js` (below) when extending the skill:

| Report id | Hook |
|---|---|
| uwKrTuSsd | Critical RCE in YouTube Studio via Closure Loader `goog.loadModuleFromSource_` |
| wG2bN8vZr | postMessage `targetOrigin` bypass → OAuth authorization-code theft |
| M3Pjk25Sn | Cloud Data Fusion (CDAP) GitHub Actions "pwn request" → RCE + artifact compromise |
| oCeVFaaoi | Deserialization RCE in AppSheet |
| bg7ZEGsgc | Internal GCP access via `GoogleCloudPlatform/magic-modules` |
| h1BHi6NVn | `GITHUB_TOKEN` leak with `id-token: write` on a GoogleCloud repo |
| KeEt53Jbh | Airflow/Composer privesc via hardcoded `secret_key` |
| wJPJcyy9h | Header injection in Google Apigee (inject headers / pollute body) |
| h1K5SciPh | Bucket traversal in `storage.transfer_manager.upload_chunks_concurrently()` |
| qudtD79xt | Broken access control — create kernel session from another user's private resource |
| HVo9sjDGj | Vulnerable maven-bundle-plugin in Guava build → RCE (CVE-2021-42036) |
| qbvU4KBpe | Zip-Slip → arbitrary file write → RCE in SecOps SOAR |

---

## Re-harvest (reproducible)
Public, no auth. Scripts used live in `~/terminal/target/topg-train/` (Playwright via the project's `node_modules`):

1. **Catalog** every report (paginated table, 6/page; terminate when range label hits "N of N"):
   `node catalog.js` → `extract/catalog.json` (rows = `{href, text}`, cells are **tab**-separated).
2. **Rank** by topg keywords (HI: idor/authz/cross-tenant/ssrf/cloud/pii/token/api/internal/…; MED: xss/csrf/graphql/…):
   `node rank.js` → `extract/ranked.json` + top-40 to stdout. Score on the **full row text**, not the parsed title.
3. **Extract bodies** for a curated id list (renders in DOM; grab `main` innerText):
   `node bodies.js <id> [<id>…]` → `extract/reports/<id>.txt`.

Gotchas seen: the Material paginator "Next" uses `aria-disabled` (not `:disabled`) — detect last page via the range label. `/report/reports` is **public "Featured/All public reports"**, not a private dashboard, so a headless context with no login works.

Note: these are *disclosed* reports — public, intended for learning. They describe already-fixed bugs. Apply the **patterns** to in-scope targets with your own accounts; never replay a PoC against the original third-party host.
