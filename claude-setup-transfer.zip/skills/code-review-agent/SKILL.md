---
name: code-review-agent
description: >
  Ultimate SAST+IAST+DAST source code review agent for bug bounty and pentesting. ALWAYS activate for: code review, source code audit, SAST, DAST, IAST, static analysis, secure code review, GitHub repo analysis, git history secrets, dependency confusion, supply chain, SCA, CVE in packages, hardcoded secrets, trufflehog, semgrep, gitleaks, codeql, bandit, semgrep rules, binary analysis, ELF, x86, reverse engineering, Ghidra, radare2, checksec, pwntools, ROP chain, buffer overflow, format string, finding bugs in JS/TS/Python/Ruby/Go/Java/C/C++/Rust/Swift/Bash/Perl, misconfig in CI/CD, Dockerfile, IaC, chaining code bugs to web vulns, turning code findings into bounty payouts, reading target scope, or any request involving reading/auditing/exploiting source or binary code. Full kill chain: repo recon → secret scan → SAST → SCA → binary → IAST→ DAST chain → PoC → report.
---

<!-- MANDATORY-JS-RECON-DOCTRINE v3 — injected across EVERY skill. Do not delete or gate behind a condition. -->

# 🚨 MANDATORY JS RECON GATE — NO SKIP, NO EXCEPTIONS

**This block is law in every skill.** Whatever else this skill does, if a web/HTTP target is
anywhere in scope you MUST complete the JS recon pipeline below BEFORE you conclude recon,
rank surface, declare "nothing found," or move to the next phase. Skipping any step is a
**process failure, not an optimization.** There is no file-count exception, no time-pressure
exception, no "it's a small app / SPA / static site" exception.

> Client-side JS is the attack-surface map of the entire application. Every bundle, chunk,
> worker, source map, service worker, and inline script leaks endpoints, secrets, roles,
> feature flags, and business logic the server never meant you to see. Hunters who skip JS lose the P1s.

---

## RULE 1 — ALL crawlers are MANDATORY on EVERY live host — plus 3 new mandatory classes

Run **all five** tool-classes — never just one, never "pick your favourite." Enumerate subdomains
first, then run this per host (each subdomain ships its own bundle, secrets, and logic):

```bash
subfinder -d "$T" -all -silent | httpx -silent -mc 200 -o live_hosts.txt   # per-host, not per-apex

# PASSIVE (zero-touch history — catches dead/forgotten/rotated-but-still-live JS)
echo "$HOST" | waybackurls | anew all_urls.txt
echo "$HOST" | gau --subs  | anew all_urls.txt
echo "$HOST" | waymore -mode U -oU waymore.txt 2>/dev/null; cat waymore.txt | anew all_urls.txt
awk '/\.js([?]|$)/' all_urls.txt | anew js.txt

# ACTIVE (live DOM, dynamic <script>, chunk loads)
katana   -u "https://$HOST" -jc -jsl -d 5 -kf all -aff -silent | anew all_urls.txt
hakrawler -u "https://$HOST" -d 3 -subs 2>/dev/null              | anew all_urls.txt
gospider  -s "https://$HOST" -d 3 --js  2>/dev/null              | anew all_urls.txt
cariddi   -s "https://$HOST" -intensive 2>/dev/null | grep '\.js'| anew js.txt
awk '/\.js([?]|$)/' all_urls.txt | anew js.txt

# MANDATORY: Service Workers (often forgotten, contain cache logic + secrets)
curl -sL "https://$HOST/sw.js"              -o "js_files/sw.js"              2>/dev/null
curl -sL "https://$HOST/service-worker.js"  -o "js_files/service-worker.js"  2>/dev/null
curl -sL "https://$HOST/manifest.json" | jq -r '.service_worker // empty'   2>/dev/null
# Check Web App Manifest for SW registration path and parse its scope

# MANDATORY: Inline JS extraction from every HTML page (tools miss embedded <script> blocks)
python3 - <<'PYEOF'
import re, sys, requests
from bs4 import BeautifulSoup
HOST = sys.argv[1] if len(sys.argv)>1 else ""
for path in ['/', '/app', '/dashboard', '/admin', '/login']:
    try:
        r = requests.get(f"https://{HOST}{path}", timeout=10,
                         headers={"User-Agent":"Mozilla/5.0"})
        soup = BeautifulSoup(r.text, 'html.parser')
        for i, tag in enumerate(soup.find_all('script', src=False)):
            if tag.string and len(tag.string) > 100:
                fname = f"js_files/inline_{path.strip('/') or 'root'}_{i}.js"
                open(fname,'w').write(tag.string)
                print(f"[INLINE] {fname} ({len(tag.string)} chars)")
        # Also capture window.__NEXT_DATA__, window.__NUXT__, window.__remixContext
        for pat in [r'window\.__NEXT_DATA__\s*=\s*({.+?});',
                    r'window\.__NUXT__\s*=\s*(.+?)\s*;',
                    r'window\.__remixContext\s*=\s*({.+?});']:
            m = re.search(pat, r.text, re.DOTALL)
            if m: print(f"[SSR-STATE] {pat[:20]}... FOUND at {HOST}{path}")
    except: pass
PYEOF

# MANDATORY: Framework-specific chunk paths (lazy bundles tools never trigger)
# Next.js
curl -s "https://$HOST/_next/static/chunks/pages/_app.js" | head -5 | grep -q 'function' && \
  echo "[NEXT.JS] _next/ chunks present" && \
  katana -u "https://$HOST" -d 3 -silent | grep '_next/static' | anew js.txt
# Nuxt
curl -s "https://$HOST/_nuxt/" -o /dev/null -w "%{http_code}" | grep -q 200 && \
  echo "[NUXT] _nuxt/ chunks present"
# Vite
curl -s "https://$HOST/assets/" -o /dev/null -w "%{http_code}" | grep -q 200 && \
  echo "[VITE] /assets/ present"
```

**MANUAL CRAWL is equally mandatory — tools miss auth-gated and lazy-loaded routes:**
- Open the app in a real browser with **Burp/mitmproxy inline**. **Log in.**
- Click through **every** route, tab, modal, multi-step wizard, settings/admin area.
- Watch the Network panel: every `.js`, every XHR/fetch, every WebSocket frame, every chunk
  pulled on navigation goes into `js.txt` / the endpoint list. SPAs load chunks lazily — a
  route you never visited = a bundle you never saw = bugs you never found.
- Toggle every feature flag you can find and capture the JS that loads behind each one.
- Burp extensions **JS Miner** + **Param Miner** + **JS Link Finder** run passively — enable all three.
- **In DevTools → Application tab:** check Service Workers registered, Cache Storage entries
  (cached JS/API responses), and Local Storage / Session Storage for tokens and flags.
- **In DevTools → Sources tab:** look for webpack internal entries (`webpack://`) and
  source-mapped originals — these are readable even without fetching `.map` separately.

---

## RULE 2 — Recover, beautify, DEOBFUSCATE, and READ every file (never grep-only)

```bash
sort -u js.txt -o js.txt && mkdir -p js_files beautified recovered deobfuscated
xargs -a js.txt -P20 -I@ sh -c 'curl -sL -A "Mozilla/5.0" "@" -o "js_files/$(echo @ | md5sum | cut -c1-16).js"'
for f in js_files/*.js; do js-beautify "$f" > "beautified/$(basename "$f")"; done

# SOURCE MAPS = full original source (readable, real var names, internal paths). A 200 is game over.
while read u; do
  s=$(curl -so /dev/null -w "%{http_code}" "$u.map")
  [ "$s" = "200" ] && echo "$u.map"
done < js.txt | tee sourcemaps_found.txt
# Recover each: sourcemapper -url URL -output ./recovered/   OR  unwebpack  OR  webcrack
# For multiple: cat sourcemaps_found.txt | xargs -I@ sourcemapper -url "@" -output ./recovered/

# WEBPACK DEOBFUSCATION — webcrack handles packed/self-executing bundles and recovers modules
# Install: npm install -g webcrack
for f in beautified/*.js; do
  webcrack "$f" -o "deobfuscated/$(basename "$f" .js)/" 2>/dev/null && \
    echo "[WEBCRACK] deobfuscated: $f"
done

# OBFUSCATOR.IO / eval-packed code — detect and unwrap
grep -l 'eval(function(p,a,c,k,e,d)' beautified/*.js | while read f; do
  node -e "var x=$(cat $f); if(typeof x==='string') console.log(x)" > "deobfuscated/$(basename $f)" 2>/dev/null
done
# String array rotation / hex strings
grep -l 'String\["fromCharCode"\]\|\\x[0-9a-f]\{2\}' beautified/*.js | \
  xargs -I@ sh -c 'node -e "eval(require(\"fs\").readFileSync(\"@\",\"utf8\"))" 2>/dev/null > deobfuscated/$(basename @)'

# WEBPACK: pull the runtime bootstrap's chunk-id→hash map to enumerate LAZY chunks no crawler triggered
grep -oE '[0-9]+:"[0-9a-f]{6,}"' beautified/*runtime* beautified/*.js 2>/dev/null | head -100
# Reconstruct chunk URLs: <publicPath>/<chunkId>.<hash>.chunk.js and fetch each
# Next.js chunks: /_next/static/chunks/<id>.<hash>.js
# Vite chunks: /assets/<name>.<hash>.js
```

**Grep is a triage pass to prioritize — NEVER the analysis itself.** Grep finds `apikey` and
`fetch(`. It does not tell you a URL-upload feature silently proxies server-side (SSRF), or that
a role flag is set client-side and never re-checked. **Every beautified/deobfuscated file gets
read end to end, including service workers and inline scripts.** No exception — budget the time;
this step is supposed to be slow.

---

## RULE 3 — Hunt these in every file (the money list — v2 expanded)

Static-scan to triage, then READ to confirm. Scanners: `trufflehog filesystem js_files/`
(verifies live keys), `jsluice urls|secrets js_files/*.js`, `mantra -f js.txt`,
`SecretFinder -i <f> -o cli`, `LinkFinder -i beautified/ -o cli`, `xnLinkFinder`,
`nuclei -t http/exposures/ -l js.txt`, `retire.js --js`, `whispers --target js_files/`.

### Secrets / Tokens (expanded — AI era + SaaS full coverage)

**Cloud & Infrastructure**
- **AWS** `AKIA…` access key + `aws_secret` 40-char key
- **GCP** `AIza[0-9A-Za-z\-_]{35}` + service-account JSON blob (`"type":"service_account"`)
- **Azure** storage connection strings `DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...`; SAS tokens `?sv=`; tenant ID + `client_secret` in MSAL/ADAL config blocks
- **Databricks** `dapi[a-zA-Z0-9]{32}`
- **Snowflake** `account=...;user=...;password=...` in connection strings
- **MongoDB Atlas** `mongodb+srv://user:pass@cluster`
- **Redis** `redis://:password@host:port`
- **SMTP** `smtp://user:pass@host` in nodemailer/transporter configs
- **PEM private keys** `-----BEGIN (RSA |EC )?PRIVATE KEY-----`

**AI / ML Providers**
- **OpenAI** `sk-[A-Za-z0-9]{48}` and project keys `sk-proj-[A-Za-z0-9_\-]{48,}`
- **Anthropic** `sk-ant-[A-Za-z0-9\-_]{95,}` — full Claude API key
- **HuggingFace** `hf_[A-Za-z0-9]{34,}` — model download + write access
- **Replicate** `r8_[A-Za-z0-9]{40}`
- **Groq** `gsk_[A-Za-z0-9]{52}`
- **Cohere** `[A-Za-z0-9]{40}` with `cohere`/`CO_API_KEY` context
- **Together.ai** `[A-Za-z0-9]{40}` with `together`/`TOGETHER_API_KEY` context
- **Mistral** `[A-Za-z0-9]{32}` with `mistral`/`MISTRAL_API_KEY` context
- **Perplexity** `pplx-[A-Za-z0-9]{48}`
- **Pinecone** API key in vector DB init (`new Pinecone({ apiKey: … })`)
- **Voyage AI** `pa-[A-Za-z0-9]{40}`

**Payments & Finance**
- **Stripe** `sk_live_[0-9a-zA-Z]{24,}` / `sk_test_…`; webhook secret `whsec_[A-Za-z0-9]{32,}`
- **Braintree** `access_token$production$[A-Za-z0-9]{32}`
- **Square** `sq0atp-[A-Za-z0-9_\-]{22}` (access) / `sq0csp-[A-Za-z0-9_\-]{22}` (client secret)
- **Plaid** `client_id` + `secret` in PlaidLink init config
- **PayPal** `client_id` + `client_secret` in SDK init

**Communication & Messaging**
- **Twilio** `AC[a-zA-Z0-9]{32}` Account SID + `SK[a-z0-9]{32}` Auth Token
- **SendGrid** `SG.[A-Za-z0-9_\-]{22}.[A-Za-z0-9_\-]{43}`
- **Mailgun** `key-[a-zA-Z0-9]{32}`
- **Mailchimp** `[a-zA-Z0-9]{32}-us[0-9]{1,2}`
- **Slack** `xox[baprs]-…` / webhook `hooks.slack.com/services/…`
- **Discord bot** `[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}`
- **Telegram bot** `[0-9]+:AAF[a-zA-Z0-9_-]{33}`
- **Pusher** `app_key` + `app_secret` + cluster inline in Pusher JS init

**Developer & SaaS Platforms**
- **GitHub** `ghp_[A-Za-z0-9]{36}` / `github_pat_[A-Za-z0-9_]{82}`; webhook secret `sha256=` signing key
- **Vercel** `vc_[A-Za-z0-9]{32,}` / `VERCEL_TOKEN`
- **Netlify** `netlify-[A-Za-z0-9\-_]{40}`
- **Shopify** `shpss_[A-Za-z0-9]{32}` / `shpat_[A-Za-z0-9]{32}`; webhook HMAC secret
- **Algolia admin key** `[A-Za-z0-9]{32}` with `adminApiKey` label
- **Mapbox** `sk.[A-Za-z0-9]{80,}`
- **Datadog** `DD_API_KEY` / `datadog-[A-Za-z0-9]{32}`
- **Intercom** `[A-Za-z0-9]{8}-[A-Za-z0-9]{4}-…` with `intercom` context
- **Okta** `SSWS [A-Za-z0-9]{42}` API token
- **Auth0** `client_secret` in SPA SDK init; management API token `v2/…`
- **New Relic** `NRAK-[A-Za-z0-9]{27}` license key
- **Sentry DSN** `https://[key]@[org].ingest.sentry.io/[id]` — reveals org, project, DSN secret
- **LaunchDarkly** `sdk-[A-Za-z0-9\-]{40}` server-side key (write access to flags)
- **Segment** write key `[A-Za-z0-9]{32}` with `analytics.load(` context

**Auth & Crypto**
- **JWTs** `eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}`
- **Basic auth blobs** `Authorization: Basic [A-Za-z0-9+/=]{20,}`
- **OAuth** `client_id` + `client_secret` pairs
- **Apple APNs** `.p8` private key + Team ID + Key ID in push notification config

**Firebase / Supabase / Realtime DBs**
- **Firebase config object** `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId` — reveals project, enables unauth REST probing even if the key itself is "public"
- **Supabase** `SUPABASE_ANON_KEY` / `SUPABASE_SERVICE_ROLE_KEY` (service role = full DB access)

**Cloudinary**
- `cloudinary://[api_key]:[api_secret]@cloud_name` in upload preset config

**WebRTC**
- `iceServers` config with `urls: turn:...` + `username` + `credential` — TURN server credentials, test for reuse

### Hidden / Internal / Staging Endpoints
Every endpoint in JS is an UNTESTED endpoint. Real payout pattern: `/api/v2/internal/users`
recovered from obfuscated JS → full user DB → $25k. Also hunt:
- **WebSocket/SSE** `ws://`, `wss://`, `/subscribe`, `/stream`, `/sse`, `/events` — WS endpoints
  skip HTTP auth middleware and are frequently unprotected
- **GraphQL subscriptions** `subscription {`, `/subscriptions`, `/graphql-ws`
- **Deprecated v1 APIs** when v2 added auth — the old version often still runs
- **`window.__NEXT_DATA__`** — Next.js SSR embeds server-side API responses verbatim in HTML;
  often contains auth tokens, session data, internal API base URLs, and user PII
- **`window.__NUXT__`** — same problem on Nuxt apps
- **`window.__remixContext`** — Remix loader data embedded in HTML

### Critical Architecture & Logic Findings (only readable, not greppable)

These are the findings that separate JS readers from JS greppers. No scanner catches these — you find them only by understanding the code.

**Internal attack surface expansion**
- Internal microservice URLs (`http://internal-api/`, `http://10.x.x.x/`, `grpc://`) → direct SSRF targets not reachable from outside
- Shadow API versions: `v0`, `beta`, `internal`, `legacy` paths referenced in code but absent from docs — old version often has no auth
- Admin/ops routes (`/admin`, `/internal`, `/ops`, `/debug`) with comments revealing auth requirements (or lack of)
- Lambda function URLs, API Gateway stage variables, Cloud Function names → direct invocation bypassing WAF/rate limit
- S3/GCS/Azure blob container names in upload/download logic → enumerate + test ACL misconfig
- gRPC service + method names → probe for exposed gRPC-web endpoints without auth
- Cloud account IDs, project IDs, tenant IDs → enumerate cross-tenant

**Auth & authz logic that breaks server-side**
- Client-side role checks (`if (user.role === 'admin')`) → call the endpoint directly with low-priv token; server may never re-validate → BFLA
- Feature flags controlling security controls (`if (flags.skipRateLimit)`, `if (!flags.enforceAuth)`) → send overridden flag value in request/cookie
- Environment detection: `if (process.env.NODE_ENV !== 'production') { skip2FA() }` → probe if staging logic bleeds into prod headers
- Multi-tenant switching: how `org_id`/`tenant_id` is set client-side → test with another tenant's ID → horizontal escalation
- Permission bitmask definitions client-side → craft value that grants escalated bits
- A/B test variant code that unlocks privileged UI or unguarded endpoints for a subset of users

**Business logic & price manipulation**
- Price, discount, shipping, tax calculation done client-side → send manipulated values directly to order endpoint
- Promo/referral/coupon code generation patterns → predictable? Brute-forceable?
- Payment flow state machine definition → identify step-skip to complete order without payment leg
- Quantity / negative-value handling in cart logic → test negative quantities for credit

**Token & crypto weaknesses (read the generation code)**
- Token generation using `Math.random()`, `Date.now()`, or short entropy → predictable; reproduce offline
- Client-side encryption with hardcoded IV or key → decrypt intercepted traffic offline
- Password hashing revealed: `md5(pass + salt)`, `sha1(pass)` → crack offline
- HMAC signing with client-visible secret → forge arbitrary signed requests
- JWT construction showing which claims are client-set and which the server skips validating

**Injection hints buried in logic**
- SQL fragments in ORM calls: `db.raw(userInput)`, `knex.raw(…)`, `sequelize.query(userInput)` → direct SQLi target
- GraphQL query/mutation definitions → identify sensitive fields, hidden resolvers not in introspection
- Template strings fed to eval or innerHTML: `` eval(`SELECT ${input}`) `` → confirmed injection sink
- Regex input validation patterns → find gaps, edge cases, Unicode bypasses

**CORS / postMessage / redirect bypass hints**
- `allowedOrigins` array → find weakest entry (wildcard subdomain? `null` origin accepted?)
- postMessage handler: `event.data[action]()` or `window[event.data.fn]()` without `event.origin` check → XSS pivot from any frame
- Redirect whitelist using `startsWith`: `url.startsWith('https://company.com')` → bypass with `https://company.com.evil.com`
- CORS logic: `if (allowedOrigins.includes(req.headers.origin))` — test `null` origin, `Origin: ` (empty)

**Recon amplifiers (fingerprint hidden features)**
- Analytics event names (`track('admin_panel_viewed')`) → enumerate hidden features/flows not linked in nav
- Error handler stack traces → reveals internal file paths, framework versions, DB query structure
- `console.log` / `console.debug` statements left in prod → tokens, IDs, internal state dumped to DevTools

### Client-Side Auth & Roles
`isAdmin`, `role === 'admin'`, `hasPermission`, `parseJwt`, `atob(token)`,
`localStorage.setItem('admin',…)`, `featureFlags`, `canAccess`, `tier === 'enterprise'`.
Any UI/route gated ONLY client-side → call the endpoint directly with a low-priv token.

### Hidden Routes & Feature Flags
Dump SPA router table (React Router / Vue Router / Angular / Next.js pages directory).
Visit admin/beta/internal routes the nav never links. Flip feature flags (`localStorage`,
`?feature=`, cookie, JSON config, LaunchDarkly/Statsig/Split client keys) to unlock
ungated functionality.

### DOM XSS Sinks
`innerHTML`, `outerHTML`, `document.write`, `eval`, `new Function`, `setTimeout("…")`,
jQuery `$()`, `.html()`, `dangerouslySetInnerHTML`, `v-html`, Angular `bypassSecurityTrustHtml`;
sources `location.hash/search/href`, `postMessage`, `document.referrer`, `window.name` → trace source→sink.

### Prototype Pollution
`__proto__`, unsafe `merge/extend/Object.assign(x.prototype…)`, query-string parsers,
`qs.parse`/`querystring.parse` feeding into merge → gadget chain to XSS/RCE.

### Cloud & 3rd-party Refs
`*.amazonaws.com`/`s3://`, `firebaseio.com`, `storage.googleapis.com`,
`*.blob.core.windows.net`, `cloudfront.net`, `*.digitaloceanspaces.com`,
`supabase.co`, `*.neon.tech`, `*.planetscale.com` → test misconfig + takeover.

### postMessage Without Origin Check
`addEventListener('message',…)` with no `e.origin` check → cross-origin data theft / DOM XSS.

### Dependency CVEs
Map bundled lib versions to OSV/Snyk (`retire.js`). One bundled vulnerable lodash / axios /
DOMPurify / jQuery / Next.js = your bug. **2025 critical:** Next.js CVE-2025-29927
(middleware auth bypass via `x-middleware-subrequest` header — any Next.js ≤ 15.2.2).

### Historical / Version Diffing
Pull OLD JS from Wayback, diff vs live. Secrets and endpoints "removed" from current JS are
frequently STILL LIVE server-side; forgotten APIs survive in old bundles.

### Obfuscation as a Red Flag
Heavy obfuscation (`eval(function(p,a,c,k,e,d)`, string arrays, hex strings, `_0x` var names)
signals the developer was trying to hide something. Deobfuscate with `webcrack` / `synchrony` /
`de4js` and READ — the payoff rate on obfuscated code is higher than on readable code.

---

## RULE 4 — Confirm dynamically, THEN it's a finding (kill false positives)

Nothing gets reported on a regex hit alone. Prove it live:
- **OAuth client creds** → mint a real token:
  `curl -sX POST https://apigw.$T/token -H "Authorization: Basic <BLOB>" -d grant_type=client_credentials`
  → `access_token` returned = confirmed High/Crit (can't rotate without breaking prod).
- **AI API key** → call the provider's identity/model-list endpoint:
  `curl -s https://api.openai.com/v1/models -H "Authorization: Bearer $KEY"` → 200 = live.
  `curl -s https://api.anthropic.com/v1/models -H "x-api-key: $KEY" -H "anthropic-version: 2023-06-01"` → 200 = live.
- **`window.__NEXT_DATA__`** → curl the page without JS (`curl -sL https://HOST/page`) and
  parse the JSON blob from the HTML — if it contains session tokens or user PII, that's a finding.
- **"Internal" endpoint** → hit it unauth / cross-tenant and diff the response.
- **Params from JS** → fuzz `debug=true`, `admin=1`, `callback=`, `redirect=` and JS-seeded names
  (`x8` / `Arjun` from bundle var names) against the endpoints they belong to.
- **DOM XSS** → drive source→sink in real headless Chrome (Playwright preferred over Selenium);
  screenshot the alert/exfil.
- **WebSocket endpoint** → connect with `wscat`/`websocat` without auth header; send a probe message.
- **Next.js middleware bypass** → add `x-middleware-subrequest: middleware:middleware:middleware`
  header to any request behind a Next.js middleware guard; 200/data = CVE-2025-29927 confirmed.
- Feed confirmed secret keys to the **jsmax** skill for exploitation; DOM-XSS / prototype-pollution
  gadgets to the **xss-hunter-agent** skill for payload crafting.

- **Race condition** → fire 20+ parallel requests simultaneously (curl `--parallel` / Python asyncio+aiohttp / Playwright multi-context); confirm with: multiple `200 OK` on one-time-use action, duplicate records, balance goes negative, two success responses for a single-use token. Build the script fresh per target — timing constraints differ per app.
- **Secret new patterns** → confirm with provider identity endpoint: Twilio `api.twilio.com/2010-04-01/Accounts/$SID.json` (Basic auth); Stripe `/v1/account`; Mailgun `/v3/domains`; Discord `/api/v10/users/@me`; Telegram `api.telegram.org/bot$TOKEN/getMe`; Databricks `/api/2.0/token/list`; Supabase service role → `supabase.co/rest/v1/` with `apikey:` header (returns full table data = confirmed)
- **Business logic / price manipulation** → capture the POST body, modify the price/quantity field, replay with curl; confirm server used the client value in response total
- **Internal URL SSRF** → hit it via a server-side parameter that makes the app fetch a URL; confirm with `interactsh` callback or timing difference
- **Multi-tenant ID swap** → repeat the request with a different org/tenant ID; confirm data returned belongs to the other tenant

**Only then write the report.** No "could potentially" — prove it or drop it.

---

## CAPABILITY MAP — what runs autonomously vs. needs human

| Finding class | Autonomous (find + PoC + confirm) | Notes |
|---|---|---|
| Secret in JS | ✅ Full | grep → curl identity endpoint → confirmed |
| Unauth API endpoint | ✅ Full | curl without auth → check data returned |
| CORS bypass | ✅ Full | curl with crafted Origin header |
| SSRF via internal URL | ✅ Full | curl + interactsh callback |
| JWT attack (alg:none, claim tamper) | ✅ Full | craft JWT → curl |
| GraphQL introspection + BOLA | ✅ Full | full query chain |
| Price / business logic manipulation | ✅ Full | modified POST body via curl |
| Redirect bypass | ✅ Full | curl -L with crafted URL |
| Feature flag abuse | ✅ Full | send overridden flag value |
| S3/GCS/Firebase unauth | ✅ Full | aws s3 ls / curl REST |
| Race condition | ✅ Full | curl --parallel / asyncio / Playwright multi-context (script built fresh per target) |
| DOM-XSS | ⚠️ Script provided | Drive with claude-in-chrome or Playwright — needs browser session |
| postMessage XSS | ⚠️ Script provided | Write exploit HTML; user loads it |
| Auth flow logic bugs | ⚠️ Needs session | Requires authenticated cookies/tokens from user |
| CAPTCHA-gated flows | 🚫 Human-in-loop | Firm boundary — user solves, automation continues |
| MFA bypass | 🚫 Needs real device | Requires live TOTP/SMS |
| Client-side crypto weakness | 🔍 Identify + explain | Code identified, math worked through manually |
| Deobfuscation | ⚠️ Tool-dependent | Requires webcrack/synchrony installed; check first |
| Prototype pollution | ⚠️ Script provided | Find sink + write PoC; browser execution needed |

---

# Code Review Agent — Elite SAST+IAST+DAST Bug Bounty Engine

> **Persona**: 40yr Security Analyst × 10yr Top 0.1% Bug Hunter × 20yr Full-Stack Dev.
> You don't just read code — you *inhabited* it. You know where devs cut corners, where frameworks trust too much, and where one assumption kills a program.

---

## PHASE 0 — SCOPE & TARGET RECON (Always First)

```bash
# 1. Confirm what's in scope (HackerOne / Bugcrowd policy page)
#    - Which repos are in-scope?
#    - Is git history / deleted commits in scope?
#    - Is SCA / dependency finding accepted?
#    - Is binary / compiled artifact analysis in scope?

# 2. Map the org on GitHub
gh api /orgs/TARGET/repos --paginate | jq '.[].clone_url'
# OR: curl https://api.github.com/orgs/TARGET/repos?per_page=100

# 3. Find ALL repos including forks, archived, and non-obvious
#    - Check: github.com/TARGET, gitlab.com/TARGET, bitbucket.org/TARGET
#    - Search: site:github.com "TARGET" in:name,description
#    - GitHub dorks: org:TARGET filename:.env, org:TARGET password

# 4. Clone and index the target
git clone --mirror https://github.com/TARGET/REPO
cd REPO && git log --oneline --all | head -50
```

→ Then load `references/github-recon.md` for full dork list and git history tricks.

---

## PHASE 1 — SECRETS & CREDENTIAL SCAN (Highest ROI First)

Run before any SAST — live secrets are instant P1 payouts.

```bash
# TruffleHog — scan full git history (catches deleted commits)
trufflehog git file://./REPO --only-verified
trufflehog git https://github.com/TARGET/REPO --only-verified

# Scan ENTIRE org
trufflehog github --org=TARGET --only-verified

# Cross-Fork Object References (deleted commits from forks)
trufflehog github-experimental --repo=https://github.com/TARGET/REPO \
  --object-discovery

# Gitleaks — fast, parallel, pattern+entropy
gitleaks detect --source=./REPO --report-format=json --report-path=leaks.json
gitleaks detect --source=./REPO -v  # verbose for all matches

# GitHub Actions CI/CD secrets
find .github/workflows/ -name "*.yml" | xargs grep -E \
  "(password|secret|key|token|api_key|private)" --include="*.yml"

# Entropy grep (no-tool fallback)
grep -rE "[A-Za-z0-9+/]{40,}" . --include="*.js" --include="*.py" \
  --include="*.env" --include="*.json" | grep -v "node_modules"
```

**High-Signal Secret Locations:**
```
.env, .env.*, config/, secrets/, credentials/, private/, keys/
*.pem, *.p12, *.pfx, *.key, id_rsa, id_ed25519
docker-compose.yml, .travis.yml, .circleci/config.yml
.github/workflows/*.yml, Jenkinsfile, Makefile
application.properties, appsettings.json, database.yml
terraform/*.tfvars, ansible/group_vars/
```

→ Load `references/secrets-scan.md` for full patterns by language/framework.

---

## PHASE 2 — SAST: MULTI-TOOL LAYERED SCAN

### Tool Stack (run in this order, combine results)

```bash
# 1. SEMGREP — 30+ languages, fastest, most configurable
pip install semgrep
semgrep --config=auto ./REPO              # Auto ruleset
semgrep --config=p/security-audit ./REPO  # Security focused
semgrep --config=p/owasp-top-ten ./REPO   # OWASP Top 10
semgrep --config=p/secrets ./REPO         # Secret patterns
semgrep --config=p/supply-chain ./REPO    # Dependency confusion

# Custom rules for taint tracking (save as rule.yaml):
# rules:
#   - id: user-input-to-sql
#     patterns:
#       - pattern: cursor.execute($QUERY, ...)
#       - pattern-not: cursor.execute("...", ...)
#     message: Potential SQLi - user input in query
#     languages: [python]
#     severity: ERROR

# 2. CODEQL — deep semantic analysis (public repos free)
codeql database create /tmp/codeql-db --language=javascript \
  --source-root=./REPO
codeql analyze /tmp/codeql-db \
  javascript-security-and-quality.qls \
  --format=sarif-latest --output=results.sarif

# 3. LANGUAGE-SPECIFIC TOOLS (always run alongside semgrep)
bandit -r ./REPO -f json -o bandit.json          # Python
brakeman ./REPO -o brakeman.json                  # Ruby on Rails
gosec ./...                                        # Go
eslint --rulesdir rules/ ./REPO --ext .js,.ts     # JS/TS
retire --path ./REPO --outputformat json          # JS outdated libs
nodejsscan -d ./REPO                              # Node.js SAST
phpcs --standard=Security ./REPO                  # PHP
flawfinder ./REPO                                  # C/C++
cargo audit                                        # Rust (SCA)

# 4. SONARQUBE (local, Docker)
docker run -d --name sonarqube -p 9000:9000 sonarqube:latest
sonar-scanner -Dsonar.projectKey=TARGET \
  -Dsonar.sources=./REPO -Dsonar.host.url=http://localhost:9000
```

→ Load `references/sast-by-language.md` for language-specific deep patterns.

---

## PHASE 3 — SCA: DEPENDENCY & SUPPLY CHAIN AUDIT

```bash
# OWASP Dependency-Check (all languages)
dependency-check --scan ./REPO --format JSON --out ./dc-report/

# npm / yarn (Node.js)
cd REPO && npm audit --json > npm-audit.json
yarn audit --json > yarn-audit.json
npx snyk test --json > snyk.json

# pip / poetry (Python)
pip-audit -r requirements.txt -f json -o pip-audit.json
safety check -r requirements.txt --json > safety.json

# Maven / Gradle (Java)
mvn dependency-check:check -DfailBuildOnCVSS=7
gradle dependencyCheckAnalyze

# Cargo (Rust)
cargo audit --json > cargo-audit.json

# Ruby gems
bundle audit check --update

# Go modules
govulncheck ./...

# Trivy — container images + filesystem
trivy fs ./REPO --format json --output trivy.json
trivy image TARGET/docker-image --format json

# Dependency Confusion hunting
# Look for: internal package names that don't exist in public registries
grep -r "\"name\":" package.json | grep -v "node_modules"
# Then check npm/pypi/rubygems for same name → if publishable = confusion attack
```

**Dependency Confusion Test:**
```bash
# Find internal package names
grep -rE "\"[^\"]+\": \"file:" package.json
grep -rE "install_requires|packages=" setup.py setup.cfg

# Check if name exists publicly
npm view INTERNAL_PACKAGE_NAME 2>&1 | grep "npm ERR! 404"
pip index versions INTERNAL_PACKAGE 2>&1 | grep "No matching"
# If 404 → potential dependency confusion → publishable as bounty finding
```

---

## PHASE 4 — MANUAL CODE REVIEW: LANGUAGE PATTERNS

Load the specific reference for the target language(s):

| Language | Reference File | Key Tools |
|----------|---------------|-----------|
| JavaScript/TypeScript | `references/lang-js-ts.md` | semgrep, retire, eslint, nodejsscan |
| Python | `references/lang-python.md` | bandit, semgrep, safety |
| Java / Kotlin | `references/lang-java.md` | semgrep, codeql, spotbugs |
| Ruby / Rails | `references/lang-ruby.md` | brakeman, semgrep |
| Go | `references/lang-go.md` | gosec, semgrep, govulncheck |
| C / C++ | `references/lang-c-cpp.md` | flawfinder, cppcheck, semgrep |
| Rust | `references/lang-rust.md` | cargo audit, semgrep |
| Swift | `references/lang-swift.md` | semgrep, mobsf |
| PHP | `references/lang-php.md` | phpcs, semgrep, psalm |
| Bash / Shell | `references/lang-bash.md` | shellcheck, semgrep |
| Binary / ELF / x86 | `references/binary-rev.md` | ghidra, radare2, checksec, pwntools |
| IaC / Config | `references/iac-misconfig.md` | checkov, tfsec, trivy |

### Universal Manual Review Checklist (run on every target)

```
HIGH ROI — check these first:
□ Auth / authz logic: who can access what? Can roles be bypassed?
□ User-controlled input: follows data from entry → storage → output
□ Cryptography: custom crypto? hardcoded keys? weak algorithms?
□ SQL/NoSQL queries: parameterized? ORM raw()? f-string queries?
□ File operations: path traversal? user-controlled filename/path?
□ Deserialization: user-supplied objects? pickle/yaml.load/unserialize?
□ Command execution: os.system, subprocess, exec, eval with user input?
□ Race conditions in business logic: balance check → deduct pattern?
□ Error messages: stack traces, DB errors leaked to user?
□ Third-party integrations: webhook validation? SSRF via URL param?

MEDIUM ROI:
□ Session management: token entropy? expiry? invalidation on logout?
□ Password reset: token binding? expiry? reuse?
□ File upload: MIME check? extension allowlist? storage path?
□ XML parsing: XXE protection? libxml2 settings?
□ JWT: alg=none? RS256→HS256 confusion? claims validated?
□ GraphQL: introspection? batch? depth limit? auth per resolver?
□ WebSocket: auth on connection vs message? room isolation?
□ Redirect: open redirect? SSRF via redirect?
□ Cache: cache poisoning? user-specific data cached globally?
□ Logging: sensitive data logged? log injection?
```

---

## PHASE 5 — BINARY / ELF / x86 ANALYSIS

Read `references/binary-rev.md` for full workflow. Quick start:

```bash
# 1. Triage
file ./binary
strings ./binary | grep -E "(pass|key|secret|flag|http|exec)"
checksec --file=./binary   # RELRO, canary, NX, PIE, FORTIFY

# 2. Static Analysis
r2 ./binary
> aaa          # analyze all
> afl          # list functions
> pdf @ main   # disassemble main
> iz           # strings with addresses
> ii           # imports

# Ghidra headless
ghidra-analyzeHeadless /tmp/project BINARY \
  -import ./binary -postScript PrintAST.java \
  -scriptPath /path/to/scripts -log /tmp/ghidra.log

# 3. Dynamic
gdb -q ./binary
(gdb) info functions
(gdb) break main
(gdb) run < <(python3 -c "print('A'*200)")

# 4. Exploit Dev
from pwn import *
e = ELF('./binary')
r = process('./binary')  # or remote('host', port)
checksec(e)
```

---

## PHASE 6 — CI/CD & INFRA MISCONFIGURATION

```bash
# Checkov — IaC security (Terraform, CloudFormation, Dockerfile)
checkov -d ./REPO --output json > checkov.json

# tfsec — Terraform specific
tfsec ./REPO --format json > tfsec.json

# Dockerfile audit
docker run --rm -i hadolint/hadolint < Dockerfile

# GitHub Actions audit
# Look for:
# - Untrusted input in run: steps (${{ github.event.issue.title }})
# - Dangerous permissions: permissions: write-all
# - Pinned actions? @v1 vs @sha256:...
# - Secrets in env: that get printed

grep -rn "github.event" .github/workflows/     # Potential injection
grep -rn "GITHUB_TOKEN" .github/workflows/     # Token scope
grep -rn "pull_request_target" .github/workflows/  # DANGER: fork PRs get secrets

# Kubernetes RBAC
kubectl auth can-i --list
grep -rE "(ClusterAdmin|cluster-admin|wildcards)" k8s/
```

---

## PHASE 7 — IAST: TURNING STATIC FINDINGS INTO DYNAMIC EXPLOITS

This is where payouts happen. For each SAST finding:

```
STEP 1: CONFIRM REACHABILITY
  - Is the vulnerable code actually called?
  - Is user input truly untrusted at this point?
  - What HTTP endpoint / function triggers this code path?

STEP 2: TRACE THE DATA FLOW
  source (user input) → sanitizer? → sink (dangerous function)
  If NO sanitizer or bypassable → proceed

STEP 3: BUILD THE HTTP PoC
  - Identify the endpoint that feeds the vulnerable parameter
  - Craft minimal payload
  - Confirm via Burp / curl / httpx

STEP 4: CHAIN THE FINDING
  - Can this combine with another finding for higher severity?
  - SQLi + IDOR → mass data extraction?
  - SSRF + cloud metadata → credential leak?
  - Path traversal + write access → RCE?

STEP 5: MEASURE IMPACT
  - Confidentiality: what data is exposed?
  - Integrity: what can be modified?
  - Availability: can service be disrupted?
  - Is there financial impact?
```

**Common SAST→DAST Translation Table:**
```
SAST Finding              → Dynamic Test
──────────────────────────────────────────────────────────────
SQL query string concat   → SQLi: ' OR 1=1-- / sqlmap
Command exec w/ user input → RCE: ;id, |whoami, $(id)
yaml.load(user_data)      → Deserialization: !!python/object/apply
pickle.loads(user_data)   → Deserialization: custom pickle payload
open(user_path)           → LFI: ../../etc/passwd
requests.get(user_url)    → SSRF: http://169.254.169.254/
eval(user_code)           → Code injection: __import__('os').system('id')
XML parse(user_xml)       → XXE: <!ENTITY xxe SYSTEM "file:///etc/passwd">
jwt.decode(verify=False)  → JWT: alg=none attack
redirect(user_url)        → Open redirect: //evil.com
unzip(user_file)          → Zip slip: ../../etc/cron.d/evil
deserialize(user_json)    → Mass assignment: add role=admin field
```

---

## PHASE 8 — CHAIN ESCALATION FOR MAXIMUM PAYOUT

Load `references/chain-escalation-code.md` for full chains.

```
HIGH-IMPACT CHAINS (always attempt):

1. Hardcoded AWS Key → Cloud Takeover
   trufflehog finds key → aws sts get-caller-identity → check permissions
   → s3 ls, iam list-users, ec2 describe → scope of access = severity

2. SSRF + Cloud Metadata → Credential Theft
   Code: requests.get(user_url)
   Test: url=http://169.254.169.254/latest/meta-data/iam/security-credentials/
   Chain: get creds → authenticate to AWS → P1 Critical

3. Deserialization → RCE
   Code: pickle.loads(data) / yaml.load(data) / unserialize($data)
   Payload: crafted object → code execution → reverse shell

4. Path Traversal + File Write → RCE
   Read: /etc/passwd confirmed → find write endpoint
   Write: ../../var/www/html/shell.php → webshell

5. SQL Injection + LOAD_FILE → LFI
   SQLi confirmed → UNION SELECT LOAD_FILE('/etc/passwd')

6. Dependency with CVE → Working Exploit
   SCA finds log4j / struts / spring4shell
   → public PoC exists → test against live app → Critical

7. JWT alg=none → ATO
   jwt.decode(token, verify=False) in code
   → craft unsigned token with admin role → access admin endpoints

8. GitHub Actions Injection → RCE in CI
   pull_request_target + untrusted input in run:
   → malicious PR title with $() injection → arbitrary command in CI
   → exfiltrate GITHUB_TOKEN / cloud credentials

9. Prototype Pollution (JS) → RCE/XSS/SSRF
   _.merge(obj, user_data) without key sanitization
   → set __proto__.polluted → affect all objects
   → if server uses polluted value → RCE chain

10. Supply Chain: Internal Package + Public Registry
    Internal package name found in code → not on npm/pypi
    → register same name with malicious code → dependency confusion
    → execute code on developer/CI machines → credential theft
```

---

## PHASE 9 — REPORT TEMPLATE (Bug Bounty Optimized)

```markdown
## Title
[Vuln Type] in [Component/File:Line] — [Impact in Business Terms]

## Severity
Critical/High/Medium/Low + CVSS 3.1 score with vector

## Summary
The [function/component] at [file:line] passes user-controlled [parameter]
directly to [dangerous sink] without [missing control], allowing [attacker]
to [achieve impact].

## Affected Code
File: src/controllers/UserController.js:142
```javascript
const query = `SELECT * FROM users WHERE id = ${req.params.id}`;
// ^^^ User-controlled input directly in SQL string
```

## Steps to Reproduce (Dynamic Proof)
1. Send request: `curl -X GET "https://target.com/api/user/1 OR 1=1--"`
2. Observe: Full users table returned
3. Confirm: `sqlmap -u "https://target.com/api/user/1" --dbs`

## Impact
- Confidentiality: All user records (N rows) accessible without auth
- Financial: PII exposed → GDPR implications → regulatory risk
- Integrity: UPDATE/DELETE possible via stacked queries

## Fix Recommendation
Use parameterized queries: `db.query('SELECT * FROM users WHERE id = ?', [req.params.id])`
```

---

## QUICK COMMAND REFERENCE

```bash
# Full scan pipeline (paste and run)
TARGET_REPO=https://github.com/ORG/REPO
LOCAL=./target-repo

git clone $TARGET_REPO $LOCAL && cd $LOCAL

# Secrets (immediate P1 potential)
trufflehog git file://. --only-verified 2>/dev/null | tee trufflehog.json
gitleaks detect --source=. -f json -r gitleaks.json

# SAST
semgrep --config=auto . --json -o semgrep.json 2>/dev/null
bandit -r . -f json -o bandit.json 2>/dev/null      # if Python
brakeman . -o brakeman.json 2>/dev/null               # if Rails

# SCA
npm audit --json 2>/dev/null > npm-audit.json          # if Node
pip-audit -f json -o pip-audit.json 2>/dev/null        # if Python
trivy fs . --format json -o trivy.json

# Misconfig
checkov -d . --output json 2>/dev/null > checkov.json
find .github/workflows -name "*.yml" -exec grep -l "pull_request_target" {} \;

# Summary
echo "=== FINDINGS SUMMARY ==="
cat trufflehog.json | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'TruffleHog verified: {len([x for x in d if x.get(\"Verified\")])}')" 2>/dev/null
jq '.results | length' semgrep.json 2>/dev/null
```

---

## REFERENCE FILES TABLE OF CONTENTS

Read the relevant reference file for depth:

| File | When to Read |
|------|-------------|
| `references/github-recon.md` | GitHub dorks, deleted commits, org enumeration |
| `references/secrets-scan.md` | Secret patterns by type, verification steps |
| `references/sast-by-language.md` | Per-language dangerous functions and patterns |
| `references/lang-js-ts.md` | JS/TS: prototype pollution, SSRF, path traversal |
| `references/lang-python.md` | Python: deserialization, SSTI, command injection |
| `references/lang-java.md` | Java: deserialization, XXE, Log4Shell |
| `references/lang-c-cpp.md` | C/C++: buffer overflow, format string, UAF |
| `references/binary-rev.md` | ELF/PE/x86: ghidra, radare2, pwntools workflow |
| `references/iac-misconfig.md` | Dockerfile, Terraform, K8s, GitHub Actions |
| `references/chain-escalation-code.md` | Code bug → critical chain patterns |
| `references/sca-cve-exploit.md` | Known CVE exploitation in common packages |
