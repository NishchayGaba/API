# GitHub Recon — Full Playbook

## Org & Repo Enumeration
```bash
# All repos in an org (paginate)
curl -s "https://api.github.com/orgs/TARGET/repos?per_page=100&type=all" \
  | jq '.[].clone_url'

# With auth (get private if you have token from secret scan)
GH_TOKEN=ghp_LEAKED_TOKEN
curl -H "Authorization: token $GH_TOKEN" \
  "https://api.github.com/orgs/TARGET/repos?per_page=100&type=private" \
  | jq '.[].clone_url'

# Using GitHub CLI
gh api /orgs/TARGET/repos --paginate --jq '.[].full_name'
gh api /users/TARGET/repos --paginate --jq '.[].full_name'

# Find repos with specific keywords
gh search repos TARGET --limit 100 --json full_name,url
```

## GitHub Dorks (Code Search)
```
# In GitHub code search (search.github.com or API):

org:TARGET password
org:TARGET secret
org:TARGET api_key
org:TARGET "DB_PASSWORD"
org:TARGET filename:.env
org:TARGET filename:config.yml password
org:TARGET filename:database.yml password
org:TARGET extension:pem private
org:TARGET extension:ppk private
org:TARGET extension:key private
org:TARGET "ssh-rsa"
org:TARGET "BEGIN RSA PRIVATE KEY"
org:TARGET "BEGIN OPENSSH PRIVATE KEY"
org:TARGET "AKIA" (AWS access key pattern)
org:TARGET "eyJhbGciO" (JWT)
org:TARGET "Authorization: Bearer"
org:TARGET filename:*.tfvars
org:TARGET "access_token"
org:TARGET "client_secret"
org:TARGET "GITHUB_TOKEN"
org:TARGET filename:Jenkinsfile password
org:TARGET filename:.travis.yml password
org:TARGET filename:circle.yml password
org:TARGET "mongodb://" OR "mysql://" OR "postgres://"
org:TARGET filename:wp-config.php
org:TARGET filename:settings.py SECRET_KEY
org:TARGET filename:application.properties datasource.password
```

## CLI GitHub Dorking at Scale
```bash
# Using github-dork CLI
pip install github-dork
github-dork -u TARGET -q "password filename:.env"

# GitDorker
python3 gitdorker.py -tf token.txt -q "org:TARGET filename:.env" -o results.csv

# Shhgit (real-time monitoring)
shhgit --search-query "org:TARGET password"
```

## Git History Deep Dive
```bash
# Full commit history secrets (TruffleHog best for this)
trufflehog git file://./REPO --only-verified
trufflehog git file://./REPO  # unverified too (catches deleted)

# Manual git archaeology
git log --all --oneline                    # all commits all branches
git log --all -p -- "*.env"               # all changes to .env files ever
git log --diff-filter=D --summary         # deleted files
git log --all --full-history -- "secrets.json"

# Find deleted sensitive files
git log --all --diff-filter=D --name-only --format="" | sort -u | grep -iE \
  "(secret|password|key|token|credential|private)"

# Resurrect deleted file from history
git show COMMIT_HASH:path/to/deleted/file

# Search all commits for specific string
git log -p --all -S "api_key" | grep -A5 -B5 "api_key"
git log -p --all --grep="password" --pickaxe-regex -S "password"

# Find large blobs (may contain binaries with secrets)
git rev-list --objects --all \
  | git cat-file --batch-check='%(objecttype) %(objectname) %(objectsize) %(rest)' \
  | sort -k3 -rn | head -20
```

## Cross-Fork Object Reference (CFOR)
```bash
# Secrets in deleted forks — use TruffleHog experimental
trufflehog github-experimental \
  --repo=https://github.com/TARGET/REPO \
  --object-discovery \
  --only-verified

# Manual: if you have a commit hash from a deleted fork
# GitHub never truly deletes commits if you know the hash
curl https://github.com/TARGET/REPO/commit/HASH
# Or: git fetch origin HASH (from a clone)
```

## GitHub Actions Security Review
```bash
# Find workflows using pull_request_target (high risk)
grep -rl "pull_request_target" .github/workflows/

# Find untrusted input in run: steps (injection risk)
grep -rn "github.event.pull_request.title\|github.event.issue.title\|github.event.comment.body\|github.head_ref" .github/workflows/

# Hardcoded secrets in workflows
grep -rn "password\|secret\|token\|key" .github/workflows/ | \
  grep -v "secrets\.\|GITHUB_TOKEN"

# Overly permissive tokens
grep -rn "permissions: write-all\|contents: write" .github/workflows/

# Pinning check — @v1 vs @sha256 (supply chain)
grep -rn "uses:" .github/workflows/ | grep -v "@[a-f0-9]\{40\}"
```

## Exposed .git Directories (Web)
```bash
# Check if .git is exposed on web server
curl -s https://TARGET.com/.git/HEAD | head -1
# If "ref: refs/heads/main" → exposed!

# Dump exposed .git
git clone https://TARGET.com/.git exposed-repo/
# OR use gitdumper:
python3 gitdumper.py https://TARGET.com/.git/ /tmp/dumped-repo

# Then scan with trufflehog
trufflehog filesystem /tmp/dumped-repo
```

## Miscellaneous Recon
```bash
# Find all subdomains from JS/code
grep -rE "https?://[a-zA-Z0-9\-\.]+\.[a-z]{2,}" --include="*.js" \
  --include="*.ts" --include="*.json" . | \
  grep -oE "https?://[a-zA-Z0-9\-\.]+\.[a-z]{2,}" | sort -u

# Internal endpoints / admin paths
grep -rE "(/admin|/internal|/debug|/api/v[0-9]|/_)" \
  --include="*.js" --include="*.py" --include="*.rb" . | sort -u

# Find all TODO/FIXME/HACK/SECURITY comments
grep -rniE "(TODO|FIXME|HACK|SECURITY|XXX|VULN|CVE|temp|workaround)" . \
  --include="*.js" --include="*.py" --include="*.java" | grep -v ".git"

# NPM package.json → internal package names
cat package.json | jq '.dependencies + .devDependencies | keys[]'
# Then check if any are not on npm registry
```
