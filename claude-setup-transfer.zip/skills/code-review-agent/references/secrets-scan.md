# Secrets Scanning — Full Pattern Reference

## Quick Secret Verification by Type

```bash
# AWS
aws sts get-caller-identity --access-key AKIA... --secret-key ...
# Checks: what account/role does this key belong to?

# GitHub Token
curl -H "Authorization: token ghp_..." https://api.github.com/user
curl -H "Authorization: token ghs_..." https://api.github.com/rate_limit

# Stripe
curl https://api.stripe.com/v1/balance -u "sk_live_...:
# sk_live_ = production, sk_test_ = test (lower impact)

# Twilio
curl -X GET "https://api.twilio.com/2010-04-01/Accounts/ACXXX.json" \
  -u "ACXXX:AUTH_TOKEN"

# Slack webhook
curl -X POST "https://hooks.slack.com/services/T.../B.../..." \
  -H 'Content-Type: application/json' -d '{"text":"test"}'

# SendGrid / Mailgun
curl -X GET "https://api.sendgrid.com/v3/user/profile" \
  -H "Authorization: Bearer SG...."

# GCP Service Account
gcloud auth activate-service-account --key-file=service-account.json
gcloud projects list

# Firebase
# Check: https://PROJECTID.firebaseio.com/.json
# If returns data without auth → unauthenticated read
```

## High-Signal File Patterns
```bash
# Files most likely to have secrets
find . -name ".env*" -not -path "*/node_modules/*"
find . -name "*.key" -not -path "*/node_modules/*"
find . -name "*.pem" -not -path "*/node_modules/*"
find . -name "secrets.*" -not -path "*/node_modules/*"
find . -name "credentials.*" -not -path "*/node_modules/*"
find . -name "*.tfvars" -not -path "*/node_modules/*"
find . -name "application.properties"
find . -name "appsettings.json" -not -path "*/node_modules/*"
find . -name "database.yml"
find . -name "config.php"
find . -name "wp-config.php"
find . -name "settings.py" -not -path "*/node_modules/*"
find . -name "*.conf" | head -20

# Git-specific
cat .git/config             # might have credential URLs
git config --list           # all git config including credentials
```

## Regex Patterns for Manual Grep
```bash
# AWS
grep -rE "AKIA[0-9A-Z]{16}" .
grep -rE "aws_secret_access_key\s*=\s*[A-Za-z0-9/+]{40}" .

# Generic API Keys (high entropy)
grep -rE "['\"][A-Za-z0-9_\-]{20,}['\"]" . | grep -iE "key|token|secret|api"

# Private keys
grep -rn "BEGIN RSA PRIVATE KEY\|BEGIN OPENSSH PRIVATE KEY\|BEGIN EC PRIVATE KEY" .

# Database connections
grep -rE "(mysql|postgres|mongodb|redis)://[^\"']+:[^\"']+@" .
grep -rE "password\s*[:=]\s*['\"]?[A-Za-z0-9!@#$%^&*]{6,}" .

# JWT
grep -rE "eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}" .

# Google API
grep -rE "AIza[0-9A-Za-z\-_]{35}" .
grep -rE "ya29\.[A-Za-z0-9\-_]+" .   # OAuth token

# GitHub
grep -rE "ghp_[A-Za-z0-9]{36}" .     # personal access token
grep -rE "ghs_[A-Za-z0-9]{36}" .     # app token
grep -rE "github_pat_[A-Za-z0-9_]{82}" .  # fine-grained PAT

# Stripe
grep -rE "sk_(live|test)_[A-Za-z0-9]{20,}" .
grep -rE "pk_(live|test)_[A-Za-z0-9]{20,}" .

# Slack
grep -rE "xox[baprs]-[0-9A-Za-z\-]+" .
grep -rE "hooks\.slack\.com/services/[A-Z0-9]+/[A-Z0-9]+/[a-zA-Z0-9]+" .

# Twilio
grep -rE "AC[a-z0-9]{32}" .           # Account SID
grep -rE "SK[a-z0-9]{32}" .           # API Key

# Sendgrid
grep -rE "SG\.[A-Za-z0-9_-]{22,}\.[A-Za-z0-9_-]{43}" .

# SSH private keys
grep -rn "-----BEGIN.*PRIVATE KEY-----" .
```

## TruffleHog Advanced Usage
```bash
# Scan entire GitHub org (requires token for private repos)
trufflehog github --org=TARGET \
  --token=$GITHUB_TOKEN \
  --only-verified \
  --json | tee org-secrets.json

# Scan all commits including deleted (full history)
trufflehog git file://./REPO \
  --since-commit=0000000 \
  --max-depth=999999

# Scan HuggingFace models (new attack surface!)
trufflehog huggingface --org=TARGET

# Custom detector (add your own secret pattern)
# Create detector config:
cat > custom.yaml << 'EOF'
detectors:
  - name: InternalAPIKey
    regex:
      - "internal_key_[a-f0-9]{32}"
    verify:
      endpoint: "https://api.target.com/validate"
      headers:
        - "X-API-Key: $MATCH"
      successCodes: [200]
EOF
trufflehog filesystem ./REPO --custom-verifiers=custom.yaml
```

## Gitleaks Configuration
```toml
# gitleaks.toml - custom rules
[[rules]]
id = "internal-jwt-secret"
description = "Internal JWT Secret"
regex = '''JWT_SECRET\s*=\s*['"]?([A-Za-z0-9_\-]{10,})['"]?'''
tags = ["jwt", "secret"]

[[rules]]
id = "internal-db-url"  
description = "Database Connection String"
regex = '''(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@[^/]+/'''
tags = ["database", "credentials"]
```

## Deleted Commits — Advanced Recovery
```bash
# List all reachable objects (including dangling)
git fsck --unreachable --no-reflogs 2>/dev/null | grep "blob\|commit"

# Get content of dangling blob (deleted file)
git cat-file -p BLOB_HASH | grep -iE "password|key|secret|api"

# Find commits not reachable from any branch/tag
git log --all --oneline
git fsck --lost-found 2>/dev/null
ls .git/lost-found/

# Cross-Fork Object References
# A deleted fork's commits still accessible via original repo
trufflehog github-experimental \
  --repo=https://github.com/TARGET/REPO \
  --object-discovery   # brute-forces commit hashes
```

## CI/CD Secret Patterns
```bash
# GitHub Actions - find secrets usage
grep -rn "secrets\." .github/workflows/
grep -rn "\${{" .github/workflows/ | grep -i "secret\|token\|key\|password"

# CircleCI - context variables
grep -rn "CIRCLE_TOKEN\|CIRCLE_API" .circleci/

# Travis CI
grep -rn "secure:" .travis.yml              # encrypted vars (but look for plaintext)
grep -rn "env:" .travis.yml | grep -v "secure:"

# Jenkins
grep -rn "credentials\|withCredentials\|usernamePassword" Jenkinsfile

# Kubernetes secrets in manifests
grep -rn "kind: Secret" k8s/
# Base64 decode values:
cat k8s/secret.yaml | grep -oP "(?<=: )([A-Za-z0-9+/=]{20,})" | base64 -d
```
