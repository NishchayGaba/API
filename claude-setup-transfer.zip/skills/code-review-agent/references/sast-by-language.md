# SAST by Language — Dangerous Patterns & Manual Audit Guide

## JavaScript / TypeScript

### Dangerous Sinks (grep for these)
```javascript
// Command Injection
child_process.exec(USER_INPUT)
child_process.spawn('sh', ['-c', USER_INPUT])
eval(USER_INPUT)
new Function(USER_INPUT)()

// Path Traversal / LFI
fs.readFile(USER_INPUT)
fs.readFileSync(req.params.file)
path.join(__dirname, req.query.name)  // if unsanitized

// SSRF
axios.get(req.body.url)
fetch(req.query.target)
request(user_url)

// SQL Injection (raw queries)
db.query(`SELECT * FROM users WHERE id = ${id}`)
connection.query("SELECT * FROM t WHERE x='" + input + "'")
knex.raw(`... ${user_input}`)

// NoSQL Injection
User.find({ username: req.body.username })  // if obj, can bypass with {$gt: ""}
db.collection.find(JSON.parse(req.body.query))

// Template Injection (SSTI)
res.render(req.query.template)    // template name from user
_.template(user_string)({})       // user-controlled template

// Prototype Pollution
_.merge({}, JSON.parse(user_input))
Object.assign({}, user_obj)       // if user_obj has __proto__
jQuery.extend(true, {}, user_obj)

// Deserialization
JSON.parse(user_input)            // safe for JSON, but check what's done with it
serialize.unserialize(user_data)  // node-serialize CVE
```

### Semgrep Rules for JS
```bash
semgrep --config=p/nodejs-security ./
semgrep --config=p/javascript ./
semgrep --config=p/express-security ./
semgrep --config=p/react ./
```

### Retire.js — Outdated Libraries
```bash
retire --path . --outputformat json
# Focus on: HIGH severity CVEs in popular libs (lodash, moment, axios)
```

---

## Python

### Dangerous Patterns
```python
# Command Injection
os.system(user_input)
subprocess.call(user_input, shell=True)   # shell=True is the danger
subprocess.Popen(f"cmd {user}", shell=True)
eval(user_input)
exec(user_input)
__import__(user_input)

# SSTI (Template Injection)
render_template_string(user_input)        # Flask - HIGH RISK
Template(user_input).render()             # Jinja2 direct
env.from_string(user_input).render()

# SQL Injection
cursor.execute("SELECT * FROM t WHERE id=" + user_id)
cursor.execute(f"SELECT * FROM users WHERE name='{name}'")
session.query(User).filter(text(user_filter))  # SQLAlchemy raw

# Deserialization
pickle.loads(user_data)                   # RCE via pickle
yaml.load(user_data)                      # Use yaml.safe_load!
yaml.load(f, Loader=yaml.Loader)
marshal.loads(user_data)
jsonpickle.decode(user_data)

# Path Traversal
open(user_path)
send_file(request.args.get('filename'))
os.path.join('/uploads', user_filename)   # if not validated

# SSRF
requests.get(user_url)
urllib.urlopen(user_url)
httpx.get(user_url)

# XXE
lxml.etree.parse(user_xml)               # without defusedxml
xml.etree.ElementTree.fromstring(user_xml)

# Insecure Deserialization
shelve.open(user_input)
```

### Tools
```bash
bandit -r . -f json -o bandit.json
bandit -r . -ll -ii           # high confidence, high severity only
semgrep --config=p/python ./
safety check -r requirements.txt
pip-audit -r requirements.txt
```

---

## Java

### Dangerous Patterns
```java
// Command Injection
Runtime.getRuntime().exec(userInput)
ProcessBuilder(userInput)

// SQL Injection
stmt.executeQuery("SELECT * FROM t WHERE id=" + id)
connection.prepareStatement("... WHERE name='" + name + "'")
entityManager.createNativeQuery("... " + input)

// XXE (XML External Entity)
DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
// Missing: dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
dbf.parse(userXmlInput)

// Deserialization
ObjectInputStream ois = new ObjectInputStream(userStream);
ois.readObject()              // Classic Java deserialization → ysoserial
XStream.fromXML(userInput)   // Known CVEs (CVE-2021-21345)

// SSRF
new URL(userUrl).openConnection()
HttpURLConnection conn = (HttpURLConnection) new URL(userUrl).openConnection()

// SSTI (Freemarker/Velocity)
Template template = freemarker.getTemplate(userTemplateName)
Template t = new Template("name", new StringReader(userInput), cfg)

// Path Traversal
new File(basePath + userPath)
Paths.get(uploadDir, userFilename)

// Log4Shell (Log4j)
logger.error(userInput)  // if log4j < 2.17 and JNDI lookup enabled

// Spring Mass Assignment
@RequestMapping public void update(@ModelAttribute User user) {}
// If User has isAdmin field → send isAdmin=true
```

### Tools
```bash
semgrep --config=p/java ./
# SpotBugs with FindSecBugs plugin
mvn com.github.spotbugs:spotbugs-maven-plugin:check
# OWASP Dependency-Check
mvn dependency-check:check
# CodeQL (public repos)
codeql database create db --language=java && codeql analyze db
```

---

## Ruby / Rails

### Dangerous Patterns
```ruby
# Command Injection
`#{user_input}`                    # backtick exec
system(user_input)
exec(user_input)
IO.popen(user_input)
Open3.popen3(user_input)
eval(user_input)

# SQL Injection
User.where("name = '#{params[:name]}'")    # string interpolation in query
User.where("admin = #{params[:admin]}")     # boolean injection
User.find_by_sql("... #{user_input}")
ActiveRecord::Base.connection.execute("... #{input}")

# Mass Assignment
User.new(params[:user])                     # if attr_accessible not used
User.update_attributes(params[:user])

# Path Traversal
send_file(Rails.root.join(params[:file]))
File.open(params[:path])

# SSTI (ERB direct)
ERB.new(user_input).result

# Deserialization
Marshal.load(user_data)
YAML.load(user_data)               # Use YAML.safe_load!
```

### Tools
```bash
brakeman . -o report.json --format json
semgrep --config=p/ruby ./
bundler-audit check
```

---

## Go

### Dangerous Patterns
```go
// Command Injection
exec.Command("sh", "-c", userInput).Run()
exec.Command(userInput).Run()

// SQL Injection
db.Query("SELECT * FROM users WHERE name = " + input)
db.Raw("SELECT ... WHERE name='" + input + "'")

// Path Traversal
http.ServeFile(w, r, r.URL.Path)           // without filepath.Clean
os.Open(userPath)
ioutil.ReadFile("./files/" + userInput)

// SSRF
http.Get(userURL)
http.DefaultClient.Do(req)                 // if req.URL from user

// Template Injection
tmpl, _ := template.New("").Parse(userInput)
html/template vs text/template confusion    // XSS if using text/template
```

### Tools
```bash
gosec ./...
semgrep --config=p/golang ./
govulncheck ./...
```

---

## C / C++

### Dangerous Patterns
```c
// Buffer Overflow
gets(buf)                          // NEVER safe
strcpy(dest, src)                  // no bounds check
sprintf(buf, "%s", userInput)      // can overflow
scanf("%s", buf)                   // unbounded

// Format String
printf(userInput)                  // user controls format string!
fprintf(f, userInput)
sprintf(buf, userInput)
syslog(LOG_INFO, userInput)

// Integer Overflow
size_t len = atoi(userInput);
char *buf = malloc(len * sizeof(item));  // can overflow to small alloc

// Use After Free
free(ptr);
ptr->member = val;                 // UAF

// Null Pointer Dereference
char *p = malloc(0);
*p = 'x';

// Command Injection
system(userInput)
popen(userInput, "r")
```

### Tools
```bash
flawfinder . 2>/dev/null
cppcheck --enable=all . 2>/dev/null
semgrep --config=p/c ./
semgrep --config=p/cpp ./
# AddressSanitizer during compilation:
gcc -fsanitize=address,undefined -g ./target.c -o target
```

---

## Bash / Shell Scripts

### Dangerous Patterns
```bash
# Command Injection via unquoted variables
rm -rf $USER_INPUT                 # DANGER
eval "$user_command"               # DANGER
$(echo $user_input)               # subshell injection

# Path Traversal
cat /var/log/$filename            # if filename=../../etc/passwd

# Unvalidated redirects
source $config_file               # arbitrary code execution

# Insecure temp files
tmpfile=/tmp/myfile$$             # predictable, race condition
```

### Tools
```bash
shellcheck ./script.sh
semgrep --config=p/bash ./
```

---

## IaC — Terraform / Dockerfile / K8s

### Dockerfile Audit
```dockerfile
# HIGH RISK:
RUN apt-get install sudo           # escalation vector
COPY . .                           # copies entire context including secrets
ENV API_KEY=secret123              # hardcoded secret in image layer
RUN curl | bash                    # arbitrary remote code
USER root                          # don't run as root

# CHECK:
FROM base:latest                   # unpinned → supply chain risk
ADD https://external.com/file .    # remote ADD
```

### Terraform Audit
```hcl
# HIGH RISK:
resource "aws_s3_bucket" "bad" {
  acl = "public-read"             # public bucket!
}
resource "aws_security_group_rule" "bad" {
  cidr_blocks = ["0.0.0.0/0"]    # 0.0.0.0/0 inbound
  from_port = 22                  # SSH exposed to world
}
resource "aws_iam_role_policy" "bad" {
  policy = jsonencode({
    Statement = [{
      Effect = "Allow"
      Action = ["*"]              # wildcard permissions!
      Resource = ["*"]
    }]
  })
}
```

### Tools
```bash
checkov -d . --output json
tfsec . --format json
trivy config ./
hadolint Dockerfile
kube-score score deployment.yaml
```
