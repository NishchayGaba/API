# Business-Logic-Flaw (BLF) Hub — economic / workflow logic

Domain entry-point for the `blf` hunt class (Phase 5). A business logic flaw is a rule the app is
*supposed* to enforce — a price stays correct, a coupon is used once, one vote per person, a seat cap
holds, KYC happens before withdrawal — that can be broken through legitimate-looking requests. This is
**orthogonal to authorization**: the bug is real even if every permission check is perfect, because the
flaw is in the *rule itself*, not in who's allowed to trigger it. (For "can Account A read Account B's
data," that's IDOR — use [authz-idor.md](authz-idor.md), not this class.)

Method: pick a workflow, tamper with its parameters / sequence / timing, and prove the rule broke by
showing a real before→after state change. A second (or third) account is just one tool — used only when
an exploit genuinely needs a counterparty — not the organizing idea.

## Bug categories (what you're hunting for)

- **Price / quantity / discount** — tampered cart math, negative or overflow quantities, coupon stacking or reuse, currency/rounding abuse.
- **Workflow sequence** — skipping a required step (KYC, approval, payment confirmation) by forced-browsing straight to the endpoint that should come after it.
- **Race conditions** — any check-then-act operation (balance, coupon, seat, quota) hit with parallel requests to exceed its limit. Deep engine: [race-conditions.md](race-conditions.md).
- **Vote / reputation / ranking** — sockpuppet votes/reviews, poll stuffing, leaderboard farming, karma-threshold gaming.
- **Points / currency / referral** — loyalty-point arbitrage, self-referral loops, fake transactions for a bonus.
- **Seat / plan / entitlement** — SaaS seat-cap bypass, plan-parameter override, feature-flag abuse, trial reset.
- **Account-lifecycle billing desync** — a deleted/downgraded/cancelled account still billed, or still keeping paid entitlements.
- **Abuse-limit bypass via account switching** — a per-account rate limit, CAPTCHA, or quota reset by creating another account.

Full checklists per category, with concrete parameters/endpoints:
- [blf-workflows-by-business-type.md](blf-workflows-by-business-type.md) — ecommerce, fintech, SaaS, healthcare, gaming, workflow-gate-skip checklists
- [blf-additional-bug-classes.md](blf-additional-bug-classes.md) — vote/reputation manipulation, abuse-limit bypass via account switching, referral farming, coupon stacking, points arbitrage, idempotency-key money bugs, rounding abuse
- [blf-cms-and-platform-patterns.md](blf-cms-and-platform-patterns.md) — WordPress/WooCommerce, Shopify, Magento, feature-flag abuse

## Method

### 1. Map the workflow
Answer before testing:
1. What does this app DO, and what's the "money" here (literal $, credits, votes, reputation, access)?
2. What workflows are multi-step (checkout, onboarding, KYC, approval, invite, withdrawal)?
3. What's the assumed cardinality — one vote/coupon/bonus per what (account? person? payment method?)?
4. What limits reset if you just create another account?

Prioritize **HIGH-MONEY + MULTI-STEP + EASILY-REPEATABLE** intersections. (Within an asset — this is
*not* prioritizing one asset over another, which Rule 2 forbids; it's ordering the tests inside one asset.)

### 2. Run the SABOTAGE matrix

| Letter | Category | Try |
|---|---|---|
| S | Skip / Sequence | Jump to step N without completing 1..N-1 |
| A | Abuse Limits | Negative, zero, MAX_INT, fractional values |
| B | Bypass State | Replay a valid token/request in a new context |
| O | Override Role | `role=user`→`role=admin`, `plan=free`→`plan=premium` (on your own account) |
| T | Tamper Params | price/qty/discount/orderId in the request |
| A | Abuse Timing | Race any non-atomic check-then-act operation → [race-conditions.md](race-conditions.md) |
| G | Ghost Features | Hit a disabled UI feature's API directly |
| E | Escalate Chain | Combine 2+ low findings into one critical one → [chaining.md](chaining.md), [blf-chain-escalation.md](blf-chain-escalation.md) |

*(Spells "SABOTAGE" — the word has two A's, hence Abuse Limits and Abuse Timing are separate rows.)*

**Run order: read-only/single-shot checks first, races next, anything that burns an account
(lifecycle transitions) last** — so an early destructive test doesn't cost you an account a later test
still needs.

### 3. Reach for a second account only when the exploit needs one
Most economic-logic bugs (price, quantity, coupon, step-skip) are provable on a single account. Mint a
second/third account specifically for:
- **Self-dealing** — buyer + seller, both yours, to trigger an escrow release or bonus with a fake transaction.
- **Collusion** — sockpuppet votes/reviews, referral loops (A refers B, B refers A).
- **Limit evasion** — a fresh account to reset a rate-limit, CAPTCHA, or free-tier quota tied to "one account."
- **Arbitrage** — moving points/credits between two accounts you control at a favorable rate.

Acquisition order, actor-model table, when-you-actually-need-N-accounts guide: [blf-account-setup.md](blf-account-setup.md).
(Signup automation itself: [access-tempmail.md](access-tempmail.md) — same temp-mail pipeline as Phase 3.)

### 4. Prove it
1. **Before** — the correct/expected state (real price, real vote count, real balance, real seat count).
2. **Tamper** — the exact request modified (param, sequence, timing, race, or the multi-account maneuver used).
3. **After** — the server-confirmed state change. Re-fetch and show the value actually moved — a 200 response alone proves nothing.
4. **Scale** — quantify the impact if repeated (per-cycle $ gain, votes per minute, seats bypassed).

"Possibly"/"might be" is not a finding. Confirm the after-state or drop it (see [validation.md](validation.md)).

### 5. Chain to critical
A single BLF is a finding; a chained BLF is a payday. After confirming one, always ask: who benefits,
what state changed, what can I do with that changed state, is there a financial component downstream that
compounds it? Worked chain patterns: [blf-chain-escalation.md](blf-chain-escalation.md) and [chaining.md](chaining.md).

## Quick reference — parameters to always fuzz
```
price, amount, total, discount, coupon_code, quantity, seats, plan, tier, role,
is_premium, is_admin, is_verified, status, order_status, kyc_status, is_active,
token, reset_token, invite_token, referral_code, expires_at, trial_end, currency
```

## Common mistakes
| Mistake | Fix |
|---|---|
| Reaching for a second account by default | Most bugs here are provable on one account — only add a second when the exploit genuinely needs a counterparty |
| Reporting "possible"/"might be" | Confirm with an after-state re-fetch, or drop it |
| Stopping at the first bug | Always run Step 5 — chain before reporting |
| Treating a client-side flip as the finding | A feature-flag/response flip only matters if a *subsequent server call* honors it — verify that, not the flip itself |
| Drifting into "can Account A read Account B's data" | That's IDOR/authorization testing ([authz-idor.md](authz-idor.md)), a different class — stay on rule violations (price/votes/limits) here |

## PoC / report template
```
Title: [BLF Type] — [Impact in Business Terms]
Severity: Critical/High/Medium (justify with $$ impact or scale)

Summary:
  The [feature/endpoint] allows [actor] to [action] by [technique], resulting in [business impact].

Steps to Reproduce:
  1. [Account setup, if a second account was needed and why]
  2. [Exact request(s), param/sequence/timing modified]
  3. [Observe the confirmed state change — before vs. after]

Impact:
  - Financial: $X per exploitation cycle
  - Scale: how many times this is repeatable / how fast

Remediation:
  - Server-side validation for [specific parameter/state]
  - Atomic transaction for [operation]
  - Re-validate [state/role/limit] at each workflow step, not just the entry point
```
Full write-up rules: [reporting.md](reporting.md).
