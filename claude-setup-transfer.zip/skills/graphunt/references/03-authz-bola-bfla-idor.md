# 03 — Authorization: BOLA / BFLA / IDOR (Phases 4–5) — THE money class

> **The gateway authenticates. Resolvers authorize — or forget to.** This file is where most
> GraphQL P1/P2 lives. You need **two accounts** (Tenant A, Tenant B) — signup automation is fine,
> never bypass captcha.

Setup: log in as A and B, capture each session/JWT. For every operation you ranked in Phase 4, ask:
*does the resolver re-check that this viewer owns this object?* Prove it by requesting **A's object
with B's token**.

---

## 3.1 BOLA / IDOR — object-level authorization

### Pattern 1 — direct object argument (the classic)
Any query/mutation that takes an `id`/`uuid`/`slug` argument is a BOLA candidate:
```graphql
# As Tenant B, request Tenant A's object:
query { order(id: "A_ORDER_ID") { id total customerEmail shippingAddress } }
query { invoice(id: 4711) { pdfUrl amount taxId } }
query { user(id: "A_USER_UUID") { email phone twoFactorSecret } }
```
`data` returned (not `null`, not `Not authorized`) = **confirmed BOLA**. Increment numeric IDs or
enumerate UUIDs harvested from JS to prove scale (respect the 50-record cap — a count + one redacted
record is enough).

### Pattern 2 — `node(id:)` global object identification (Relay) — very common, often missed
Relay/graphql-ruby expose a single `node(id: ID!)` that returns **any object type** by its global ID.
Global IDs are usually **base64 of `Type:localID`**:
```bash
echo -n 'User:1' | base64          # VXNlcjox
echo 'VXNlcjox' | base64 -d        # User:1   ← decode a real global ID, then increment localID
```
```graphql
query {
  node(id: "VXNlcjoy") {                 # User:2 — a different tenant
    ... on User { id email fullName phoneNumber }
    ... on Order { id total customerEmail }
    ... on Team  { id name billingEmail }
  }
}
```
Because `node()` is a **single generic resolver**, developers frequently forget per-type ownership
checks here even when the dedicated `user(id:)`/`order(id:)` resolvers are guarded. **Always test
`node()` for every sensitive type**, using inline fragments. Encodings vary: some are
`base64(TypeName:uuid)`, some are opaque — decode a few of your own IDs to learn the scheme.

### Pattern 3 — nested-resolver authz gap (depth leaks)
The top-level object is authorized; a **nested field** silently returns another tenant's data:
```graphql
query {
  me {                                   # authorized: your own user
    organization {                        # your org — fine
      members { id email }                # ← is THIS re-checked? often not
      billingAccount { last4 stripeCustomerId }   # ← or this?
      auditLog(first: 50) { node { actorEmail ip action } }
    }
  }
}
```
Or reach across tenants through a relationship:
```graphql
query { order(id:"MY_ORDER") { customer { otherOrders { id total } } } }   # pivots to other customers
```
Test **every edge** in the graph, not just root fields. Nested authz is the single most-forgotten check.

### Pattern 4 — alias-based mass enumeration in one request
Batch hundreds of object lookups into a single HTTP request (also defeats naive rate limits — see 06):
```graphql
query {
  u1: user(id: 1) { email } u2: user(id: 2) { email } u3: user(id: 3) { email }
  # … generate u1..u1000 programmatically
}
```
Generate with a script:
```bash
python3 -c 'print("query{"+" ".join(f"u{i}:user(id:{i}){{email}}" for i in range(1,501))+"}")'
```
One request → 500 users' emails = mass-PII well. (Prove with a count + one redacted record.)

### Pattern 5 — mutation BOLA (write to someone else's object)
Don't stop at reads. State-changing mutations on another tenant's object are higher impact:
```graphql
mutation { updateOrderAddress(orderId:"A_ORDER", address:"attacker") { id } }
mutation { deleteComment(id:"A_COMMENT_ID") { success } }
mutation { addCollaborator(projectId:"A_PROJECT", email:"attacker@x.com", role:"ADMIN") { id } }
```
**Read guardrail:** confirm reversibility / ask before firing destructive mutations. A single
non-destructive write to a foreign object (e.g., renaming *your own* object then proving the resolver
*accepts* a foreign ID via error/response diff) can prove the bug without damage.

---

## 3.2 BFLA — function/field-level authorization (vertical privesc)

A low-priv user reaching an admin-only operation. GraphQL makes this easy to miss because there's no
URL to gate — the "endpoint" is a field name inside one POST.

- From the schema, list every mutation/query that *sounds* privileged: `admin*`, `impersonate*`,
  `setRole`, `grant*`, `internal*`, `export*`, `deleteUser`, `updateBilling`, feature-flag toggles.
- Call each with a **low-privilege token**. `data` back (not `Forbidden`) = BFLA / vertical privesc.
```graphql
mutation { updateUserRole(userId:"me", role:"SUPER_ADMIN") { id role } }   # self-privesc → ATO of the platform
mutation { impersonateUser(userId:"A_ADMIN_ID") { sessionToken } }          # → full ATO
query    { adminUsers(first:50){ nodes{ email role lastLoginIp } } }        # admin-only list from a normal user
```

### Hasura-specific BFLA — header-role injection
Hasura authorizes off request headers. If the gateway trusts client-supplied role/user headers (or
they leak), you escalate directly:
```
x-hasura-role: admin
x-hasura-admin-secret: <if leaked in JS — full DB, see JS gate>
x-hasura-user-id: <victim uuid>
```
Try sending `x-hasura-role: admin` as an unauthenticated/low-priv user — misconfigured deployments
honor it. A leaked `x-hasura-admin-secret` = complete database read/write (identity-confirm only,
never abuse further per guardrails).

---

## 3.3 Real disclosed examples — authorization

**PortSwigger Web Security Academy (reproducible, canonical):**
- *"Accessing private GraphQL posts"* / *"Accidental exposure of private GraphQL fields"* — reading a
  field the UI hides returns another user's data. Root cause = field-level authz gap. This is the
  minimal reproducible model of every BOLA above.

**Shopify (public bug bounty, GraphQL-heavy Admin/Partner APIs):** Shopify's platform is GraphQL-first
and multiple disclosed reports centre on **object-level authorization** in the Admin/Partner API —
an app or staff token reaching objects belonging to another shop/tenant. The recurring root cause is
a resolver that checks *authentication* (valid token) but not *authorization* (this token owns this
shop's object). Test every `Order`, `Customer`, `Fulfillment`, `DiscountCode` object with a token
scoped to a *different* shop.

**GitLab (public HackerOne, actively discloses GraphQL reports):** repeated GraphQL findings where a
confidential object (issue/epic titles, member data, CI variables) was reachable via a GraphQL path
that skipped the permission check enforced on the REST/UI path. Root cause: **multiple paths to the
same type, inconsistent authz.** Mirrors Pattern 3 above — enumerate every path with
`graphql-path-enum`.

**HackerOne (their own platform uses GraphQL):** disclosed reports around GraphQL object access where
team/report objects were reachable cross-context. Same class: resolver-level authz omission.

**Relay `node()` IDOR (widespread real-world pattern):** apps built on graphql-ruby/Relay repeatedly
ship a `node(id:)` that resolves any global ID without a per-type ownership check, while the typed
resolvers are guarded. Decoding+incrementing the base64 global ID yields cross-tenant object reads.
This is one of the most reliably-paid GraphQL bugs in the wild.

**Payout reality (honest):** cross-tenant PII read (BOLA) on a real SaaS = commonly **P2–P1**,
mid-four to five figures depending on data class and scale. Self-privesc mutation (BFLA →
account/tenant takeover) = **P1**. A `node()` IDOR leaking emails/PII across tenants with mass
enumeration = top-tier. **Reading introspection alone = low/info** — don't confuse the enabler with
the exploit.

---

## 3.4 Confirm & kill false positives

Before you call it: a finding requires **cross-account impact on a real user who took no unusual
action.**
- Prove it with **B's token against A's object** — not with your own object, and not unauthenticated
  against public data.
- `null` return can mean "authorized but empty" OR "silently filtered" — diff against a *known-good*
  authorized request to be sure you actually got A's data (compare a stable field like `createdAt`).
- Rule out that the "other" ID is actually public/shared by design.
- Respect the **50-record exfil cap**; prefer `totalCount` / `aggregate{count}` to prove scale.

Then: `04-injection.md` and the rest of Phase 5, or jump straight to `08-tooling-poc-report.md` if
this is your finding.
