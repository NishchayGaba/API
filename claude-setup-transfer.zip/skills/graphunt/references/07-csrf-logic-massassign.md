# 07 — CSRF, Mass Assignment, Business Logic, Info Disclosure (Phase 5)

The remaining high-value GraphQL classes that aren't authz or injection.

---

## 7.1 GraphQL CSRF

GraphQL is normally `POST` with `Content-Type: application/json`, which is **not** a form-encodable
type — so it's usually CSRF-safe *by default*. It becomes CSRF-able when the server relaxes that:

**(a) GET-based operations.** If the server executes queries/mutations over GET, and the session is a
cookie, you have classic CSRF for any state-changing GET operation:
```
GET /graphql?query=mutation{updateEmail(email:"attacker@evil.com"){id}}
```
```html
<!-- zero-click if it's a GET mutation -->
<img src="https://target/graphql?query=mutation%7BdeleteAccount%7Bsuccess%7D%7D">
```
Test: does `GET /graphql?query=mutation{...}` actually execute the mutation? Many engines refuse
mutations over GET (graphql-js does) — but misconfigured/custom servers allow it.

**(b) Content-type confusion.** If the server accepts the operation with a **simple** content type
that a `<form>` can send — `application/x-www-form-urlencoded`, `multipart/form-data`, or
`text/plain` — you can CSRF it cross-site without preflight:
```html
<form action="https://target/graphql" method="POST" enctype="text/plain">
  <input name='{"query":"mutation{updateEmail(email:\"attacker@evil.com\"){id}}","variables":{}}' value="">
</form>
<script>document.forms[0].submit()</script>
```
or `enctype="application/x-www-form-urlencoded"` with the JSON as a single field. If the server parses
it and runs the mutation with the victim's cookie → **CSRF confirmed.**

**Requirements to be a real finding:** (1) session must be cookie-based (not a bearer token in a
header — those aren't sent cross-site), (2) the operation must be **state-changing** (a query is not
CSRF), (3) no CSRF token / no `Sec-Fetch`/origin check enforced. If all three hold → CSRF.

**Real disclosed example:** PortSwigger Academy *"Performing CSRF exploits over GraphQL"* — the app
accepts mutations sent as `x-www-form-urlencoded` with cookie auth and no CSRF token; a cross-site
form changes the victim's email → ATO. Reproducible model for the above.

---

## 7.2 Mass assignment via mutation inputs

GraphQL input objects are frequently mapped straight onto ORM models. If the input type accepts a
field the UI never shows, you may set privileged attributes:
```graphql
mutation { signup(input:{ email:"me@x.com", password:"x", role:"ADMIN", isVerified:true, credit:99999 }) { id role } }
mutation { updateUser(input:{ id:"me", emailVerified:true, plan:"ENTERPRISE" }) { plan } }
```
**Find the candidate fields** by reading the input type in the schema (Phase 3) and the JS bundle —
hidden input fields (`role`, `ownerId`, `isAdmin`, `balance`, `price`, `verified`, `tenantId`) that
aren't in the UI form are the leads. Response echoing back `role:"ADMIN"` / `plan:"ENTERPRISE"` =
confirmed privesc / financial manipulation.

**Real pattern:** Lighthouse (Laravel) apps using `@spread`/mass-fill on input objects, and any
resolver doing `Model.update(input)` — repeatedly disclosed as mass-assignment privesc. Match this to
the array-injection / mass-assignment playbook: probe every mutation input with extra fields.

---

## 7.3 Business-logic abuse

GraphQL exposes the app's operations directly, so logic flaws are reachable without UI constraints:
- **Negative / boundary values**: `mutation{purchase(quantity:-5, price:...)}` → negative total /
  refund. `transfer(amount:-100)` → reverse direction.
- **Step skipping**: call the final mutation of a multi-step flow directly (`completeOrder` without
  `payment`), because the UI's sequencing isn't enforced server-side.
- **Race conditions**: fire the same mutation in parallel (coupon redeem, withdrawal, vote) — GraphQL
  batching makes single-packet parallelism easy. Hand off to **race-condition-hunter**.
- **State-machine violations**: `approve` your own `pendingRequest`, re-open a closed object, etc.

Route deep logic work to **blf-hunter-agent**; GraphQL is just the delivery mechanism.

---

## 7.4 Information disclosure via errors / debug

- **Verbose errors**: trigger a resolver exception (wrong type, division by zero, malformed arg) →
  stack traces, SQL fragments, file paths, framework versions, internal hostnames. Report only when
  it leaks something exploitable (a secret, an internal endpoint, a version enabling a CVE) — a bare
  stack trace is usually informational.
- **`debug`/`tracing` extensions**: Apollo can return `extensions.tracing` with resolver timings and
  internal field names; some deployments leave Apollo Studio/landing page or `tracing:true` on in prod.
- **Field stuffing / over-fetching**: request every field on a type to surface data the UI hides
  (`internalNotes`, `riskScore`, `ssn`, `passwordChangedAt`).
- **`__typename` on interfaces/unions** leaks the concrete backing types (schema recon even with
  introspection off).

**Real pattern:** disclosed reports where GraphQL errors returned SQL/ORM stack traces exposing table
names + a DB version → chained to SQLi; and where `users`/`me` over-fetching leaked PII fields the UI
never rendered.

---

## 7.5 Subscriptions (often the least-guarded surface)

WebSocket subscriptions frequently skip the authz that queries enforce:
```graphql
subscription { messageAdded(channelId:"A_PRIVATE_CHANNEL") { body author } }
subscription { orderUpdated { id customerEmail total } }   # no filter → firehose of all tenants' events
```
Connect via `graphql-ws`/`subscriptions-transport-ws`, subscribe to another tenant's resource or an
unfiltered stream. Live cross-tenant data over the socket = BOLA on the subscription resolver (P1/P2).
Always enumerate subscriptions — most hunters never touch them.

---

## 7.6 Don't inflate
- CSRF on a **query** or with **bearer-token** (non-cookie) auth = not a finding.
- A stack trace with nothing sensitive = informational.
- Mass-assignment that the server silently ignores (field not persisted) = not a finding; confirm the
  privileged value actually stuck via a follow-up read.

Finish at `08-tooling-poc-report.md`.
