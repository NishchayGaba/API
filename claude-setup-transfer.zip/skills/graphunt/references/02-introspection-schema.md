# 02 — Introspection & Schema Recovery (Phase 3)

The schema is the map. With it, you list every operation, every argument, every type touching
money/PII/roles/other tenants. **You want the schema whether introspection is on or off.**

---

## 2.1 Introspection ON — dump everything

Quick liveness:
```json
{"query":"{__schema{queryType{name} mutationType{name} subscriptionType{name}}}"}
```

**Full introspection query** — in `payloads/full-introspection-query.txt` (paste-ready). Then
render it to a readable SDL:
```bash
# Save the JSON response as schema.json, then:
graphql-inspector introspect schema.json --write schema.graphql   # or:
node -e "const {buildClientSchema,printSchema}=require('graphql');const j=require('./schema.json');console.log(printSchema(buildClientSchema(j.data)))"
# Tools that do fetch+render in one shot:
inql -t https://$T/graphql -o inql_out         # Burp/standalone; writes schema + generates queries
clairvoyance https://$T/graphql -o schema.json # works with introspection OFF too (see 2.3)
graphql-path-enum -i schema.json -t User       # find every path that reaches type User
```

**Read the SDL like a hunter, not a developer.** Grep the schema for the money:
```bash
grep -iE 'password|token|secret|apikey|api_key|ssn|creditcard|billing|invoice|role|isAdmin|permission|internal|email|phone|address|balance|payout' schema.graphql
grep -iE '^\s*(delete|remove|update|create|set|grant|revoke|impersonate|reset|admin|export)[A-Za-z]*\(' schema.graphql   # dangerous mutations
grep -iE '@deprecated|@internal|@auth|@hasRole|@requires' schema.graphql                                                # gated / hidden fields
```

For every mutation and every query field, note: **what object does it touch, what argument
identifies that object, and would a resolver need to re-check ownership?** That list is your
Phase-4 hunt queue.

---

## 2.2 Introspection OFF — recover it anyway (this is where the money is)

Introspection being disabled is **not** a dead end. Real programs disable `__schema` but leave the
schema fully recoverable. Recover it four ways:

### (a) Field suggestions / "Did you mean" — clairvoyance
Most engines (graphql-js/Apollo, graphene, gqlgen, …) ship a "Did you mean X?" validator that
**leaks valid field names even with introspection disabled.** Send near-miss field names and read
the suggestions:
```json
{"query":"{ user { emaill } }"}
// → "Cannot query field 'emaill' on type 'User'. Did you mean 'email'?"
```
Automate it — this reconstructs a large fraction of the schema:
```bash
clairvoyance -o recovered_schema.json -w /path/wordlist.txt https://$T/graphql
# clairvoyanceng (maintained fork) is faster; feed it a big field wordlist (graphql-wordlist, or the
# words you mined from the JS bundle — those are the exact field names the client uses).
```
Then hunt the recovered schema exactly as in 2.1.

### (b) Mine the JS bundle (see the JS gate — do this always)
The client contains the operations verbatim. From the beautified bundles:
```bash
grep -rhoE '(query|mutation|subscription)\s+[A-Za-z0-9_]+[^{]*\{[^`]*' beautified/   # whole operations
grep -rhoE 'gql`[^`]+`' beautified/                                                  # apollo/urql literals
```
Every captured operation is a ready-made request. Operations the **UI never calls** but ship in the
bundle are the ones most likely to be unguarded.

### (c) Error-message oracle for arguments/types
Even without suggestions, error messages leak types:
```json
{"query":"{ user(id: 1) }"}              // "Field 'user' argument 'id' of type 'ID!' is required" → arg name+type
{"query":"mutation { updateUser }"}       // leaks required input object name
```

### (d) Persisted-query / APQ abuse
If the server only accepts persisted operations (rejects raw queries):
- **Apollo APQ**: the client sends `extensions.persistedQuery.sha256Hash`; on cache miss it sends
  the full query and the server stores it. You can **register your own arbitrary query** by sending
  the full query + its sha256 once — bypassing any "allowlisted operations only" control:
  ```json
  {"query":"{__typename}","extensions":{"persistedQuery":{"version":1,"sha256Hash":"<sha256 of the query string>"}}}
  ```
  If the server accepts and caches it, APQ is being used as APQ (perf), not as a security allowlist —
  you can send anything. If it rejects unknown hashes with `PersistedQueryNotFound` only for
  *registration*, it's a real allowlist; then harvest hashes from the JS instead.
- Harvest existing hashes from JS: `grep -rhoE '"sha256Hash":"[a-f0-9]{64}"' beautified/` and replay them.

---

## 2.3 Real disclosed examples — schema exposure → real impact

**PortSwigger Web Security Academy (canonical, reproducible):**
- *"Accessing private GraphQL posts"* — a blog exposes introspection; the schema reveals a
  `getBlogPost(id:)` query and a `postPassword` field on unpublished posts. Introspection → read the
  field → dump the secret. This is the exact real-world shape: **introspection is the enabler, a
  sensitive field is the bug.**
- *"Finding a hidden GraphQL endpoint"* — introspection disabled at `/graphql` but the endpoint is
  reachable at `/api` and responds to `{__typename}`; suggestions on → recover schema → same exploit.
- *"Accidental exposure of private GraphQL fields"* — a `users` query returns a field the UI never
  shows; reading it directly leaks another user's data. Mine the schema, not the UI.

**Real program pattern — GitLab (public HackerOne, discloses GraphQL reports):** GitLab has disclosed
multiple GraphQL info-disclosure issues where a resolver returned data that should have been
confidential (issue/epic titles, user email/username in contexts where it should be private). The
recurring root cause: a field authorized in one context is reachable via a different GraphQL path
that skips the check. **Takeaway: enumerate every path to a sensitive type** (`graphql-path-enum`),
not just the obvious one.

**Real pattern — WPGraphQL (WordPress):** with introspection on and the `users` connection exposed,
unauthenticated attackers enumerate all usernames/emails/roles — a classic recon → targeted-attack
chain reported across many WordPress bounty programs.

---

## 2.4 Output of this phase

- [ ] `schema.graphql` (dumped or recovered) saved.
- [ ] A ranked list: every operation touching **money / PII / roles / cross-tenant objects**, with
      the argument that identifies the object.
- [ ] Every JS-mined operation the UI does *not* call, flagged as high-priority (likely unguarded).

Go to `03-authz-bola-bfla-idor.md` — the highest-value class.
