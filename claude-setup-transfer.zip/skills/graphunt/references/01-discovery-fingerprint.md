# 01 — Discovery & Fingerprinting (Phases 1–2)

Goal: find **every** GraphQL endpoint (including hidden/renamed ones) and identify the engine so
you know which engine-specific bugs and WAF behaviours apply.

---

## 1.1 Endpoint discovery

GraphQL is served over HTTP. The endpoint is usually `POST /graphql`, but it hides under many paths.

**Wordlist of common paths — fuzz all of them (GET and POST):**
```
/graphql          /api/graphql        /graphql/console     /graphql-devtools
/graphql/          /v1/graphql         /graphiql            /graphql/schema.json
/api/gql           /v2/graphql         /graphiql.php        /playground
/gql              /v1/gql             /graphql/v1          /graphql/api
/query            /api/query          /console             /subscriptions
/graphql/api/     /admin/graphql      /user/graphql        /index.php?graphql
/api/graphql/v1   /gateway/graphql    /_graphql            /hasura/v1/graphql
```

**Probe technique** — the cleanest positive signal is the "must provide query string" error:
```bash
# A GraphQL endpoint answers a bare GET/POST with a structured GraphQL error, not a 404.
ffuf -w graphql-paths.txt -u https://$T/FUZZ -X POST \
  -H "Content-Type: application/json" -d '{"query":"{__typename}"}' \
  -mc 200,400,405 -mr 'query|__typename|GraphQL|errors'
```
- `{"data":{"__typename":"Query"}}` → **confirmed live GraphQL, introspection-friendly root**.
- `{"errors":[{"message":"Must provide query string."}]}` → confirmed GraphQL, needs a real query.
- `{"errors":[{"message":"...POST body sent invalid..."}]}` → confirmed, try correct content-type.

**Mine the endpoint out of the JS (highest hit rate — see the JS gate):**
```bash
grep -rhoE '/([a-z0-9_-]+/)*graph(ql|iql)[a-z0-9_/-]*' beautified/ | sort -u
grep -rhoE '"uri":\s*"[^"]*graphql[^"]*"' beautified/       # Apollo client config
grep -rhoE 'createHttpLink\([^)]*\)'      beautified/       # Apollo link
```
`nuclei -t technologies/graphql-detect.yaml -l live_hosts.txt` and `katana -jc` will also surface it.

**Don't forget alternate transports:**
- **GET**: `GET /graphql?query={__typename}` — many servers accept it. GET-reachable = CSRF-testable + cacheable.
- **Persisted queries only**: if raw queries are rejected but the app works, it uses **Automatic
  Persisted Queries (APQ)** or a hash allowlist — see `02-introspection-schema.md`.
- **WebSocket subscriptions**: `wss://.../graphql` with `graphql-ws`/`subscriptions-transport-ws`.
  Subscriptions are frequently less-guarded than queries — always enumerate them.

---

## 1.2 Fingerprint the engine (`graphw00f`)

Different engines leak schema differently, enforce depth/batch differently, and have distinct
default misconfigurations. Fingerprint first.

```bash
# graphw00f — sends benign malformed queries and matches error strings to an engine
python3 graphw00f.py -d -f -t https://$T/graphql
# -d detect, -f fingerprint, -t target. Also: -T (threads), -w wordlist for -d discovery mode.
```

**Fingerprint by hand** — send a deliberately broken query and read the error dialect:

| Probe | Engine tell |
|-------|-------------|
| `query @deprecated { __typename }` | `graphql-ruby`: "Directive 'deprecated' is missing required arguments" |
| `{ __typename @skip }` | Apollo: "Directive '@skip' argument 'if' is required" |
| `{alias:__typename}` then break it | **Hasura**: errors carry `"code":"validation-failed"` + `x-request-id` header |
| Any error | **Hasura** responses include `extensions.code`; **Apollo** include `extensions.code:"GRAPHQL_VALIDATION_FAILED"` |
| `X-Powered-By` / `Server` headers | Yoga/Envelop, Sangria (Scala), Absinthe (Elixir), Lighthouse (Laravel/PHP), gqlgen (Go) |

**Why the engine matters (engine → what to test first):**

| Engine | Language | Test-first bugs |
|--------|----------|-----------------|
| **Apollo Server** | Node | APQ hash abuse, introspection often on in prod, batching enabled by default in older versions |
| **Hasura** | Haskell | `x-hasura-admin-secret` leak = full DB; **`x-hasura-role`/`x-hasura-user-id` header injection** for privesc; permission-rule gaps; SQL functions exposed |
| **graphql-ruby** | Ruby | Introspection often on; **`node(id:)` global-ID IDOR** (Relay); depth/complexity sometimes unset |
| **graphene / Ariadne / Strawberry** | Python | Verbose Django/SQLAlchemy errors; often no query-cost limit |
| **Lighthouse** | PHP/Laravel | Mass assignment via `@spread`/`fill`, `@can` directive gaps, model-binding IDOR |
| **gqlgen** | Go | Introspection on by default; strong typing but resolver authz often missing |
| **Sangria** | Scala | Batching, deep queries; complexity analysis frequently off |
| **AWS AppSync** | managed | API-key auth left on, IAM/Cognito authz rules misconfigured, resolver VTL injection |
| **WPGraphQL** | WordPress | User enumeration via `users`, unauth post/media disclosure, introspection on |

---

## 1.3 WAF / rate-limit detection before you hunt

GraphQL WAFs are immature — but some programs deploy Cloudflare/Akamai GraphQL rules. Detect early
so you don't burn the IP.

- Send a benign introspection query. `403`/challenge with a clean `{__typename}` allowed = a GraphQL-aware WAF.
- Cloudflare GraphQL rules often block on the literal string `__schema` / `IntrospectionQuery`.
  Bypasses (try in this order, respect program rules):
  - Rename the operation: `query NotIntrospection { __schema { ... } }`.
  - Strip whitespace / newlines, or add extra whitespace/comments inside the query.
  - Use **aliases** on the meta-fields: `{ s: __schema { types { name } } }`.
  - Split introspection into small chunks (types first, then fields per type).
  - Switch transport: try GET if POST is filtered, or vice-versa; try `application/graphql`
    content-type instead of `application/json`.
- **Respect per-program rules.** Some programs forbid automated tooling / high RPS entirely.
  Throttle. Passive-first.

---

## 1.4 Output of this phase

Before moving on you must have written down:
- [ ] Every live GraphQL endpoint + transport (POST/GET/WS) + whether APQ/persisted-only.
- [ ] The engine + version hints.
- [ ] Whether introspection is ON or OFF (test `{__schema{queryType{name}}}`).
- [ ] Whether field suggestions are ON (send a typo, see if it says "Did you mean").
- [ ] WAF present? which strings trip it?

Then go to `02-introspection-schema.md`.
