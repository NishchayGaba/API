# 05 — DoS: Batching, Aliasing, Complexity (Phase 5)

⚠️ **Severity + rules first.** Many programs **forbid DoS / high-RPS / automated load** outright.
Read the program rules. A single **low-volume** proof that the server *accepts and processes* an
abusive query (measured latency delta, or a returned complexity error you triggered with a tiny
query) proves the flaw without taking anything down. **Never actually degrade a production service.**
Most GraphQL "DoS" findings are **P3/informational** unless you can show real, disproportionate
resource cost — downgrade honestly.

The bug is always the same: **missing query-cost controls** (no depth limit, no complexity/cost
analysis, no alias/batch caps, no pagination caps, no timeout). Each vector below is a way to make one
cheap request do expensive work.

---

## 5.1 Field duplication (cheapest amplification)
Same field repeated N times multiplies resolver work:
```graphql
query { me { id id id id id id id id id id … (×10000) } }
```
Generate: `python3 -c 'print("{me{"+"id "*5000+"}}")'`. If accepted and latency scales linearly →
no cost analysis. Tiny version (10×) already proves it via a small latency delta.

## 5.2 Alias overloading
Aliases let you request the same expensive field many times in one query (also the engine of
brute-force in `06`):
```graphql
query { a1: expensiveReport(range:"1y"){total} a2: expensiveReport(range:"1y"){total} … }
```

## 5.3 Deep recursion via circular relationships
If the schema has a cycle (`User → posts → author → posts → …`), nest it deep:
```graphql
query {
  user(id:1){ posts{ author{ posts{ author{ posts{ author{ id }}}}}}}
}
```
Depth of 15–20 on a circular relation with list fields = exponential resolver fan-out. A depth-limit
error at, say, depth 11 tells you the limit exists (good—note it). No error at depth 30 = no depth
limit (the finding). Use a **shallow** probe to establish the limit, not a bomb.

## 5.4 Circular fragments (parser/validation DoS)
Some engines don't reject cyclic fragment spreads pre-execution:
```graphql
query { ...A }
fragment A on Query { ...B }
fragment B on Query { ...A }
```
graphql-js rejects this ("Cannot spread fragment ... within itself"); engines that don't may hang in
validation. Send once, measure, stop.

## 5.5 Query batching (array of operations)
Many servers accept a JSON **array** of operations and run them all in one request:
```json
[ {"query":"{expensiveThing}"}, {"query":"{expensiveThing}"}, … ]
```
This both amplifies cost **and** multiplies any per-request rate limit (see `06` — this is the
high-value use). Test whether batching is enabled with a 2-element array first.

## 5.6 Directive overloading
Thousands of directives on one field can blow up validation in some engines:
```graphql
query { __typename @a @a @a @a … (×1000) }
```

## 5.7 Pagination abuse
`first: 1000000` / `last:` with no server cap → huge result set = memory DoS **and** a mass-exfil
primitive:
```graphql
{ users(first: 1000000) { edges { node { email } } } }
```
This one is often more valuable as **mass PII exposure** than as DoS — if the server honors a giant
`first`, you have bulk data access. (Respect the 50-record cap when proving; use `totalCount`.)

---

## 5.8 Real disclosed examples
- **PortSwigger / OWASP GraphQL cheat sheet** document depth, alias, and batching resource attacks as
  the canonical GraphQL DoS classes; reproducible in the Academy labs.
- **graphql-cop / batchql** (Dolev Farhi et al.) ship checks for batching, alias overloading, field
  duplication, and deep recursion precisely because these are the recurring real-world findings.
- **Real program pattern:** absent complexity limits on a public GraphQL API where a single crafted
  query pins CPU — typically triaged **P3** (or higher if it reliably takes the service down and the
  program counts DoS). Where the same missing cap enables **bulk PII extraction** via huge `first:`,
  it's re-classed as an **info-disclosure P2**, which is usually the better story to tell.

## 5.9 Don't inflate
- "Batching is enabled" alone = not a finding. It's only a finding when it **amplifies** something
  (rate-limit bypass in `06`, or measurable resource exhaustion).
- A depth/complexity **error** you triggered is *evidence the control exists* — the finding is its
  *absence*, not its presence.
- Self-inflicted slowness with no amplification factor = informational.

Highest-value pivot from this file: batching/aliasing as a **rate-limit / brute-force** primitive →
`06-auth-bypass-ratelimit.md`.
