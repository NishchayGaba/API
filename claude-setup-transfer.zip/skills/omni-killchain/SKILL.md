---
name: omni-killchain
description: >
  Elite end-to-end offensive bug-bounty hunting orchestrator. ALWAYS activate for: full-scope recon, killchain, bug hunting strategy, target triage, attack surface mapping, "find me a bug", "hunt on $target", high-payout vuln hunting, P1/P2 bug discovery, $10K+ bounty hunting, account takeover (ATO), authentication bypass, IDOR/BOLA, SSRF→cloud-metadata, RCE chains, file upload to RCE, dependency confusion, request smuggling, cache poisoning, OAuth/SAML/JWT abuse, GraphQL abuse, exposed services (Jenkins/Kubernetes/Spring/Actuator), secrets leaks (GitHub/Postman), subdomain takeover, race conditions, web cache deception, XXE chains, unsafe deserialization, SSTI, prototype pollution, mass assignment, CORS abuse, postMessage abuse, business logic, privilege escalation, chaining low → critical, exploit PoC writing, HackerOne/Bugcrowd/Intigriti report writing. Built from analysis of HackerOne TOP100PAID, TOP100UPVOTED, TOPRCE, TOPSSRF, TOPUPLOAD, TOPOAUTH, TOPOPENID, TOPINFODISCLOSURE, TOPXXE plus Awesome-Bugbounty-Writeups. Routes to specialist hunters (sqli, xss, blf, js-recon, prompt-injection) when applicable. Authorized testing only — bug bounty in-scope, pentest engagement, or CTF. Token-efficient. Never assumes — always verifies. 20+ year red-team mindset.
---

<!-- MANDATORY-JS-RECON-DOCTRINE v3 — injected across EVERY skill. Do not delete or gate behind a condition. -->

# 🚨 MANDATORY JS RECON GATE — NO SKIP, NO EXCEPTIONS

**This block is law in every skill.** Whatever else this skill does, if a web/HTTP target is
anywhere in scope you MUST complete the JS recon pipeline below BEFORE you conclude recon,
rank surface, declare "nothing found," or move to the next phase. Skipping any step is a
**process failure, not an optimization.** There is no file-count exception, no time-pressure
exception, no "it's a small app / SPA / static site" exception.

> Client-side JS is the attack-surface map of the entire application. Every bundle, chunk,
> worker, source map, service worker, and inline script leaks endpoints, secrets, roles,
> feature flags, and business logic the server never meant you to see. Hunters who skip JS lose the P1s.

---

## RULE 1 — ALL crawlers are MANDATORY on EVERY live host — plus 3 new mandatory classes

Run **all five** tool-classes — never just one, never "pick your favourite." Enumerate subdomains
first, then run this per host (each subdomain ships its own bundle, secrets, and logic):

```bash
subfinder -d "$T" -all -silent | httpx -silent -mc 200 -o live_hosts.txt   # per-host, not per-apex

# PASSIVE (zero-touch history — catches dead/forgotten/rotated-but-still-live JS)
echo "$HOST" | waybackurls | anew all_urls.txt
echo "$HOST" | gau --subs  | anew all_urls.txt
echo "$HOST" | waymore -mode U -oU waymore.txt 2>/dev/null; cat waymore.txt | anew all_urls.txt
awk '/\.js([?]|$)/' all_urls.txt | anew js.txt

# ACTIVE (live DOM, dynamic <script>, chunk loads)
katana   -u "https://$HOST" -jc -jsl -d 5 -kf all -aff -silent | anew all_urls.txt
hakrawler -u "https://$HOST" -d 3 -subs 2>/dev/null              | anew all_urls.txt
gospider  -s "https://$HOST" -d 3 --js  2>/dev/null              | anew all_urls.txt
cariddi   -s "https://$HOST" -intensive 2>/dev/null | grep '\.js'| anew js.txt
awk '/\.js([?]|$)/' all_urls.txt | anew js.txt

# MANDATORY: Service Workers (often forgotten, contain cache logic + secrets)
curl -sL "https://$HOST/sw.js"              -o "js_files/sw.js"              2>/dev/null
curl -sL "https://$HOST/service-worker.js"  -o "js_files/service-worker.js"  2>/dev/null
curl -sL "https://$HOST/manifest.json" | jq -r '.service_worker // empty'   2>/dev/null
# Check Web App Manifest for SW registration path and parse its scope

# MANDATORY: Inline JS extraction from every HTML page (tools miss embedded <script> blocks)
python3 - <<'PYEOF'
import re, sys, requests
from bs4 import BeautifulSoup
HOST = sys.argv[1] if len(sys.argv)>1 else ""
for path in ['/', '/app', '/dashboard', '/admin', '/login']:
    try:
        r = requests.get(f"https://{HOST}{path}", timeout=10,
                         headers={"User-Agent":"Mozilla/5.0"})
        soup = BeautifulSoup(r.text, 'html.parser')
        for i, tag in enumerate(soup.find_all('script', src=False)):
            if tag.string and len(tag.string) > 100:
                fname = f"js_files/inline_{path.strip('/') or 'root'}_{i}.js"
                open(fname,'w').write(tag.string)
                print(f"[INLINE] {fname} ({len(tag.string)} chars)")
        # Also capture window.__NEXT_DATA__, window.__NUXT__, window.__remixContext
        for pat in [r'window\.__NEXT_DATA__\s*=\s*({.+?});',
                    r'window\.__NUXT__\s*=\s*(.+?)\s*;',
                    r'window\.__remixContext\s*=\s*({.+?});']:
            m = re.search(pat, r.text, re.DOTALL)
            if m: print(f"[SSR-STATE] {pat[:20]}... FOUND at {HOST}{path}")
    except: pass
PYEOF

# MANDATORY: Framework-specific chunk paths (lazy bundles tools never trigger)
# Next.js
curl -s "https://$HOST/_next/static/chunks/pages/_app.js" | head -5 | grep -q 'function' && \
  echo "[NEXT.JS] _next/ chunks present" && \
  katana -u "https://$HOST" -d 3 -silent | grep '_next/static' | anew js.txt
# Nuxt
curl -s "https://$HOST/_nuxt/" -o /dev/null -w "%{http_code}" | grep -q 200 && \
  echo "[NUXT] _nuxt/ chunks present"
# Vite
curl -s "https://$HOST/assets/" -o /dev/null -w "%{http_code}" | grep -q 200 && \
  echo "[VITE] /assets/ present"
```

**MANUAL CRAWL is equally mandatory — tools miss auth-gated and lazy-loaded routes:**
- Open the app in a real browser with **Burp/mitmproxy inline**. **Log in.**
- Click through **every** route, tab, modal, multi-step wizard, settings/admin area.
- Watch the Network panel: every `.js`, every XHR/fetch, every WebSocket frame, every chunk
  pulled on navigation goes into `js.txt` / the endpoint list. SPAs load chunks lazily — a
  route you never visited = a bundle you never saw = bugs you never found.
- Toggle every feature flag you can find and capture the JS that loads behind each one.
- Burp extensions **JS Miner** + **Param Miner** + **JS Link Finder** run passively — enable all three.
- **In DevTools → Application tab:** check Service Workers registered, Cache Storage entries
  (cached JS/API responses), and Local Storage / Session Storage for tokens and flags.
- **In DevTools → Sources tab:** look for webpack internal entries (`webpack://`) and
  source-mapped originals — these are readable even without fetching `.map` separately.

---

## RULE 2 — Recover, beautify, DEOBFUSCATE, and READ every file (never grep-only)

```bash
sort -u js.txt -o js.txt && mkdir -p js_files beautified recovered deobfuscated
xargs -a js.txt -P20 -I@ sh -c 'curl -sL -A "Mozilla/5.0" "@" -o "js_files/$(echo @ | md5sum | cut -c1-16).js"'
for f in js_files/*.js; do js-beautify "$f" > "beautified/$(basename "$f")"; done

# SOURCE MAPS = full original source (readable, real var names, internal paths). A 200 is game over.
while read u; do
  s=$(curl -so /dev/null -w "%{http_code}" "$u.map")
  [ "$s" = "200" ] && echo "$u.map"
done < js.txt | tee sourcemaps_found.txt
# Recover each: sourcemapper -url URL -output ./recovered/   OR  unwebpack  OR  webcrack
# For multiple: cat sourcemaps_found.txt | xargs -I@ sourcemapper -url "@" -output ./recovered/

# WEBPACK DEOBFUSCATION — webcrack handles packed/self-executing bundles and recovers modules
# Install: npm install -g webcrack
for f in beautified/*.js; do
  webcrack "$f" -o "deobfuscated/$(basename "$f" .js)/" 2>/dev/null && \
    echo "[WEBCRACK] deobfuscated: $f"
done

# OBFUSCATOR.IO / eval-packed code — detect and unwrap
grep -l 'eval(function(p,a,c,k,e,d)' beautified/*.js | while read f; do
  node -e "var x=$(cat $f); if(typeof x==='string') console.log(x)" > "deobfuscated/$(basename $f)" 2>/dev/null
done
# String array rotation / hex strings
grep -l 'String\["fromCharCode"\]\|\\x[0-9a-f]\{2\}' beautified/*.js | \
  xargs -I@ sh -c 'node -e "eval(require(\"fs\").readFileSync(\"@\",\"utf8\"))" 2>/dev/null > deobfuscated/$(basename @)'

# WEBPACK: pull the runtime bootstrap's chunk-id→hash map to enumerate LAZY chunks no crawler triggered
grep -oE '[0-9]+:"[0-9a-f]{6,}"' beautified/*runtime* beautified/*.js 2>/dev/null | head -100
# Reconstruct chunk URLs: <publicPath>/<chunkId>.<hash>.chunk.js and fetch each
# Next.js chunks: /_next/static/chunks/<id>.<hash>.js
# Vite chunks: /assets/<name>.<hash>.js
```

**Grep is a triage pass to prioritize — NEVER the analysis itself.** Grep finds `apikey` and
`fetch(`. It does not tell you a URL-upload feature silently proxies server-side (SSRF), or that
a role flag is set client-side and never re-checked. **Every beautified/deobfuscated file gets
read end to end, including service workers and inline scripts.** No exception — budget the time;
this step is supposed to be slow.

---

## RULE 3 — Hunt these in every file (the money list — v2 expanded)

Static-scan to triage, then READ to confirm. Scanners: `trufflehog filesystem js_files/`
(verifies live keys), `jsluice urls|secrets js_files/*.js`, `mantra -f js.txt`,
`SecretFinder -i <f> -o cli`, `LinkFinder -i beautified/ -o cli`, `xnLinkFinder`,
`nuclei -t http/exposures/ -l js.txt`, `retire.js --js`, `whispers --target js_files/`.

### Secrets / Tokens (expanded — AI era + SaaS full coverage)

**Cloud & Infrastructure**
- **AWS** `AKIA…` access key + `aws_secret` 40-char key
- **GCP** `AIza[0-9A-Za-z\-_]{35}` + service-account JSON blob (`"type":"service_account"`)
- **Azure** storage connection strings `DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...`; SAS tokens `?sv=`; tenant ID + `client_secret` in MSAL/ADAL config blocks
- **Databricks** `dapi[a-zA-Z0-9]{32}`
- **Snowflake** `account=...;user=...;password=...` in connection strings
- **MongoDB Atlas** `mongodb+srv://user:pass@cluster`
- **Redis** `redis://:password@host:port`
- **SMTP** `smtp://user:pass@host` in nodemailer/transporter configs
- **PEM private keys** `-----BEGIN (RSA |EC )?PRIVATE KEY-----`

**AI / ML Providers**
- **OpenAI** `sk-[A-Za-z0-9]{48}` and project keys `sk-proj-[A-Za-z0-9_\-]{48,}`
- **Anthropic** `sk-ant-[A-Za-z0-9\-_]{95,}` — full Claude API key
- **HuggingFace** `hf_[A-Za-z0-9]{34,}` — model download + write access
- **Replicate** `r8_[A-Za-z0-9]{40}`
- **Groq** `gsk_[A-Za-z0-9]{52}`
- **Cohere** `[A-Za-z0-9]{40}` with `cohere`/`CO_API_KEY` context
- **Together.ai** `[A-Za-z0-9]{40}` with `together`/`TOGETHER_API_KEY` context
- **Mistral** `[A-Za-z0-9]{32}` with `mistral`/`MISTRAL_API_KEY` context
- **Perplexity** `pplx-[A-Za-z0-9]{48}`
- **Pinecone** API key in vector DB init (`new Pinecone({ apiKey: … })`)
- **Voyage AI** `pa-[A-Za-z0-9]{40}`

**Payments & Finance**
- **Stripe** `sk_live_[0-9a-zA-Z]{24,}` / `sk_test_…`; webhook secret `whsec_[A-Za-z0-9]{32,}`
- **Braintree** `access_token$production$[A-Za-z0-9]{32}`
- **Square** `sq0atp-[A-Za-z0-9_\-]{22}` (access) / `sq0csp-[A-Za-z0-9_\-]{22}` (client secret)
- **Plaid** `client_id` + `secret` in PlaidLink init config
- **PayPal** `client_id` + `client_secret` in SDK init

**Communication & Messaging**
- **Twilio** `AC[a-zA-Z0-9]{32}` Account SID + `SK[a-z0-9]{32}` Auth Token
- **SendGrid** `SG.[A-Za-z0-9_\-]{22}.[A-Za-z0-9_\-]{43}`
- **Mailgun** `key-[a-zA-Z0-9]{32}`
- **Mailchimp** `[a-zA-Z0-9]{32}-us[0-9]{1,2}`
- **Slack** `xox[baprs]-…` / webhook `hooks.slack.com/services/…`
- **Discord bot** `[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}`
- **Telegram bot** `[0-9]+:AAF[a-zA-Z0-9_-]{33}`
- **Pusher** `app_key` + `app_secret` + cluster inline in Pusher JS init

**Developer & SaaS Platforms**
- **GitHub** `ghp_[A-Za-z0-9]{36}` / `github_pat_[A-Za-z0-9_]{82}`; webhook secret `sha256=` signing key
- **Vercel** `vc_[A-Za-z0-9]{32,}` / `VERCEL_TOKEN`
- **Netlify** `netlify-[A-Za-z0-9\-_]{40}`
- **Shopify** `shpss_[A-Za-z0-9]{32}` / `shpat_[A-Za-z0-9]{32}`; webhook HMAC secret
- **Algolia admin key** `[A-Za-z0-9]{32}` with `adminApiKey` label
- **Mapbox** `sk.[A-Za-z0-9]{80,}`
- **Datadog** `DD_API_KEY` / `datadog-[A-Za-z0-9]{32}`
- **Intercom** `[A-Za-z0-9]{8}-[A-Za-z0-9]{4}-…` with `intercom` context
- **Okta** `SSWS [A-Za-z0-9]{42}` API token
- **Auth0** `client_secret` in SPA SDK init; management API token `v2/…`
- **New Relic** `NRAK-[A-Za-z0-9]{27}` license key
- **Sentry DSN** `https://[key]@[org].ingest.sentry.io/[id]` — reveals org, project, DSN secret
- **LaunchDarkly** `sdk-[A-Za-z0-9\-]{40}` server-side key (write access to flags)
- **Segment** write key `[A-Za-z0-9]{32}` with `analytics.load(` context

**Auth & Crypto**
- **JWTs** `eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}`
- **Basic auth blobs** `Authorization: Basic [A-Za-z0-9+/=]{20,}`
- **OAuth** `client_id` + `client_secret` pairs
- **Apple APNs** `.p8` private key + Team ID + Key ID in push notification config

**Firebase / Supabase / Realtime DBs**
- **Firebase config object** `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId` — reveals project, enables unauth REST probing even if the key itself is "public"
- **Supabase** `SUPABASE_ANON_KEY` / `SUPABASE_SERVICE_ROLE_KEY` (service role = full DB access)

**Cloudinary**
- `cloudinary://[api_key]:[api_secret]@cloud_name` in upload preset config

**WebRTC**
- `iceServers` config with `urls: turn:...` + `username` + `credential` — TURN server credentials, test for reuse

### Hidden / Internal / Staging Endpoints
Every endpoint in JS is an UNTESTED endpoint. Real payout pattern: `/api/v2/internal/users`
recovered from obfuscated JS → full user DB → $25k. Also hunt:
- **WebSocket/SSE** `ws://`, `wss://`, `/subscribe`, `/stream`, `/sse`, `/events` — WS endpoints
  skip HTTP auth middleware and are frequently unprotected
- **GraphQL subscriptions** `subscription {`, `/subscriptions`, `/graphql-ws`
- **Deprecated v1 APIs** when v2 added auth — the old version often still runs
- **`window.__NEXT_DATA__`** — Next.js SSR embeds server-side API responses verbatim in HTML;
  often contains auth tokens, session data, internal API base URLs, and user PII
- **`window.__NUXT__`** — same problem on Nuxt apps
- **`window.__remixContext`** — Remix loader data embedded in HTML

### Critical Architecture & Logic Findings (only readable, not greppable)

These are the findings that separate JS readers from JS greppers. No scanner catches these — you find them only by understanding the code.

**Internal attack surface expansion**
- Internal microservice URLs (`http://internal-api/`, `http://10.x.x.x/`, `grpc://`) → direct SSRF targets not reachable from outside
- Shadow API versions: `v0`, `beta`, `internal`, `legacy` paths referenced in code but absent from docs — old version often has no auth
- Admin/ops routes (`/admin`, `/internal`, `/ops`, `/debug`) with comments revealing auth requirements (or lack of)
- Lambda function URLs, API Gateway stage variables, Cloud Function names → direct invocation bypassing WAF/rate limit
- S3/GCS/Azure blob container names in upload/download logic → enumerate + test ACL misconfig
- gRPC service + method names → probe for exposed gRPC-web endpoints without auth
- Cloud account IDs, project IDs, tenant IDs → enumerate cross-tenant

**Auth & authz logic that breaks server-side**
- Client-side role checks (`if (user.role === 'admin')`) → call the endpoint directly with low-priv token; server may never re-validate → BFLA
- Feature flags controlling security controls (`if (flags.skipRateLimit)`, `if (!flags.enforceAuth)`) → send overridden flag value in request/cookie
- Environment detection: `if (process.env.NODE_ENV !== 'production') { skip2FA() }` → probe if staging logic bleeds into prod headers
- Multi-tenant switching: how `org_id`/`tenant_id` is set client-side → test with another tenant's ID → horizontal escalation
- Permission bitmask definitions client-side → craft value that grants escalated bits
- A/B test variant code that unlocks privileged UI or unguarded endpoints for a subset of users

**Business logic & price manipulation**
- Price, discount, shipping, tax calculation done client-side → send manipulated values directly to order endpoint
- Promo/referral/coupon code generation patterns → predictable? Brute-forceable?
- Payment flow state machine definition → identify step-skip to complete order without payment leg
- Quantity / negative-value handling in cart logic → test negative quantities for credit

**Token & crypto weaknesses (read the generation code)**
- Token generation using `Math.random()`, `Date.now()`, or short entropy → predictable; reproduce offline
- Client-side encryption with hardcoded IV or key → decrypt intercepted traffic offline
- Password hashing revealed: `md5(pass + salt)`, `sha1(pass)` → crack offline
- HMAC signing with client-visible secret → forge arbitrary signed requests
- JWT construction showing which claims are client-set and which the server skips validating

**Injection hints buried in logic**
- SQL fragments in ORM calls: `db.raw(userInput)`, `knex.raw(…)`, `sequelize.query(userInput)` → direct SQLi target
- GraphQL query/mutation definitions → identify sensitive fields, hidden resolvers not in introspection
- Template strings fed to eval or innerHTML: `` eval(`SELECT ${input}`) `` → confirmed injection sink
- Regex input validation patterns → find gaps, edge cases, Unicode bypasses

**CORS / postMessage / redirect bypass hints**
- `allowedOrigins` array → find weakest entry (wildcard subdomain? `null` origin accepted?)
- postMessage handler: `event.data[action]()` or `window[event.data.fn]()` without `event.origin` check → XSS pivot from any frame
- Redirect whitelist using `startsWith`: `url.startsWith('https://company.com')` → bypass with `https://company.com.evil.com`
- CORS logic: `if (allowedOrigins.includes(req.headers.origin))` — test `null` origin, `Origin: ` (empty)

**Recon amplifiers (fingerprint hidden features)**
- Analytics event names (`track('admin_panel_viewed')`) → enumerate hidden features/flows not linked in nav
- Error handler stack traces → reveals internal file paths, framework versions, DB query structure
- `console.log` / `console.debug` statements left in prod → tokens, IDs, internal state dumped to DevTools

### Client-Side Auth & Roles
`isAdmin`, `role === 'admin'`, `hasPermission`, `parseJwt`, `atob(token)`,
`localStorage.setItem('admin',…)`, `featureFlags`, `canAccess`, `tier === 'enterprise'`.
Any UI/route gated ONLY client-side → call the endpoint directly with a low-priv token.

### Hidden Routes & Feature Flags
Dump SPA router table (React Router / Vue Router / Angular / Next.js pages directory).
Visit admin/beta/internal routes the nav never links. Flip feature flags (`localStorage`,
`?feature=`, cookie, JSON config, LaunchDarkly/Statsig/Split client keys) to unlock
ungated functionality.

### DOM XSS Sinks
`innerHTML`, `outerHTML`, `document.write`, `eval`, `new Function`, `setTimeout("…")`,
jQuery `$()`, `.html()`, `dangerouslySetInnerHTML`, `v-html`, Angular `bypassSecurityTrustHtml`;
sources `location.hash/search/href`, `postMessage`, `document.referrer`, `window.name` → trace source→sink.

### Prototype Pollution
`__proto__`, unsafe `merge/extend/Object.assign(x.prototype…)`, query-string parsers,
`qs.parse`/`querystring.parse` feeding into merge → gadget chain to XSS/RCE.

### Cloud & 3rd-party Refs
`*.amazonaws.com`/`s3://`, `firebaseio.com`, `storage.googleapis.com`,
`*.blob.core.windows.net`, `cloudfront.net`, `*.digitaloceanspaces.com`,
`supabase.co`, `*.neon.tech`, `*.planetscale.com` → test misconfig + takeover.

### postMessage Without Origin Check
`addEventListener('message',…)` with no `e.origin` check → cross-origin data theft / DOM XSS.

### Dependency CVEs
Map bundled lib versions to OSV/Snyk (`retire.js`). One bundled vulnerable lodash / axios /
DOMPurify / jQuery / Next.js = your bug. **2025 critical:** Next.js CVE-2025-29927
(middleware auth bypass via `x-middleware-subrequest` header — any Next.js ≤ 15.2.2).

### Historical / Version Diffing
Pull OLD JS from Wayback, diff vs live. Secrets and endpoints "removed" from current JS are
frequently STILL LIVE server-side; forgotten APIs survive in old bundles.

### Obfuscation as a Red Flag
Heavy obfuscation (`eval(function(p,a,c,k,e,d)`, string arrays, hex strings, `_0x` var names)
signals the developer was trying to hide something. Deobfuscate with `webcrack` / `synchrony` /
`de4js` and READ — the payoff rate on obfuscated code is higher than on readable code.

---

## RULE 4 — Confirm dynamically, THEN it's a finding (kill false positives)

Nothing gets reported on a regex hit alone. Prove it live:
- **OAuth client creds** → mint a real token:
  `curl -sX POST https://apigw.$T/token -H "Authorization: Basic <BLOB>" -d grant_type=client_credentials`
  → `access_token` returned = confirmed High/Crit (can't rotate without breaking prod).
- **AI API key** → call the provider's identity/model-list endpoint:
  `curl -s https://api.openai.com/v1/models -H "Authorization: Bearer $KEY"` → 200 = live.
  `curl -s https://api.anthropic.com/v1/models -H "x-api-key: $KEY" -H "anthropic-version: 2023-06-01"` → 200 = live.
- **`window.__NEXT_DATA__`** → curl the page without JS (`curl -sL https://HOST/page`) and
  parse the JSON blob from the HTML — if it contains session tokens or user PII, that's a finding.
- **"Internal" endpoint** → hit it unauth / cross-tenant and diff the response.
- **Params from JS** → fuzz `debug=true`, `admin=1`, `callback=`, `redirect=` and JS-seeded names
  (`x8` / `Arjun` from bundle var names) against the endpoints they belong to.
- **DOM XSS** → drive source→sink in real headless Chrome (Playwright preferred over Selenium);
  screenshot the alert/exfil.
- **WebSocket endpoint** → connect with `wscat`/`websocat` without auth header; send a probe message.
- **Next.js middleware bypass** → add `x-middleware-subrequest: middleware:middleware:middleware`
  header to any request behind a Next.js middleware guard; 200/data = CVE-2025-29927 confirmed.
- Feed confirmed secret keys to the **jsmax** skill for exploitation; DOM-XSS / prototype-pollution
  gadgets to the **xss-hunter-agent** skill for payload crafting.

- **Race condition** → fire 20+ parallel requests simultaneously (curl `--parallel` / Python asyncio+aiohttp / Playwright multi-context); confirm with: multiple `200 OK` on one-time-use action, duplicate records, balance goes negative, two success responses for a single-use token. Build the script fresh per target — timing constraints differ per app.
- **Secret new patterns** → confirm with provider identity endpoint: Twilio `api.twilio.com/2010-04-01/Accounts/$SID.json` (Basic auth); Stripe `/v1/account`; Mailgun `/v3/domains`; Discord `/api/v10/users/@me`; Telegram `api.telegram.org/bot$TOKEN/getMe`; Databricks `/api/2.0/token/list`; Supabase service role → `supabase.co/rest/v1/` with `apikey:` header (returns full table data = confirmed)
- **Business logic / price manipulation** → capture the POST body, modify the price/quantity field, replay with curl; confirm server used the client value in response total
- **Internal URL SSRF** → hit it via a server-side parameter that makes the app fetch a URL; confirm with `interactsh` callback or timing difference
- **Multi-tenant ID swap** → repeat the request with a different org/tenant ID; confirm data returned belongs to the other tenant

**Only then write the report.** No "could potentially" — prove it or drop it.

---

## CAPABILITY MAP — what runs autonomously vs. needs human

| Finding class | Autonomous (find + PoC + confirm) | Notes |
|---|---|---|
| Secret in JS | ✅ Full | grep → curl identity endpoint → confirmed |
| Unauth API endpoint | ✅ Full | curl without auth → check data returned |
| CORS bypass | ✅ Full | curl with crafted Origin header |
| SSRF via internal URL | ✅ Full | curl + interactsh callback |
| JWT attack (alg:none, claim tamper) | ✅ Full | craft JWT → curl |
| GraphQL introspection + BOLA | ✅ Full | full query chain |
| Price / business logic manipulation | ✅ Full | modified POST body via curl |
| Redirect bypass | ✅ Full | curl -L with crafted URL |
| Feature flag abuse | ✅ Full | send overridden flag value |
| S3/GCS/Firebase unauth | ✅ Full | aws s3 ls / curl REST |
| Race condition | ✅ Full | curl --parallel / asyncio / Playwright multi-context (script built fresh per target) |
| DOM-XSS | ⚠️ Script provided | Drive with claude-in-chrome or Playwright — needs browser session |
| postMessage XSS | ⚠️ Script provided | Write exploit HTML; user loads it |
| Auth flow logic bugs | ⚠️ Needs session | Requires authenticated cookies/tokens from user |
| CAPTCHA-gated flows | 🚫 Human-in-loop | Firm boundary — user solves, automation continues |
| MFA bypass | 🚫 Needs real device | Requires live TOTP/SMS |
| Client-side crypto weakness | 🔍 Identify + explain | Code identified, math worked through manually |
| Deobfuscation | ⚠️ Tool-dependent | Requires webcrack/synchrony installed; check first |
| Prototype pollution | ⚠️ Script provided | Find sink + write PoC; browser execution needed |

---

# OMNI-KILLCHAIN — Elite Bug Hunting Orchestrator

> **Scope reminder**: Authorization gate first. Confirm target is in-scope for an active bounty program / pentest / CTF before any active probing. If unclear, ask.

---

## PHILOSOPHY (read once, internalize forever)

1. **High payouts come from impact, not novelty.** A boring IDOR that exposes 10M users beats a clever XSS on a marketing page. Always ask: *who else does this affect, and what's the worst they can do?*
2. **Chains > single bugs.** $10K+ reports are almost always chains: `subdomain takeover → cookie scoping → ATO`, `SSRF → metadata → cloud creds → S3 read → source code → harder bugs`, `low IDOR → mass assignment → admin role → tenant pivot`.
3. **Boring features hide gold.** Import/export, bulk actions, integrations, webhooks, password reset, email confirmation, billing, file upload, OAuth callbacks, GraphQL, admin migration tools — these are where the real bugs live. Don't waste hours on the homepage search box.
4. **Verify, don't assume.** Memory of past programs ≠ current state. Re-recon before re-reporting.
5. **Document like a Tier-1 hunter.** Reproducible PoC, video/curl, impact statement, suggested fix, CVSS — see `references/report-writing.md`.

---

## PHASE 0 — TARGET TRIAGE (do this first, every time)

Classify the target before touching it. Different classes get different killchain routes.

```
SaaS multi-tenant web app   → IDOR/BOLA, mass assignment, tenant pivot, GraphQL, OAuth, billing logic
Devtool / SCM (GitLab-like) → import features, template injection, file read, git flag injection, plugin RCE
Marketplace / Two-sided     → seller<->buyer auth boundary, marketplace IDOR, escrow logic, payment flows
API-first / mobile-backend  → BOLA, mass assignment, JWT, GraphQL introspection, rate limit bypass
Identity provider / OAuth   → redirect_uri, state, PKCE, scope creep, account linking, SAML signature
File processor (PDF/img/AV) → ImageMagick, FFmpeg, Ghostscript, ExifTool, parser confusion, SSRF, XXE
E-commerce / payments       → race conditions, coupon stacking, refund logic, currency mismatch, IDOR on orders
Internal/admin panel exposed→ default creds, SSRF pivot, exposed actuators, debug endpoints
Self-hosted/on-prem         → version disclosure, supply chain, dependency confusion
Cloud infra (S3/IAM)        → public buckets, IAM misconfig, presigned URL leaks, metadata SSRF
```

If you can't classify in 60 seconds, you haven't done enough recon. Go to Phase 1.

---

## PHASE 1 — RECON KILLCHAIN

Read `references/recon-killchain.md` for full one-liners. Summary flow:

```
SCOPE -> SUBDOMAINS -> ASSETS -> HTTP PROBE -> SCREENSHOT -> JS HARVEST -> ENDPOINTS -> PARAMS -> SECRETS -> DECISION
```

**Passive (no traffic to target)**
- `subfinder -d $T -all -silent`, `amass enum -passive`, `chaos -d $T`
- `crt.sh`, `github-subdomains -d $T -t $GH_TOKEN`, `cero -c 1000 $T`
- `waybackurls $T`, `gau --threads 10 $T`, `katana -passive -list ...`
- `trufflehog github --org=$T --only-verified`, `gitleaks`, `noseyparker`

**Active**
- `httpx -silent -status-code -title -tech-detect -ip -cname`
- `naabu -top-ports 1000` then `nmap -sV -sC -p $PORTS`
- `katana -d 5 -jc -kf all -aff -fs fqdn`
- `gospider -d 5 -c 10 --js`
- `ffuf -w $WL -u https://$T/FUZZ -mc all -fc 404 -ac` (auto-calibrate)

**Decision criteria (move to Phase 2 only when):**
- >=10 live hosts mapped with tech stack
- >=1 admin/staging/dev subdomain identified
- JS bundles harvested from EVERY live subdomain (not just the apex), parsed for
  endpoints, beautified, and fully read end to end (`js-recon-agent`) — grep/parsing
  alone doesn't satisfy this, no file-count exception
- Auth flow understood (cookies, JWT, session, OAuth?)
- Existing CVEs for the stack catalogued

---

## PHASE 2 — ATTACK SURFACE MAPPING

Read `references/recon-killchain.md` § "Surface Mapping". Build this table for each target before attacking:

```
| Surface              | Examples                                      | Top bug classes                          |
| -------------------- | --------------------------------------------- | ---------------------------------------- |
| Auth                 | /login, /reset, /verify, /oauth/callback      | ATO, OAuth, password reset, SAML, JWT    |
| User-controlled IDs  | /user/{id}, /order/{id}, GraphQL node(id:...) | IDOR, BOLA, mass assignment              |
| Status/state siblings| /invitations/{challenged,unchallenged}, pending/accepted, active/archived | BOLA (per-variant authz gap → token+PII leak) |
| Import/Export        | /import, /migration, /backup, /clone          | File read, SSRF, RCE, data exfil         |
| File upload          | avatar, attachment, csv import, doc           | RCE, XSS, SSRF, XXE, polyglot            |
| Integrations         | webhooks, OAuth apps, slack/jira              | SSRF, OAuth scope, secret leak           |
| Billing              | checkout, refund, coupon, plan change         | Race, business logic, IDOR               |
| Admin/internal       | /admin, /staff, /internal, X-Forwarded-For    | Auth bypass, header smuggling            |
| GraphQL              | /graphql, /api/graphql                        | Introspection, batch, alias, IDOR        |
| Search/filter/sort   | ?q=, ?orderBy=, ?filter=                      | SQLi, NoSQLi, SSTI, sort injection       |
| URL fetchers         | url=, image=, callback=, return_to=           | SSRF, open redirect -> OAuth ATO         |
| Templating           | email templates, invoice PDF, markdown        | SSTI -> RCE, XSS                         |
| Crypto/JWT           | Authorization: Bearer ...                     | alg=none, kid traversal, weak secret     |
```

---

## PHASE 3 — PAYOUT-PRIORITY ROUTING

Hunt highest-EV first. From HackerOne data, these archetypes consistently pay $10K+ when impact is shown. Each links to a deep reference.

> **Empirical payout model** — from the TOP100PAID set (every entry ≥ $10K, ceiling $50K):
> - **Class share of the $10K+ tier:** RCE ~28% · arbitrary file-read / IDOR / info-disclosure ~22% ·
>   credential/token exposure ~18% · ATO / auth-bypass ~14% · injection (SQLi/XSS/SSTI/SSRF) ~12% ·
>   memory-kernel ~6%. Rough EV order — hunt top-down.
> - **The $30K–$50K ceiling is always blast radius:** leaked token/cert → internal infra
>   (Shopify GitHub token **$50K**, Uber Phabricator cert **$39,999**), pre-auth RCE on a core
>   platform (GitLab **$33.5K**), dependency confusion (**$30K**), 0-interaction ATO / password-reset
>   (**$35K**), or an exposed cluster with creds (Zeppelin / K8s **$25–35K**).
> - **Target-value multiplier — pick the program, not just the bug.** The SAME bug pays more on a
>   mature, high-blast-radius target. GitLab, PayPal, Shopify, Mail.ru, Snapchat, PlayStation
>   dominate the list. A stored XSS on PayPal signin paid **$20K** — target × impact beats class.
> - **The $10K floor:** narrow single-feature RCE and memory/kernel bugs bottom out at exactly $10K.
>   To *clear* the bar you need one of: code exec · infra/credential access · cross-tenant data at
>   scale · 0-interaction ATO. Single-user / single-record / interaction-required rarely clears it.

### TIER S ($20K–$50K) — Shoot for these
1. **Pre-auth RCE on production / VPN / SSO host** → `references/rce-archetypes.md` § "Pre-auth"
2. **Dependency confusion on internal package names** → `references/dependency-confusion.md`
3. **Account takeover via password reset / email confirmation flaw** — incl. username/identifier reuse: delete or rename account A, claim A's freed username/handle/email/org-slug, inherit A's orphaned resources/membership/links (ownership keyed on a mutable identifier instead of immutable user ID)
4. **GraphQL authorization bypass exposing private program/tenant data** → `references/graphql-deep.md`
5. **Exposed Kubernetes API / Jenkins / Zeppelin / Spring Actuator with creds** → `references/exposed-services.md`
6. **GitHub/GitLab/CI secrets leak with verified credentials** → `references/secrets-recon.md`
7. **SSRF → cloud metadata → IAM credentials → cross-account / S3 takeover** → `references/ssrf-killchain.md`
8. **HTTP request smuggling → mass session/cookie theft** → `references/request-smuggling.md`
9. **Supply chain: malicious PR / compromised release / build agent** → `references/dependency-confusion.md` § "Build pipeline"
10. **OAuth/SAML response_type or signature bypass → ATO across IdP**

### TIER A ($10K–$20K)
11. **Cache poisoning → stored XSS / session / DoS** → `references/cache-poisoning-deception.md`
12. **Web cache deception leaking auth tokens** → same file
13. **Server-side template injection (Kramdown, Jinja, Smarty, Velocity, Twig, FreeMarker)** → `references/ssti-rce.md`
14. **Java/PHP/Python/.NET unsafe deserialization** → `references/deserialization.md`
15. **File upload to RCE (polyglot, parser confusion, magic bytes, ZIP slip, GhostScript, ImageMagick MSL)** → `references/file-upload-rce.md`
16. **XXE in SOAP/SAML/SVG/DOCX/JPEG XMP/SVG-on-PDF** → `references/xxe-deep.md`
17. **GraphQL batch/alias/depth → DoS, brute-force, info disclosure** → `references/graphql-deep.md`
18. **Race condition on payment / coupon / refund / 2FA / rate limit** → `references/race-conditions.md`
19. **Privilege escalation via role/permission abuse on multi-tenant** → `references/idor-bola-mass-assignment.md`
20. **Subdomain takeover → cookie scope → ATO chain** → `references/subdomain-takeover.md`

### TIER B ($1K–$10K) — Bread and butter
21. IDOR / BOLA on /api/v\*/\*/{id}, GraphQL node(id:...)
22. Mass assignment on PUT/PATCH user/profile/account
23. Open redirect → OAuth code theft
24. Self-XSS → CSRF → stored XSS
25. CORS misconfig leaking auth tokens
26. Session fixation / cookie scoping on sibling subdomain
27. 2FA bypass (race, response manipulation, backup code reuse)
28. SSRF (blind, DNS rebinding, IPv6, URL parser confusion)
29. Reflected XSS in legacy/marketing site → cookie steal on main
30. Path traversal in export/download/zip features

---

## PHASE 4 — EXECUTION RULES

For every candidate vuln:

1. **Reproduce twice.** Different account, different IP, different browser. False positives kill credibility.
2. **Maximize impact before reporting.** A blind SSRF is $500. SSRF→metadata→cloud keys→S3 read→PII is $10K+. Always escalate.
3. **Chain across surfaces.** Subdomain X has reflected XSS. Domain Y sets cookies on `*.target.com`. Combine.
4. **Test rate limits and quotas with care.** Don't break prod. Use minimal payloads to confirm — then stop.
5. **Never exfil real data.** Use marker files / your own accounts / test buckets. Read enough to prove impact, no more.
6. **Capture everything.** Store HTTP requests/responses, screenshots, video. Use Burp Logger/Pro.
7. **Write the report when impact is provable, not before.** Half-impact reports get triaged as low.

---

## PHASE 5 — IMPACT MAXIMIZATION (the $10K multiplier)

Read `references/chaining-impact.md`. Quick mental checklist for every finding:

```
Q1. Can this affect another user (cross-user)?           -> IDOR/BOLA family
Q2. Can this affect another tenant (cross-tenant)?       -> Privilege escalation, big multiplier
Q3. Can this leak credentials/tokens/keys?               -> Secret exposure, big multiplier
Q4. Can this be triggered without auth?                  -> Pre-auth, big multiplier
Q5. Can this be triggered without user interaction?      -> 0-click, big multiplier
Q6. Can this persist (stored)?                           -> Stored XSS, persistent IDOR
Q7. Can this read internal services/cloud metadata?      -> SSRF chain
Q8. Can this read source code or config?                 -> Source disclosure -> harder bugs
Q9. Can this lead to RCE or SQLi?                        -> Critical
Q10. Can this be mass-exploited (batch/race/automation)? -> Mass-impact, big multiplier
```

Each "yes" raises payout tier. Aim for >=3 yeses before submitting.

---

## ROUTING — when to delegate

| Trigger | Delegate to |
|---|---|
| SQL injection signal (errors, time delay, ORDER BY) | `sqli-hunter-agent` |
| XSS sink in DOM/markdown/HTML reflection | `xss-hunter-agent` |
| Heavy JS bundles, source maps, big SPA | `js-recon-agent` |
| Broken Logic / business-logic / authz check pattern | `blf-hunter-agent` |
| LLM/agent target, system prompt, AI feature | `prompt-injection-hunter-agent` |

For everything else — RCE, SSRF, ATO, OAuth, IDOR, upload, XXE, race, smuggling, cache, subdomain takeover, dependency confusion, exposed services, secrets — stay here and use the references below.

---

## REFERENCE INDEX

**Recon & surface**
- `references/recon-killchain.md` — full passive+active recon flow with one-liners
- `references/secrets-recon.md` — GitHub/GitLab/Postman/Docker/CI secret hunting
- `references/subdomain-takeover.md` — full dangling-CNAME provider catalog
- `references/exposed-services.md` — Jenkins, Kubernetes, Zeppelin, Spring Actuator, Drupal, Airflow, Grafana

**Server-side execution**
- `references/rce-archetypes.md` — every RCE archetype seen on H1 ($10K+ ones first)
- `references/ssti-rce.md` — Jinja2, Kramdown, Smarty, Twig, Velocity, FreeMarker, Handlebars, Pug, Mako
- `references/deserialization.md` — Java, PHP (phar/wakeup), .NET, Python, Node (node-serialize), Ruby
- `references/file-upload-rce.md` — polyglot, parser confusion, ImageMagick, GhostScript, ZIP slip, XSLT, ExifTool
- `references/dependency-confusion.md` — npm/pip/RubyGems/Maven/Go substitution, build pipeline RCE

**Server-side request abuse**
- `references/ssrf-killchain.md` — cloud metadata (AWS/GCP/Azure/Alibaba/DO), DNS rebinding, IPv6, parser tricks
- `references/xxe-deep.md` — SOAP, SAML, SVG, DOCX, OOXML, JPEG XMP, blind/OOB extraction

**HTTP layer**
- `references/request-smuggling.md` — CL.TE, TE.CL, TE.TE, h2c, response queue desync
- `references/cache-poisoning-deception.md` — unkeyed input, fat GET, web cache deception
- `references/cors-postmessage.md` — CORS misconfig, postMessage origin abuse

**Authorization & logic**
- `references/idor-bola-mass-assignment.md` — IDOR, BOLA, mass assignment, prototype pollution sinks
- `references/race-conditions.md` — Turbo Intruder, single-packet attack, financial logic
- `references/graphql-deep.md` — introspection, batch, alias, depth, suggestions, IDOR

**ATO / CSRF / OAuth / JWT / API / PII** (distilled from 1500+ disclosed reports) → sibling skills:
- `web2-vuln-classes` §8 OAuth (redirect_uri bypass, referer code leak, pre-hijacking),
  §12 API (BOLA/BFLA, excessive data exposure, JWT jwk/jku/kid injection, alias-DoS),
  §13 ATO (15 paths), §25 CSRF (modern SameSite-bypass table, JSON CSRF, method-override),
  §26 PII/sensitive-data disclosure (severity = sensitivity × scale × 1/auth; source maps,
  Wayback token leak, excessive data exposure, exposed DBs/buckets, CORS/JSONP reads)
- `security-arsenal` → JWT / OAuth / CSRF BYPASS PAYLOADS + SENSITIVE-DATA/PII EXPOSURE PROBES

**Maximization**
- `references/chaining-impact.md` — low->critical recipes from $10K+ H1 reports
- `references/report-writing.md` — H1/Bugcrowd/Intigriti templates, CVSS, impact statements

**Payloads & cheatsheets**
- `payloads/rce-payloads.md`
- `payloads/ssrf-payloads.md`
- `payloads/ssti-payloads.md`
- `payloads/cmd-injection.md`
- `cheatsheets/waf-bypass.md`
- `cheatsheets/oneliners.md` — copy-paste commands per phase
- `cheatsheets/encoding-tricks.md`

---

## QUICK START — when the user says "hunt $TARGET"

1. Confirm scope authorization.
2. Run Phase 1 recon (passive first; ask before going active).
3. Triage findings into the Phase 2 surface table.
4. Prioritize by Phase 3 tier (TIER S → A → B).
5. Pick the top 3 candidates, dig deep with the relevant `references/*.md`.
6. For each candidate, run the Phase 5 impact checklist.
7. Only write the report when >=3 impact answers are "yes".
8. Use `references/report-writing.md` for the submission.

Stay paranoid. Stay scoped. Stack chains. Hunt the $10K+ tier first.
