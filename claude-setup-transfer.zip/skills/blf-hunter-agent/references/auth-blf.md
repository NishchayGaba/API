# Auth & Session BLF — Logic Flaws in Authentication Flows

## 2FA / MFA Bypass Patterns

```
METHOD 1: Step Skip
- Complete username + password (step 1)
- Do NOT submit 2FA code
- Directly browse to authenticated endpoint: /dashboard, /api/user
- If session is created at step 1 (before 2FA) → bypass
- Test: check Set-Cookie after step 1

METHOD 2: OTP Not Invalidated
- Request OTP → use it → request another OTP → old one still works
- Race: submit same OTP 20x simultaneously → may all pass
- No brute-force protection: enumerate 6-digit code (0-999999)

METHOD 3: Response Manipulation
- POST /auth/verify-2fa {"code": "000000"}
- Response: {"success": false, "next": "/2fa"}
- Modify response: {"success": true, "next": "/dashboard"}
- Check if server honors modified state on next request

METHOD 4: Backup Code Abuse  
- Generate backup codes → use all → regenerate
- Race code regeneration + last code use
- Backup codes without rate limit

METHOD 5: 2FA on Account Recovery Only
- Forgot password flow bypasses 2FA entirely
- Reset password → log in → no 2FA prompt

METHOD 6: Trust on First Device Flag
- "Remember this device" flag in cookie or JWT
- Modify flag: remember_device=false → true
- Or steal remember_device token for victim
```

## Password Reset Logic Flaws

```
METHOD 1: Token Not Invalidated After Use
- Request reset → use link → request another → OLD link still works
- Test: reset → log in → request new reset → use first link again

METHOD 2: Token Tied to Email, Not Account
- Request reset for victim → token sent to victim
- But token validation only checks token validity, not who requested
- Combine with email change IDOR

METHOD 3: Predictable Token
- Token = base64(email + timestamp) → predict
- Token = MD5(email) → enumerate
- Sequential numeric IDs → enumerate

METHOD 4: Host Header Injection
- POST /forgot-password with Host: attacker.com
- Reset email contains: https://attacker.com/reset?token=ABC
- Token sent to attacker's server

METHOD 5: Cross-User Token
- Request reset for user A → get token
- Use token for user B → server only validates token format, not binding

METHOD 6: Token in URL (Logged)
- Reset link: /reset?token=SECRET
- Token appears in server logs, referer headers, browser history
- If logs accessible (via LFI/SSRF) → harvest tokens
```

## Session Management BLF

```
METHOD 1: Session Not Rotated on Privilege Change
- Log in as user → get session token
- Admin upgrades your account
- Old session token now has admin privileges without re-auth

METHOD 2: Concurrent Session Abuse
- Log in on device A → session A
- Log in on device B → session B
- Both sessions remain valid
- If app grants trial to "new sessions" → create infinite sessions

METHOD 3: Session After Logout (Cache)
- Log out → session cookie cleared from browser
- BUT if you saved the cookie → it still works server-side
- Test: copy cookie before logout → use after

METHOD 4: Session Fixation
- Attacker sets session: /login?session_id=ATTACKER_CHOSEN
- Victim logs in → server accepts that session ID
- Attacker now authenticated as victim

METHOD 5: JWT Algorithm Confusion
- alg: RS256 → try alg: HS256 with public key as secret
- alg: none → remove signature entirely
- JWT kid header: path traversal, SQLi

METHOD 6: JWT Claims Not Validated
- exp claim: set far future → never expires
- iss claim: change to other service's issuer
- role claim: user → admin
- sub claim: your_id → victim_id
```

## OAuth & SSO Logic Flaws

```
OAUTH:
□ Missing state parameter → CSRF login
□ redirect_uri: evil.com, evil.com/callback, legitimate.com.evil.com
□ scope escalation: request read → get read+write
□ Auth code reuse: code not invalidated after first exchange
□ Token leakage: access_token in URL → appears in logs/referer
□ Account linking CSRF: link attacker OAuth to victim account
□ Open redirect in OAuth flow: redirect_uri= → steal code

SAML:
□ Signature wrapping: copy valid signed element, inject unsigned admin element
□ Comment injection: user<!---->admin → parsed as "useradmin" by some parsers
□ XML external entity: SAML response with XXE payload
□ Role/email attribute manipulation: change role="admin" in assertion
□ Replay: SAML assertions without NotBefore/NotAfter → replay old assertion

SSO LOGIC:
□ SP-initiated vs IdP-initiated: skip SP auth check via IdP-initiated flow
□ Tenant isolation: authenticate to Tenant A → access Tenant B
□ JIT provisioning: malformed SSO response creates admin account
□ Logout not propagated: log out of SP but IdP session remains
```

## Account Registration & Verification Logic

```
□ Email verification skip: register → access app before verifying email
□ Duplicate registration: race account creation with same email
□ Username enumeration: timing difference on /forgot-password
□ Email case sensitivity: User@Email.com ≠ user@email.com in DB → two accounts
□ Unicode normalization: café@test.com → cafe@test.com → same mailbox, different DB records  
□ Subdomain email: user+admin@target.com → creates admin-level account
□ Invitation token: accept invite as different user than intended recipient
□ Account hijacking pre-registration: register with victim's email before they do
□ Verification link: does not expire, works for different account
□ Phone number: reassigned numbers accepted as valid verification
□ Username/identifier reuse → ATO: see below
```

### Username / Identifier Reuse → Account Takeover

Root cause: resource ownership, ACLs, group/org membership, invites, @mentions,
billing, and audit references are keyed on a MUTABLE identifier (username,
handle, email, team/org slug) instead of an immutable user ID. When account A is
deleted or renamed, its handle is freed; any orphaned resource still
string-matched to that handle gets silently re-bound to whoever claims it next.

```
□ Deletion-reclaim:  A deletes account → register new account, set username = A's old handle → inherit A's resources
□ Rename-reclaim:    A renames to "A2" (frees "A") → rename YOUR account to "A" → inherit A's resources
□ Email reuse:       A changes email away → register/rebind with A's old email → inherit A's account links
□ Slug reuse:        org/team deleted or renamed → recreate with same slug → inherit old members/invites/data
□ OAuth re-link:     provider re-uses sub/handle → new owner of handle gets old account's linked identity
```

What to confirm after the reclaim: does the new account see the previous owner's
shared docs, group/org membership, OAuth links, profile data, history, or
billing? If yes = cross-account access / ATO (High–Critical, victim took no
unusual action beyond having existed). Fix is to key everything on an immutable
user ID and hard-revoke orphaned grants on deletion/rename.

## Account Lifecycle / Offboarding Desync (Zombie Account)

Root cause: a lifecycle transition (delete / ban / suspend / deactivate /
downgrade / close-org / offboard) is enforced at ONE chokepoint — almost always
login/auth — but is NOT fan-out-propagated to the other subsystems the account
touches. The account becomes a **zombie**: dead for login, alive for
sessions / API keys / webhooks / invoicing / payouts / credits. Any asymmetry
between subsystems is the bug; financial asymmetry is the highest impact and
usually lives in the **platform / billing layer, not the target app**.

🚩 Canonical tell: *"Account deleted → login says Not Found, but invoice still
generates → payout still missing."* Test the lifecycle of YOUR OWN account on
the platform/billing layer — not just the target's features.

```
ZOMBIE SWEEP — run after ANY lifecycle transition:
1. MAP subsystems: login, live sessions, API keys/PATs, OAuth grants + refresh
   tokens, webhooks, scheduled/cron jobs, billing/invoicing, payouts,
   referral/credit ledger, team/org membership, shared docs, exports, signed URLs.
2. CAPTURE artifacts BEFORE transition: session cookie, API key, OAuth/refresh
   token, signed URL, deep link.
3. TRIGGER transition: self-delete / get banned / suspend / downgrade / close org.
4. REPLAY each artifact against each subsystem POST-transition.
5. ASYMMETRY = finding (works in X, blocked in Y).

MANIFESTATIONS / SEVERITY:
□ Offboarded API key/PAT still authenticates        → persistent access (P1)
□ Old session cookie survives delete/ban            → ban evasion / post-delete access
□ Banned user's refresh/OAuth token still mints      → ban bypass via token refresh
□ Deleted acct still generates invoices / burns meter → billing fraud (platform eats liability)
□ Deactivated org still receives webhooks w/ PII     → data leak
□ Downgraded acct keeps premium entitlements         → feature theft
□ Generate-liability works but settle-liability blocked → accounting desync / money machine
```

Fix: on every lifecycle transition, hard-revoke ALL sessions, API keys, OAuth
grants and refresh tokens; stop webhooks/cron; gate every subsystem on the
account's current state (not just the auth/login path).

## Privilege Escalation Patterns

```
VERTICAL (user → admin):
□ role parameter in update request
□ is_admin, is_staff boolean flag
□ account_type, plan, tier manipulation
□ Admin API endpoint accessible with user token
□ Function-level access control missing on specific endpoint

HORIZONTAL (user A → user B):
□ user_id, account_id in request body → change to victim
□ Shared resources via predictable IDs
□ Team/org scoping missing on nested resources
□ Cross-tenant API access via organization parameter

LATERAL (feature bypass):
□ Disabled feature → accessible via direct API call
□ Beta/internal feature via X-Beta-User header
□ Premium feature check only in UI, not API
□ Admin-only report accessible to regular user
□ Verification-token reuse across steps (JWT returned by registration = email-verify token — email is decorative)
```

## High-Value Auth BLF — New Classes (Always Check)

```
OAUTH / OIDC ADVANCED:
□ Open dynamic client registration (RFC 7591): check /.well-known/oauth-authorization-server for
  registration_endpoint → POST {redirect_uris:[attacker.com]} with no auth → register client → ATO via
  consent phishing on the real domain. PKCE does NOT stop this.
□ Refresh token rotation bypass: use RT1 → get RT2 → replay RT1 → should error + revoke family;
  if server silently issues RT3, the stolen token survives rotation indefinitely.
□ OAuth device flow: device_code not bound to client or IP → stolen code + polling = ATO.
  Check device_authorization_endpoint in OIDC config.
□ IDN homograph in redirect_uri: unicode confusables in domain (e.g. Cyrillic characters) bypass
  naive string-compare allowlists. tárget.com accepted as target.com.

SAML ADVANCED:
□ EntityId normalization mismatch ($10,500 bounty): register entityId="legit-org.com " (trailing space).
  Validation trims + matches legit. Assignment lookup does NOT trim → victims land in attacker org.
  General: test every security identifier for trim/case-fold inconsistency between validation and lookup.
□ SAML response replay: capture valid SAMLResponse, resubmit → server must check NotOnOrAfter and
  InResponseTo; many don't. SAML Raider (Burp) automates.

MFA ADVANCED:
□ Enrollment race: POST /account/2fa/enroll without re-authentication → add YOUR authenticator device
  to victim's account during their enrollment window or post-password-reset.
□ "Remember this device" cookie: predictable value, works cross-account, or not bound to account.
  Collect multiple samples, test on different user, check entropy.
□ Legacy v1 endpoint MFA skip: /api/v1/login may predate MFA rollout → authenticates without OTP check.
  Diff every login-adjacent endpoint for MFA parity.
□ Backup code brute force: /api/auth/backup-code has a SEPARATE rate limit from /api/auth/verify-otp.
  Test it independently. 8-digit = 100M combinations; often unprotected.

EMAIL / ACCOUNT:
□ Email-change confirmation to wrong address x SSO linking (most-upvoted H1 ever):
  change email to victim@target.com → confirmation link sent to YOUR old address → you confirm
  ownership of victim's email → platform auto-links SSO accounts sharing that email → ATO at scale.
  Always check WHICH address receives the link, not just that one is sent.
□ Client-side token consumption: one-time token (SSO handoff, invite, magic link) only burned when
  legitimate-domain JS calls the consumption endpoint. If a redirect-regex bug lands the token on
  attacker.com first, JS never runs → token survives → replay on real domain.

PASSWORDLESS / MAGIC LINK:
□ Email scanner prefetch burns the token: Outlook SafeLinks / Proofpoint GET the URL before victim
  clicks → token consumed by scanner; or attacker forwards email to get in first.
□ Token not bound to session/IP/UA: magic link works from any device — request from A, open from B.

SCIM:
□ /scim/v2/Users with no auth or weak static token → enumerate org users, reset passwords, add admin.
  Try /scim/v2/ServiceProviderConfig, /api/scim/v2, /identity/scim/v2.

WEBAUTHN / PASSKEY:
□ Challenge replay: same WebAuthn assertion body resubmitted → server must validate challenge + counter.
□ rpId not validated: credential enrolled on sub.target.com accepted on target.com.
□ userHandle not tied to account: credential for account A submitted when authenticating as account B.

CUSTOM SSO / PROPRIETARY TOKEN:
□ Shape-check bypass: backend checks token is present/well-formed but never verifies with issuer.
  AES key/IV hardcoded in JS → extract key → forge payload → submit fake token.
```

**Full bash PoCs for all of the above:** `~/.claude/skills/js-recon-agent/references/13-auth-failures-and-flows.md` §§13-23

## Auth BLF — Round 2 New Classes (§§24–29)

```
XMLRPC / CMS SSO BYPASS ($10k–$17k):
□ SSO "enforced" on main login but /xmlrpc.php accepts native WordPress creds → full session without SSO
□ Confirm XMLRPC live: POST /xmlrpc.php with system.listMethods → returns method list
□ Auth: wp.getUsersBlogs or system.multicall → session cookie → test on SSO-protected routes
□ Impact: complete SSO enforcement bypass → P1 on any site running WordPress + enterprise SSO
□ Full PoC: 13-auth-failures-and-flows.md §24

NULL / EMPTY / LOOSE-COMPARISON AUTH BYPASS:
□ PHP: null == "" == false == 0 → empty password POST or null JSON value may authenticate
□ MongoDB: {"password": {"$ne": null}} matches accounts with no password set
□ JWT: alg:none with empty sub claim may match any account with null ID in DB
□ Try: empty string, null, false, 0, [], {} in every credential field
□ Try: absent parameter entirely (missing password key in JSON)
□ Full PoC: 13-auth-failures-and-flows.md §25

AUTH STATE MACHINE / OUT-OF-ORDER STEP EXECUTION:
□ Snapchat pattern (969 upvotes): POST /otp/logout (no auth) → POST /otp/login {phone: victim} → authenticated as victim
□ Call final-step endpoint (/verify-otp, /complete) directly without a valid partial-auth state cookie
□ Swap identity at step 2: start OTP flow as self, then submit victim's identifier at the OTP step
□ Recovery flow bypass: start account recovery → jump to final step without completing earlier steps
□ Impact: full ATO on any multi-step auth with no server-side state binding between steps
□ Full PoC: 13-auth-failures-and-flows.md §26

PRE-SIGNED / TIME-LIMITED URL AUTH BYPASS:
□ Remove session cookie and replay the URL alone → should 401/403; if 200 → not user-bound → IDOR
□ Replay after first use → should 410/423; if 200 → single-use not enforced
□ Replace resource ID in URL before signature → if sig doesn't cover resource_id → cross-user IDOR
□ Extend expires param manually; test with common HMAC keys: "secret", "app_secret", "changeme"
□ Impact: unauthenticated access to any user's signed resources if not user-bound
□ Full PoC: 13-auth-failures-and-flows.md §27

UNAUTHENTICATED SSO / SAML PROVIDER REGISTRATION:
□ POST /api/admin/saml/providers or /api/sso/providers without Authorization header
□ Rocket.Chat Meteor DDP: {"msg":"method","method":"addSamlService","params":[{attacker IdP params}]}
□ Test: non-admin user adding provider (vertical privesc) + modify existing provider entryPoint (BFLA)
□ Impact: attacker controls IdP → all SSO logins redirected to attacker → mass ATO → P1
□ Full PoC: 13-auth-failures-and-flows.md §28

LEGACY AUTH METHOD SKIPS NEW SECURITY CONTROLS:
□ Enumerate ALL login-adjacent endpoints: /api/v1/auth/login, /api/mobile/login, /auth/token, /oauth/token
□ Test 2FA parity: does legacy endpoint return access_token without OTP step?
□ Test rate-limit parity: legacy endpoints often have separate (or no) rate limiting
□ Test SSO parity: basic auth curl -u "user:pass" against API even when browser login requires SSO
□ Apache Airflow CVE-2024-25128: legacy OpenID 2.0 AUTH_OID bypasses newer auth controls
□ Impact: 2FA/SSO bypass via undocumented legacy path → P1 when 2FA is a "security feature"
□ Full PoC: 13-auth-failures-and-flows.md §29
```

**Full bash PoCs for §§24–29:** `~/.claude/skills/js-recon-agent/references/13-auth-failures-and-flows.md` §§24–29
