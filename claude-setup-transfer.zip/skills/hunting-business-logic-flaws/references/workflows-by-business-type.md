# Business-Logic Checklists by App Type

Run these per `account-setup.md`. Most are provable on a single account (before/tamper/after); a second account is called out explicitly only where the exploit needs a counterparty.

## 🛒 E-Commerce / Marketplace
```
□ Add to cart → pay → add more items → finalize (cart freeze bypass)
□ Apply coupon → remove items → cart retains discount
□ Negative quantity: quantity=-5 → negative total → free items
□ Price in request body: change price=99.99 to price=0.01
□ Refund abuse: refund without return, double refund race
□ Gift card: negative amount, reuse after redemption, race on balance
□ Free shipping threshold: manipulate cart subtotal
□ Inventory: reserve without purchase, oversell via race
□ Seller account ↔ buyer account: escrow self-payment
□ Order status: skip "payment_confirmed" → go direct to "shipped"
□ Refund to a different payment method than the original
□ Gift card purchase → refund to original payment → gift card still valid
```

## 💰 Fintech / Crypto / Payments
```
□ Withdrawal race: two simultaneous withdrawals exceed balance
□ Transfer negative amount: -$100 to victim = receive $100
□ Currency confusion: send USD amount, credited as BTC amount
□ TOCTOU: check balance → delay → spend in parallel → overdraft
□ Fee bypass: manipulate fee_amount in request
□ KYC step skip: access post-KYC features before verification
□ Limit reset: daily limit resets — exploit at midnight boundary
□ Webhook replay: resend payment_success webhook for free credits
□ Referral abuse: self-referral with multiple emails/accounts (or A refers B, B refers A loop)
□ Crypto: insufficient slippage check, price oracle manipulation
```

## 📦 SaaS / Subscription Platforms
```
□ Seat manipulation: PUT /seats with seats=1000 while paying for 1
□ Plan parameter: plan=enterprise in API while on free tier
□ Trial extension: re-trigger trial via new account linkage
□ Feature flag: client-side flag flip to enable premium features
□ Downgrade race: access premium features during downgrade window
□ Billing bypass: complete signup without credit card via step skip
□ API key scope: free-tier key used on enterprise endpoints
□ Usage quota: race on quota check to exceed limits
□ Team invitation: invite after seat limit → bypass seat cap (race N simultaneous invites)
□ Export/import: import premium templates on free plan
□ Add member → race to exceed seat limit before check completes
□ Remove member → seat freed → re-add → never charged for extra month
□ Transfer seat to unverified user → inherit premium features
□ API key from premium account (Account B) → use on free account's (Account A) API calls
```

## 🏥 Healthcare / Regulated Industries
```
□ Prescription refill: refill count bypass via race
□ Appointment: book for past date, book conflicting slots
□ Insurance claim: double-submit claim via race
□ Audit trail: delete/modify records that should be immutable
□ Role: nurse account → doctor-only action via parameter tamper (on your own account)
```

## 🎮 Gaming / Reward Systems
```
□ Point/XP race: submit score/achievement multiple times
□ Leaderboard: negative score, max score injection
□ Loot box: purchase → race → double receive items
□ Achievement: trigger without meeting criteria (skip steps)
□ Virtual currency: purchase → refund → keep virtual goods
□ Referral loop: A refers B, B refers A = infinite credits
□ Badge/rank: manually set rank parameter in profile update
□ Tournament: join after deadline via forced browse to submit endpoint
```

## 🔐 Workflow-Gate Logic (Multi-Step Flows)
```
□ 2FA bypass: complete step 1, jump directly to authenticated endpoint
□ One-time token reuse: a verification/reset token still works after it's
  already been used once (state not invalidated) → replay it
□ Account merge: merge two accounts you control → retain both balances/
  entitlements instead of one being voided
□ Approval-gate skip: submit your own listing/job-post/KYC directly with
  status=ACTIVE/approved — the "requires admin approval" gate often lives
  only in the happy-path UI, not the endpoint
□ Invite/onboarding step skip: complete only the steps that grant the reward
  (e.g. "invite a friend" credit) without the friend actually completing
  their side, if the two aren't atomically linked
```

> Note: account-takeover-flavored issues (OAuth/SAML/session fixation, identifier-reuse hijacking, replaying another user's captured request) are authorization/ATO bugs, not business logic — hunt those with a dedicated auth/IDOR skill instead.

## ♻️ Account Lifecycle / Billing Desync — cross-cutting

A lifecycle transition (delete / ban / suspend / deactivate / downgrade / close) is usually enforced at login, but the billing/entitlement layer isn't always updated in lockstep. The bug: the account can still incur cost, keep a paid entitlement, or generate a liability the platform can no longer collect on, after the state that was supposed to stop it.

Canonical tell: *"Account deleted → login says Not Found, but invoice still generates → payout still missing."*

```
BILLING-DESYNC SWEEP (run after triggering any lifecycle transition on your own account):
1. Note current billing/entitlement state: plan, metered usage counters, pending
   invoices, credit/referral ledger balance.
2. Trigger the transition: self-delete / downgrade / cancel / close org.
3. Re-check: does metered usage still accrue? Does the next invoice still
   generate? Do premium features/API scopes still work? Does a pending
   payout/refund still process (or get stuck, with the charge already taken)?
4. ASYMMETRY = finding — e.g. still billed after cancellation, or still gets
   premium access after downgrade, or the platform can charge but can't settle.

HIGH-SIGNAL MANIFESTATIONS:
□ Deleted/cancelled account still generates invoices or burns metered usage → billing fraud
□ Downgraded account keeps premium entitlements/features it no longer pays for → feature theft
□ Account can generate a liability (invoice/charge) but the corresponding
  settlement (payout/refund) is blocked → accounting desync
□ Subscription cancel → still billed one more cycle, or conversely keeps
  access without being charged for the current cycle
```
