# Chain Escalation — From Low to Critical

## The Chain Mindset

A single BLF is a finding. A chained BLF is a payday. Always ask: "What else can I do WITH this bug?"

## Chain Discovery Framework

When you find a low/medium BLF, ask:
```
1. WHO benefits from this bug? (attacker role)
2. WHAT state does this bug change? (DB field, session, balance)
3. WHAT can I do WITH that changed state? (follow-up actions)
4. IS there a financial/data/access component downstream?

If YES to #4 → chain it and re-rate severity
```

## Worked Chain Patterns

### 1. Race Condition + Coupon = Infinite Discount
```
Step 1: One-time coupon endpoint — POST /checkout/apply-coupon {"code": "SAVE100"}
Step 2: Race 20 requests simultaneously → multiple redemptions succeed before
  the server flags the code as used
Result: FINANCIAL FRAUD AT SCALE — Critical
```

### 2. Feature Flag + Sensitive Export = Data Exfil
```
Step 1: Flip a client-side feature flag (X-Feature: {"enterprise_export": true})
  and the server trusts the header with no server-side validation
Step 2: GET /api/export/all-users?format=csv → all user PII
Result: DATA BREACH — Critical
```

### 3. Step Skip + Financial Feature = Fraud Gateway
```
Step 1: KYC step skip — POST /api/v1/kyc/complete via forced browse
Step 2: POST /api/v1/withdraw {"amount": 10000} without identity verification
Result: FINANCIAL FRAUD ENABLEMENT — Critical
```

### 4. Negative Quantity + Gift Card = Money Generation
```
Step 1: POST /cart {"item_id": "gift_card_100", "quantity": -1} → negative total
Step 2: Apply to account credit → credited without payment
Step 3: Repeat or race → infinite money
Result: DIRECT FINANCIAL LOSS TO COMPANY — Critical
```

### 5. Response Manipulation + Role Escalation
```
Step 1: Intercept login response {"role":"user"} → modify to {"role":"admin"}
Step 2: Check if subsequent SERVER requests honor the manipulated state
  (GET /api/admin/users → returns list?)
Step 3: If yes → POST /api/admin/make-refund, GET /api/admin/export
Result: PRIVILEGE ESCALATION → DATA BREACH / FRAUD — Critical
NOTE: response manipulation alone is invalid (client-side); the bug is only
real if a subsequent server call honors the tampered state.
```

### 6. Referral Loop → Infinite Credits
```
Step 1: Account A refers Account B → both get $10 credit
Step 2: B refers A back (or A refers itself) — no circular-referral check
Step 3: Automate → $X infinite credits
Result: FINANCIAL FRAUD — High/Critical
```

### 7. Expired Token + Race = Extended Session
```
At trial-expiry boundary (T+0), send parallel requests:
  Request A: trial expiry check     Request B: access premium feature
The race window lets B succeed just after expiry.
Result: UNAUTHORIZED PREMIUM ACCESS — Medium (may chain higher)
```

### 8. Invite Logic → Bypass Seat Cap
```
Org at seat limit (5/5). Send 10 simultaneous POST /invites for 10 new users.
Server checks "seats_used < max_seats" independently per request → all pass →
org ends up at 15/5 seats.
Result: SaaS REVENUE FRAUD — High
```

### 9. Account-Lifecycle Billing Desync
```
Step 1: Delete/downgrade/cancel your own account
Step 2: Check the billing subsystem post-transition
  → invoice/charge still generates, or payout/settlement is blocked, or
  premium entitlements still work
Result: Platform eats the liability — ACCOUNTING FRAUD — Critical
(see workflows-by-business-type.md → Billing-Desync Sweep for the full method)
```

## Severity Escalation Matrix

| Base Finding | Chain With | Result Severity |
|---|---|---|
| Client-side flag flip | Backend export endpoint | Critical |
| Step skip | Reaches payment/data | Critical |
| Race condition | Financial transaction | Critical |
| Negative quantity | Credit/refund system | Critical |
| Role parameter | Admin functionality | Critical |
| Coupon reuse | Race for scale | High/Critical |
| Referral self-loop | Auto-exploitation | High |
| Account-lifecycle transition | Billing/entitlement layer not updated | Critical |

## Report Writing for Chains

```
Title: [Chain]: [BLF1] + [BLF2] → [Critical Impact]

Example:
"Race Condition in Coupon Redemption + Missing Server-Side Use Tracking
→ Unlimited $100 Discounts (Financial Fraud)"

Steps to Reproduce:
1. [Set up initial condition, e.g. two accounts / initial state]
2. [Trigger BLF1]
3. [Use BLF1's effect to reach BLF2]
4. [Show critical outcome]
5. [Quantify impact: $X per exploit cycle]

Severity Justification:
"While each individual flaw may be rated Medium, their combination enables
[critical outcome] with [financial/data/access impact]. Confidentiality/
Integrity/Availability impact is HIGH with no privileges required beyond a
standard user account."
```
