# CMS & Platform-Specific BLF Patterns

## WordPress / WooCommerce
```
□ WooCommerce coupon: apply coupon → change cart → coupon stays on checkout
□ Product price: price stored client-side in a hidden field → tamper
□ Subscription: cancel → reactivate without payment via order-status change
□ User role: change role=subscriber to role=administrator in profile update
□ Refund: WooCommerce refund endpoint race condition
□ Gift card plugin: generate codes via predictable pattern
□ Membership: expiry date in user_meta → modify via profile endpoint
```

## Shopify Apps & Storefronts
```
□ Discount: draft_order API with manual discount → bypasses normal validation
□ Cart attributes: hidden cart attributes controlling price
□ Checkout token: reuse checkout token across different sessions
□ Inventory: negative inventory oversell via API
□ Wholesale pricing: access wholesale endpoint as a retail customer
□ App webhooks: replay payment webhooks for duplicate fulfillment
□ Multipass: forge Multipass token if the secret is exposed
□ Storefront API: access admin-only product data via a storefront token
```

## Magento / Adobe Commerce
```
□ Quote manipulation: modify quote_id price via REST API
□ Catalog price rule: trigger an incorrectly scoped discount
□ Reward points: race on redemption, negative point balance
□ Customer group: change customer_group_id for B2B pricing
□ Admin panel: cached admin session survives a role downgrade
□ Gift registry: transfer registry items without auth
```

## Laravel / Django / Rails Apps
```
□ Mass assignment: POST extra fields (role, is_admin, confirmed, plan) the form
  doesn't expose but the model accepts
□ Enum coercion: send an unexpected string for an enum field → unexpected branch
```

## Feature-Flag Abuse (any stack)
```
□ Search JS bundles for feature-flag names/keys
□ Header: X-Feature-Flag: enterprise_export → try enabling
□ Cookie: featureFlags={"ai_assist": true} → modify the JSON
□ URL parameter: ?beta=true, ?preview=enterprise
□ Request body: add {"features": ["advanced_analytics"]}
□ Response manipulation: flip feature_enabled false→true, then check whether a
  SUBSEQUENT server call actually honors it (the flip itself proves nothing)
```

## Multi-Step Auth Flows (workflow-gate logic only — see workflows-by-business-type.md)
```
□ Step 1 complete (username+pass) → skip 2FA → direct to /dashboard
□ Email/SMS OTP: valid for 10 min, no brute-force protection → enumerate (pair
  with the abuse-limit-bypass-via-account-switching technique if per-account
  locked)
□ TOTP: clock skew allows ±1 window → extends the valid window
□ Account recovery: security questions with no lockout
□ Magic link: still works after a password change (old link not invalidated)
```

> OAuth/SAML `redirect_uri`, `state`, token-scope, and account-linking bugs are account-takeover primitives, not business logic — hunt those with a dedicated auth/IDOR skill instead.

## Cart & Checkout Test Sequence (run in this order)
```
1. Map the full checkout flow (cart → shipping → payment → confirm)
2. Attempt a direct POST to /checkout/confirm without the prior steps
3. Intercept the final payment request → modify amount/currency
4. Add item → apply coupon → remove item → keep the coupon for new items
5. quantity=-1 or quantity=0.5 or quantity=99999999
6. price=0.00, price=-100, price=0.001
7. currency=XXX (invalid), or swap USD→EUR for a favorable rate
```

## SaaS Trial & Subscription Depth
```
□ Trial end date in a JWT claim → modify the expiry
□ Trial reset: create a new account reusing the same payment method
□ Subscription cancel → still access premium for the remaining billing period
  → race right at the expiry boundary
□ Proration: downgrade → immediate upgrade → get premium at the lower rate
□ Invoice manipulation: modify the invoice amount before payment processing
```
