# Account Setup — Acquisition, When You Actually Need a Second One, Pacing

## Acquiring Accounts

Try in strict order, only escalate on failure:
1. Use creds/cookies the user already provided.
2. **Auto-signup via temp-mail** — register through the target's real signup flow using a disposable inbox (mail.tm, 1secmail, dropmail.me, etc.), confirm the email, log in. Rotate to the next provider if one is blocklisted or a poll times out — never give up after one.
3. Ask the human — only if both above fail. This is the sole mandatory pause.

Repeat auto-signup as needed. Store each session (cookie jar / bearer token) and wire self-refresh (refresh-token → re-login → cookie renewal) so a long hunt doesn't stall on an expired session.

## Do You Actually Need a Second Account?

Most economic-logic bugs are provable solo — don't reach for a second account by default.

| Situation | Accounts needed | Why |
|---|---|---|
| Price/quantity/coupon/param tampering | 1 | You're tampering with your own request; proof is before/after state on your own account |
| Step-skip / forced browsing | 1 | Same account, different sequence |
| Race condition on a limit (coupon, seat, quota) | 1 (fired in parallel) | The race is against the server's own atomicity, not another user |
| Self-dealing (escrow, fake transaction for a bonus) | 2, both yours | The workflow requires a counterparty role (buyer+seller, referrer+referee) |
| Collusion (sockpuppet votes/reviews, poll stuffing) | 2+ | The rule assumes independent people; you're simulating multiple |
| Abuse-limit bypass via account switching | 2+ | The limit is keyed to "one account," so a fresh account resets it |
| Points/currency arbitrage | 2, both yours | You need somewhere to move value *to* |

## Intel Pass (before touching anything, ~5 min)

- What does this app do, and what's the "money" (literal $, credits, votes, reputation, seats)?
- Which workflows are multi-step, and which have a one-time/one-per-account assumption (coupon, vote, bonus, trial)?
- What's rate-limited or capped, and is that limit keyed to account, IP, payment method, or a real-world identity signal?

## Test Methodology

1. **Before** — capture the real, expected state (price, balance, vote count, seat count) prior to any tampering.
2. **Tamper** — apply the SABOTAGE technique (skip/limit-abuse/state-replay/role-override/param-tamper/race/ghost-feature) or the multi-account maneuver (self-deal/collude/switch-and-reset).
3. **After** — re-fetch and confirm the state actually changed server-side. A 200 response is not proof; the underlying value moving is.
4. **Repeat/scale** — if it worked once, confirm it's repeatable and quantify the impact (per-cycle $ gain, votes per minute, seats bypassed).

## Pacing / Anti-Automation Handling

Pace roughly 1 request/minute on production targets when testing anything that could look like automation (voting, coupon redemption, signups) — WAFs and anti-fraud systems commonly escalate to CAPTCHA or account flags after a burst of similar actions from one IP. If a hard lockout hits, stop and get a fresh session/IP rather than burning the engagement fighting the anti-automation layer.

## Checklist (run before writing any finding)

- [ ] Before-state captured before tampering?
- [ ] After-state re-fetched and confirmed changed (not just a 200)?
- [ ] Impact quantified if repeated (scale/rate)?
- [ ] Only reached for a second account because the exploit genuinely needed a counterparty?
- [ ] Dropped "potential/possible" language — only proven claims survive?
