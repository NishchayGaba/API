# Additional Bug Classes — Pure Business Logic (Not Access Control)

Everything here is a flaw in the app's business/economic rules — it works even
if authorization is implemented perfectly. None of these are "A can read B's
data"; they're "the rule that's supposed to govern price/votes/points/limits
can be gamed." A second (or third) account is usually the *tool*, not a victim.

## Voting / Reputation / Ranking Manipulation
```
□ Sockpuppet voting: use Account B (or N throwaway accounts) to upvote/downvote/
  like/favorite Account A's own content — check if "one vote per user" is
  actually enforced per real person or just per session/cookie
□ Review manipulation: post a "verified purchase" review without a real
  purchase (or after refunding it), or write+upvote your own review from a
  second account to push it to the top
□ Poll/survey stuffing: submit the same vote from multiple accounts where the
  poll assumes one response per user
□ Leaderboard/ranking gaming: farm the ranking metric with sockpuppet
  interactions (follows, shares, plays) rather than genuine engagement
□ Report/flag abuse: mass-report a competitor's content from multiple accounts
  to trigger an automated takedown/suspension threshold
□ Karma/reputation threshold bypass: reputation gates a feature (posting links,
  skipping moderation) — farm the threshold with easy actions across accounts
  faster than intended, then use the unlocked feature for real abuse
```

## Abuse-Limit Bypass via Account Switching
```
□ Rate-limit reset: get locked out on Account A (OTP brute force, login
  attempts, API calls) → switch to Account B/a fresh signup → continue the
  same attack, since the limit is keyed to account/session, not the resource
□ CAPTCHA/anti-automation reset: verification solved once per account/session →
  spin up a fresh account to get a fresh unverified attempt
□ Free-tier quota reset: per-account usage caps (API calls, exports, trial
  actions, free searches) reset by creating additional accounts instead of
  paying — check if the cap should really be per-person/per-IP/per-payment-method
□ Distributed brute force: split a large guess space across many accounts to
  stay under each account's individual rate limit
```

## Referral / Self-Dealing Farming
```
□ Self-referral: refer your own second account (or B refers A back) when the
  program assumes referrer ≠ referee are unrelated parties
□ Fake transaction for bonus: buyer account + seller account both controlled
  by the tester → complete a real-looking transaction purely to trigger a
  signup bonus, cashback, or milestone reward
□ Affiliate/commission stacking: route a purchase through your own affiliate
  link using a second account to collect a commission on your own spend
```

## Coupon / Discount Stacking
```
□ Apply two single-use coupons in the same cart/checkout when only one should
  apply
□ Combine a coupon with a plan-level or seasonal discount meant to be
  mutually exclusive
□ Use a "first purchase only" coupon on a second account, then transfer/gift
  the discounted item to the main account
```

## Loyalty / Points / Currency Arbitrage
```
□ Transfer points/credits between two accounts you control at a rate that
  nets a gain (rounding, promotional multiplier, region-based exchange rate)
□ Redeem the same reward across two regions/currencies at inconsistent
  internal exchange rates for a profit
□ Gift/transfer feature moves a balance without correctly debiting the source
```

## Idempotency-Key / Duplicate-Request Money Bugs
```
□ Reuse a charge's idempotency key against a DIFFERENT endpoint (e.g. reuse a
  payment's key on the refund call) to see if the server conflates the two
  operations and double-processes
□ Omit, predict, or replay an idempotency key to force a single logical
  transaction to be processed twice
```

## Salami Slicing / Rounding Abuse
```
□ Repeated small transactions where a rounding rule (currency conversion, fee
  split, tax calculation) rounds in the tester's favor by a fraction of a
  cent — only profitable at volume, but a genuine accounting-integrity bug
□ Split one large transaction into many small ones to land under a threshold
  (fraud-review limit, fee-tier boundary, tax/reporting threshold)
```
