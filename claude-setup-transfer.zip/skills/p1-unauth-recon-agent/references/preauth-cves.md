# Pre-auth RCE & Auth-Bypass CVE Catalog (2023 → 2026)

> Fingerprint → exact version → match here → **confirm with a version-disclosure-only check** → PoC on your own clone → one marked shot at prod. Never blast `nuclei -t cves/` blindly; version-detection holes waste hours.

**Golden rule:** a login page is not a finding. A *version banner matching an unpatched CVE* + a non-destructive proof is. Where a CVE has active mass-exploitation, assume the asset may already be compromised — tread carefully and report fast.

---

## TIER 0 — 2025's perimeter-breakers (mass-exploited, unauth RCE)

| Product | CVE | Type | Version-safe confirm |
|---|---|---|---|
| **MS SharePoint (on-prem)** "ToolShell" | **CVE-2025-53770** (+53771, 49704/49706) | Unauth deserialization RCE via `/_layouts/15/ToolPane.aspx` w/ crafted `Referer` | Check build via `/_layouts/15/`; SP 2016/2019/SE on-prem only (SP Online safe). IoC: `spinstall0.aspx` |
| **Ivanti Connect Secure** | **CVE-2025-0282** (also 2025-22457) | Pre-auth stack overflow → RCE | Version in `/dana-na/...`; patched build compare |
| **Ivanti EPMM** | **CVE-2025-4427 + CVE-2025-4428** | Auth-bypass **chain** → pre-auth RCE | EPMM version banner |
| **Citrix NetScaler ADC/Gateway** | **CVE-2025-6543**, **CVE-2025-7775** | Memory overflow → pre-auth RCE/webshell | `/vpn/index.html`, version in resp headers |
| **Citrix NetScaler** "CitrixBleed 2" | **CVE-2025-5777** | Unauth memory over-read → session token leak → hijack | Repeated `POST /p/u/doAuthentication.do` mem leak |
| **Fortinet FortiSIEM** | **CVE-2025-25256** | Pre-auth command injection → RCE | FortiSIEM phMonitor version |
| **Fortinet FortiOS/FortiProxy** | **CVE-2024-21762** (SSL-VPN), **CVE-2024-55591** (auth-bypass) | Pre-auth RCE / super-admin | `/remote/login` build |
| **PHP-CGI (Windows, XAMPP)** | **CVE-2024-4577** | Argument-injection → unauth RCE | `?%ADd+allow_url_include…`; Windows PHP-CGI only |
| **Laravel (leaked APP_KEY)** | class, not a CVE | `decrypt()`→`unserialize()` → RCE | `/.env` 200 → APP_KEY → phpggc `Laravel/RCE*` (→ secrets-recon.md) |
| **Erlang/OTP SSH** | **CVE-2025-32433** | Pre-auth RCE (SSH msg before auth) | port 22 running Erlang SSH |
| **Next.js middleware** | **CVE-2025-29927** | `x-middleware-subrequest` header → authz bypass | Next.js version in build manifest |
| **Langflow** (AI) | **CVE-2025-34291**, **CVE-2026-33017**, **CVE-2026-5027** | Unauth Python code exec / deserialization RCE (`/api/v1/validate/code`, `/build_public_tmp/`, `/process`) | version banner; :7860 |
| **HTTP/1.1 desync** (front-end/back-end) | **CVE-2025-32094** (Akamai), **CVE-2025-4366** | 0.CL/CL.0/Expect/H2.0 request smuggling → response-queue poisoning → mass ATO | Burp HTTP Request Smuggler v3; see `desync-and-cache.md` |
| **Zimbra Collaboration** | **CVE-2025-68645** | Unauth PHP RFI via `/h/rest` → file inclusion | Zimbra version footer |

---

### "Missing auth for critical function" (CWE-306) — the 2025 KEV wave
A whole class of criticals is simply *an endpoint that forgot to check auth* — no exploit craft, just a request. 2025 KEV examples: **Oracle PeopleSoft PeopleTools** (unauth → full takeover), **Splunk Enterprise** (unauth arbitrary file create/truncate via PostgreSQL sidecar), **Ivanti Sentry** CVE-2023-38035 (unauth root RCE when endpoints externally reachable). Hunt: probe admin/critical routes with **no** cookie/token; a 200 where you expect 401/403 is the bug. Overlaps `top10-unauth.md §8 BOLA` and the §3.13 mass-PII killchain.

## TIER 1 — enduring enterprise pre-auth RCE (still found live)

### Atlassian
- **Confluence** CVE-2022-26134 (OGNL inj → RCE, `/`), CVE-2023-22515 (broken access → admin creation, `/setup/*`), CVE-2023-22518 (auth bypass → config wipe/RCE), CVE-2024-21683 (auth'd RCE).
  - Confirm version: `/login.action?logout=true` footer, `/server-info.action`, `/rest/applinks/1.0/manifest`.
- **Jira** CVE-2022-0540 (auth bypass Seraph), CVE-2019-11581 (SSTI→RCE), CVE-2023-22501 (Service Mgmt auth).
  - Version: `/rest/api/2/serverInfo`, `/secure/Dashboard.jspa` footer.
- **Bitbucket** CVE-2022-36804 (command injection, `/rest/api/…`).

### GitLab
- CVE-2023-7028 (no-click **ATO** via password-reset to attacker email — pre-auth), CVE-2021-22205 (ExifTool → unauth RCE on uploads), CVE-2022-2884 (GitHub import RCE).
- Version: `/help`, `/-/users/sign_in` footer, `/api/v4/version` (sometimes public), `/assets/` build hash.

### Web/app servers & frameworks
- **Apache Struts** CVE-2023-50164 (path-traversal file-upload → RCE), CVE-2017-5638 (Content-Type OGNL), CVE-2018-11776.
- **Spring** Spring4Shell CVE-2022-22965 (`class.module.classLoader…`), Spring Cloud Gateway CVE-2022-22947 (SpEL→RCE via actuator), Spring Cloud Function CVE-2022-22963.
- **Apache OFBiz** CVE-2023-49070 + CVE-2023-51467 (auth bypass → XML-RPC RCE), CVE-2024-45195.
- **Apache ActiveMQ** CVE-2023-46604 (OpenWire deserialization → unauth RCE, port 61616).
- **Apache Log4j** "Log4Shell" CVE-2021-44228 (`${jndi:ldap://…}` in any logged field/header — test UA, X-Forwarded-For, username).
- **Apache RocketMQ** CVE-2023-33246 (broker RCE). **Apache Solr** CVE-2019-17558 (Velocity SSTI RCE).
- **Adobe ColdFusion** CVE-2023-26360 / CVE-2023-38831-adjacent, CVE-2024-53961 (path traversal → RCE).
- **WebLogic** CVE-2023-21931/21839, CVE-2020-14882/14883, CVE-2019-2725 (T3/IIOP deserialization).
- **JBoss/WildFly** jmx/invoker deserialization; **WebSphere** CVE-2020-4450.

### File-transfer & edge (mass-breach class)
- **MOVEit Transfer** CVE-2023-34362 (SQLi → RCE; `/human.aspx`, `/moveitisapi/`).
- **GoAnywhere MFT** CVE-2023-0669, CVE-2024-0204 (auth bypass admin).
- **Citrix** CVE-2023-4966 "Citrix Bleed" (session-token leak → hijack), CVE-2019-19781 (path traversal RCE).
- **F5 BIG-IP** CVE-2022-1388 (iControl REST auth bypass → RCE), CVE-2023-46747 (AJP smuggling → RCE, `/tmui/`).
- **Fortinet** CVE-2022-42475 (SSL-VPN heap overflow), FortiManager CVE-2024-47575 ("FortiJump").
- **Palo Alto PAN-OS** CVE-2024-3400 (GlobalProtect command injection → RCE), CVE-2024-0012 + CVE-2024-9474 (mgmt auth-bypass chain).
- **SonicWall SMA** CVE-2021-20038; **Zoho ManageEngine** CVE-2022-47966 (SAML → unauth RCE across many products).
- **Progress WhatsUp Gold** CVE-2024-4885; **Ivanti Sentry** CVE-2023-38035.

### Print / device / misc
- **PaperCut NG/MF** CVE-2023-27350 (auth bypass → RCE via SetupCompleted).
- **Telerik UI for ASP.NET** CVE-2019-18935 (deserialization, `/Telerik.Web.UI.WebResource.axd?type=rau`).
- **VMware** vCenter CVE-2021-21972 (upload RCE), CVE-2021-22005; ESXi OpenSLP CVE-2021-21974; Aria/vRealize CVE-2023-34051.
- **Cisco** IOS XE CVE-2023-20198 (web UI → admin → RCE).
- **Drupal** "Drupalgeddon2" CVE-2018-7600, CVE-2018-7602; Drupalgeddon3.
- **Magento** CVE-2022-24086 (template → unauth RCE), CVE-2024-34102 "CosmicSting" (XXE → RCE).
- **Joomla** CVE-2023-23752 (unauth API info-disclosure → creds).
- **WordPress** — hunt *plugins*, not core: File-Manager CVE-2020-25213, Bricks CVE-2024-25600 (unauth RCE), and current mass-exploited plugin RCEs. Fingerprint `/wp-content/plugins/<name>/readme.txt`.

### Image/document parsers (upload-driven, framework-agnostic)
- **ImageMagick** "ImageTragick" CVE-2016-3714, CVE-2022-44268 (file read via PNG). **GhostScript** CVE-2023-36664, CVE-2024-29510. **ExifTool** CVE-2021-22204 (→ the GitLab RCE). **libwebp** CVE-2023-4863. **OpenOffice/LibreOffice** macro/`WEBSERVICE`.

---

## TIER 2 — dev / CI / data-infra (see exposed-services.md for unauth checks)

Jenkins **CVE-2024-23897** (CLI arbitrary file read → secret → RCE chain) · Argo CD/Workflows misconfig · Airflow **CVE-2022-40127** (example-DAG code inj) · Apache Zeppelin (Shell interp) · GoCD CVE-2021-43287 · TeamCity **CVE-2024-27198/27199** (auth bypass → admin → RCE) · Grafana **CVE-2021-43798** (path traversal) · Kibana CVE-2019-7609 (Timelion RCE) · Consul/Nomad script-check RCE · Kubernetes anon API · etcd `:2379` open.

---

## Version-disclosure-only confirmation (fire these, not the exploit)

| Product | Safe version probe |
|---|---|
| Confluence | `/login.action?logout=true` footer · `/server-info.action` |
| Jira | `/rest/api/2/serverInfo` |
| GitLab | `/help` · `/api/v4/version` |
| Spring Boot | `/actuator/info` · `/actuator/env` · whitelabel `/error` |
| WebLogic | `/console/login/LoginForm.jsp` title |
| ColdFusion | `/CFIDE/administrator/` · `/cf_scripts/scripts/ajax/` |
| Fortinet | `/remote/login?lang=en` build hash |
| Citrix | `/vpn/index.html` · `/logon/LogonPoint/...` |
| Ivanti | `/dana-na/auth/url_default/welcome.cgi` |
| MOVEit | `/human.aspx` version string |
| Telerik | request `/Telerik.Web.UI.WebResource.axd?type=rau` (dialog handler present) |
| Drupal | `/CHANGELOG.txt` · `/core/CHANGELOG.txt` |
| WordPress plugin | `/wp-content/plugins/<name>/readme.txt` (`Stable tag:`) |

---

## Workflow

```bash
# 1. Fingerprint precisely (title alone is not enough)
httpx -l alive.txt -silent -title -tech-detect -server -json > probe.json

# 2. Map fingerprints → this catalog (manual, judgement-driven)
# 3. Confirm version via the table above (no exploit yet)
# 4. Reproduce the PoC on a local Docker of the SAME version
# 5. One marked, non-destructive shot at prod:  id; hostname; whoami; curl OOB
#    RCE is terminal — prove execution, do NOT dump data or pivot. Report immediately.

# nuclei ONLY to confirm a specific, already-fingerprinted CVE:
nuclei -l alive.txt -id CVE-2025-53770 -rl 20
```

**Escalation:** RCE is the ceiling (CVSS 9.8–10.0, AV:N/PR:N/UI:N). Stop at proof of execution. Auth-bypass chains (Ivanti EPMM, TeamCity, PAN-OS) → treat as pre-auth RCE for severity.
