# Subdomain Takeover — Dangling DNS → Content Control

> A subdomain CNAMEs/aliases to a third-party resource that **no longer exists**. Claim it → serve attacker content on a target-branded host. P1 when the subdomain shares cookies, OAuth `redirect_uri`, CORS allowlist, or SSO origin with the parent.

**Confirm before claiming:** DNS record present + resource unclaimed + provider "unclaimed" fingerprint. Then (in scope) claim it, host a **benign marker page** proving control. Never serve real phishing/malware; the PoC is control, not abuse.

---

## Detection

```bash
# 1. Resolve CNAMEs across all subs
dnsx -l subs.uniq -cname -resp -silent -o cnames.txt

# 2. Automated fingerprint scanners (run 2+, cross-check)
nuclei -l subs.uniq -t http/takeovers/ -severity high,critical
subzy run --targets subs.uniq --concurrency 50 --hide_fails
dnsReaper file --filename subs.uniq        # best signal, huge provider set
subjack -w subs.uniq -t 50 -ssl -c fingerprints.json

# 3. Manual validation (never report on scanner output alone)
dig +short sub.acme.com               # what does it point to?
curl -sI https://sub.acme.com/        # status + headers
curl -s  https://sub.acme.com/ | grep -iE 'not found|no such|does not exist|unclaimed'
```

**Also hunt beyond CNAME:**
- **Dangling A record** → IP released back to a cloud pool → claim the IP (EIP/reserved IP roulette).
- **NS takeover** → delegated nameserver domain expired/free → control the *entire* zone.
- **MX takeover** → dangling mail provider → receive password-reset emails.
- **Expired base domain** in a redirect/JS/CORS allowlist → register it.

---

## Confirmed-vulnerable fingerprints (claimable)

| Service | Unclaimed fingerprint | Notes |
|---|---|---|
| AWS S3 | `The specified bucket does not exist` | claim bucket name (→ cloud-storage.md §9) |
| AWS Elastic Beanstalk | `NXDOMAIN` / region CNAME free | claim EB env name in region |
| Agile CRM | `Sorry, this page is no longer available.` | |
| Anima | `The page you were looking for does not exist.` | |
| Bitbucket | `Repository not found` | |
| Campaign Monitor | `Trying to access your account?` | |
| Canny | `Company Not Found` | |
| Cargo Collective | `404 Not Found` | |
| Discourse | `NXDOMAIN` | |
| Gemfury | `404: This page could not be found.` | |
| GetResponse | `With GetResponse Landing Pages…` | |
| Ghost | `Site unavailable` / `Failed to resolve DNS path` | |
| HatenaBlog | `404 Blog is not found` | |
| Help Juice | `We could not find what you're looking for.` | |
| Help Scout | `No settings were found for this company:` | |
| JetBrains YouTrack | `is not a registered InCloud YouTrack` | |
| LaunchRock | `HTTP 500` | |
| Ngrok | `Tunnel .*.ngrok.io not found` | |
| Pantheon | `404 error unknown site!` | |
| Pingdom | `Sorry, couldn't find the status page` | |
| Readme.io | `The creators of this project are still working…` | |
| ReadTheDocs | `The link you have followed or the URL that you entered does not exist.` | |
| Short.io | `Link does not exist` | |
| SmartJobBoard | `This job board website is either expired or invalid.` | |
| Strikingly | `PAGE NOT FOUND.` | |
| Surge.sh | `project not found` | |
| SurveySparrow | `Account not found.` | |
| Uberflip | `The URL you've accessed does not provide a hub.` | |
| UptimeRobot | `page not found` | |
| WordPress.com | `Do you want to register .*.wordpress.com?` | |
| Worksites | `Hello! Sorry, but the website you're looking for doesn't exist.` | |

## Edge cases (vulnerable under specific conditions — verify manually)

| Service | Fingerprint | Condition |
|---|---|---|
| GitHub Pages | `There isn't a GitHub Pages site here.` | name not claimed in any org; verify custom-domain rules |
| Heroku | `No such app` | app name free; wildcard/region nuances |
| Netlify | `Not Found - Request ID:` | site name free |
| Vercel | `DEPLOYMENT_NOT_FOUND.` | project claim + domain add |
| Shopify | `Sorry, this shop is currently unavailable.` | store domain re-add (support-gated sometimes) |
| Webflow | `The page you are looking for doesn't exist…` | domain add to a site |
| Wix | `Looks Like This Domain Isn't Connected…` | |
| Tumblr | `Whatever you were looking for doesn't currently exist` | |
| Intercom | `Uh oh. That page doesn't exist.` | custom domain re-add |
| Tilda | `Please renew your subscription` | |
| Frontify / Landingi / Mashery / Smartling / Fastly | provider-specific | Fastly/Zendesk/Desk = support-gated |
| **Microsoft Azure** | `NXDOMAIN` | App Service / Traffic Manager / CloudApp / Blob — **claim same resource name in another subscription** (very common in 2025) |

> Fastly, Zendesk, Desk, Tumblr custom domains and some others are **support-gated** (need a ticket to reclaim). Note the condition; a scanner "match" ≠ takeover.

---

## Escalation — why it's a P1, not a defacement

| Chain | Impact |
|---|---|
| Sub shares cookies with parent (`Domain=.acme.com`) | inject/steal session cookies → **ATO** |
| Sub in OAuth `redirect_uri` allowlist / wildcard | host redirect receiver → **steal OAuth codes → ATO** |
| Sub in CORS `Access-Control-Allow-Origin` allowlist | read authenticated cross-origin responses → ATO |
| Sub is SSO/IdP or SAML ACS origin | forge assertions / phish creds → tenant-wide |
| Sub hosts JS `<script src>` used by main app | attacker JS on main app → mass ATO |
| Sub is a CSP `script-src`/`connect-src` allow entry | bypass CSP on the main app |
| Email (MX/NS) takeover | receive password-reset mail → ATO of arbitrary users |

**Report lead:** `[Takeover] Dangling <provider> on <sub>.<tld> → I control content; it is in the OAuth redirect allowlist → account takeover. Marker page: https://<sub>.<tld>/bbp-poc.html`

---

## PoC etiquette
1. Claim the resource in **your** account.
2. Serve a single page: `bbp-poc-<timestamp> — authorized takeover PoC, contact <you>`.
3. Screenshot it live on the target subdomain + show DNS resolution.
4. Release the resource after triage confirms. Never point it at real phishing.
