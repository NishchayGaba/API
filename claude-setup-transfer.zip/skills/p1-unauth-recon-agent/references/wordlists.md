# Wordlists — Curated for Unauth P1 Recon

> Small, high-signal lists beat huge dumps for manual unauth hunting. Use these inline; augment with SecLists for depth. Every path here is chosen because it has *actually* returned a P1.

**Install SecLists once:** `git clone https://github.com/danielmiessler/SecLists /usr/share/seclists`

---

## Sensitive files / config exposure (curl-per-host)
```
.git/HEAD
.git/config
.gitignore
.svn/entries
.hg/store/data
.env
.env.local
.env.production
.env.bak
config/.env
.DS_Store
web.config
elmah.axd
elmah
appsettings.json
application.properties
config.php.bak
config.php.swp
wp-config.php.bak
settings.py
docker-compose.yml
Dockerfile
.npmrc
.dockercfg
.aws/credentials
id_rsa
id_rsa.pub
.ssh/authorized_keys
backup.sql
dump.sql
database.sql
backup.zip
backup.tar.gz
db.sqlite3
credentials.json
service-account.json
google-services.json
firebase.json
phpinfo.php
info.php
composer.lock
package-lock.json
yarn.lock
```

## Actuator / debug / metrics
```
actuator
actuator/env
actuator/heapdump
actuator/health
actuator/mappings
actuator/configprops
actuator/beans
actuator/threaddump
actuator/jolokia
actuator/gateway/routes
actuator/prometheus
metrics
-/metrics
debug
debug/pprof
debug/vars
trace
_profiler
telescope/requests
```

## API docs / introspection (BOLA/PII seeds)
```
swagger-ui.html
swagger/index.html
api/swagger.json
v2/api-docs
v3/api-docs
openapi.json
api-docs
graphql
api/graphql
v1/graphql
graphiql
__graphql
altair
playground
redoc
```

## Admin / mgmt panels
```
admin
administrator
admin/login
manager/html
jmx-console
console
solr/
_cat/indices
wp-admin/
user/login
login.action
login.jsp
setup
install
install.php
setup.php
configure
phpmyadmin
adminer.php
pgadmin
rabbitmq
grafana
kibana
jenkins
airflow
argocd
```

## Well-known / disclosure
```
.well-known/security.txt
.well-known/openid-configuration
.well-known/oauth-authorization-server
.well-known/assetlinks.json
.well-known/apple-app-site-association
robots.txt
sitemap.xml
crossdomain.xml
clientaccesspolicy.xml
humans.txt
```

## Subdomain prefixes (permute with the TLD)
```
dev staging stage test qa uat sandbox demo preview
api api-dev api-stage internal intranet admin panel dashboard
git gitlab jenkins ci cd argo argocd grafana kibana prometheus
vpn remote gateway sso auth login oauth idp saml
mail smtp webmail mx autodiscover
s3 assets cdn static media uploads files download backup backups
db database redis mongo elastic es solr kafka
app apps m mobile beta old legacy v1 v2 new
status health metrics monitor logs
graphql ws socket rtc stream
```

## Interesting params (SSRF / LFI / redirect / IDOR)
```
url uri image img fetch proxy callback webhook redirect redirect_uri
next return return_to returnUrl dest destination continue link target
file path filename download attachment template theme view page include
module load doc document report export id user_id account uid pid oid
q search query filter sort order lang locale
```

## File extensions to grep from wayback/gau
```
.json .xml .env .bak .swp .old .orig .sql .db .sqlite
.zip .tar .tar.gz .tgz .7z .rar .gz
.log .conf .config .yaml .yml .ini .properties
.pem .key .p12 .pfx .crt .cer .ppk
.map .js.map
```

## Cloud bucket name suffixes (permute with org/base)
```
"" -prod -production -stage -staging -dev -test -qa
-backup -backups -assets -media -static -uploads -files -data
-db -dump -logs -public -private -internal -cdn -images
-user-data -exports -reports -documents -invoices -pii -kyc
-bucket -storage -s3 -web -app
```

Prefer references over guessing (grep JS/wayback first). Fuzz with `-ac` (auto-calibrate) and match `200,401,403` — a 403 on `/actuator/env` still tells you the endpoint exists.
