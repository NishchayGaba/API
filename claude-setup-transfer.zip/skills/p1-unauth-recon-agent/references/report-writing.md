# P1 Report Writing + Disclosure

> A finding is worth what you can *prove*. Lead with impact, make repro copy-pasteable, quantify the data, be honest on CVSS. Triagers fast-track unauth P1s that are one-click reproducible.

**Golden rule:** never write "could potentially." Prove it or downgrade it. One provable record beats ten theoretical paragraphs.

---

## Template

```markdown
## Title
[Pre-auth] <Bug class> on <host> → <concrete impact>
e.g. "[Pre-auth] World-readable Firebase RTDB on acme-prod → 2.3M user records (email, phone, hashed pw)"

## Summary
One paragraph, no jargon, impact first. WHO is affected, WHAT is exposed, WHY it's critical,
that it needs NO authentication.

## Steps to Reproduce
1. Copy-pasteable curl / HTTP with exact URL, headers, body.
2. Deterministic — a triager runs it and sees the same thing.
3. No "open Burp and…" — give the raw request. Screenshots SUPPORT, don't REPLACE, the curl.

$ curl -s 'https://acme-prod.firebaseio.com/users.json?shallow=true' | head
{ "u_1001": true, "u_1002": true, ... }

## Proof of Concept
Minimal, non-destructive, marker-based. ONE record/file/key (redacted). A count for scale.
Show the marker file for write/takeover PoCs.

## Impact
Concrete: "N records exposed incl. <PII types>", "any of ~M users", "full AWS account via IAM privesc",
"RCE as <user> on <host>". Name the chain if there is one.

## CVSS 3.1
Vector + score. Be honest (see below).

## Suggested Fix
Vendor patch ref / config change / IAM tighten / DNS cleanup. Specific and actionable.

## Disclosure Timeline
Found <date> · Reported <date> · (embargo per program policy)
```

---

## CVSS 3.1 quick-reference (true unauth ceilings)

| Finding | Vector | Score |
|---|---|---|
| Pre-auth RCE | `AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H` | 9.8 |
| Pre-auth RCE (scope change: host→cluster) | `…/S:C/C:H/I:H/A:H` | 10.0 |
| Unauth mass-PII (read) | `AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N` | 7.5 (argue higher w/ volume+sensitivity) |
| Unauth SSRF → cloud creds | `AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:L/A:N` | 9.3 |
| SQLi dump (unauth) | `…/C:H/I:H/A:N` | 9.1–9.8 |
| Subdomain takeover → ATO | `AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:H/A:N` | 9.0 |
| Public bucket write → stored XSS all users | `…/UI:R/S:C/C:H/I:H/A:N` | 9.0+ |
| CORS w/ creds → data theft | `…/UI:R/C:H/I:N/A:N` | 7.5–8.0 |

Use the volume/sensitivity of exposed data to justify `C:H` on PII findings; a triager who sees 2M records will accept it.

---

## Do / Don't

**Do:** impact-first title · raw repro request · quantify · redact PII in the report · name the chain · one clean PoC.
**Don't:** "could potentially" · Burp-screenshot-only repro · dump/attach real customer data · overclaim severity · report a bare login page or a naked info-leak that's a known duplicate.

## Dedup awareness (see triage-validation)
Anonymous metrics, GraphQL introspection, `alg:none` on a non-security JWT, existence oracles, CORS `*`, missing security headers, self-XSS — **high-duplication or low-signal**. Submit only when chained to concrete impact (internal access / cross-tenant PII / SSRF / RCE). Lead with the chain, not the disclosure.

## Disclosure norms
- Use the program's channel; respect embargo and safe-harbor scope.
- Never share found credentials — even with the program. Prove validity, let them rotate.
- No exfil beyond proof; no prod disruption; delete PoC artifacts (marker files, claimed resources) after triage confirms.
