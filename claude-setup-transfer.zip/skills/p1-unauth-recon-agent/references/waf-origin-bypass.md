# WAF / Origin-IP Bypass — Hit the Real Server

> The CDN/WAF (Cloudflare, Akamai, Imperva, AWS WAF, Fastly) is a filter, not the app. Find the **origin IP**, connect directly with the right Host header → WAF rules never run, rate-limits vanish, and IP-allowlisted admin/staging endpoints come alive.

---

## 1. Find the origin IP

```bash
T=acme.com

# (a) Cert transparency — origin often in an old/leaf cert SAN
curl -s "https://crt.sh/?q=%25.$T&output=json" | jq -r '.[].name_value' | sort -u

# (b) DNS history — the A record before they moved behind CDN
#   SecurityTrails, ViewDNS.info/iphistory, DNSdumpster, Netlas, IPinfo
curl -s "https://api.securitytrails.com/v1/history/$T/dns/a" -H "APIKEY: $ST_KEY"

# (c) Favicon hash → Shodan/Censys (origin usually shares the favicon)
python3 - <<'PY'
import mmh3,codecs,requests
r=requests.get("https://acme.com/favicon.ico").content
print(mmh3.hash(codecs.encode(r,"base64")))
PY
#   shodan search "http.favicon.hash:<hash>"   → IPs NOT in CDN ranges = origin candidates
#   censys: services.http.response.favicons.md5_hash:<md5>

# (d) Full-internet scan datasets by TLS cert / body hash
#   shodan  ssl.cert.subject.CN:"*.acme.com"  -"cloudflare"
#   censys  services.tls.certificates.leaf_data.subject.common_name:acme.com
#   FOFA/ZoomEye/Netlas: cert=, body=, title= pivots

# (e) SPF / MX / email headers — send yourself a bounce, read Received: from <real IP>
dig +short TXT $T | grep spf ; dig +short MX $T

# (f) Subdomains not proxied — dev/staging/mail/direct often point straight at origin
#   check each sub's IP; ones outside CDN CIDR = origin/adjacent
```

**Purpose-built tools:** `cloudfail`, `cloudflair` (Censys-backed), `CloakQuest3r`, `bypass-firewalls-by-DNS-history`, `hakoriginfinder`.

---

## 2. Confirm the IP serves the app

```bash
# Force Host header at the candidate IP; if you get the app (not a default page), it's origin
curl -sk -H "Host: $T" https://<origin-ip>/ -o /dev/null -w '%{http_code}\n'
curl -sk -H "Host: $T" https://<origin-ip>/ | grep -i '<title>'

# Pin in /etc/hosts or --resolve for a full browsing session
curl -sk --resolve $T:443:<origin-ip> https://$T/admin
```
Match a unique app string (title, CSRF token name, a known path) to confirm it's the real origin, not a shared-host default.

---

## 3. WAF rule bypass (when you can't reach origin)

If stuck behind the WAF, bypass the *rules* rather than the box:

| Technique | Example |
|---|---|
| Case / encoding | `SeLeCt`, `%53elect`, double-URL-encode, unicode/overlong UTF-8 |
| Comment/whitespace | `sel/**/ect`, tab/newline/`%0b` in SQL/XSS |
| HTTP param pollution | `?id=1&id=2` — WAF sees one, app another |
| Verb/method | `GET`→`POST`/`PUT`, add body, chunked `Transfer-Encoding` |
| Content-Type swap | `application/json` vs form vs multipart; WAF only parses one |
| Header smuggling | `X-Original-URL`, `X-Rewrite-URL`, `X-Forwarded-For`, `X-Forwarded-Host` |
| Oversized/junk prefix | pad body >WAF inspection limit (many stop at N KB) |
| Protocol | HTTP/2 or HTTP/0.9 downgrade; request smuggling (CL.TE/TE.CL/H2.CL) |
| Path normalization | `//admin`, `/./admin`, `/admin;/`, `%2e%2e`, trailing dot |
| Real-browser stealth | AWS WAF/captcha → drive Playwright/real-Chrome to pass JS challenge |

WAF fingerprint first: `wafw00f https://$T`.

---

## 4. Escalation — what origin access unlocks
- **Rate-limit removal** → password spray, OTP brute, enumeration the WAF was throttling.
- **IP-allowlisted endpoints** → `/admin`, `/actuator`, `/internal/*`, staging — often assume "only internal can reach me."
- **WAF-blocked payloads now land** → the SQLi/RCE/SSRF that returned 403 at the edge succeeds at origin.
- **Direct exploit of origin software** → CVEs the WAF virtual-patched.

**Report lead:** `Origin IP <ip> reachable directly (Host: $T), bypassing <WAF>. WAF-blocked <bug> now exploitable / IP-allowlisted /admin exposed.` Include how you found the IP so the fix (firewall origin to CDN CIDRs) is clear.
