# Auth / OAuth / OIDC / SAML / JWT / Reset — ATO (deep)

Account takeover is the top-value non-RCE class. Paid patterns (H1): Coinbase *OAuth consent clickjacking*
**$5k**; GitLab *unauthenticated blind SSRF in OAuth Jira controller* **$4k**; GitLab *email-verification
bypass for OAuth grants → ATO on 3rd parties* **$3k**; pixiv *steal OAuth code via `redirect_uri`* **$2k**;
LY/page.line.me *open redirect → OAuth code exposure* **$1k**; Rockstar *smuggle Facebook OAuth code via
Referer leakage* **$750**; Twitter/xAI *steal OAuth tokens*.

## OAuth 2.0 / OIDC
- **Metadata discovery — step 1, always.** `GET /.well-known/oauth-authorization-server` (RFC 8414) and
  `/.well-known/openid-configuration` (OIDC) return the full server config in one shot on any target
  running its own OAuth/OIDC server: every endpoint (authorize/token/registration/revocation/userinfo/
  jwks), every supported grant type, `token_endpoint_auth_methods_supported`, PKCE methods. Free attack-
  surface map before anything else.
- **Open/unauthenticated dynamic client registration (RFC 7591).** If `registration_endpoint` (found
  above) accepts `POST {redirect_uris:[...]}` with no auth, anyone can register a new OAuth client with an
  attacker-controlled `redirect_uri` and no domain-ownership check — the foothold for first-party
  consent-phishing: register your client → craft an `/authorize` link with your client_id pointing at the
  *target's own legitimate domain* → victim (already logged in) sees a normal consent screen on the real
  domain and approves → code lands at your redirect_uri. More convincing than typical OAuth phishing
  because the victim never leaves the legitimate domain until after approving.
- **PKCE does not stop a malicious/attacker-registered client.** Common misconception: PKCE binds a code to
  whoever generated the `code_verifier` for *that flow* — it stops a third party intercepting someone
  else's code, but does nothing if the attacker runs their own fully-valid PKCE flow end-to-end with their
  own registered client. "This uses PKCE" is not a reason to stop testing for open client registration.
  Also check **how** `code_verifier` is generated on mobile clients specifically — a real disclosed Android
  case used a weak PRNG (not `SecureRandom`) to generate it, making it guessable/brute-forceable by another
  app co-located on the same device. PKCE is only as strong as the randomness behind it.
- **`redirect_uri` theft (the #1 payer):** try suffix/prefix/substring matches, added path, subdomain,
  `@`-userinfo, path-traversal, **open-redirect chains** on an allowed host, **IDN homograph / punycode
  lookalike domains** (bypasses a naive string/visual allowlist check — confirmed across multiple
  disclosed reports), and **regex-validation bugs** in the allowlist itself (unanchored pattern, unescaped
  `.`, greedy match — "domain.com" regex matching "evildomain.com" or "domain.com.evil.com"):
  ```
  redirect_uri=https://evil.com                 redirect_uri=https://target.com.evil.com
  redirect_uri=https://evil.com?x=target.com    redirect_uri=https://target.com@evil.com
  redirect_uri=https://target.com/cb/../../evil  redirect_uri=https://sub.target.com/openredirect?to=evil.com
  redirect_uri=https://tárget.com (punycode/homograph)   redirect_uri with %09/%00/%0a control chars
  ```
  Landing the `code`/`token` on your host = ATO.
- **Code/token leak via Referer** (Rockstar $750, confirmed across 7+ separate disclosed reports on one
  program alone): if the auth code/token lands in the URL of a page reachable while it's still valid, it
  leaks via the `Referer` header on any outbound request from that page. The leak source doesn't have to
  be in the OAuth flow itself — **any page on the domain with an attacker-controllable image/resource URL
  parameter** (a "careers" page, a screenshot viewer, anything accepting `?img=`) is a candidate: inject an
  attacker-controlled image URL, and if that page is reached with the code/token still live in the
  browser's session/URL, the image request's Referer carries it to you.
- **`state` missing/reused → login CSRF / forced account-linking:** no `state` lets you stitch the victim's
  session to your social account (or vice-versa) → ATO. Also test whether `state` (and other callback
  params, especially under `response_mode=form_post`) is **reflected unescaped into the callback HTML** —
  that's a distinct XSS injection point, not just a CSRF-nonce check.
- **Account pre-hijack:** pre-register the victim's email (unverified) → victim later "Sign in with
  Google/…" links into your account, or your pre-set password survives. Also *email-verification bypass*
  (GitLab $3k): if the IdP grant trusts an unverified email, claim any email.
- **Email-change confirmation sent to the wrong address, multiplied by shared-email SSO linking** (real
  disclosed case, 1900+ upvotes, one of the most-upvoted reports on all of HackerOne): change your email
  to the victim's — if the confirmation link is mistakenly delivered to your OLD (attacker-controlled)
  address instead of the new one, you just "confirmed" ownership of an email you don't own. **Always check
  which address actually receives the link, not just that a link is sent.** On any platform where accounts
  sharing a verified email get auto-linked/SSO'd together (common in multi-tenant SaaS — "we found another
  account with this email, want to link it?"), this single bug becomes full takeover of every account
  under that email, not just your own — the email-confirmation bug and the account-linking feature
  multiply each other's severity. Test both independently, then combine.
- **Client-side-only token consumption** — a one-time transfer/handoff token (cross-domain SSO handoff,
  email-confirm, invite-accept) is sometimes only marked "consumed" when specific client-side JS on the
  *legitimate* domain calls a consumption endpoint after reading it from the URL. If the token instead
  lands on an attacker-controlled domain (via a redirect-validation bug, open redirect, or a lookalike
  domain), that JS never runs — the token survives unconsumed in the backend and can be manually replayed
  on the real domain to complete the login/handoff as the victim. Real disclosed case combined this with a
  redirect-domain-validation bypass (`KA_DOMAIN_REGEX` unescaped `.` in `-uc.a.run.app` matching
  `-uc-a-run.app`) recovered by reading a leaked `.js.map` source map — a good reminder that sourcemap
  recovery ([js-mining.md](js-mining.md)) can hand you the exact validation logic to break, not just secrets.
- **`response_type`/`response_mode` switch** (`code`→`token`, query→fragment), **scope upgrade**, **PKCE
  downgrade** (drop `code_challenge`), **consent clickjacking** (Coinbase $5k — frameable authorize page;
  also test **double clickjacking** — a newer two-step drag/double-click variant that can bypass
  single-click framebusting assumptions, confirmed on at least one disclosed OAuth-authorize-page report).
- **Managed-identity-provider direct API testing.** If the app delegates auth to AWS Cognito/Firebase
  Auth/Auth0/similar, test the identity provider's **own API directly**, not just the app's wrapper around
  it — misconfigured user-pool/IAM permissions (e.g. admin-level user-management calls reachable without
  proper restriction) are a distinct ATO vector separate from bugs in the app's own code.

## SAML
- **XML Signature Wrapping (XSW):** inject a forged `Assertion`/`Response` alongside the signed one so the
  validator checks the signed copy but consumes the forged (change `NameID` to victim/admin).
- **Signature stripping** (accepts unsigned assertion), **comment injection** in `NameID`
  (`admin@target.com<!---->.evil.com` → some parsers read `admin@target.com`), **key confusion / self-signed
  cert accepted**. Tools: SAML Raider (Burp).
- **Inconsistent normalization of the SSO entityId/issuer between validation and assignment** (real
  disclosed case, $10,500): register an entityId identical to a legitimate org's except with a trailing
  space. Signature validation correctly trims and matches the legit org — but the *org-assignment* lookup
  that decides which organization to provision the newly-authenticated user into does **not** trim, so it
  prioritizes the attacker's padded entityId. Net effect: victims signing in with the real org's valid,
  correctly-signed SAML response get silently provisioned into the attacker's org instead (DoS on the real
  org, ATO via forced re-provisioning). General technique: whenever a security-relevant identifier
  (entityId, email, username) is checked in more than one place, test whether every check normalizes
  (trim/case-fold) it the same way — a mismatch between the *validation* check and the *lookup/assignment*
  logic on the same field is a real, repeatable bug class.

## Custom/proprietary SSO & deeplink tokens (non-OAuth/SAML)
Many apps roll their own "partner token" or "deeplink handoff" mechanism outside standard OAuth/OIDC/SAML
— standard JWT/SAML tooling won't flag bugs here, you have to test it by hand. Real disclosed pattern: a
client-side-encrypted payload (AES key/IV necessarily hardcoded in the JS bundle, since the browser has to
encrypt it — extract via [js-mining.md](js-mining.md)) carries an inner "proof of third-party origin"
token (SSO/partner/deeplink token). The bug: the backend only checks the decrypted payload is well-formed
(expected `source` field, token present/truthy) — it never round-trips the token to the real issuer to
verify it's genuine. A completely fake string in the token field still returns "validation success."
**Test any flow accepting a "proof you came from partner/SSO/deeplink X" token: does the backend actually
verify it against the issuer's API/public key, or just check presence/shape?** Secondary lesson: client-
side encryption of a request body is never a security boundary by itself — if the decrypt key ships to the
browser, the plaintext schema is fully forgeable; test what the backend *does* with each decrypted field,
not just "is it encrypted." Even when the outer session/bearer token is still required (so it's "only" an
authenticated bypass), this is a real BFLA primitive if the outer token is cheap to obtain and the inner
check gates a higher-trust action (role/control-transfer).

## JWT
```
alg:none            → header {"alg":"none"}, drop signature
RS256 → HS256       → sign with the server's PUBLIC key as the HMAC secret (alg confusion)
kid injection       → kid:"../../dev/null" (empty key), or SQLi/path in kid
jku / jwks injection→ point jku/x5u to attacker-hosted JWKS you control
weak secret         → brute with hashcat (-m 16500) / jwt_tool
claim tamper        → change sub/uid/email/role/isAdmin; re-sign if key known
```

## Password reset / verification
- **Host-header poisoning** (reset link built from `Host`/`X-Forwarded-Host` → attacker domain gets the
  token when victim clicks).
- **Token leak via Referer**, predictable/short token, **token not invalidated** after use/email-change,
  reuse, token/`email` in the response body, **email-parameter injection** (`email=victim@x.com&email=
  attacker@x.com`, or CC via `%0a`).
- **Response/OTP manipulation** (change `"verified":false`→`true`, brute OTP via GraphQL alias batching).

## Identifier reuse
Rename/delete account A → claim A's freed username/handle/email/slug → inherit A's orphaned resources.
Root cause: ownership keyed on a **mutable** identifier. Cross-ref [authz-idor.md](authz-idor.md).

## Passwordless / magic-link flows
- **Token not bound to the originating session/IP/UA** — a leaked or forwarded link works from anywhere,
  not just the device that requested it. Request a link, open it from a different session/IP — should fail.
- **Reusable / long-lived token** — the link should be single-use and short-lived; test replay after use
  and after the stated expiry.
- **Link-prefetch consumption** — corporate email "safe link" scanners (Outlook/Teams/Proofpoint) or the
  mail client itself GET the URL server-side before the victim ever clicks. If the token is burned by
  that prefetch, it's a usability bug; if the *scanner's* fetch is what authenticates, that's a takeover
  primitive (whoever controls the scanner's network position, or a forwarded email, gets in first).

## MFA / 2FA-specific vectors
- **Backup-code brute force** — recovery/backup codes are frequently shorter and less rate-limited than
  the primary OTP flow. Test the backup-code endpoint's rate limit independently.
- **Enrollment race** — if the "add authenticator/device" endpoint doesn't re-authenticate the session,
  register a second factor during the victim's own enrollment window (or right after a password-reset
  that doesn't kill other sessions) to add *your* device to *their* account.
- **"Remember this device" cookie forgeable/replayable** — check whether the trusted-device cookie is a
  predictable value, works across accounts, or isn't bound to the account it was issued for.
- **Legacy/deprecated endpoint skips the MFA step** — `/api/v1/login` or a mobile-specific login route
  that predates MFA rollout may still authenticate without ever calling the OTP-check step that
  `/api/v2/login` enforces. Diff every login-adjacent endpoint for MFA parity.
- **MFA-required flag trusted from the client** — the "needs 2FA" decision is made server-side once, but
  if the follow-up "verify OTP" call isn't itself gated on a server-held pending-auth state, replaying
  just the final "login success" step (or omitting the OTP field) may complete auth anyway.

## Session, token, and impersonation hygiene
- **Session fixation** — a pre-auth session id issued before login is *kept* (not rotated) after
  successful login. An attacker who plants a session id in the victim's browser (subdomain cookie write,
  XSS on a weaker subdomain, shared kiosk) inherits their authenticated session post-login.
- **Concurrent-session / no invalidation on password change** — after a password reset or email change,
  confirm whether *other* existing sessions/refresh tokens are actually killed, not just the current one.
- **Account-linking confusion** — signing up via OAuth with an **unverified** email that matches an
  existing password-based account can silently link/take it over (pairs with the pre-hijack note above);
  also test linking two different OAuth providers to one account without re-confirming ownership of both.
- **SCIM / provisioning API abuse** — enterprise-SSO orgs often expose a SCIM endpoint for automated user
  provisioning. Missing auth or a weak/static bearer token there is a direct multi-account ATO vector
  (create, modify, or reset credentials for any user in the org).
- **"Login as" / support-impersonation abuse** — verify the impersonation endpoint re-checks the
  **caller's** role server-side on every use, not just at the initial "start impersonating" click, and
  that it can't be reached with a client-supplied target-user id from a non-support session.
- **Refresh-token hygiene** — a refresh token that never expires or isn't rotated on use is a "steal once,
  valid forever" primitive. Check whether it's bound to the original client/device (`aud`/`device_id`) —
  unbound tokens harvested via a JS-mining secret hit (see [js-mining.md](js-mining.md)) work from anywhere.
  Also test **rotation reuse-detection specifically**: use RT1 to get AT2/RT2, then replay the
  already-superseded RT1 again. A correct implementation revokes the entire token family on detecting
  reuse; many implementations just silently issue new tokens instead, meaning a stolen-then-rotated
  refresh token stays useful indefinitely even though "rotation" is technically implemented.
- **Token-in-URL leakage** — a session/bearer token placed in the query string leaks via browser history,
  server access logs, the `Referer` header on any outbound link, and third-party analytics (GA/Segment)
  that log full URLs. Grep logs and outbound requests for token-shaped querystring values, not just bodies.
- **Cross-subdomain cookie scope abuse** — a cookie scoped to `.target.com` set by the *weakest* subdomain
  (old marketing site, abandoned blog) is readable/settable from every subdomain. Combine with a
  subdomain takeover ([params-takeover.md](params-takeover.md)) or XSS on that weak subdomain to forge a
  session cookie the main app trusts.
- **CSV/bulk-import impersonation** — a bulk user-import feature (CSV upload) that creates/updates
  accounts by email without verifying the uploader owns those emails lets a misconfigured-authz importer
  silently create or take over accounts at scale.
- **OTP predictability** — sequential, short (4-digit), or server-clock/user-id-derived OTPs; also check
  whether the OTP is echoed back in the API response or headers (a dev/debug leftover).
- **Verification-token reuse across steps** — diff the FULL response body of the registration/step-1 API
  call against whatever value the next out-of-band step (email link, SMS OTP, confirmation code) requires.
  A real disclosed case: the JWT returned by the registration endpoint was byte-identical to the token the
  `/verify-email?token=` endpoint required — the email was never actually needed, the client already had
  everything to "verify" itself. A match between what you already hold and what the next step demands
  means that side-channel is decorative, not a real check.
- **Response manipulation on auth/2FA/registration flows** — a distinct primitive from tampering the
  *request*: intercept the **server's response** on a login/2FA/registration step and flip a
  `success`/`valid`/`authorized`/`is_email_verified`-style boolean before the client processes it. Recurs
  across multiple disclosed reports (login bypass, 2FA bypass, free-tier-to-paid unlock, 0-click account
  creation) because some SPA/mobile clients make the actual authorization decision — redirect on success,
  unlock the next screen — based on trusting that response field, instead of the server maintaining its
  own session/state independent of what the client claims to have seen. Test this on every multi-step
  auth-adjacent flow, not just login.

## OAuth Device Authorization Flow Abuse

Enterprise/CLI targets use `grant_type=urn:ietf:params:oauth:grant-type:device_code`.
- **Device code not bound to client** — redeem a stolen `device_code` with a different `client_id`
- **Device code stolen via CSRF on the user-authorization page** — force victim to approve attacker's device
- **Polling without auth** — if `/token` device-code polling doesn't require client authentication, anyone with a `device_code` can poll
- **Social engineering** — generate a device code, trick victim into entering the `user_code` on a phishing page that proxies to the real device-authorization URL

Discovery: `device_authorization_endpoint` in `/.well-known/openid-configuration`
Full PoC commands: see `13-auth-failures-and-flows.md §13.4`

## WebAuthn / Passkey Implementation Flaws

Growing attack surface. Five classes:
1. **Challenge replay** — no challenge rotation or counter check → replay a captured WebAuthn assertion
2. **rpId not validated** — credential enrolled on `sub.target.com` used on `target.com`; or credential from `evil.com` accepted
3. **userHandle not bound to account** — credential issued for account A accepted when claiming to authenticate as account B
4. **Attestation not required** — any authenticator accepted, no device binding, cert trust not checked
5. **Counter not enforced** — sign counter should monotonically increase; a counter that can repeat → credential cloning undetected

Testing: intercept WebAuthn assertion POST, decode `clientDataJSON` (base64url), check `origin` and `challenge` fields, replay the same assertion body. Full PoC: see `13-auth-failures-and-flows.md §18`

## SCIM Provisioning API Abuse

Enterprise SaaS often exposes `/scim/v2/Users` with a static or missing bearer token.
- Missing auth → enumerate all org users, create admin accounts, reset passwords, change roles
- Weak token (`Bearer changeme`, `Bearer scim_token`) → same impact
- SCIM endpoint scoped to org but no cross-org validation → BOLA: modify users in other organizations

Discovery: try `/scim/v2/ServiceProviderConfig`, `/api/scim/v2`, `/identity/scim/v2`.
Full SCIM PoC curl commands: see `13-auth-failures-and-flows.md §17`

## Proof-of-impact bar
Demonstrate **full control of another account** (log in as them, read their data, act as them) or capture
a token that grants it. A theoretical redirect_uri accept with no code/token captured is downgraded. Any-user
ATO w/o interaction = Critical (9.8); with interaction = High.

## WordPress / CMS XMLRPC → SSO Bypass ($10k–$17k paid)

XMLRPC predates SSO. When OneLogin/Okta/SAML is "enforced", `/xmlrpc.php` still accepts native WordPress credentials → full session without SSO.
- Check if XMLRPC is live: `curl "https://$T/xmlrpc.php" -d "<methodCall><methodName>system.listMethods</methodName></methodCall>"`
- Auth via `wp.getUsersBlogs` or `system.multicall` with known/brute-forced WP creds → returns a valid session cookie
- If session cookie from XMLRPC works on SSO-protected routes → SSO is UI-level only → P1
- Also test: `/wp-json/jwt-auth/v1/token`, `/?rest_route=/wp/v2/users`, `/wp-cron.php`
- Full PoC: see `13-auth-failures-and-flows.md §24`

## Null / Empty / Loose-Comparison Auth Bypass

Auth logic fails when stored credential is null/empty. PHP: `null == ""` → true. MongoDB: `{"password": null}` matches missing-field documents.
- Try: empty password `""`, `null`, `false`, `0`, `[]`, `{}` in JSON body
- Try: MongoDB operators `{"password": {"$ne": null}}`, `{"$exists": false}`
- Try: JWT with empty `sub`/`uid` claim using `alg:none`
- Try: absent password param entirely in both JSON and form-urlencoded
- GraphQL: `login(email: "admin@target.com", password: null)`
- Full PoC: `13-auth-failures-and-flows.md §25`

## Auth State Machine / Out-of-Order Step Execution

Multi-step auth flows (login → OTP → access) with poorly enforced server-side state.
- **Snapchat pattern** (969 upvotes): `POST /otp/logout` (no auth) → `POST /otp/login {phone: victim}` → authenticated as victim
- Call the final-step endpoint (`/api/auth/verify-otp`, `/api/auth/complete`) without a valid partial-auth state
- Call step 2 with a DIFFERENT identity than step 1 (swap email at OTP verification)
- Test account recovery flow — recovery state often weaker than login state
- Helium pattern: add 2FA device, call `/api/2fa/verify` without completing the linking flow
- Full PoC: `13-auth-failures-and-flows.md §26`

## Pre-Signed / Time-Limited URL Authentication Bypass

Pre-signed URLs (file access, API, invites, temporary shares) that are not user-bound, reusable, or have predictable signatures.
- Remove session cookie and test the URL alone — should fail; if returns resource → not user-bound
- Replay after first use — should 410; if 200 → single-use not enforced
- Replace resource ID in URL (before signature) — if sig doesn't cover resource_id → IDOR on any resource
- Extend `expires` parameter manually; test with HMAC key candidates: `secret`, `app_secret`, `changeme`
- ownCloud $2k report: `13-auth-failures-and-flows.md §27`

## Unauthenticated SSO / SAML Provider Registration

Admin endpoint to add a new SAML/OAuth provider that lacks authentication → attacker registers malicious IdP.
- `POST /api/admin/saml/providers` or `POST /api/sso/providers` without `Authorization` header
- Rocket.Chat Meteor DDP: `{"msg":"method","method":"addSamlService","params":[{"entryPoint":"https://attacker.com/sso",...}]}`
- Also test: modifying an existing provider's `entryPoint` to attacker domain (BFLA)
- Also test: non-admin user registering a provider (vertical privesc)
- Full PoC: `13-auth-failures-and-flows.md §28`

## Legacy Auth Method Skips New Security Controls

Old login paths (v1, mobile, XMLRPC, basic auth, OpenID 2.0) exist alongside the primary path but weren't updated when 2FA, rate-limiting, or SSO was added.
- Enumerate all login-adjacent endpoints: `/api/v1/auth/login`, `/api/mobile/login`, `/api/android/login`, `/api/partner/login`, `/auth/token`, `/oauth/token`
- For each live endpoint: does it return `access_token` WITHOUT an OTP step? → 2FA skip
- Test rate limiting independently on each — legacy paths often unprotected
- Test basic auth: `curl -u "admin:password" "https://$T/api/user/me"` even when browser login requires SSO
- Apache Airflow CVE-2024-25128: legacy OpenID 2.0 `AUTH_OID` bypasses newer auth
- Full PoC: `13-auth-failures-and-flows.md §29`

---
**Full bash PoC commands for ALL classes above:** `~/.claude/skills/js-recon-agent/references/13-auth-failures-and-flows.md` §§13–29
